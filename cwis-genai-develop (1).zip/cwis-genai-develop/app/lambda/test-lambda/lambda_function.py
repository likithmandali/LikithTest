import json

def lambda_handler(event, context):
    """
    Simple test Lambda handler
    """
    print("Lambda function started")
    print(f"Event: {json.dumps(event)}")
    
    # Extract parameters from event
    name = event.get("name", "World")
    
    # Return response
    response = {
        "message": f"Hello, {name}!",
        "status_code": 200
    }
    
    print("Lambda function completed successfully")
    return response
