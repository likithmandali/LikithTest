import json
import requests_wrapper as requests
import os
import boto3
from datetime import datetime
import time
import logging
from s3_helper import S3ObjectWrapper

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Create formatter for consistent log format
formatter = logging.Formatter(
    '[%(levelname)s] %(asctime)s - %(funcName)s:%(lineno)d - %(message)s'
)


def ensure_claude_v4_arn(model_id: str) -> str:
    """
    Intercepts Claude Sonnet 4 model ID and ensures ARN is used instead.
    
    Args:
        model_id: The original model ID from the request

    Returns:
        The ARN if model is Claude Sonnet 4, otherwise returns original model_id
    """
    if model_id == "us.anthropic.claude-sonnet-4-20250514-v1:0":
        aws_region = os.environ.get('AWS_REGIONINFO', os.environ.get('AWS_REGION', 'us-east-1'))
        aws_account_id = os.environ.get('AWS_ACCOUNT_ID', '')
        
        # If account ID is not present, try to fetch it using STS
        if aws_account_id in (None, ""):
            try:
                # Get AWS credentials from environment
                aws_access_key = os.environ.get('AWS_ACCESS_KEY')
                aws_secret_key = os.environ.get('AWS_SECRET_KEY')
                
                # Create STS client with explicit credentials if available
                if aws_access_key and aws_secret_key:
                    sts = boto3.client(
                        "sts", 
                        region_name=aws_region,
                        aws_access_key_id=aws_access_key,
                        aws_secret_access_key=aws_secret_key
                    )
                else:
                    sts = boto3.client("sts", region_name=aws_region)
                
                caller_identity = sts.get_caller_identity()
                aws_account_id = caller_identity.get("Account")
                logger.info("Dynamically fetched AWS Account ID")
            except Exception as e:
                # Leave as empty string if discovery fails
                logger.warning(f"Could not fetch AWS Account ID: {str(e)}")
                aws_account_id = ""
        # Remove sensitive print statements for security
        created_arn=f"arn:aws:bedrock:{aws_region}:{aws_account_id}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
        # ARN created successfully
        return created_arn
    return model_id

# Ensure handler exists and set formatter
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)
else:
    for handler in logger.handlers:
        handler.setFormatter(formatter)


def generate_timestamp_string():
    try:
        logger.info("Generating timestamp string")
        local_datetime = datetime.now()
        local_iso_str = datetime.strftime(local_datetime, "%Y-%m-%dT%H-%M-%S.%f")[:-3]
        valid_iso_str = local_iso_str.replace(":", "-").replace(".", "-")
        logger.info(f"Generated timestamp: {valid_iso_str}")
        return valid_iso_str
    except Exception as e:
        from custom_error import GenericError

        logger.error(f"Error generating timestamp: {str(e)}")
        raise GenericError(
            status_code=500,
            error_message=f"Failed to generate timestamp: {str(e)}",
            error=e,
        )


class AWSEmbeddings:
    def __init__(self):
        """
        :param s3_object: A Boto3 Object resource. This is a high-level resource in Boto3
                          that wraps object actions in a class-like structure.
        """
        
        embed_model_name=os.environ.get("AWS_EMBEDDING_MODEL_NAME")
        logger.info(f"Initializing AWSEmbeddings with model: {embed_model_name}")
        self.boto3_session = boto3.session.Session(
            region_name=os.environ["AWS_REGIONINFO"]
        )
        # logger.info(f"Created boto3 session for region: {os.environ['AWS_REGIONINFO']}")

        self.bedrock_agent_client = self.boto3_session.client(
            "bedrock-agent",
            region_name=os.environ["AWS_REGIONINFO"],
            
        )
        self.bedrock_agent_runtime_client = boto3.client(
            "bedrock-agent-runtime",
            region_name=os.environ["AWS_REGIONINFO"],
        )
        logger.info("Initialized Bedrock clients")
        
        self.embeddingModelArn = f"arn:aws:bedrock:{os.environ['AWS_REGIONINFO']}::foundation-model/{embed_model_name}"
        self.roleArn = os.environ["AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN"]

        self.opensearchcollerctionArn = os.environ["AWS_OPENSEARCH_COLLECTION_ARN"]
        self.opensearchServerlessConfiguration = {
            "collectionArn": self.opensearchcollerctionArn,
            "vectorIndexName": os.environ[
                "AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME"
            ],
            "fieldMapping": {
                "vectorField": "embeddings",
                "textField": "raw-text-chunk",
                "metadataField": "knowledge-metadata",
            },
        }
        logger.info("AWSEmbeddings initialization completed")

    def create_knowledge_base_func(self, knowledge_base_name):
        try:
            logger.info(f"Creating knowledge base with name: {knowledge_base_name}")
            # Create a specific folder for this knowledge base's supplemental data
            supplemental_folder = f"supplemental-data/{knowledge_base_name}/"
            
            create_kb_response = self.bedrock_agent_client.create_knowledge_base(
                name=knowledge_base_name,
                description=knowledge_base_name,
                roleArn=self.roleArn,
                knowledgeBaseConfiguration={
                    "type": "VECTOR",
                    "vectorKnowledgeBaseConfiguration": {
                        "embeddingModelArn": self.embeddingModelArn,
                        "supplementalDataStorageConfiguration": {
                            "storageLocations": [
                                {
                                    "type": "S3",
                                    "s3Location": {
                                        "uri": f"s3://{os.environ['AWS_STORAGE_BUCKET_NAME']}/"
                                    }
                                }
                            ]
                        }
                    },
                },
                storageConfiguration={
                    "type": "OPENSEARCH_SERVERLESS",
                    "opensearchServerlessConfiguration": self.opensearchServerlessConfiguration,
                },
            )
            kb_id = create_kb_response["knowledgeBase"]["knowledgeBaseId"]
            # logger.info(f"Successfully created knowledge base with ID: {kb_id}")
            return create_kb_response["knowledgeBase"]
        except Exception as e:
            logger.error(f"Error creating knowledge base '{knowledge_base_name}': {str(e)}")
            from custom_error import ExternalAPIError

            raise ExternalAPIError(f"Failed to create knowledge base: {str(e)}")

    def create_data_source_to_knowledge_base(
        self, datasourcename, datsourcedescription, kb_id, chunk_config, s3_config, parsing_config
    ):
        try:
            logger.info("Creating data source for knowledge base")
            logger.debug("S3 config provided")
            logger.debug("Chunk config provided")
            logger.debug("Parsing config provided")
            
            vector_ingestion_config = {"chunkingConfiguration": chunk_config}
            if parsing_config:
                vector_ingestion_config["parsingConfiguration"] = parsing_config
                logger.info("Added parsing configuration to vector ingestion config")
                
            data_source_config = {
                "name": datasourcename,
                "description": datsourcedescription,
                "knowledgeBaseId": kb_id,
                "dataDeletionPolicy": "DELETE",
                "dataSourceConfiguration": {
                    "type": "S3",
                    "s3Configuration": s3_config,
                },
                "vectorIngestionConfiguration": vector_ingestion_config,
            }
            
            ds_response = self.bedrock_agent_client.create_data_source(**data_source_config)
            ds_id = ds_response["dataSource"]["dataSourceId"]
            logger.info("Successfully created data source")
            return ds_response
        except Exception as e:
            logger.error("Error creating data source for knowledge base")
            from custom_error import ExternalAPIError

            raise ExternalAPIError(f"Failed to create data source: {str(e)}")

    @staticmethod
    def get_parsing_configuration(parsing_strategy: str = "BEDROCK_DATA_AUTOMATION", model_name=None, custom_prompt=None):
        """
        Get parsing configuration based on strategy.
        For multimodal documents with tables, charts, and visual elements.
        For Using BEDROCK_FOUNDATION_MODEL, you need to pass a model name.
        """
        try:
            logger.info(f"Getting parsing configuration for strategy: {parsing_strategy}")
            match parsing_strategy:
                case "BEDROCK_DATA_AUTOMATION":
                    config = {
                        "parsingStrategy": "BEDROCK_DATA_AUTOMATION",
                        "bedrockDataAutomationConfiguration": {
                            "parsingModality": "MULTIMODAL"
                        }
                    }
                    logger.info("Using BEDROCK_DATA_AUTOMATION parsing strategy")
                    return config
                case "BEDROCK_FOUNDATION_MODEL":
                    # Alternative option with customizable prompts
                    # First, ensure Claude V4 gets the correct ARN
                    model_name = ensure_claude_v4_arn(model_name)
                    logger.info("Model name received with ARN format")
                    # Check if model_name is already a full ARN (inference profile or foundation model)
                    if model_name.startswith("arn:aws:bedrock:"):
                        model_arn = model_name
                        logger.info("Using provided full ARN")
                    else:
                        # Construct foundation model ARN from model name
                        model_arn = f"arn:aws:bedrock:{os.environ['AWS_REGIONINFO']}::foundation-model/{model_name}"
                        logger.info("Constructed foundation model ARN")
                    
                    model_config = {
                        "modelArn": model_arn,
                        "parsingModality": "MULTIMODAL"
                    }
                    logger.info("Using BEDROCK_FOUNDATION_MODEL parsing strategy")
                    logger.debug("Parsing prompt configured")
                    # Remove sensitive configuration logging
                    if custom_prompt:
                        model_config["parsingPrompt"] = {
                            "parsingPromptText": custom_prompt
                        }
                        logger.info("Added custom parsing prompt")
                        
                    return {
                        "parsingStrategy": "BEDROCK_FOUNDATION_MODEL",
                        "bedrockFoundationModelConfiguration": model_config
                    }
                case "DEFAULT":
                    # No parsing configuration needed for default parser
                    logger.info("Using DEFAULT parsing strategy (no config)")
                    return None
                case _:
                    logger.warning(f"Unknown parsing strategy {parsing_strategy}, using default")
                    return None
        except Exception as e:
            logger.error(f"Error in parsing configuration for strategy '{parsing_strategy}': {str(e)}")
            from custom_error import GenericError
            
            raise GenericError(
                status_code=500,
                error_message=f"Error in parsing configuration: {str(e)}",
                error=e,
            )



    def data_source_ingestion(self, data_source_id, kb_id, max_wait_time=800):
        try:
            time.sleep(2)
            logger.info("Starting data source ingestion")
            start_job_response = self.bedrock_agent_client.start_ingestion_job(
                knowledgeBaseId=kb_id, dataSourceId=data_source_id
            )
            job = start_job_response["ingestionJob"]
            logger.info("Started ingestion job")
            return {
                "status": job["status"],
                "ingestionJobId": job["ingestionJobId"],
            }
        except Exception as e:
            if "job" in locals() and job.get("status") == "FAILED":
                failure_reasons = job.get('failureReasons', ['Unknown error'])
                logger.error(f"Ingestion job failed with reasons: {failure_reasons}")
                from custom_error import ExternalAPIError

                raise ExternalAPIError(
                    f"Ingestion job failed: {failure_reasons}"
                )
            else:
                logger.error("Error during data source ingestion")
                from custom_error import ExternalAPIError

                raise ExternalAPIError(f"Failed during data source ingestion: {str(e)}")

    @staticmethod
    def aws_embedding_chunking(
        chunking_strategy: str,
        chunk_size: int = 2000,
        overlap_percentage: int = 15,
        child_max_token: int = 300,
        buffer_size: int = 1,
        breakpoint_percentile_threshold: int = 95,
    ):
        try:
            logger.info(f"Configuring chunking strategy: {chunking_strategy}")
            logger.debug(f"Chunking parameters - size: {chunk_size}, overlap: {overlap_percentage}%, "
                        f"child_max: {child_max_token}, buffer: {buffer_size}, threshold: {breakpoint_percentile_threshold}")
            
            match chunking_strategy:
                case "NONE":
                    chunkingStrategyConfiguration = {"chunkingStrategy": "NONE"}
                    logger.info("Using NONE chunking strategy")
                    return chunkingStrategyConfiguration
                case "FIXED_SIZE":
                    chunkingStrategyConfiguration = {
                        "chunkingStrategy": "FIXED_SIZE",
                        "fixedSizeChunkingConfiguration": {
                            "maxTokens": chunk_size,
                            "overlapPercentage": overlap_percentage,
                        },
                    }
                    logger.info(f"Using FIXED_SIZE chunking with {chunk_size} tokens and {overlap_percentage}% overlap")
                    return chunkingStrategyConfiguration
                case "HIERARCHICAL":
                    chunkingStrategyConfiguration = {
                        "chunkingStrategy": "HIERARCHICAL",
                        "hierarchicalChunkingConfiguration": {
                            "levelConfigurations": [
                                {"maxTokens": chunk_size},
                                {"maxTokens": child_max_token},
                            ],
                            "overlapTokens": overlap_percentage,
                        },
                    }
                    logger.info(f"Using HIERARCHICAL chunking with parent: {chunk_size} tokens, child: {child_max_token} tokens")
                    return chunkingStrategyConfiguration
                case "SEMANTIC":
                    chunkingStrategyConfiguration = {
                        "chunkingStrategy": "SEMANTIC",
                        "semanticChunkingConfiguration": {
                            "breakpointPercentileThreshold": breakpoint_percentile_threshold,
                            "bufferSize": buffer_size,
                            "maxTokens": chunk_size,
                        }
                    }
                    logger.info(f"Using SEMANTIC chunking with {chunk_size} max tokens, threshold: {breakpoint_percentile_threshold}%")
                    return chunkingStrategyConfiguration
                case _:
                    logger.error(f"Invalid chunking strategy: {chunking_strategy}")
                    from custom_error import BadRequestError

                    raise BadRequestError(
                        f"Invalid chunking strategy: {chunking_strategy}"
                    )
        except Exception as e:
            from custom_error import BadRequestError, GenericError

            if isinstance(e, BadRequestError):
                raise
            else:
                logger.error(f"Error in chunking configuration for strategy '{chunking_strategy}': {str(e)}")
                raise GenericError(
                    status_code=500,
                    error_message=f"Error in chunking configuration: {str(e)}",
                    error=e,
                )

    def create_and_upload_metadata_datasource(self, filename, kb_id):
        try:
            logger.info("Creating and uploading metadata for file")
            s3_uri = f"s3://{os.environ['AWS_STORAGE_BUCKET_NAME']}/{filename}"
            # Remove S3 URI from logs for security

            # Define the new data
            new_data = {
                "metadataAttributes": {
                    "x-amz-bedrock-kb-data-source-id": kb_id,
                    "x-amz-bedrock-kb-source-uri": s3_uri,
                }
            }

            full_metadatafilename = filename + ".metadata.json"
            logger.info("Metadata filename generated")

            file_contents_bytes = json.dumps(new_data).encode("utf-8")
            s3_obj = S3ObjectWrapper(
                os.environ["AWS_STORAGE_BUCKET_NAME"],
                dest_file_path=full_metadatafilename,
            )
            s3_obj.put(file_contents_bytes)
            logger.info(f"Successfully uploaded metadata file: {full_metadatafilename}")

            return full_metadatafilename
        except Exception as e:
            logger.error(f"Error creating and uploading metadata for file '{filename}': {str(e)}")
            from custom_error import ExternalAPIError

            raise ExternalAPIError(f"Failed to create and upload metadata: {str(e)}")


def lambda_handler(event, context):
    try:
        logger.info("=== Lambda function started ===")
        logger.info(f"Event: {json.dumps(event, default=str)}")
        logger.info(f"Context: {context}")
        
        suffix = generate_timestamp_string()
        logger.info(f"Generated suffix: {suffix}")

        data_generator = AWSEmbeddings()

        destination_file_name = event.get("destination_file_name")
        if not destination_file_name:
            logger.error("destination_file_name is missing from event payload")
            from custom_error import BadRequestError

            raise BadRequestError(
                "destination_file_name is required in the event payload"
            )
        logger.info(f"Processing file: {destination_file_name}")

        # Get parsing strategy from event or default to Data Automation
        parsing_strategy = event.get("parsing_strategy", "BEDROCK_DATA_AUTOMATION")
        if parsing_strategy=="BEDROCK_FOUNDATION_MODEL":
            model_name=os.environ.get("AWS_PARSING_FOUNDATION_MODEL", "us.anthropic.claude-3-5-sonnet-20240620-v1:0")
            parsing_config = AWSEmbeddings.get_parsing_configuration(parsing_strategy,model_name=model_name)
        else:
            parsing_config = AWSEmbeddings.get_parsing_configuration(parsing_strategy)
        logger.info(f"Using parsing strategy: {parsing_strategy}")
        logger.debug(f"Parsing config: {parsing_config}")

        knoweledge_base_creation = data_generator.create_knowledge_base_func(
            knowledge_base_name=f"API_CREATE_KNOWLEDGE_BASE_{suffix}"
        )

        logger.info("Knowledge base created successfully")

        s3Configuration = {
            "bucketArn": f"arn:aws:s3:::{os.environ['AWS_STORAGE_BUCKET_NAME']}",
            "inclusionPrefixes": [destination_file_name],
        }
        # Remove S3 configuration from logs for security

        knowlegebaseid = knoweledge_base_creation["knowledgeBaseId"]
        logger.info("Knowledge base ID retrieved")

        description = "Bedrock Knowledge Bases for the file"
        chunk_config = AWSEmbeddings.aws_embedding_chunking(
            chunking_strategy=event.get("chunking_strategy"),
            chunk_size=event.get("chunk_size"),
            overlap_percentage=event.get("overlapPercent", 15),
            child_max_token=event.get("childMaxTokens", 300),
            buffer_size=event.get("bufferSize", 1),
            breakpoint_percentile_threshold=event.get("breakpointChunking", 95),
        )

        logger.debug("Chunk config created")

        ##Create Data source
        logger.info("Creating primary data source")
        create_datasource = data_generator.create_data_source_to_knowledge_base(
            datasourcename=f"bedrock-sample-knowledge-base-pdf-{suffix}",
            datsourcedescription=description,
            kb_id=knowlegebaseid,
            chunk_config=chunk_config,
            s3_config=s3Configuration,
            parsing_config=parsing_config
        )

        logger.info("Primary data source created successfully")

        datasourceid = create_datasource["dataSource"]["dataSourceId"]
        logger.info("Primary data source ID retrieved")

        logger.info("Starting primary data source ingestion")
        data_source_ingestion_result = data_generator.data_source_ingestion(
            data_source_id=create_datasource["dataSource"]["dataSourceId"],
            kb_id=knowlegebaseid,
        )
        ingestion_job_id = data_source_ingestion_result["ingestionJobId"]
        logger.info("Primary data source ingestion started successfully")

        ##Metadata Ingestion
        logger.info("Creating metadata data source")
        metatdata_upload_name = data_generator.create_and_upload_metadata_datasource(
            filename=destination_file_name,
            kb_id=create_datasource["dataSource"]["dataSourceId"],
        )
        logger.info("Metadata upload name generated")
        
        s3Configurationmetadata = {
            "bucketArn": f"arn:aws:s3:::{os.environ['AWS_STORAGE_BUCKET_NAME']}",
            "inclusionPrefixes": [metatdata_upload_name],
        }
        # Remove S3 configuration from logs for security

        chunk_config_metadata = AWSEmbeddings.aws_embedding_chunking(
            chunking_strategy="NONE"
        )

        logger.debug("Metadata chunk config created")

        create_datasource_metadata = (
            data_generator.create_data_source_to_knowledge_base(
                datasourcename=f"bedrock-sample-knowledge-base-pdf-metadata-{suffix}",
                datsourcedescription=description,
                kb_id=knowlegebaseid,
                chunk_config=chunk_config_metadata,
                s3_config=s3Configurationmetadata,
                parsing_config=None
            )
        )

        logger.info("Metadata data source created successfully")

        logger.info("Starting metadata data source ingestion")
        
        response = {
            "filename": destination_file_name,
            "knowledge_base_id": knowlegebaseid,
            "datasource_id": datasourceid,
            "status_code": 200,
            "knowledge_ingestion_job_id": ingestion_job_id,
        }
        logger.info("=== Lambda function completed successfully ===")
        logger.info("Response prepared with all required information")
        return response

    except Exception as e:
        from custom_error import GenericError, BadRequestError, ExternalAPIError

        if isinstance(e, (GenericError, BadRequestError, ExternalAPIError)):
            # If it's already one of our custom errors, just pass it through
            logger.error(f"Custom error in lambda_handler: {str(e)}")
            raise
        else:
            # For any other unexpected exceptions, wrap in a generic error
            logger.error(f"Unexpected error in lambda_handler: {str(e)}", exc_info=True)
            raise GenericError(
                status_code=500,
                error_message=f"Unexpected error in knowledge base update: {str(e)}",
                error=e,
            )
