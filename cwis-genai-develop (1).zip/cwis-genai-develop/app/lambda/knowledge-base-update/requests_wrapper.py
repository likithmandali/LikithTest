import urllib3
import json
from urllib.parse import urlencode
from typing import Optional, Dict, Any, Union

class Response:
    """Mimics requests.Response object"""
    def __init__(self, urllib3_response):
        self._response = urllib3_response
        self.status_code = urllib3_response.status
        self.headers = urllib3_response.headers
        self._content = None
        self._text = None
        self._json = None
    
    @property
    def content(self) -> bytes:
        if self._content is None:
            self._content = self._response.data
        return self._content
    
    @property
    def text(self) -> str:
        if self._text is None:
            self._text = self.content.decode('utf-8')
        return self._text
    
    def json(self) -> Any:
        if self._json is None:
            self._json = json.loads(self.text)
        return self._json

class RequestsWrapper:
    def __init__(self):
        self.http = urllib3.PoolManager()
    
    def request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
        data: Optional[Union[Dict[str, Any], str, bytes]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None
    ) -> Response:
        try:
        # Process parameters
            if params:
                url = f"{url}?{urlencode(params)}"
            
            # Process headers
            request_headers = {}
            if headers:
                request_headers.update(headers)
            
            # Process body
            body = None
            if json is not None:
                body = json.dumps(json).encode('utf-8')
                request_headers['Content-Type'] = 'application/json'
            elif data is not None:
                if isinstance(data, dict):
                    body = urlencode(data).encode('utf-8')
                    request_headers['Content-Type'] = 'application/x-www-form-urlencoded'
                else:
                    body = data if isinstance(data, bytes) else str(data).encode('utf-8')
            
            # Make request
            urllib3_response = self.http.request(
                method=method.upper(),
                url=url,
                headers=request_headers,
                body=body,
                timeout=timeout
            )
            
            return Response(urllib3_response)
        except Exception as e:
            raise Exception(f"An error occurred: {str(e)}")
    
    def get(self, url: str, **kwargs) -> Response:
        return self.request('GET', url, **kwargs)
    
    def post(self, url: str, **kwargs) -> Response:
        return self.request('POST', url, **kwargs)
    
    def put(self, url: str, **kwargs) -> Response:
        return self.request('PUT', url, **kwargs)
    
    def delete(self, url: str, **kwargs) -> Response:
        return self.request('DELETE', url, **kwargs)
    
    def patch(self, url: str, **kwargs) -> Response:
        return self.request('PATCH', url, **kwargs)
    
    def head(self, url: str, **kwargs) -> Response:
        return self.request('HEAD', url, **kwargs)

# Create a global instance like requests library
session = RequestsWrapper()

# Convenience functions mimicking requests API
def request(method: str, url: str, **kwargs) -> Response:
    return session.request(method, url, **kwargs)

def get(url: str, **kwargs) -> Response:
    return session.get(url, **kwargs)

def post(url: str, **kwargs) -> Response:
    return session.post(url, **kwargs)

def put(url: str, **kwargs) -> Response:
    return session.put(url, **kwargs)

def delete(url: str, **kwargs) -> Response:
    return session.delete(url, **kwargs)

def patch(url: str, **kwargs) -> Response:
    return session.patch(url, **kwargs)

def head(url: str, **kwargs) -> Response:
    return session.head(url, **kwargs)
