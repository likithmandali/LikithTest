import json
import requests_wrapper as requests
import os
import random
import string
import boto3
from datetime import datetime
import time
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AWSEmbeddings:
    def __init__(self):
        """
        :param s3_object: A Boto3 Object resource. This is a high-level resource in Boto3
                          that wraps object actions in a class-like structure.
        """
        print("AWSEmbeddings __init__ starting...")
        logger.info("AWSEmbeddings __init__ starting...")
        
        try:
            embed_model_name = os.environ.get("AWS_EMBEDDING_MODEL_NAME")
            logger.info(f"Initializing AWSEmbeddings with model: {embed_model_name}")
            
            logger.info("Creating boto3 session...")
            region = os.environ.get("AWS_REGIONINFO")
            if not region:
                raise ValueError("AWS_REGIONINFO environment variable is not set")
            
            self.boto3_session = boto3.session.Session(region_name=region)
            logger.info(f"Created boto3 session for region: {region}")

            logger.info("Creating bedrock agent client...")
            self.bedrock_agent_client = self.boto3_session.client(
                "bedrock-agent",
                region_name=region,
            )
            
            logger.info("Initialized Bedrock clients")
            
            logger.info("Setting up OpenSearch configuration...")
            opensearch_arn = os.environ.get("AWS_OPENSEARCH_COLLECTION_ARN")
            if not opensearch_arn:
                raise ValueError("AWS_OPENSEARCH_COLLECTION_ARN environment variable is not set")
            
            self.opensearchcollerctionArn = opensearch_arn
            
            vector_index_name = os.environ.get("AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME")
            if not vector_index_name:
                raise ValueError("AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME environment variable is not set")
                
            self.opensearchServerlessConfiguration = {
                "collectionArn": self.opensearchcollerctionArn,
                "vectorIndexName": vector_index_name,
                "fieldMapping": {
                    "vectorField": "embeddings",
                    "textField": "raw-text-chunk",
                    "metadataField": "knowledge-metadata",
                },
            }
            logger.info("AWSEmbeddings initialization completed")
            
        except Exception as e:
            logger.error(f"Failed to initialize AWSEmbeddings: {str(e)}", exc_info=True)
            raise

    def data_source_ingestion(self, data_source_id, kb_id, max_wait_time=800):
        try:
            time.sleep(2)
            logger.info(f"Starting data source ingestion for datasource: {data_source_id}, KB: {kb_id}")
            start_job_response = self.bedrock_agent_client.start_ingestion_job(
                knowledgeBaseId=kb_id, dataSourceId=data_source_id
            )
            job = start_job_response["ingestionJob"]
            logger.info(f"Started ingestion job with ID: {job['ingestionJobId']}")
            return {
                "status": job["status"],
                "ingestionJobId": job["ingestionJobId"],
            }
        except Exception as e:
            if "job" in locals() and job.get("status") == "FAILED":
                failure_reasons = job.get('failureReasons', ['Unknown error'])
                logger.error(f"Ingestion job failed with reasons: {failure_reasons}")
                from custom_error import ExternalAPIError

                raise ExternalAPIError(
                    f"Ingestion job failed: {failure_reasons}"
                )
            else:
                logger.error(f"Error during data source ingestion for datasource {data_source_id}: {str(e)}")
                from custom_error import ExternalAPIError

                raise ExternalAPIError(f"Failed during data source ingestion: {str(e)}")

def lambda_handler(event, context):
    # Add immediate logging to verify function starts
    print("Lambda handler starting...")
    logger.info("Lambda handler starting - immediate log")
    
    try:
        logger.info("Lambda function started - update_existing_knowledge")
        logger.info(f"Received event: {json.dumps(event, default=str)}")
        
        logger.info("About to create AWSEmbeddings instance...")
        data_generator = AWSEmbeddings()
        logger.info("AWSEmbeddings instance created successfully")

        datasourceid = event.get("data_source_id")
        kb_id=event.get("knowledge_base_id")
        
        logger.info(f"Processing ingestion - datasource_id: {datasourceid}, knowledge_base_id: {kb_id}")
        
        if not datasourceid or not kb_id:
            logger.error(f"Missing required parameters - datasource_id: {datasourceid}, knowledge_base_id: {kb_id}")
            raise ValueError("Both data_source_id and knowledge_base_id are required")
        
        data_source_ingestion = data_generator.data_source_ingestion(
            data_source_id=datasourceid,
            kb_id=kb_id,
        )
        ingestion_job_id = data_source_ingestion.get("ingestionJobId")
        ingestion_job_status = data_source_ingestion.get("status")
        logger.info(f"Ingestion job created - Job ID: {ingestion_job_id}, Status: {ingestion_job_status}")

        response = {
                "knowledge_base_id": kb_id,
                "datasource_id": datasourceid,
                "ingestionJobId": ingestion_job_id,
                "status": ingestion_job_status,
                "status_code":200
            }
        
        logger.info(f"Lambda function completed successfully: {json.dumps(response, default=str)}")
        return response
    except Exception as e:
        # Handle exceptions and format them properly for the wrapper
        error_type = type(e).__name__
        error_message = str(e)
        status_code = 500
        
        # Extract status code from custom errors
        if hasattr(e, 'status_code'):
            status_code = e.status_code
        
        # Log the error for CloudWatch
        logger.error(f"Lambda function failed - Error Type: {error_type}, Message: {error_message}", exc_info=True)
        logger.error(f"Event that caused error: {json.dumps(event, default=str)}")
        
        # Return error details in a structured format
        error_response = {
            "error_type": error_type,
            "error_message": error_message,
            "status_code": status_code,
            "knowledge_base_id": None,
            "datasource_id": None
        }
        
        logger.info(f"Returning error response: {json.dumps(error_response, default=str)}")
        return error_response