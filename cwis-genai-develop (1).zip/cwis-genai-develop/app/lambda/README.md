# NC_path Enterprise AI Backend - Lambda Functions

This directory contains AWS Lambda functions for the NC_path Enterprise AI Backend, specifically for managing AWS Bedrock Knowledge Bases.

## 🚀 Quick Start

```bash
# Setup development environment
make setup-lambda-dev

# Build Lambda functions
make build-lambda

# Start Lambda functions locally
make up-lambda

# Test Lambda functions
make test-lambda

# Test individual Lambda functions
cd app/services/lambda
python3 run_local.py kb-update
python3 run_local.py update-existing
python3 run_local.py test
```

## 📋 Lambda Functions

### 1. Knowledge Base Update (`knowledge-base-update/`)

**Purpose**: Creates new AWS Bedrock Knowledge Bases and ingests documents

**Endpoint**: http://localhost:9010 (local development)

**Input Event**:

```json
{
  "destination_file_name": "document.pdf",
  "parsing_strategy": "BEDROCK_DATA_AUTOMATION",
  "chunking_strategy": "FIXED_SIZE",
  "chunk_size": 2000,
  "overlapPercent": 15,
  "childMaxTokens": 300,
  "bufferSize": 1,
  "breakpointChunking": 95
}
```

**Output**:

```json
{
  "filename": "document.pdf",
  "knowledge_base_id": "kb-12345",
  "datasource_id": "ds-67890",
  "status_code": 200,
  "knowledge_ingestion_job_id": "job-abcde"
}
```

### 2. Update Existing Knowledge (`update-existing-knowledge/`)

**Purpose**: Updates existing Knowledge Bases with new documents

**Endpoint**: http://localhost:9011 (local development)

**Input Event**:

```json
{
  "knowledge_base_id": "kb-12345",
  "data_source_id": "ds-67890",
  "operation": "sync"
}
```

**Output**:

```json
{
  "knowledge_base_id": "kb-12345",
  "datasource_id": "ds-67890",
  "operation": "sync",
  "status": "STARTING",
  "ingestionJobId": "job-12345",
  "status_code": 200
}
```

### 3. Test Lambda (`test-lambda/`)

**Purpose**: Simple test Lambda for verifying local Lambda execution

**Endpoint**: http://localhost:9012 (local development)

**Input Event**:

```json
{
  "name": "NC_path"
}
```

**Output**:

```json
{
  "message": "Hello, NC_path!",
  "status_code": 200
}
```

## 🛠️ Development

### Environment Setup

1. Create a `.env` file based on `.env.example`:

   ```bash
   cp .env.example .env
   ```

2. Update the `.env` file with your AWS credentials and settings:
   ```
   AWS_REGION=us-east-1
   AWS_STORAGE_BUCKET_NAME=your-bucket-name
   AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN=your-role-arn
   AWS_OPENSEARCH_COLLECTION_ARN=your-collection-arn
   ```

### Local Development

The Lambda functions are set up to run locally using Docker containers with the AWS Lambda Runtime Interface Emulator (RIE). This allows you to test the functions without deploying to AWS.

```bash
# Start all Lambda functions
make up-lambda

# Or using Docker Compose directly
cd app/services/lambda
docker-compose --profile all up -d
```

### Testing

```bash
# Run all tests
make test-lambda

# Test specific Lambda function
cd app/services/lambda
python3 run_local.py kb-update
```

### Deployment

```bash
# Package Lambda functions
make build-lambda

# Deploy to AWS
make deploy-lambda
```

## 📊 Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Lambda Functions Architecture                 │
├─────────────────────────────────────────────────────────────────┤
│  Input Layer                                                    │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │   S3 Events     │    │   API Gateway   │                    │
│  │   (Document     │    │   (Manual       │                    │
│  │    Upload)      │    │    Trigger)     │                    │
│  └─────────────────┘    └─────────────────┘                    │
├─────────────────────────────────────────────────────────────────┤
│  Processing Layer                                               │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │  Knowledge Base │    │  Update Existing│                    │
│  │     Update      │    │   Knowledge     │                    │
│  │   Lambda        │    │    Lambda       │                    │
│  └─────────────────┘    └─────────────────┘                    │
├─────────────────────────────────────────────────────────────────┤
│  AWS Services Integration                                       │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │   AWS Bedrock   │    │   OpenSearch    │                    │
│  │   Knowledge     │    │   Serverless    │                    │
│  │     Base        │    │   (Vector DB)   │                    │
│  └─────────────────┘    └─────────────────┘                    │
├─────────────────────────────────────────────────────────────────┤
│  Storage Layer                                                  │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │      S3         │    │   Metadata      │                    │
│  │   Documents     │    │     Files       │                    │
│  └─────────────────┘    └─────────────────┘                    │
└─────────────────────────────────────────────────────────────────┘
```

## 🔧 Configuration

### Environment Variables

#### Knowledge Base Update Lambda

```bash
AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN=arn:aws:iam::ACCOUNT:role/knowledge-base-role
AWS_EMBEDDING_MODEL_NAME=amazon.titan-embed-text-v2:0
AWS_OPENSEARCH_COLLECTION_ARN=arn:aws:aoss:REGION:ACCOUNT:collection/COLLECTION_ID
AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME=index
AWS_PARSING_FOUNDATION_MODEL=anthropic.claude-3-5-sonnet-20240620-v1:0
AWS_REGIONINFO=us-east-1
AWS_STORAGE_BUCKET_NAME=your-s3-bucket-name
```

#### Update Existing Knowledge Lambda

```bash
AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME=index
AWS_OPENSEARCH_COLLECTION_ARN=arn:aws:aoss:REGION:ACCOUNT:collection/COLLECTION_ID
AWS_REGIONINFO=us-east-1
AWS_STORAGE_BUCKET_NAME=your-s3-bucket-name
```

## 📚 Additional Resources

- [AWS Bedrock Knowledge Bases Documentation](https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base.html)
- [AWS Lambda Python Runtime](https://docs.aws.amazon.com/lambda/latest/dg/python-programming-model.html)
- [OpenSearch Serverless Documentation](https://docs.aws.amazon.com/opensearch-service/latest/developerguide/serverless.html)

## 🤝 Support

For support, contact the GenAIe Team at genaiesupport@deloitte.com
