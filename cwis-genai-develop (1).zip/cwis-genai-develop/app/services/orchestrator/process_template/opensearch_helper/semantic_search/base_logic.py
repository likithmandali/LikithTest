import re
from jinja2 import Environment, BaseLoader, select_autoescape


class TemplateSemanticSearch:
    @staticmethod
    def process_template(template_string: str, template_keys: dict) -> str:
        # Create a Jinja2 environment with a custom loader
        env = Environment(
            loader=BaseLoader(),
            autoescape=select_autoescape(
                enabled_extensions=("html", "htm", "xml"),
                default_for_string=True,
                default=True,
            ),
        )
        # Load the template
        template = env.from_string(template_string)
        # Render the template with the provided template_keys
        rendered_template = template.render(**template_keys)
        return rendered_template

    @staticmethod
    def get_template_tags_v2(template):
        # Find all matches using re.findall
        return re.findall(r"\{\{([^}]+)\}\}", template)

    @staticmethod
    def parse_knowledge_id(template_tag: str):
        return int(template_tag.split("_")[-1])
