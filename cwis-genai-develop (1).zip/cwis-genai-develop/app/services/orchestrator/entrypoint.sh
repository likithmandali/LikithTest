#!/bin/bash
set -e

# Create required directories if they don't exist
mkdir -p /app/shared_volume /app/logs

# Fix permissions for volumes (run as root first, then switch to appuser)
if [ "$(id -u)" = "0" ]; then
    # Running as root, fix permissions then switch to appuser
    chown -R appuser:appgroup /app/logs /app/shared_volume 2>/dev/null || true
    exec su-exec appuser "$@"
else
    # Already running as appuser
    exec "$@"
fi
