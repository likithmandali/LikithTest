import requests
import json
from settings.loguru import logger


class APIInterface:
    @staticmethod
    def post(route, data=None, headers=None):
        try:
            url = route
            logger.info("POST request sent")
            logger.debug(f"url = {url}, data = {data}")
            response = requests.post(url, data=data, headers=headers)
            if response.status_code >= 400:
                raise Exception(
                    f"Call to {route} failed with {response.status_code} and response {response.text}"
                )
            return json.loads(response.text), response.status_code
        except Exception as error:
            logger.error(f"Error in the POST API request : {error}")

    @staticmethod
    def get(route, params=None, headers=None):
        try:
            url = route
            logger.info("GET request sent")
            logger.debug(f"url = {url}, params = {params}")
            response = requests.get(url, params=params, headers=headers)
            if response.status_code >= 400:
                raise Exception(
                    f"Call to {route} failed with {response.status_code} and response {response.text}"
                )
            return json.loads(response.text), response.status_code
        except Exception as error:
            logger.error(f"Error in GET API request: {error}")

    @staticmethod
    def put(route, data=None, headers=None, params=None):
        try:
            url = route
            logger.info("PUT request sent")
            logger.debug(f"url = {url}, data = {data}")
            response = requests.put(url, data=data, headers=headers, params=params)
            if response.status_code >= 400:
                raise Exception(
                    f"Call to {route} failed with {response.status_code} and response {response.text}"
                )
            return json.loads(response.text), response.status_code
        except Exception as error:
            logger.error(f"Error in PUT API request: {error}")

    @staticmethod
    def delete(route, headers=None):
        try:
            url = route
            logger.info("DELETE request sent")
            logger.debug(f"url = {url}")
            response = requests.delete(url, headers=headers)
            if response.status_code >= 400:
                raise Exception(
                    f"Call to {route} failed with {response.status_code} and response {response.text}"
                )
            return response.status_code
        except Exception as error:
            logger.error(f"Error in DELETE API request: {error}")
