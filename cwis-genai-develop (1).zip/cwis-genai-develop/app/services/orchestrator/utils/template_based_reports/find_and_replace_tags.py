import re
from jinja2 import Environment, BaseLoader, select_autoescape
from settings.loguru import logger


def find_tags(text):
    # Use regex to find Python tags enclosed in double curly braces
    return re.findall(r"{{(.*?)}}", text)


def concatenate_nested(value):
    if isinstance(value, str):
        return value
    elif isinstance(value, (list, tuple)):
        return "\n".join(concatenate_nested(item) for item in value)
    elif isinstance(value, dict):
        parts = []
        for key, val in value.items():
            # Include keys and values in return value
            parts.extend([f"{key}", concatenate_nested(val)])
            if val is None:
                parts.pop()
        return "\n".join(parts)
    else:
        return ""


# Update master_tags by concatenating nested values
def format_master_tags(master_tags: dict):
    master_tags_formatted = {}
    for tag in master_tags:
        value = master_tags[tag]
        if isinstance(value, (str, int, float)):
            master_tags_formatted[tag.lower()] = str(value)
        else:
            # Handle nested list/dict
            master_tags_formatted[tag.lower()] = concatenate_nested(value)
    return master_tags_formatted


def render_jinja2_template(template_string, template_vars):
    # Create a Jinja2 environment with a custom loader
    env = Environment(
        loader=BaseLoader(),
        autoescape=select_autoescape(enabled_extensions=("html"), default_for_string=True, default=True),
    )

    # Load the template
    template = env.from_string(template_string)

    # Render the template with the provided variables
    rendered_template = template.render(**template_vars)
    return rendered_template


def match_with_master_tags(tag: str, master_tags: dict) -> str | None:
    for master_tag in master_tags:
        if tag.lower() in master_tag.lower():
            return master_tags[master_tag]
    return None


def replace_docx_tags(doc, master_tags):
    # format the master tags
    master_tags = format_master_tags(master_tags)
    logger.debug(f"formatted_master_tags={master_tags}")

    for paragraph in doc.paragraphs:
        text = paragraph.text
        tags = find_tags(text)

        for tag in tags:
            match_tag_result = match_with_master_tags(tag=tag, master_tags=master_tags)
            if match_tag_result:
                # Get the tag's value
                value = match_tag_result

                # Check if the value is a multi-line string
                if isinstance(value, str) and "\n" in value:
                    # Split the value into individual lines
                    lines = value.split("\n")

                    # Clear the original paragraph
                    for run in paragraph.runs:
                        run.clear()

                    # Add each line as a separate paragraph with the existing formatting
                    for line in lines:
                        p = paragraph.add_run()
                        p.text = "• " + line
                        p.add_break()
                elif isinstance(value, str):
                    # Split the value into individual lines

                    # Clear the original paragraph
                    for run in paragraph.runs:
                        run.clear()

                    # Add the line as a separate paragraph with the existing formatting
                    p = paragraph.add_run()
                    p.text = "• " + value
                    p.add_break()
                else:
                    # Handle nested list/dict using Jinja2 rendering
                    rendered_value = render_jinja2_template(value, master_tags)

                    # Preserve paragraph formatting (alignment, spacing, etc.)
                    new_paragraph = paragraph.insert_paragraph_before(rendered_value)
                    new_paragraph.alignment = paragraph.alignment
                    new_paragraph.space_before = paragraph.space_before
                    new_paragraph.space_after = paragraph.space_after
                    new_paragraph.line_spacing_rule = paragraph.line_spacing_rule

                    # Remove the original paragraph
                    doc.paragraphs.remove(paragraph)
                    break


def replace_pptx_tags(presentation, master_tags):
    # format the master tags
    master_tags = format_master_tags(master_tags)
    logger.debug(f"formatted_master_tags={master_tags}")

    for slide in presentation.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text_frame"):
                for paragraph in shape.text_frame.paragraphs:
                    tags = find_tags(paragraph.text)

                    for tag in tags:
                        match_tag_response = match_with_master_tags(tag=tag, master_tags=master_tags)
                        if match_tag_response:
                            # Get the tag's value
                            value = match_tag_response

                            # Check if the value is a multi-line string
                            if isinstance(value, str) and "\n" in value:
                                # Split the value into individual lines
                                lines = value.split("\n")

                                # Clear the original paragraph
                                paragraph.clear()

                                # Add each line as a separate paragraph with the existing bullet points
                                for line in lines:
                                    p = shape.text_frame.add_paragraph()
                                    p.text = line
                                    p.level = 1
                            elif isinstance(value, str):
                                # Clear the original paragraph
                                paragraph.clear()

                                # Add the line as a separate paragraph with the existing bullet points
                                p = shape.text_frame.add_paragraph()
                                p.text = value
                                p.level = 1
                            else:
                                # Handle nested list/dict using Jinja2 rendering
                                rendered_value = render_jinja2_template(value, master_tags)
                                paragraph.text = paragraph.text.replace(f"{{{{{tag}}}}}", rendered_value)
