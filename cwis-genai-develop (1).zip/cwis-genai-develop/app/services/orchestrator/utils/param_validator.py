from api.schemas.aws.submit import AWSBedrockModel
from settings.config import CONFIG


def ensure_claude_v4_arn(model_id: str) -> str:
    """
    Intercepts Claude Sonnet 4 model ID and ensures ARN is used instead.
    
    Args:
        model_id: The original model ID from the request

    Returns:
        The ARN if model is Claude Sonnet 4, otherwise returns original model_id
    """
    if model_id == AWSBedrockModel.AWS_CLAUDE_V4_SONNET.value:
        return f"arn:aws:bedrock:{CONFIG.AWS_REGION}:{CONFIG.AWS_ACCOUNT_ID}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
    return model_id
