import os
import boto3
from botocore.client import Config
from fastapi import APIRouter, Request, UploadFile, File, Depends
from fastapi.responses import JSONResponse
import psycopg2
from datetime import datetime

# from api.controllers import KnowledgeController
from api.schemas.common.knowledge import (
    CreateKnowledgeInput,
)
from helper.custom_errors import BadRequestError
from api.db.knowledge import KnowledgeDBController

from settings.db import get_db_connection
from settings.config import CONFIG
from settings.loguru import logger
from settings.security import User, get_current_user_normal
from typing import Annotated

router = APIRouter(prefix="/knowledge")


@router.get("/flow/{flow_id}")
async def get_knowledges_by_flow_id(
    flow_id: int,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Retrieve knowledge items associated with a specific flow.**

    Parameters:
    - **flow_id** (int): The Flow ID for which knowledge entries are requested.
    - **current_user** (Annotated[User, Depends]): The current user accessing the endpoint.
    - **db** (psycopg2.extensions.connection): Database connection object.

    Returns:
    - **list[dict]**: A list of knowledge items associated with the specified Flow ID.
    """  # noqa: E501

    # Create Knowledge and return id
    try:
        response = KnowledgeDBController.get_knowledges_by_flow_id(flow_id, db)
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@router.post("")
async def create_knowledge(
    create_knowledge_input: CreateKnowledgeInput,
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Create a new knowledge item.**

    Parameters:
    - **create_knowledge_input** (CreateKnowledgeInput): Contains name of the knowledge to be created.
    - **db** (psycopg2.extensions.connection): Database connection object.

    Returns:
    - **Knowledge**: The newly created knowledge item.
    """  # noqa: E501

    # Create Knowledge and return id
    try:
        response = KnowledgeDBController.create_knowledge(create_knowledge_input, db)
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err
