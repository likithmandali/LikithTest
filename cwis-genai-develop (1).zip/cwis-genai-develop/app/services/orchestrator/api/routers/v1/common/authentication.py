from fastapi import APIRouter, Depends, Request
import psycopg2
from starlette.responses import RedirectResponse
import os
from api.db.user import UserDBController
from settings.db import get_db_connection
from settings.security import create_access_token
from datetime import timedelta
from fastapi.responses import JSONResponse
from settings.security import router as security_router

ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days (mins x hrs x days)

router = APIRouter(prefix="/authentication")
router.include_router(security_router)


os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"
