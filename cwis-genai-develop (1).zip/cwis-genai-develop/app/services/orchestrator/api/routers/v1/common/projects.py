from typing import Annotated
import psycopg2
from fastapi import APIRouter, Depends, Security
from fastapi.responses import JSONResponse
from settings.loguru import logger
from api.db.projects import ProjectDBController
from settings.security import (
    User,
    get_current_user_normal,
    get_current_user_superadmin,
    get_current_user_staff,
)
from settings.db import get_db_connection
from api.schemas.common.activity import (
    CreateProject,
    AddAppsToProject,
    AddUserGroupOrProject,
    AddGroupsToProject,
)
from api.db.group import GroupsDBController
from api.db.app import AppDBController


auth_router = APIRouter(prefix="/projects")


@auth_router.get("/all")
async def get_projects_by_user_id(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve all projects associated with the authenticated user.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all projects associated with the user.
    """
    try:
        user_id = current_user[0].get("id")
        response = ProjectDBController.get_projects_by_user_id(user_id, db)
        return JSONResponse(
            content={
                "response": response,
            }
        )
    except Exception as err:
        raise err


@auth_router.post("/create/with-custom-apps")
async def create_new_project_with_custom_apps(
    new_project: CreateProject,
    current_user: Annotated[User, Depends(get_current_user_superadmin)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to create a new project and assign custom applications to it.**

    Args:
    - **projectname** (str) : The name of the new project.
    - **app_ids** (list[int]): List of application ids to be added to the new project.
    - **group_ids** (list[int]): List of group ids to be added to the new project.
    - **current_user** (Annotated[User, Depends(get_current_user_superadmin)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all projects associated with the user.
    """
    try:
        new_project_id = ProjectDBController.create_new_project(new_project, db=db)
        logger.debug(f"{new_project_id=}")
        assign_group_to_project = ProjectDBController.add_groups_to_project(new_project_id, new_project.group_ids, db)
        logger.debug(f"{assign_group_to_project=}")
        response = ProjectDBController.assign_apps_to_project(new_project_id, new_project.app_ids, db)

        response = [
            {
                "projectid": response[1],
                "projectname": new_project.projectname,
            }
        ]
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.post("/add-apps")
async def add_apps_to_project(
    project: AddAppsToProject,
    current_user: Annotated[User, Depends(get_current_user_superadmin)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to add apps to a project .**

    Args:
    - **project_id** (int) : The name of the new project.
    - **app_id_list** (list[int]): List of application ids to be added to the new project.
    - **current_user** (Annotated[User, Depends(get_current_user_superadmin)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all projects associated with the user.
    """
    try:
        status, response = ProjectDBController.assign_apps_to_project(project.project_id, project.app_id_list, db)
        if status:
            return JSONResponse(content={"response": f"Applications added to project having id {response}."})
    except Exception as err:
        raise err


@auth_router.get("/get/by-email")
async def get_projects_by_user_email_id(
    email_id: str,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve all projects associated with the entered user email.**

    Args:
    - **email_id** (User): The email id of the user.
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all projects associated with the user.
    """
    try:
        status, response = ProjectDBController.get_projects_by_user_email_id(email_id, db)
        if status:
            return JSONResponse(
                content={
                    "response": response,
                },
                status_code=200,
            )
        else:
            return JSONResponse(
                content="No projects found. Check if the user exists or has any projects assigned.",
                status_code=400,
            )
    except Exception as err:
        raise err


@auth_router.get("/all-projects")
async def get_all_projects(
    current_user: Annotated[
        User,
        Security(get_current_user_staff),
    ],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve all projects.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all projects associated with the user.
    """
    try:
        response = ProjectDBController.get_projects(db)
        return JSONResponse(
            content={
                "response": response,
            }
        )
    except Exception as err:
        raise err




@auth_router.post("/user/add")
async def add_user_to_project(
    user: AddUserGroupOrProject,
    current_user: Annotated[User, Depends(get_current_user_superadmin)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to add user to existing project.**

    Args:
    - **user_id** (int):  Id of the user.
    - **group_or_project_id_list** (list[int]): List of project ids to be added to  user.
    - **current_user** (Annotated[User, Depends(get_current_user_superadmin)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response after adding user to the projects.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the activity information
    """
    try:
        status, response = ProjectDBController.add_user_into_existing_project(
            user.user_id, user.group_or_project_id_list, db
        )
        if status:
            return JSONResponse(content={"response": f"User having id {response} added to projects successfully."})
    except Exception as err:
        raise err


@auth_router.post("/add/groups")
async def add_groups_to_project(
    groups: AddGroupsToProject,
    current_user: Annotated[User, Depends(get_current_user_superadmin)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to add groups to a project.**

    Args:
    - **project_id** (str) : The id of the project.
    - **group_id_list** (list[int]): List of groups ids to be added to the project.
    - **current_user** (Annotated[User, Depends(get_current_user_superadmin)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all projects associated with the user.
    """
    try:
        response = ProjectDBController.add_groups_to_project(groups.project_id, groups.group_id_list, db)
        return JSONResponse(content={"response": f"Groups added to project having id {response}."})
    except Exception as err:
        raise err


@auth_router.get("/users/groups/apps/in/project")
async def get_all_users_and_apps_in_projects(
    project_name: str,
    current_user: Annotated[User, Depends(get_current_user_superadmin)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to get all users ,apps and groups in each project.**

    Args:
    - **project_name** (str) : The name of the project.
    - **current_user** (Annotated[User, Depends(get_current_user_superadmin)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all projects associated with the user.
    """
    try:
        users_in_project = ProjectDBController.users_in_each_project(project_name=project_name, db=db)
        apps_in_project = AppDBController.get_all_apps_in_each_project(projectname=project_name, db=db)
        groups_in_project = ProjectDBController.groups_in_each_project(project_name=project_name, db=db)
        return JSONResponse(
            content={
                "user_in_project": users_in_project,
                "apps_in_project": apps_in_project,
                "groups_in_project": groups_in_project,
            }
        )
    except Exception as err:
        raise err
