from fastapi import APIRouter, Depends, HTTPException, Request
import psycopg2
import json
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import ValidationError
from helper.aws_bedrock_wrapper import AWSBedrockCaller
from api.schemas.aws.aws_bedrock import (
    PromptInput,
    PromptInputStream,
)
import time
from settings.loguru import logger
from helper.custom_errors import (
    BadRequestError,
    AttributeNotFoundError,
    ExternalAPIError,
)
from settings.security import User, get_current_user_normal
from typing import Annotated
from api.controllers.aws.submit import AWSSubmitController
from settings.config import CONFIG
from settings.db import get_db_connection
from helper.aws_embeddings import (
    AWSBedrockGuardrails,
    GuardrailsCreateUpdateRequest,
)
from api.db.instance import InstanceDBController
from api.db.guardrails import GuardrailsDBController
from api.schemas.common.guardrails import CreateGuardrailsInput

router = APIRouter(prefix="/aws/bedrock")


@router.post("/messages")
async def submit_prompt_message(
    prompt_input: PromptInput,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Submit a prompt message to generate a response with AWS Bedrock.**

    Args:
    - **prompt_input** (PromptInput): Input data for generating a response, containing:
        - **messages** (list[Message]): List of messages forming the prompt.
        Sample message structure:
        ```python
            [
                {"role": "system", "content": "You are an intelligent GK expert"},
                {"role": "user", "content": "Tell me about Taj Mahal in India"}
            ]
        ```
        - **model** (Model): Model to use for generating the response. Defaults to Model.CLAUDE_V2_100K.
        - **temperature** (float): Sampling temperature for response generation. Defaults to 0.5.
        - **aws_guardrail_id** (str | None): AWS Bedrock Guardrail ID. Defaults to None.
    - **current_user** (Annotated[User, Depends]): The current user accessing the endpoint.

    Returns:
    - **JSONResponse**: Response generated based on the provided prompt input.
    """  # noqa: E501
    try:
        logger.debug(f"{prompt_input=}")
        messages = [
            message.model_dump()
            for message in prompt_input.messages
            if message.role != "system"
        ]
        system_prompt = next(
            (
                message.content
                for message in prompt_input.messages
                if message.role == "system"
            ),
            None,
        )
        logger.debug(f"messages_for_input: {messages}")
        logger.debug(f"{system_prompt=}")

        temperature = prompt_input.temperature
        model = prompt_input.model.value
        logger.debug(f"{model=}")

        # Check for Guardrails configuration
        if prompt_input.aws_guardrail_id:
            input_for_guardrails = [message.get("content") for message in messages]
            input_for_guardrails = " <SEP> ".join(input_for_guardrails)
            logger.debug(f"{input_for_guardrails=}")
            try:
                llm_guard_response = AWSBedrockGuardrails.bedrock_guardrails_input(
                    input_text=input_for_guardrails,
                    g_id=prompt_input.aws_guardrail_id,
                    service_name="aws_bedrock_submit_prompt_messages",
                    db=db,
                )
            except Exception as err:
                if hasattr(err, "error_message"):
                    raise ExternalAPIError(error_message=f"{err.error_message}")
                else:
                    raise ExternalAPIError(error_message="LLM Guard validation failed!")

            if llm_guard_response.get("sanitized_prompt"):
                cleaned_sanitized_prompt = llm_guard_response.get(
                    "sanitized_prompt"
                ).split(" <SEP> ")[-1]
                messages = [{"role": "user", "content": cleaned_sanitized_prompt}]
                logger.debug(f"messages_for_input: {messages}")

            else:
                llm_guard_message = llm_guard_response.get("response_message")
                return {
                    "status": "Failed",
                    "message": "sanitized_prompt not found",
                    "llm_response": llm_guard_message,
                }

        token_check = AWSBedrockCaller.check_token_limit(messages, model)
        if token_check:
            response = AWSBedrockCaller.regular(
                messages=messages,
                model_id=model,
                temperature=temperature,
                system_prompt=system_prompt,
            )

            logger.debug(f"{response=}")

            response["status"] = "Success"

            if prompt_input.aws_guardrail_id:
                response["sanitized_prompt"] = llm_guard_response.get(
                    "sanitized_prompt"
                )
                return JSONResponse(
                    content=response,
                    status_code=200,
                )
            else:
                return JSONResponse(
                    content=response,
                    status_code=200,
                )
        else:
            raise BadRequestError(
                "Token limit exceeded. Please choose the higher LLM Model"
            )
    except Exception as err:
        raise err


@router.post("/messages/stream", response_model=str)
async def submit_prompt_message_streaming(
    prompt_input: PromptInputStream,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Submit a prompt message to generate a response and stream it with AWS Bedrock.**

    Args:
    - **prompt_input** (PromptInput): Input data for generating a response, containing:
        - **messages** (list[Message]): List of messages forming the prompt.
        Sample message structure:
        ```python
            [
                {"role": "system", "content": "You are an intelligent GK expert"},
                {"role": "user", "content": "Tell me about Taj Mahal in India"}
            ]
        ```
        - **model** (Model): Model to use for generating the response. Defaults to Model.CLAUDE_V2_100K.
        - **temperature** (float): Sampling temperature for response generation. Defaults to 0.5.
    - **current_user** (Annotated[User, Depends]): The current user accessing the endpoint.

    Returns:
    - **StreamingResponse**: Response generated based on the provided prompt input.
    """  # noqa: E501
    try:
        logger.debug(f"{prompt_input=}")
        messages = [
            message.model_dump()
            for message in prompt_input.messages
            if message.role != "system"
        ]
        system_prompt = next(
            (
                message.content
                for message in prompt_input.messages
                if message.role == "system"
            ),
            None,
        )
        logger.debug(f"messages_for_input: {messages}")

        temperature = prompt_input.temperature
        model = prompt_input.model.value
        aws_guardrails_id = prompt_input.aws_guardrail_id
        logger.debug(f"{model=}")

        token_check = AWSBedrockCaller.check_token_limit(messages, model)
        logger.debug(f"{system_prompt=}")
        if token_check:
            return StreamingResponse(
                AWSSubmitController.submit_prompt_streaming(
                    messages=messages,
                    model=model,
                    temperature=temperature,
                    prompt_template=system_prompt,
                    aws_guardrails_id=aws_guardrails_id,
                    db=db,
                ),
                media_type="text/event-stream",
            )
        else:
            raise BadRequestError(
                "Token limit exceeded. Please choose the higher LLM Model"
            )
    except Exception as err:
        raise err


@router.post("/guardrails-create")
async def guardrails_create(
    request_obj: Request,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    try:
        # Get raw request body first for debugging
        body = await request_obj.body()
        raw_data = json.loads(body.decode())
        logger.debug(f"Raw request data: {raw_data}")
        
        # Transform the data to handle enum formatting issues
        if "pii_types" in raw_data and raw_data["pii_types"]:
            # Convert "PIIEntityType.PHONE" to "PHONE" 
            transformed_pii_types = []
            for pii_type in raw_data["pii_types"]:
                if isinstance(pii_type, str) and pii_type.startswith("PIIEntityType."):
                    transformed_pii_types.append(pii_type.replace("PIIEntityType.", ""))
                else:
                    transformed_pii_types.append(pii_type)
            raw_data["pii_types"] = transformed_pii_types
            logger.debug(f"Transformed pii_types: {raw_data['pii_types']}")
        
        # Try to validate with Pydantic model
        try:
            request = GuardrailsCreateUpdateRequest(**raw_data)
        except ValidationError as e:
            logger.error(f"Validation error: {e.errors()}")
            raise HTTPException(
                status_code=422,
                detail={
                    "message": "Validation failed",
                    "errors": e.errors(),
                    "raw_data": raw_data
                }
            )
            
        instance_details = InstanceDBController.get_instance_by_id(
            request.instance_id, db
        )
        if instance_details is None:
            raise AttributeNotFoundError(error_message="Instance not found!")

        llm_guard = instance_details.get("llmGuard")
        instance_name = instance_details.get("name")
        logger.debug(f"{llm_guard=}")

        name_check = AWSBedrockGuardrails.aws_grs_name_check(instance_name)
        if not name_check:
            raise BadRequestError(
                "Instances with AWS Bedrock guardrails should have an instance name which satisfies regular expression pattern: [0-9a-zA-Z-_]+"
            )
        else:
            if llm_guard and instance_details.get("llm_guard_value") == "aws_bedrock":
                try:
                    response, grs_params = (
                        AWSBedrockGuardrails.create_bedrock_guardrails(
                            grs_name=instance_name,
                            pii_types=request.pii_types,
                            word_to_block=request.words_to_block,
                            content_policy_filter=request.content_filter,
                        )
                    )
                except Exception as err:
                    logger.error(
                        f"Error in creating AWS Bedrock Guardrails. Please try again. {err}"
                    )
                    raise BadRequestError(
                        "Error in creating AWS Bedrock Guardrails. Please try again."
                    )
                guardrail_id = response.get("guardrailId")
                logger.debug(f"{guardrail_id=}")

                # update_llm = InstanceDBController.update_instance_aws_guardrails_id(
                #     instance_id=request.instance_id,
                #     aws_grs_id=guardrail_id,
                #     guardrails_params=request.json(),
                #     db=db,
                # )

                # update_llm.update({"aws_guardrail_id": guardrail_id})
                request_dict = request.dict()

                if "pii_types" in request_dict:
                    request_dict["pii_types"] = [
                        str(pii_type) for pii_type in request_dict["pii_types"]
                    ]

                create_guardrails_input_value = (
                    GuardrailsDBController.create_guardrails(
                        create_guardrails_input=CreateGuardrailsInput(
                            guardrails_id=guardrail_id,
                            scanner_configs=request_dict,
                            cloud_provider="aws",
                        ),
                        db=db,
                    )
                )

                update_response = InstanceDBController.update_instance_guardrails_id(
                    instance_id=request.instance_id,
                    guardrails_id=create_guardrails_input_value.get("guardrails_id"),
                    db=db,
                )
                logger.debug(f"{update_response=}")

                return JSONResponse(
                    content={
                        "response": create_guardrails_input_value,
                    }
                )
            else:
                logger.error(
                    "LLM Guard or AWS Bedrock Guardrail is not enabled for this instance"
                )
                raise BadRequestError(
                    "LLM Guard or AWS Bedrock Guardrail is not enabled for this instance"
                )

    except Exception as err:
        raise err


@router.post("/get/all/guardrails")
async def list_guardrails(
    current_user: Annotated[User, Depends(get_current_user_normal)],
):
    try:
        response = AWSBedrockGuardrails.list_bedrock_guardrails()

        return response

    except Exception as err:
        raise err


@router.delete("/delete/guardrails")
async def delete_guardrails(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    guardrail_id: str,
):
    try:
        response = AWSBedrockGuardrails.delete_aws__guardrails(
            guardrail_id=guardrail_id
        )
        delete_guardrails_db_response = GuardrailsDBController.delete_guardrails(
            guardrails_id=guardrail_id,
        )
        logger.debug(f"Database delete result: {delete_guardrails_db_response}")
        return response

    except Exception as err:
        raise err


@router.post("/update/guardrails")
async def update_guardrails(
    request: Request,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    try:
        # Get raw request body first for debugging
        body = await request.body()
        raw_data = json.loads(body.decode())
        logger.debug(f"Raw request data: {raw_data}")
        
        # Transform the data to handle enum formatting issues
        if "pii_types" in raw_data and raw_data["pii_types"]:
            # Convert "PIIEntityType.PHONE" to "PHONE" 
            transformed_pii_types = []
            for pii_type in raw_data["pii_types"]:
                if isinstance(pii_type, str) and pii_type.startswith("PIIEntityType."):
                    transformed_pii_types.append(pii_type.replace("PIIEntityType.", ""))
                else:
                    transformed_pii_types.append(pii_type)
            raw_data["pii_types"] = transformed_pii_types
            logger.debug(f"Transformed pii_types: {raw_data['pii_types']}")
        
        # Try to validate with Pydantic model
        try:
            guardrail_info = GuardrailsCreateUpdateRequest(**raw_data)
        except ValidationError as e:
            logger.error(f"Validation error: {e.errors()}")
            raise HTTPException(
                status_code=422,
                detail={
                    "message": "Validation failed",
                    "errors": e.errors(),
                    "raw_data": raw_data
                }
            )
        instance_details = InstanceDBController.get_instance_by_id(
            guardrail_info.instance_id, db
        )
        if instance_details is None:
            raise AttributeNotFoundError(error_message="Instance not found!")

        llm_guard = instance_details.get("llmGuard")
        llm_guard_value = instance_details.get("llm_guard_value")
        # aws_guardrail_id = instance_details.get("aws_guardrail_id")
        guardrails_id = instance_details.get("guardrails_id")
        guardrails_db_response = GuardrailsDBController.get_guardrails_by_id(
            guardrails_id=guardrails_id, db=db
        )
        aws_guardrail_id = instance_details.get("guardrails_id")
        instance_name = instance_details.get("name")

        if llm_guard and llm_guard_value == "aws_bedrock" and guardrails_id is not None:
            try:
                response = AWSBedrockGuardrails.update_aws__guardrails(
                    guardrail_name=instance_name,
                    guardrail_id=guardrails_id,
                    pii_types=guardrail_info.pii_types,
                    word_to_block=guardrail_info.words_to_block,
                    content_policy_filter=guardrail_info.content_filter,
                )
            except Exception as err:
                logger.error(
                    f"Error in updating AWS Bedrock Guardrails. Please try again. {err}"
                )
                raise BadRequestError(
                    "Error in updating AWS Bedrock Guardrails. Please try again."
                )
            logger.debug(f"{response=}")

            guardrail_info_json = json.loads(guardrail_info.json())
            guardrail_info_json.update(
                {"grs_name": instance_name, "action_taken": "ANONYMIZE"}
            )

            guardrail_info_dict = guardrail_info.dict()
            if "pii_types" in guardrail_info_dict:
                guardrail_info_dict["pii_types"] = [
                    str(pii_type) for pii_type in guardrail_info_dict["pii_types"]
                ]

            update_guardrails_input_value = GuardrailsDBController.update_guardrails(
                guardrails_id=guardrails_db_response.get("guardrails_id"),
                update_data=CreateGuardrailsInput(
                    guardrails_id=guardrails_id,
                    scanner_configs=guardrail_info_dict,
                    cloud_provider="aws",
                ),
                db=db,
            )

            return JSONResponse(
                content={
                    "response": update_guardrails_input_value,
                }
            )

        elif llm_guard and llm_guard_value == "aws_bedrock" and guardrails_id is None:
            response, grs_params = AWSBedrockGuardrails.create_bedrock_guardrails(
                grs_name=instance_name,
                pii_types=guardrail_info.pii_types,
                word_to_block=guardrail_info.words_to_block,
                content_policy_filter=guardrail_info.content_filter,
            )
            guardrail_id = response.get("guardrailId")
            logger.debug(f"{guardrail_id=}")

            update_llm = InstanceDBController.update_instance_aws_guardrails_id(
                instance_id=guardrail_info.instance_id,
                aws_grs_id=guardrail_id,
                guardrails_params=guardrail_info.json(),
                db=db,
            )

            update_llm.update({"aws_guardrail_id": guardrail_id})

            return JSONResponse(
                content={
                    "response": update_llm,
                }
            )

        else:
            logger.error("AWS Bedrock Guardrail is not enabled for this instance.")
            raise BadRequestError(
                "AWS Bedrock Guardrail is not enabled for this instance."
            )

    except Exception as err:
        raise err


@router.post("/get/guardrail-scanners-by-id/{guardrail_id}")
async def get_guardrail_scanners_by_id(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    guardrail_id: str,
):
    try:
        response = AWSBedrockGuardrails.get_guardrail_scanners_by_id(
            guardrail_id=guardrail_id
        )

        return response

    except Exception as err:
        raise err


@router.get("/{guardrails_id}")
async def get_guardrails_by_id(
    guardrails_id: str,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    try:
        guardrails_data = GuardrailsDBController.get_guardrails_by_id(guardrails_id, db)
        if guardrails_data is None:
            raise AttributeNotFoundError(error_message="Guardrails not found!")
        return JSONResponse(content={"response": guardrails_data})
    except Exception as err:
        raise err