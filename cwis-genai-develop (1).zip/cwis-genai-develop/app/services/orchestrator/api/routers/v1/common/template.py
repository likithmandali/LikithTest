from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
import psycopg2
from api.controllers import TemplateController
from api.controllers.common.template_based_output import (
    DocTemplateController,
)
from api.schemas.common.template import (
    CreateTemplateInput,
    UpdateTemplateFlow,
)
from settings.loguru import logger

from settings.db import get_db_connection
from settings.security import User, get_current_user_normal, get_current_user_staff
from typing import Annotated

router = APIRouter(prefix="/template")


@router.post("")
async def create_template(
    create_template_input: CreateTemplateInput,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for creating an instance template.**

    Args:
    - **create_template_input** (CreateTemplateInput): Input data for creating the template. Contains:
        - **name** (str): An identifier name to the template.
        - **flow** (int): The Flow ID to which the template is to be mapped.
        - **promptTemplate** (str): The template to be given for LLM to generate response. Defaulted to "You are an AI assistant"
        doc_template_ids: Optional[list[str]] = None
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection. Defaults to Depends(get_db_connection).

    Raises:
    - **GenericError**: Raised if an error occurs during template creation.

    Returns:
    - **JSONResponse**: JSON response containing the ID of the created template and any updated document template IDs.
    """  # noqa: E501
    try:
        responses = {}
        # Create template and return id
        if create_template_input.doc_template_ids is not None:
            responses = DocTemplateController.update_doc_template_ids_for_flow(
                str(create_template_input.flow),
                create_template_input.doc_template_ids,
                db,
            )
            logger.debug(responses)

        response = TemplateController.create_template(create_template_input, db=db)
        return JSONResponse(
            content={
                "response": response,
                "docTemplateIdUpdate": responses,
            }
        )
    except Exception as err:
        raise err

@router.put("/flow")
async def update_template_update_flow(
    update_template_flow: UpdateTemplateFlow,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for updating template by Flow ID.**

    Args:
    - **update_template_flow** (UpdateTemplateFlow): Input data for updating the template flow. Contains:
        - **flow_id** (int): The Flow ID to which the template is to be mapped.
        - **template_id** (int): ID of the template to be changed.
        - **prompt_template** (str): New prompt template to be given for LLM to generate response.
        - **temperature** (float): The level of hallucination for the LLM model.
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection. Defaults to Depends(get_db_connection).

    Raises:
    - **GenericError**: Raised if an error occurs during template flow update.

    Returns:
    - **JSONResponse**: JSON response containing the result of the update operation.
    """
    # update template and update flow
    try:
        response = TemplateController.update_template_update_flow(update_template_flow, db)
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err

@router.get("/instance/{id}")
async def get_template_by_instance_id(
    id: int,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for retrieving a template by Instance ID.**

    Args:
    - **id** (int): The instance ID.
    - **current_user** (User): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection. Defaults to Depends(get_db_connection).

    Raises:
    - **GenericError**: Raised if an error occurs during the retrieval of the template.

    Returns:
    - **JSONResponse**: JSON response containing the retrieved template.
    """
    # update template and update flow
    try:
        response = TemplateController.get_template_by_instance_id(id, db)
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err
