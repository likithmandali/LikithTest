from .instance import auth_router as instance_auth_router  # noqa
from .activity import auth_router as activity_auth_router  # noqa
from .app import auth_router as app_auth_router  # noqa
from .projects import auth_router as project_auth_router  # noqa
from .template import router as template_router  # noqa
from .knowledge import router as knowledge_router  # noqa
from .authentication import router as authentication_router # noqa
