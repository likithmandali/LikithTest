from fastapi import APIRouter
from . import aws, common
from settings.config import CONFIG

from settings.loguru import logger
env=CONFIG.ENVIRONMENT
logger.info(f"API Router initialized with environment: {env}, prefix: /rosa/{env}/v1/genaie")
api_router_v1 = APIRouter(prefix=f"/rosa/{env}/v1/genaie")

# Authentication routes with /v1/genaie prefix
api_router_v1.include_router(common.authentication_router, tags=["Authentication"])
api_router_v1.include_router(aws.aws_bedrock_router, tags=["AWS Bedrock"])
api_router_v1.include_router(common.activity_auth_router, tags=["Activity"])
api_router_v1.include_router(common.app_auth_router, tags=["Application"])
api_router_v1.include_router(common.project_auth_router, tags=["Project"])
api_router_v1.include_router(common.knowledge_router, tags=["Knowledge"])
api_router_v1.include_router(common.instance_auth_router, tags=["Instance"])
api_router_v1.include_router(common.template_router, tags=["Template"])
api_router_v1.include_router(aws.aws_submit_router, tags=["Submit"])
api_router_v1.include_router(aws.aws_knowledge_router, tags=["Knowledge"])
