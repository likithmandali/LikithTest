from typing import Annotated
import psycopg2
from settings.loguru import logger
from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse
from api.db.app import AppDBController
from settings.db import get_db_connection
from settings.security import User, get_current_user_normal, get_current_user_staff
from settings.decorators import check_project_access_decorator

auth_router = APIRouter(prefix="/apps")


@auth_router.get("/all")
async def get_apps(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Retrieve all application types (Engines) in the enviroment.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing all the apps.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the apps.
    """
    try:
        response = AppDBController.get_apps(db)
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.get("/project/{project_id}")
@check_project_access_decorator
async def get_apps_by_project_id_user_id(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    project_id: int,
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve application types (Engines) by Project ID and User ID.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **project_id** (int): The ID of the project.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the apps filtered by project ID and user ID.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the apps.
    """
    try:
        user_id = current_user[0].get("id")
        response = AppDBController.get_apps_by_project_id_user_id(project_id, user_id, db)
        logger.debug(f"{response=}")
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.get("/all/in-projects")
async def all_apps_in_projects(
    current_user: Annotated[User, Depends(get_current_user_staff)],
    project_name: str = Query(None),
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve application details in each Project.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the apps present in each project.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the apps.
    """
    try:
        row = AppDBController.get_all_apps_in_each_project(projectname=project_name, db=db)
        return JSONResponse(content={"response": row})
    except Exception as err:
        raise err
