import os
import boto3
from botocore.client import Config
from fastapi import APIRouter, Request, UploadFile, File, Depends
from fastapi.responses import JSONResponse
import psycopg2
from datetime import datetime
# from pypdf import PdfReader
# import requests
from api.controllers.aws.knowledge import AWSKnowledgeController
# from api.controllers import KnowledgeController
from api.db.qna_document import QNADocumentDBController
from api.schemas.common.knowledge import (
    CreateKnowledgeInput,
    KnowledgeLoadInput,
    DeleteDocumentsInput,
)
from helper.custom_errors import UnprocessableEntityError, BadRequestError
from api.db.flow import QNAFlowDBController
from api.db.knowledge import KnowledgeDBController
from api.db.instance import InstanceDBController
from helper.aws_s3 import S3ObjectWrapper

from settings.db import get_db_connection
from settings.config import CONFIG
from api.schemas.common.instance import ChunkingStrategy, ChunkingStrategy
from settings.loguru import logger
from settings.security import User, get_current_user_normal
from typing import Annotated
from helper.filename_generator import generate_unique_filename_timestamp
from helper.aws_lambda import LambdaWrapper
from helper.aws_embeddings import AWSBedrockEmbeddingsSearch
from api.controllers.common.ingestion_job import IngestionJobController
from api.schemas.common.knowledge import (
    CreateKnowledgeInput,
    DeleteDocumentsInput,
)
import json

router = APIRouter(prefix="/aws/knowledge")


@router.post("/bedrock/load")
async def knowledge_load_bedrock(
    request: Request,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    knowledge_name: str,
    flow_id: int,
    chunking_strategy: ChunkingStrategy = ChunkingStrategy.FIXED_SIZE,
    files: list[UploadFile] = File(...),
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for loading an AWS knowledge into the system.**

    Args:
    - **current_user** (Annotated[User, Depends]): The current user accessing the endpoint.
    - **knowledge_name** (str): The name of the knowledge being loaded.
    - **flow_id** (int): The Flow ID associated with the knowledge being loaded.
    - **chunking_strategy** (ChunkingStrategy, optional): The strategy used for chunking the knowledge.
    Defaults to ChunkingStrategy.FIXED_SIZE.
    - **files** (list[UploadFile], optional): List of files containing the knowledge data. Defaults to File(...).
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Raises:
    - **UnprocessableEntityError**: Raised when the request is malformed or the knowledge cannot be processed.
    - **GenericError**: Other errors that might occur during the execution of the endpoint.

    Returns:
    - **JSONResponse**: Response message of knowledge load. Either successful message with details or error message.
    """  # noqa: E501
    try:
        request_id = request.state.request_id
        saved_paths = []
        extensions = [file.filename.lower().split(".")[-1] for file in files]
        for extension in extensions:
            supported_ext = extension in ("pdf", "docx", "txt", "csv", "xlsx")
            if not supported_ext:
                raise UnprocessableEntityError(
                    error_message="File type not supported. Please upload a file in PDF, DOCX, TXT, CSV, MD or Excel format!"
                )

        logger.debug(f"Knowledge Type is - {chunking_strategy}")
        knowledge_load_input = KnowledgeLoadInput(
            knowledge_name=knowledge_name,
            flow_id=flow_id,
            chunking_strategy=chunking_strategy.value,
            files=files,
        )
        create_knowledge_input = CreateKnowledgeInput(
            name=knowledge_load_input.knowledge_name
        )
        create_knowledge_response = KnowledgeDBController.create_knowledge(
            create_knowledge_input, db
        )
        knowledge_id = create_knowledge_response.get("id")

        logger.debug(f"{knowledge_load_input.chunking_strategy=}")

        get_flow_by_id_response = QNAFlowDBController.get_flow_by_id(
            knowledge_load_input.flow_id, db
        )
        logger.debug(f"{get_flow_by_id_response}")

        # Get instance id using flow_id
        get_inst_by_flow_id_response = InstanceDBController.get_instance_by_flow_id(
            id=flow_id, db=db
        )
        logger.debug(f"{get_inst_by_flow_id_response=}")

        instance_id = get_inst_by_flow_id_response.get("instanceId")
        logger.debug(f"{instance_id=}")

        # Get instance contents from instance_id
        instance_response = InstanceDBController.get_instance_by_id(
            id=instance_id, db=db
        )
        logger.debug(f"{instance_response=}")
        chunk_size = instance_response.get("chunkSize")
        logger.debug(f"{chunk_size=}")
        vectordb_choice = instance_response.get("vectorDb")
        chunkingParams = instance_response.get("chunkingParams")
        if isinstance(chunkingParams, str):
            try:
                chunkingParams = json.loads(chunkingParams)
            except Exception as e:
                logger.warning(f"Failed to parse chunkingParams: {e}")
                chunkingParams = {}
        elif chunkingParams is None:
            chunkingParams = {}

        # # Upload PDF or TXT files, save to disk
        document_ids = []

        local_datetime = datetime.now()
        time_suffix = datetime.strftime(local_datetime, "%Y-%m-%dT%H:%M:%S.%f")[:-3]
        aws_folder_path = f"knowledge_upload/knowledge_id_{knowledge_id}/"
        for file in knowledge_load_input.files:
            secure_filename = os.path.basename(file.filename)
            file_path = os.path.join(CONFIG.SHARED_VOLUME, secure_filename)
            with open(file_path, "wb") as f:
                f.write(file.file.read())

            # Read the file content into memory
            file.file.seek(0)
            file_data = file.file.read()
            file_name = file.filename
            # Generate a unique file name with timestamp
            # new_file_name = generate_unique_filename_timestamp(file_path=file_name)

            logger.debug(f"{file_name=}")
            # Upload the file directly to AWS S3 Bucket

            destination_file_name = os.path.join(aws_folder_path, file_name)
            logger.debug(f"{destination_file_name=}")

            bucket_name = CONFIG.AWS_STORAGE_BUCKET_NAME

            if secure_filename.lower().split(".")[-1] == "pdf":

                # if check_pdf_text(file_path):
                status = "In Progress"
                create_document_response = QNADocumentDBController.create_qna_document(
                    file.filename, file_path, knowledge_id, status, db
                )
                document_id = create_document_response.get("id")
                document_ids.append(document_id)

                s3_obj = S3ObjectWrapper(
                    CONFIG.AWS_STORAGE_BUCKET_NAME,
                    dest_file_path=destination_file_name,
                )
                s3_obj.put(file_data)

                saved_paths.append(
                    {
                        "file_path": file_path,
                        "file_name": secure_filename,
                        "aws_file_path": destination_file_name,
                        "document_id": document_id,
                    }
                )

            else:
                status = "In Progress"
                create_document_response = QNADocumentDBController.create_qna_document(
                    file.filename, file_path, knowledge_id, status, db
                )
                document_id = create_document_response.get("id")
                document_ids.append(document_id)

                # Upload the file directly to AWS S3 Bucket
                if CONFIG.LOCAL_TESTING:
                    s3_client = boto3.client(
                        "s3",
                        aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                        aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                        region_name=CONFIG.AWS_REGION,
                        config=Config(signature_version="s3v4"),
                    )
                else:
                    s3_client = boto3.client(
                        "s3",
                        region_name=CONFIG.AWS_REGION,
                        config=Config(signature_version="s3v4"),
                    )
                # Upload the file to S3 bucket
                s3_client.put_object(
                    Bucket=bucket_name,
                    Key=destination_file_name,
                    Body=file_data,
                )

                logger.debug(file_path)
                saved_paths.append(
                    {
                        "file_path": file_path,
                        "file_name": file.filename,
                        "aws_file_path": destination_file_name,
                        "document_id": document_id,
                    }
                )
        logger.info(f"{aws_folder_path=}")
        logger.info(f"{document_ids=}")
        function_params = {
            "destination_file_name": aws_folder_path,
            "chunking_strategy": chunking_strategy.value,
            "chunk_size": chunk_size,
            "overlap_percentage": chunkingParams.get("overlap_percentage"),
            "child_max_token": chunkingParams.get("child_max_token"),
            "buffer_size": chunkingParams.get("buffer_size"),
            "breakpoint_percentile_threshold": chunkingParams.get(
                "breakpoint_percentile_threshold"
            ),
            "parsing_strategy": chunkingParams.get(
                "parsing_strategy", "BEDROCK_FOUNDATION_MODEL"
            ),
        }
        response = LambdaWrapper.invoke_function(
            function_name=CONFIG.AWS_LAMBDA_KNOWLEDGE_BASE_CREATE,
            function_params=function_params,
            request_id=request_id,
            knowledge_id=knowledge_id,
            documentids=document_ids,
            get_log=True,
        )
        flow_knowledge_response = QNAFlowDBController.create_qna_flow_knowledge(
            flow_id, knowledge_id, db
        )
        logger.debug("update flow response = {}".format(flow_knowledge_response))
        return JSONResponse(
            content={
                "message": "Files uploaded successfully.",
                "knowledge": {
                    "id": knowledge_id,
                    "name": knowledge_load_input.knowledge_name,
                },
                "flow_id": knowledge_load_input.flow_id,
                "document_ids": document_ids,
            }
        )
    except Exception as err:
        logger.error(f"Error in knowledge_load_bedrock: {str(err)}")
        if saved_paths:
            for path in saved_paths:
                QNADocumentDBController.update_document_status(
                    path["document_id"], "Failed", request_id, db
                )
        raise err


@router.post("/bedrock/upload")
async def knowledge_upload_bedrock(
    request: Request,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    knowledge_id: int,
    chunking_strategy: ChunkingStrategy = ChunkingStrategy.FIXED_SIZE,
    files: list[UploadFile] = File(...),
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for uploading document into existing AWS knowledge.**

    Args:
    - **current_user** (Annotated[User, Depends]): The current user accessing the endpoint.
    - **knowledge_id** (str): ID of the knowledge to which document is to be added.
    - **chunking_strategy** (ChunkingStrategy, optional): The strategy used for chunking the knowledge.
    Defaults to ChunkingStrategy.FIXED_SIZE.
    Possible values are:
        - **ChunkingStrategy.HIERARCHICAL**: HIERARCHICAL chunking strategy.
        - **ChunkingStrategy.FIXED_SIZE**: FIXED_SIZE chunking strategy.
        - **ChunkingStrategy.SEMANTIC**: SEMANTIC chunking strategy.
    - **files** (list[UploadFile], optional): List of files containing the knowledge data. Defaults to File(...).
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Raises:
    - **UnprocessableEntityError**: Raised when the request is malformed or the knowledge cannot be processed.
    - **GenericError**: Other errors that might occur during the execution of the endpoint.

    Returns:
    - **JSONResponse**: Response message of knowledge load. Either successful message with details or error message.
    """  # noqa: E501
    try:
        request_id = request.state.request_id
        extensions = [file.filename.lower().split(".")[-1] for file in files]
        for extension in extensions:
            supported_ext = extension in ("pdf", "docx", "txt", "csv", "xlsx")
            if not supported_ext:
                raise UnprocessableEntityError(
                    error_message="File type not supported. Please upload a file in PDF, DOCX, TXT, CSV, MD or Excel format!"
                )

        # Get flow ID and instance details in steps
        flow_id = KnowledgeDBController.get_flow_id_by_knowledge_id(
            knowledge_id, db
        ).get("id")
        flow_instance = InstanceDBController.get_instance_by_flow_id(flow_id, db)
        instance_id = flow_instance.get("instanceId")
        instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
        vectordb_choice = instance_details.get("vectorDb")
        chunk_size = instance_details.get("chunkSize")

        # Get knowledge name, data source id, knowledge base id and s3 uri from knowledge
        knowledge_details = KnowledgeDBController.get_knowledge_by_id(knowledge_id, db)
        knowledge_name = knowledge_details.get("name")
        data_source_id = knowledge_details.get("data_source_id")
        knowledge_base_id = knowledge_details.get("knowledge_base_id")
        knowledge_ingestion_job_id = knowledge_details.get("knowledge_ingestion_job_id")
        is_ingestion_job_running = (
            IngestionJobController().is_knowledge_base_job_running(
                knowledge_base_id=knowledge_base_id,
                ingestion_job_id=knowledge_ingestion_job_id,
            )
        )
        if is_ingestion_job_running:
            raise BadRequestError(
                error_message="Knowledge base ingestion job is already running. Please wait for it to complete before uploading new documents."
            )
        aws_folder_path = knowledge_details.get("s3_uri")
        function_params = {
            "data_source_id": data_source_id,
            "knowledge_base_id": knowledge_base_id,
            "aws_folder_path": aws_folder_path,
        }

        existing_documents = QNADocumentDBController.get_qna_document_with_knowledge_id(
            knowledge_id, db
        )
        existing_document_names = [doc.get("name") for doc in existing_documents]

        # # Upload PDF or TXT files, save to disk
        saved_paths = []
        document_ids = []
        for file in files:
            secure_filename = os.path.basename(file.filename)
            if secure_filename in existing_document_names:
                QNADocumentDBController.remove_qna_document_from_knowledge_id(knowledge_id, secure_filename, db)
            file_path = os.path.join(CONFIG.SHARED_VOLUME, secure_filename)
            with open(file_path, "wb") as f:
                f.write(file.file.read())

            # Read the file content into memory
            file.file.seek(0)
            file_data = file.file.read()
            file_name = file.filename
            # Generate a unique file name with timestamp
            # new_file_name = generate_unique_filename_timestamp(file_path=file_name)

            logger.debug(f"{file_name=}")
            # Upload the file directly to AWS S3 Bucket
            destination_file_name = (
                f"knowledge_upload/knowledge_id_{knowledge_id}/{file_name}"
            )
            logger.debug(f"{destination_file_name=}")

            bucket_name = CONFIG.AWS_STORAGE_BUCKET_NAME

            if secure_filename.lower().split(".")[-1] == "pdf":
                """
                Check if the PDF file contains text or not.
                If not, then perform OCR and get document chunks.
                """
                # if check_pdf_text(file_path):
                status = "In Progress"
                create_document_response = QNADocumentDBController.create_qna_document(
                    file.filename, file_path, knowledge_id, status, db
                )
                document_id = create_document_response.get("id")
                document_ids.append(document_id)

                s3_obj = S3ObjectWrapper(
                    CONFIG.AWS_STORAGE_BUCKET_NAME,
                    dest_file_path=destination_file_name,
                )
                s3_obj.put(file_data)

                saved_paths.append(
                    {
                        "file_path": file_path,
                        "file_name": secure_filename,
                        "aws_file_path": destination_file_name,
                        "document_id": document_id,
                    }
                )

            else:
                status = "In Progress"
                create_document_response = QNADocumentDBController.create_qna_document(
                    file.filename, file_path, knowledge_id, status, db
                )
                document_id = create_document_response.get("id")
                document_ids.append(document_id)

                # Upload the file directly to AWS S3 Bucket
                if CONFIG.LOCAL_TESTING:
                    s3_client = boto3.client(
                        "s3",
                        aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                        aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                        region_name=CONFIG.AWS_REGION,
                        config=Config(signature_version="s3v4"),
                    )
                else:
                    s3_client = boto3.client(
                        "s3",
                        region_name=CONFIG.AWS_REGION,
                        config=Config(signature_version="s3v4"),
                    )
                # Upload the file to S3 bucket
                s3_client.put_object(
                    Bucket=bucket_name,
                    Key=destination_file_name,
                    Body=file_data,
                )

                logger.debug(file_path)
                saved_paths.append(
                    {
                        "file_path": file_path,
                        "file_name": file.filename,
                        "aws_file_path": destination_file_name,
                        "document_id": document_id,
                    }
                )
        logger.info(f"{aws_folder_path=}")
        logger.info(f"{document_ids=}")

        response = LambdaWrapper.invoke_update_function(
            function_name=CONFIG.AWS_LAMBDA_KNOWLEDGE_BASE_UPDATE,
            function_params=function_params,
            request_id=request_id,
            knowledge_id=knowledge_id,
            documentids=document_ids,
            get_log=True,
        )

        logger.debug(response)
        return JSONResponse(
            content={
                "message": "Files uploaded successfully.",
                "data": response.get("knowledge_base_id"),
            }
        )
    except Exception as err:
        logger.error(f"Error in knowledge_upload_bedrock: {str(err)}")
        if saved_paths:
            for path in saved_paths:
                QNADocumentDBController.update_document_status(
                    path["document_id"], "Failed", request_id, db
                )
        raise err


@router.post("/bedrock/documents/delete")
async def delete_documents_from_knowledge_bedrock(
    request: Request,
    payload: DeleteDocumentsInput,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    Batch delete documents by IDs from an existing AWS knowledge base and trigger a single re-ingestion.

    All documents must belong to the same knowledge base/project/application; otherwise the request is rejected.
    """
    try:
        request_id = getattr(request.state, "request_id", None)
        result = AWSKnowledgeController.delete_documents_from_knowledge_bedrock(
            payload=payload,
            current_user=current_user,
            db=db,
            request_id=request_id,
        )
        return JSONResponse(content=result)
    except BadRequestError as bre:
        raise bre
    except Exception as err:
        logger.error(f"Error in delete_documents_from_knowledge_bedrock: {str(err)}")
        raise err
