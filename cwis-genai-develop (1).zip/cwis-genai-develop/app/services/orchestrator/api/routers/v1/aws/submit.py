import base64
from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse, JSONResponse
import psycopg2
from api.controllers.aws.submit import AWSSubmitController
from api.schemas.aws.submit import AWSBedrockModel, AWSPromptSubmitStream, TitanEmbeddingsInput
from api.db.activity import ActivityDBController
from api.db.activity import ActivityDBController
from api.db.app import AppDBController
from api.db.instance import InstanceDBController
from api.schemas.common.activity import UserActivityCreate
from helper.select_llm_model import get_recommended_llm_model
from api.controllers.common.template import TemplateValidationController
from settings.loguru import logger
from settings.db import get_db_connection
from helper.custom_errors import AttributeNotFoundError, UnprocessableEntityError, RateLimitError
from settings.security import (
    User,
    get_current_user_normal,
    check_project_application_access,
)
from typing import Annotated


aws_submit_router = APIRouter(prefix="/aws/submit")


@aws_submit_router.post("/prompt/streaming", response_model=str)
async def aws_submit_prompt_stream(
    request: Request,
    prompt_submit_stream: AWSPromptSubmitStream,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for submitting a query, perform semantic search on the knowledges in selected instance, generate response and stream it with AWS Bedrock models**

    Args:
    - **prompt_submit_stream** (AWSPromptSubmitStream): Input data for generating a response, including:
        - **model** (AWSBedrockModel): Bedrock model to use for generating the response. Defaults to AWSBedrockModel.TITAN_TEXT_G1_EXPRESS.
          Possible AWSBedrockModel choices:
        - **input_text** (str): Text input for generating the response.
        - **instance_id** (int): Unique identifier for the instance associated with the prompt submission.
        - **additional_json_context** (dict | str | None): Additional context for the prompt.
        - **include_references** (bool): Flag indicating whether to include references in the response. Defaults to False.
    - **current_user** (Annotated[User, Depends]): The current user accessing the endpoint.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Raises:
    - **GenericError**: Raised if there are issues processing the prompt submission.

    Returns:
    - **StreamingResponse**: A streaming response of the generated response.
    """  # noqa: E501
    try:
        request_id = request.state.request_id
        user_id = current_user[0].get("id")
        # creating activity
        instance_id = prompt_submit_stream.instance_id
        instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
        if instance_details is None:
            raise AttributeNotFoundError(error_message="Instance not found!")

        # Check if the prompt template is having invalid knowledge ID (xxx)
        if not await TemplateValidationController.validate_prompt_knowledge_ids(
            instance_id, db
        ):
            raise UnprocessableEntityError(
                error_message="Invalid Knowledge ID or Knowledge not found in the prompt template! Please check the Knowledge ID and try again."
            )

        application_id = instance_details.get("applicationId")

        # Check if the user has access to the project -> application
        auth_response = check_project_application_access(
            user_id=user_id,
            project_id=int(instance_details.get("projectId")),
            application_id=int(application_id),
            db=db,
        )
        logger.debug(f"{auth_response=}")

        llm_model = instance_details.get("llmModel")
        if llm_model == "recommended":
            llm_model = get_recommended_llm_model("aws")
        if llm_model is not None:
            prompt_submit_stream.model = next(
                (m for m in AWSBedrockModel if m.value == llm_model),
                AWSBedrockModel.CLAUDE_V2_100K,
            )
        application_details = AppDBController.get_app_by_id(
            application_id=application_id, db=db
        )
        application_type = application_details.get("type")
        user_activity_create = UserActivityCreate(
            type=application_type,
            input_text=prompt_submit_stream.input_text,
            output_text="",
            feedback={},
            instance_id=instance_id,
            application_id=int(application_id),
            project_id=int(instance_details.get("projectId")),
            request_id=request_id,
        )
        activity_response = ActivityDBController.create_activity(
            user_activity_create, user_id, db
        )
        activity_id = activity_response.get("genaieActivity").get("id")
        logger.debug(f"{activity_id=}")
        return StreamingResponse(
            AWSSubmitController.aws_submit_prompt_stream(
                prompt_submit_stream=prompt_submit_stream,
                activity_id=activity_id,
                db=db,
            ),
            headers={"x-activityid": str(activity_id)},
            media_type="text/event-stream",
        )

    except Exception as err:
        logger.error(f"Unexpected error in aws_submit_prompt_stream: {str(err)}")
        raise err


@aws_submit_router.post("/prompt/streaming/guardrails")
async def aws_submit_prompt_stream_with_grs(
    request: Request,
    prompt_submit: AWSPromptSubmitStream,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for submitting a query, perform semantic search on the knowledges in selected instance, generate response and stream it with AWS Bedrock models with guardrails enabled**

    Args:
    - **prompt_submit** (AWSPromptSubmitStream): Input data for generating a response, including:
        - **model** (AWSBedrockModel): Bedrock model to use for generating the response. Defaults to AWSBedrockModel.TITAN_TEXT_G1_EXPRESS.
          Possible AWSBedModel choices:
            - **CLAUDE_V2_100K**: Anthropic Claude V2 model with 100K parameters.
            - **CLAUDE_V2_1_200K**: Anthropic Claude V2 model with 1.2M parameters.
            - **TITAN_V1_TEXT_EMBED_8K**: Amazon Titan Embed Text V1 model with 8K tokens.
            - **TITAN_TEXT_G1_EXPRESS**: Amazon Titan Text Express V1 model with 8K tokens.
            - **TITAN_MULTIMODAL_EMBED_V1**: Amazon Titan Multimodal Embeddings G1 model for text, image, and combined embeddings.
            - **AWS_JAMBA_15_MINI**: AI21 Jamba 1.5 Mini V1 model.
            - **AWS_JAMBA_15_LARGE**: AI21 Jamba 1.5 Large V1 model.
            - **AWS_CLAUDE_V35_SONNET**: Anthropic Claude 3.5 Sonnet model.
            - **AWS_CLAUDE_V37_SONNET**: Anthropic Claude 3.7 Sonnet model.
            - **AWS_LLAMA_32_1B_INSTRUCT**: Meta LLAMA 3.2 1B Instruct model.
            - **AWS_LLAMA_32_3B_INSTRUCT**: Meta LLAMA 3.2 3B Instruct model.
            - **AWS_LLAMA_32_11B_VISION_INSTRUCT**: Meta LLAMA 3.2 11B Vision Instruct model.
            - **AWS_LLAMA_32_90B_VISION_INSTRUCT**: Meta LLAMA 3.2 90B Vision Instruct model.
            - **AWS_MISTRAL_7B_INSTRUCT**: Mistral 7B Instruct model.
            - **AWS_MIXTRAL_8x_7B_INSTRUCT**: Mixtral 8x7B Instruct model.
            - **AWS_MISTRAL_LARGE_2402**: Mistral Large 24.02 model.
            - **AWS_MISTRAL_SMALL_2402**: Mistral Small 24.02 model.
        - **input_text** (str): Text input for generating the response.
        - **instance_id** (int): Unique identifier for the instance associated with the prompt submission.
        - **additional_json_context** (dict | str | None): Additional context for the prompt.
        - **include_references** (bool): Flag indicating whether to include references in the response. Defaults to False.
    - **current_user** (Annotated[User, Depends]): The current user accessing the endpoint.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Raises:
    - **GenericError**: Raised if there are issues processing the prompt submission.

    Returns:
    - **JsonResponse**: A json response of the generated response.
    """  # noqa: E501
    try:
        request_id = request.state.request_id
        user_id = current_user[0].get("id")
        instance_id = prompt_submit.instance_id

        # Instance validation
        instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
        if instance_details is None:
            raise AttributeNotFoundError(error_message="Instance not found!")

        # Template validation
        if not await TemplateValidationController.validate_prompt_knowledge_ids(
            instance_id, db
        ):
            raise UnprocessableEntityError(
                error_message="Invalid Knowledge ID or Knowledge not found in the prompt template!"
            )

        # Access validation
        application_id = instance_details.get("applicationId")
        auth_response = check_project_application_access(
            user_id=user_id,
            project_id=int(instance_details.get("projectId")),
            application_id=int(application_id),
            db=db,
        )
        logger.debug(f"{auth_response=}")

        # Model selection
        llm_model = instance_details.get("llmModel")
        if llm_model == "recommended":
            llm_model = get_recommended_llm_model("aws")
        if llm_model is not None:
            prompt_submit.model = next(
                (m for m in AWSBedrockModel if m.value == llm_model),
                AWSBedrockModel.CLAUDE_V2_100K,
            )

        # Create activity
        application_details = AppDBController.get_app_by_id(
            application_id=application_id, db=db
        )
        application_type = application_details.get("type")
        user_activity_create = UserActivityCreate(
            type=application_type,
            input_text=prompt_submit.input_text,
            output_text="",
            feedback={},
            instance_id=instance_id,
            application_id=int(application_id),
            project_id=int(instance_details.get("projectId")),
            request_id=request_id,
        )
        activity_response = ActivityDBController.create_activity(
            user_activity_create, user_id, db
        )
        activity_id = activity_response.get("genaieActivity").get("id")
        logger.debug(f"{activity_id=}")
        stream_generator, sanitized_prompt = (
            await AWSSubmitController.aws_submit_prompt_stream_with_grs(
                prompt_submit=prompt_submit,
                activity_id=activity_id,
                db=db,
            )
        )

        # Return streaming response with the sanitized prompt in headers
        return StreamingResponse(
            stream_generator,
            headers={
                "x-activityid": str(activity_id),
                "x-sanitized-prompt": base64.b64encode(
                    sanitized_prompt.encode("utf-8")
                ).decode("utf-8"),
            },
            media_type="text/event-stream",
        )
    except Exception as err:
        logger.error(f"Unexpected error in aws_submit_prompt_stream_with_grs: {str(err)}")
        raise err
