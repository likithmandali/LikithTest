from datetime import datetime
import io
from typing import Annotated, Optional
from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse
import pandas as pd

# from helper.azure_blob_wrapper import upload_to_blob_return_sas_bulk_gen
from settings.loguru import logger
import psycopg2
from api.controllers import (
    AWSSubmitController,
)
from api.schemas.common.activity import (
    UserActivityCreate,
    UpdateUserActivity,
    UserActivityCreateInternal,
    UpdateActivityStatusInternal,
)
from api.db.activity import ActivityDBController
from helper.custom_errors import GenericError
from settings.db import get_db_connection
from settings.security import (
    User,
    get_current_user_normal,
    get_current_user_superadmin,
    check_project_application_access,
    get_current_user_staff,
)
from api.schemas.common.activity import (
    ActivityDetails,
    Frequency,
    SplitBy,
)

auth_router = APIRouter(prefix="/activity")


@auth_router.post("/create")
async def create_user_activity_auth(
    request: Request,
    activity_data: UserActivityCreate,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to create Activity for an authenticated user**

    Args:
    - **activity_data** (UserActivityCreate): Data for creating user activity, including:
        - **type** (str): Type of the activity.
        - **input_text** (str): Input text for the activity.
        - **output_text** (str): Generated response for the activity.
        - **feedback** (dict): User feedback data for the activity.
        - **instance_id** (int): Instance ID associated with the activity.
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **Response**: Response indicating the success of the activity creation.

    Raises:
    - **GenericError**: Raised if there are issues creating the user activity.
    """
    try:
        request_id = request.state.request_id
        user_id = current_user[0].get("id")
        # Check if the user has access to the project and application
        auth_response = check_project_application_access(
            user_id=user_id,
            project_id=activity_data.project_id,
            application_id=activity_data.application_id,
            db=db,
        )
        logger.debug(f"{auth_response=}")
        activity_data.request_id = request_id
        response = ActivityDBController.create_activity(activity_data, user_id, db)
        logger.debug(response)
        return response
    except Exception as err:
        raise err


@auth_router.post("/feedback/update")
async def update_activity_feedback_auth(
    request: Request,
    activity_data: UpdateUserActivity,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to update feedback in the given activity.**

    Args:
    - **activity_data** (UpdateUserActivity): Data for updating activity feedback, including:
        - **activityId** (int): ID of the activity to update.
        - **feedback** (dict): New feedback data to update for the activity.
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response indicating the success of the feedback update.

    Raises:
    - **GenericError**: Raised if there are issues updating activity feedback.
    """
    try:
        request_id = request.state.request_id
        # Check if the user has access to the project and application
        user_id = current_user[0].get("id")
        activity_id = activity_data.activityId
        ActivityDBController.verify_activity_access(activity_id=activity_id, user_id=user_id, db=db)

        # Update the activity feedback
        response = ActivityDBController.update_activity_feedback(activity_data, user_id, db)

        # Call submit_qna_to_cache here
        # await SubmitController.submit_qna_to_cache(request_id=request_id, activity_id=activity_id, db=db)

        return JSONResponse(content=response)
    except Exception as err:
        raise err


@auth_router.get("/all/questions")
async def get_all_user_questions_and_answers_auth(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
    type: Optional[str] = Query(None, description="Activity type filter"),
    project_id: Optional[str] = Query(None, description="Project ID filter"),
    limit: int = Query(15, ge=1, le=100, description="Number of records to return (1-100)"),
):
    """
    **Endpoint to retrieve recent user questions with configurable limit.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.
    - **type** (str, optional): Optional type of the activities to filter by.
    - **project_id** (str, optional): Optional project ID to filter by.
    - **limit** (int, optional): Number of records to return (1-100). Defaults to 15.

    Returns:
    - **JSONResponse**: JSON response containing the user questions.

    Raises:
    - **GenericError**: Raised if there are issues retrieving user questions.
    """
    try:
        user_id = current_user[0].get("id")
        if project_id:
            # Check if the user has access to the project
            auth_response = check_project_application_access(
                user_id=user_id,
                project_id=int(project_id),
                db=db,
            )
            logger.debug(f"{auth_response=}")

        response = ActivityDBController.get_all_user_questions(
            user_id=user_id, type=type, project_id=project_id, limit=limit, db=db
        )
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.get("/{activity_id}")
def get_user_activity_auth(
    activity_id: int,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve activity details based on the given activity ID.**

    Args:
    - **activity_id** (int): The ID of the activity to retrieve.
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing details of the activity.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the user activity by ID.
    """
    try:
        # Check if the user has access to the project and application
        logger.debug(f"{current_user=}")
        user_id = current_user[0].get("id")
        ActivityDBController.verify_activity_access(activity_id=activity_id, user_id=user_id, db=db)
        response = ActivityDBController.get_user_activity_by_id(activity_id, user_id, db)

        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


def extract_values(row: dict):
    if row:
        logger.debug(f"{row=}")
        feedback_message = row.get("message", "None")
        feedback_response = row.get("was it helpful", "None")
        return feedback_message, feedback_response
    else:
        return "None", "None"


@auth_router.get("/project/app-info/{project_id}")
async def get_app_info_by_id(
    project_id: int,
    current_user: Annotated[User, Depends(get_current_user_superadmin)],
    start_date: str = Query(description="date in the dd-mm-yyyy format"),
    end_date: str = Query(description="date in the dd-mm-yyyy format"),
    limit: int = Query(100, ge=5, le=500, description="Maximum number of applications to return"),
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve activity information of applications in the given project_id with pagination.**

    Args:
    - **project_id** (int): The ID of the project.
    - **current_user** (Annotated[User, Depends(get_current_user_superadmin)]): The current authenticated user.
    - **start_date** (str): The start date for the activity information.
    - **end_date** (str): The end date for the activity information.
    - **limit** (int, optional): Maximum number of applications to return (5-500). Defaults to 100.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the activity information for the given project.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the activity information.
    """
    try:
        start_date = datetime.strptime(start_date, "%d-%m-%Y")
        end_date = datetime.strptime(end_date, "%d-%m-%Y").replace(hour=23, minute=59, second=59, microsecond=999)

        response = ActivityDBController.get_app_info_by_id(
            project_id=project_id, start_date=start_date, end_date=end_date, limit=limit, db=db
        )
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err



@auth_router.get("/add/project/to/activity")
async def add_project_to_activity(
    project_id: int,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    app_name: str,
    limit: int = Query(1000, ge=10, le=5000, description="Maximum number of activities to update"),
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to add project to activities with batch processing limits.**

    Args:
    - **project_id** (int): The ID of the project.
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **app_name** (str): The name of the application to filter out.
    - **limit** (int, optional): Maximum number of activities to update (10-5000). Defaults to 1000.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the information of the activity update.

    Raises:
    - **GenericError**: Raised if there are issues updating the activities.
    """
    try:
        # Check if the user has access to the project
        user_id = current_user[0].get("id")
        auth_response = check_project_application_access(
            user_id=user_id,
            project_id=project_id,
            db=db,
        )
        logger.debug(f"{auth_response=}")
        status, response = ActivityDBController.add_project_to_activity(
            project_id=project_id, app_name=app_name, limit=limit, db=db
        )
        if status is True and response is True:
            return JSONResponse(
                content={"response": f"Activities modified successfully (max {limit} records)."},
                status_code=201,
            )
        elif status is True and response is False:
            return JSONResponse(
                content={"response": "No activities to modify."},
                status_code=201,
            )

    except Exception as err:
        raise err
    

@auth_router.get("/all")
async def get_all_user_activity_auth(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
    ids: Optional[str] = Query(None, description="Comma-separated list of activity IDs (max 100)"),
    type: Optional[str] = Query(None, description="Activity type filter"),
    project_id: Optional[str] = Query(None, description="Project ID filter"),
    page: int = Query(1, ge=1, description="Page number (starts at 1)"),
    page_size: int = Query(15, ge=1, le=100, description="Number of records per page (1-100)"),
    sort_by: Optional[str] = Query("createdAt", description="Field to sort by"),
    sort_direction: Optional[str] = Query("desc", description="Sort direction (asc or desc)"),
    cursor_id: Optional[int] = Query(
        None, description="Activity ID cursor for cursor-based pagination (more efficient)"
    ),
    from_date: Optional[str] = Query(None, description="Start date for filtering (YYYY-MM-DD format)"),
    to_date: Optional[str] = Query(None, description="End date for filtering (YYYY-MM-DD format)"),
):
    """
    **Endpoint to retrieve all activities for the authenticated user with pagination and date range filtering support.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.
    - **ids** (str, optional): Optional string of activity IDs to filter by (max 100).
    - **type** (str, optional): Optional type of the activities to filter by.
    - **project_id** (str, optional): Optional project ID to filter by.
    - **page** (int, optional): Page number (starts at 1). Defaults to 1.
    - **page_size** (int, optional): Number of records per page (1-100). Defaults to 15.
    - **sort_by** (str, optional): Field to sort by. Defaults to "createdAt".
    - **sort_direction** (str, optional): Sort direction (asc or desc). Defaults to "desc".
    - **cursor_id** (int, optional): Activity ID cursor for cursor-based pagination (more efficient).
    - **from_date** (str, optional): Start date for filtering in YYYY-MM-DD format.
    - **to_date** (str, optional): End date for filtering in YYYY-MM-DD format.

    Returns:
    - **JSONResponse**: JSON response containing the user activities with pagination metadata.

    Raises:
    - **GenericError**: Raised if there are issues retrieving user activities.
    """
    try:
        user_id = current_user[0].get("id")
        if project_id:
            # Check if the user has access to the project
            auth_response = check_project_application_access(
                user_id=user_id,
                project_id=int(project_id),
                db=db,
            )
            logger.debug(f"{auth_response=}")

        # Process date range filtering
        start_date = None
        end_date = None

        if from_date or to_date:
            try:
                if from_date:
                    start_date = datetime.strptime(from_date, "%Y-%m-%d")
                    # Set to start of day
                    start_date = start_date.replace(hour=0, minute=0, second=0, microsecond=0)

                if to_date:
                    end_date = datetime.strptime(to_date, "%Y-%m-%d")
                    # Set to end of day
                    end_date = end_date.replace(hour=23, minute=59, second=59, microsecond=999999)

                # Handle case where only one date is provided
                if from_date and not to_date:
                    # If only from_date provided, set end_date to end of that day (today behavior)
                    end_date = start_date.replace(hour=23, minute=59, second=59, microsecond=999999)
                elif to_date and not from_date:
                    # If only to_date provided, set start_date to beginning of that day
                    start_date = end_date.replace(hour=0, minute=0, second=0, microsecond=0)

                # Validate date range
                if start_date and end_date and start_date > end_date:
                    raise GenericError(status_code=400, error_message="Start date cannot be later than end date")

                logger.info(f"Date range filter applied: {start_date} to {end_date}")

            except ValueError:
                raise GenericError(status_code=400, error_message="Invalid date format. Please use YYYY-MM-DD format")

        # Calculate offset from page number for traditional pagination
        offset = (page - 1) * page_size if not cursor_id else 0

        # Validate sort direction
        if sort_direction not in ["asc", "desc"]:
            sort_direction = "desc"

        response = ActivityDBController.get_all_user_activity(
            user_id=user_id,
            ids=ids,
            type=type,
            project_id=project_id,
            limit=page_size,
            offset=offset,
            sort_by=sort_by,
            sort_direction=sort_direction,
            cursor_id=cursor_id,
            start_date=start_date,
            end_date=end_date,
            db=db,
        )

        # Get the pagination info from the database response
        db_pagination = response.get("pagination", {})
        total_count = db_pagination.get("total", 0)

        # Log the actual count found
        logger.info(f"Total activities found: {total_count}")

        # Calculate additional pagination metadata
        total_pages = (total_count + page_size - 1) // page_size if total_count > 0 else 0

        # Enhanced pagination metadata
        pagination_metadata = {
            "current_page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "total_count": total_count,
            "has_previous_page": page > 1,
            "has_next_page": db_pagination.get("hasNext", False),
            "first_page": 1,
            "last_page": total_pages,
            "next_page": min(page + 1, total_pages) if page < total_pages else None,
            "previous_page": page - 1 if page > 1 else None,
            "sort_by": sort_by,
            "sort_direction": sort_direction,
            "next_cursor": db_pagination.get("nextCursor"),
            "date_filters": {
                "from_date": from_date,
                "to_date": to_date,
                "applied_start_date": start_date.isoformat() if start_date else None,
                "applied_end_date": end_date.isoformat() if end_date else None,
            },
        }

        # Create the unified response with only one pagination section
        activity_data = {"edges": response.get("edges", []), "pagination": pagination_metadata}

        # Handle empty results with helpful message
        if total_count == 0 and (from_date or to_date):
            activity_data["message"] = "No activities found for the selected date range."

        return JSONResponse(content={"response": activity_data})
    except Exception as err:
        raise err


