from typing import Annotated
import psycopg2
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from api.db.instance import InstanceDBController
from api.controllers.common.instance import InstanceController
from settings.loguru import logger
from api.schemas.common.instance import (
    CreateInstanceInput,
    PatchInstanceInput,
    EditInstanceParams,
    scanner_config_default,
)
from helper.custom_errors import (
    AttributeNotFoundError,
    UnprocessableEntityError,
    BadRequestError,
)
from settings.security import (
    User,
    get_current_user_normal,
    get_current_user_staff,
    check_project_application_access,
)
from settings.db import get_db_connection
from settings.decorators import check_project_app_access_decorator
from helper.aws_embeddings import AWSBedrockGuardrails

auth_router = APIRouter(prefix="/instance")


@auth_router.post("/create-instance")
async def create_instance_sql(
    create_instance_input: CreateInstanceInput,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to create a new instance for the given project ID, application ID and with specified cloud environment.**

    Args:
    - **create_instance_input** (CreateInstanceInput): Input data for creating an instance, including:
        - **name** (str): The name of the instance.
        - **projectId** (int): The ID of the project to which the instance belongs.
        - **temperature** (float): The temperature value.
        - **applicationId** (int): The ID of the application.
        - **isActive** (bool, optional): Flag indicating if the instance is active. Defaults to True.
        - **isDeleted** (bool, optional): Flag indicating if the instance is deleted. Defaults to False.
        - **chunkSize** (int, optional): The chunk size. Defaults to 10.
        - **chunkingStrategy** (ChunkingStrategy, optional): The chunking strategy. Defaults to ChunkingStrategy.FIXED_SIZE.
        - **kNearChunks** (int, optional): The number of near chunks. Defaults to 4.
        - **cloud_environment** (CloudEnvironment, optional): The cloud environment. Defaults to CloudEnvironment.AWS.
        Possible CloudEnvironment choices:
            - **aws**: To create instance with AWS cloud dependency.
        - **llm_guard** (bool): Flag to check the validity of prompt by sending it to LLM Guard.
        - **render_markdown** (bool): Flag indicating whether to render the output in markdown format or not. Defaults to False.
        - **llm_model** (str): llm model to use for generating the response.
        - **query_expansion** (bool): Flag indicating whether to use query expansion algorithm to improve response accuracy. Defaults to False.
        - **vector_db** (str): The vector database to use for the instance.
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.
    - **is_updated_model** (bool, optional): Flag indicating if the model is updated. Defaults to False.

    Returns:
    - **JSONResponse**: JSON response containing the created instance details.

    Raises:
    - **GenericError**: Raised if there are issues creating the instance.
    """  # noqa: E501
    try:
        user_id = current_user[0].get("id")
        logger.debug(f"Current User is {current_user}")

        # Check if user is authorized to create instance in this project -> application
        auth_response = check_project_application_access(
            user_id=user_id,
            project_id=create_instance_input.projectId,
            application_id=create_instance_input.applicationId,
            db=db,
        )
        logger.debug(f"{auth_response=}")

        if (
            create_instance_input.cloud_environment.lower() == "aws"
            and create_instance_input.vector_db.lower() == "opensearch_serverless"
        ):
            if not create_instance_input.embedding_choice.lower().startswith(
                "amazon.titan"
            ):
                raise BadRequestError(
                    "AWS OpenSearch Serverless vector database only supports Amazon Titan embeddings currently.Please select the appropriate model and retry."
                )

        create_instance_input.chunkingStrategy = (
            create_instance_input.chunkingStrategy.value
        )
        if (
            create_instance_input.llm_guard is True
            and create_instance_input.llm_guard_value is not None
            and create_instance_input.llm_guard_value == "aws_bedrock"
        ):
            name_check = AWSBedrockGuardrails.aws_grs_name_check(
                create_instance_input.name
            )
            if not name_check:
                raise BadRequestError(
                    "Instances with AWS Bedrock guardrails should have an instance name which satisfies regular expression pattern: [0-9a-zA-Z-_]+"
                )

        if (
            create_instance_input.llm_guard is True
            and create_instance_input.llm_guard_value is not None
        ):
            response = InstanceDBController.create_instance_llm_guard(
                create_instance_input, user_id, db
            )
        else:
            response = InstanceDBController.create_instance(
                create_instance_input, user_id, db
            )

        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.get("/{id}")
async def get_instance_by_id(
    id: int,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve instance configuration using it's ID.**

    **Deprecation Notice**: The `documentName` field has been removed from the response. This field was used in v1.0 to store the name of the document associated with the knowledge. This field is no longer needed in v2.0 and has been removed from the response.

    Args:
    - **id** (int): The ID of the instance to retrieve.
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the instance details.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the instance.
    """
    try:
        # Check if user is authorized to get instance in this project -> application
        response = InstanceDBController.get_instance_by_id(id, db)
        auth_response = check_project_application_access(
            user_id=current_user[0].get("id"),
            project_id=int(response.get("projectId")),
            application_id=int(response.get("applicationId")),
            db=db,
        )
        logger.debug(f"{auth_response=}")

        # Remove additional field from response. This is only needed in v2.0
        for knowledge in response.get("knowledgeIds"):
            del knowledge["documentDetails"]

        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.get("/get-instance")
async def get_instances_by_user_id(
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve all instances created by the authenticated user.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the instances associated with the user.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the instances.
    """
    try:
        user_id = current_user[0].get("id")
        response = InstanceDBController.get_instances_by_user_id(user_id, db)
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.patch("/{id}")
async def patch_instance(
    id: int,
    patch_instance_input: PatchInstanceInput,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to rename an instance using the Instance ID and Flow ID**

    Args:
    - **id** (int): ID of the instance to be changed.
    - **name** (str): New name to the instance.
    - **flow** (int): Flow ID of the instance.
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response showing the instance ID.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the instances.
    """
    try:
        instance_details = InstanceDBController.get_instance_by_id(id, db)

        # Check if user is authorized to patch instance in this project -> application
        auth_response = check_project_application_access(
            user_id=current_user[0].get("id"),
            project_id=int(instance_details.get("projectId")),
            application_id=int(instance_details.get("applicationId")),
            db=db,
        )
        logger.debug(f"{auth_response=}")

        response = InstanceDBController.patch_instance(id, patch_instance_input, db)
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.get("/project/{project_id}/application/{application_id}")
@check_project_app_access_decorator
async def get_instances_by_project_application_id(
    project_id: int,
    application_id: int,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve instances by project ID, application ID and.**

    Args:
    - **project_id** (int): The ID of the project.
    - **application_id** (int): The ID of the application.
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the instances associated with the specified project and application.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the instances.
    """  # noqa: E501
    try:
        response = InstanceDBController.get_instances_by_project_application_id(
            project_id, application_id, db
        )
        logger.debug(f"{response=}")
        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err


@auth_router.put("/update/temperature-markdown-llmguard/{instance_id}")
async def update_temperaure_markdown_llm_guard_by_instance_id(
    instance_id: int,
    edit_instance_params: EditInstanceParams,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to update temperature value, markdown rendering, LLM guard and query expansion flags and LLM model by Instance ID.**

    Args:
    - **instance_id** (int): The ID of the instance.
    - **edit_instance_params** (EditInstanceParams): Parameters of instance that are to be modified. Contains:
        - **temperature** (float): The temperature value.
        - **llm_guard** (bool): Flag to check the validity of prompt by sending it to LLM Guard.
        - **render_markdown** (bool): Flag indicating whether to render the output in markdown format or not. Defaults to False.
        - **llm_model** (str): llm model to use for generating the response.
        - **query_expansion** (bool): Flag indicating whether to use query expansion algorithm to improve response accuracy. Defaults to False.
        - **chunking_params** (dict): Dictionary containing overlapPercent, bufferSize, and breakpointChunking values.
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response confirming the successful update of k-Near Chunks.

    Raises:
    - **GenericError**: Raised if there are issues updating the k-Near Chunks.
    """  # noqa: E501
    try:
        instance_details = InstanceDBController.get_instance_by_id(instance_id, db)

        # Check if user is authorized to update temperature, markdown, llm guard and query expansion of this instance
        auth_response = check_project_application_access(
            user_id=current_user[0].get("id"),
            project_id=int(instance_details.get("projectId")),
            application_id=int(instance_details.get("applicationId")),
            db=db,
        )
        logger.debug(f"{auth_response=}")

        temperaure = edit_instance_params.temperature
        llm_guard = edit_instance_params.llm_guard
        render_markdown = edit_instance_params.render_markdown
        query_expansion = edit_instance_params.query_expansion
        chunking_params = edit_instance_params.chunking_params

        try:
            llm_model = edit_instance_params.llm_model.value
        except AttributeError:
            llm_model = edit_instance_params.llm_model

        response = InstanceDBController.update_temperature_markdown_llm_guard(
            instance_id=instance_id,
            temperature=temperaure,
            llm_guard=llm_guard,
            render_markdown=render_markdown,
            llm_model=llm_model,
            query_expansion=query_expansion,
            chunking_params=chunking_params,
            db=db,
        )
        logger.debug(response)
        return JSONResponse(content={"response": response})
    except Exception as ge:
        raise ge


@auth_router.delete("/delete-instance/{instance_id}")
def delete_instance_by_id(
    instance_id: int,
    current_user: Annotated[User, Depends(get_current_user_staff)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to delete instance using it's ID.**

    Args:
    - **instance_id** (int): The ID of the instance to delete.
    - **current_user** (Annotated[User, Depends(get_current_user_staff)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response confirming the successful deletion of the instance.

    Raises:
    - **GenericError**: Raised if there are issues deleting the instance.
    """
    try:
        instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
        if instance_details is None:
            raise AttributeNotFoundError(error_message="Instance not found!")

        # Check if user is authorized to delete instance in this project -> application
        auth_response = check_project_application_access(
            user_id=current_user[0].get("id"),
            project_id=int(instance_details.get("projectId")),
            application_id=int(instance_details.get("applicationId")),
            db=db,
        )
        logger.debug(f"{auth_response=}")
        response = InstanceController.delete_instance_by_id(instance_id, db)
        return JSONResponse(
            content={
                "response": response,
            }
        )
    except Exception as err:
        raise err


@auth_router.get("/{id}/with-document-details")
async def get_instance_by_id(
    id: int,
    current_user: Annotated[User, Depends(get_current_user_normal)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint to retrieve instance configuration using it's ID.**

    **Note**: The field `documentName` in v1.0 is replaced with `documentDetails` in v2.0, to show both document ID and name.

    Args:
    - **id** (int): The ID of the instance to retrieve.
    - **current_user** (Annotated[User, Depends(get_current_user_normal)]): The current authenticated user.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Returns:
    - **JSONResponse**: JSON response containing the instance details.

    Raises:
    - **GenericError**: Raised if there are issues retrieving the instance.
    """
    try:
        # Check if user is authorized to get instance in this project -> application
        response = InstanceDBController.get_refreshed_instance(id, db)
        auth_response = check_project_application_access(
            user_id=current_user[0].get("id"),
            project_id=int(response.get("projectId")),
            application_id=int(response.get("applicationId")),
            db=db,
        )
        logger.debug(f"{auth_response=}")

        # Remove deprecated field from response
        for knowledge in response.get("knowledgeIds"):
            del knowledge["documentName"]

        return JSONResponse(content={"response": response})
    except Exception as err:
        raise err
