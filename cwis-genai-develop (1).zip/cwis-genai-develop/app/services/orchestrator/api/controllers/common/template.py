from fastapi import Depends
from settings.loguru import logger
import psycopg2
import re
from api.schemas.common.template import (
    CreateTemplateInput,
    UpdateTemplateFlow,
)
from helper.json_parser import convert_quotes
from api.db.qna_template import QNATemplateDBController
from api.db.flow import QNAFlowDBController
from settings.db import get_db_connection
from api.db.instance import InstanceDBController
from helper.custom_errors import AttributeNotFoundError


class TemplateController:
    @staticmethod
    def create_template(
        create_template_input: CreateTemplateInput,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            name = create_template_input.name
            prompt_template = create_template_input.promptTemplate
            logger.debug(f"Before json parse {prompt_template=}")
            json_string = convert_quotes(prompt_template)
            metadata = create_template_input.metaData
            mode = create_template_input.mode
            output_columns = create_template_input.output_columns
            logger.debug(f"{json_string=}")
            create_template_response = QNATemplateDBController.create_template_sql(
                name=name,
                prompt_template=json_string,
                output_columns=output_columns,
                mode=mode,
                metadata=metadata,
                db=db,
            )

            logger.debug(f"{create_template_response=}")
            template_id = create_template_response.get("id")
            logger.debug(f"{template_id=}")

            flow_id = create_template_input.flow
            flow_patch_response = QNAFlowDBController.update_flow_by_id(flow_id, template_id, db)
            logger.debug(f"{flow_patch_response=}")

            return create_template_response
        except Exception as err:
            raise err

    @staticmethod
    def update_template_update_flow(
        update_template_flow: UpdateTemplateFlow,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # update template
            template_id = update_template_flow.template_id
            output_columns = update_template_flow.output_columns
            metadata = update_template_flow.metaData
            mode = update_template_flow.mode

            response = QNATemplateDBController.update_template_by_id(
                template_id,
                update_template_flow.prompt_template,
                mode,
                metadata,
                output_columns,
                db=db,
            )
            logger.debug(response)

            # Fetch nodeId for Flow
            flow_id = update_template_flow.flow_id
            temperature = update_template_flow.temperature
            update_response = QNAFlowDBController.update_flow_temperature_template_by_id(
                flow_id, template_id, temperature, db
            )
            logger.debug(f"{update_response=}")
            response = QNAFlowDBController.get_flow_by_id(flow_id, db)
            logger.debug(f"{response=}")
            return response
        except Exception as err:
            raise err

    @staticmethod
    def get_template_by_instance_id(id: int, db: psycopg2.extensions.connection = Depends(get_db_connection)):
        try:
            instance_details = InstanceDBController.get_instance_by_id(id, db)
            if instance_details is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            flow_id = instance_details.get("flow")
            flow_details = QNAFlowDBController.get_prompt_template_by_flowid(flow_id, db)
            template_id = flow_details.get("templateId")
            temperature = flow_details.get("temperature")
            prompt_template = flow_details.get("promptTemplate")
            prompt_template_name = flow_details.get("templateName")

            formatted_data = {
                "id": template_id,
                "template": prompt_template,
                "temperature": temperature,
                "name": prompt_template_name,
            }
            logger.debug(f"{formatted_data=}")
            return formatted_data
        except Exception as err:
            raise err


class TemplateValidationController:
    @staticmethod
    def get_prompt_template(
        instance_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
        prompt_template = instance_details.get("template")
        return prompt_template

    @staticmethod
    def get_template_tags(template: str) -> list:
        return re.findall(r"\{\{([^}]+)\}\}", template)

    @staticmethod
    def parse_knowledge_id(template_tag: str):
        try:
            int(template_tag.split("_")[-1])
            return True
        except ValueError:
            return False

    @staticmethod
    async def validate_prompt_knowledge_ids(
        instance_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ) -> bool:
        """
        Validates the knowledge IDs referenced in a prompt template.
        This async function checks if all knowledge IDs referenced in the template tags of a prompt
        template are valid. It extracts template tags containing 'knowledgeid' and verifies each one.

        Args:
            instance_id (int): The ID of the prompt template instance to validate.
            db (psycopg2.extensions.connection): Database connection object. Defaults to dependency injection.

        Returns:
            bool: True if all knowledge IDs in the template are valid, False otherwise.
        """

        prompt_template = TemplateValidationController.get_prompt_template(instance_id, db)
        template_tags = TemplateValidationController.get_template_tags(prompt_template)
        knowledge_validation = all(
            [TemplateValidationController.parse_knowledge_id(tag) for tag in template_tags if "knowledgeid" in tag]
        )
        return knowledge_validation
