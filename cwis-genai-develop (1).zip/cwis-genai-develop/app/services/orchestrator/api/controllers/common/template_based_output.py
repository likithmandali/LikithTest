import os
import shutil
from fastapi import Depends, UploadFile, File
import psycopg2
from api.db.qna_doctemplatefile import QNADocTemplateFile
from settings.db import get_db_connection
from settings.config import CONFIG
from settings.loguru import logger


class DocTemplateController:
    # @staticmethod
    # async def submit_doc_template(
    #     file: UploadFile = File(...),
    #     db: psycopg2.extensions.connection = Depends(get_db_connection),
    # ) -> dict:
    #     try:
    #         # Step 1 - Save file to disk
    #         save_dir = os.path.join(CONFIG.SHARED_VOLUME, "document-templates")
    #         os.makedirs(save_dir, exist_ok=True)
    #         file_name = file.filename
    #         file_type = file_name.split(".")[-1].lower()
    #         file_path = os.path.join(save_dir, file_name)
    #         logger.debug(f"{file_path=} {file_name=} {file_type=}")
    #         contents = await file.read()
    #         with open(file_path, "wb") as f:
    #             f.write(contents)
    #         # Step 2 - Upload DocTemplateFile table with file_path and get ID
    #         response = QNADocTemplateFile.create_doc_template_file(
    #             file_name,
    #             file_path,
    #             file_type,
    #             db,
    #         )
    #         return response
    #     except Exception as err:
    #         raise err

    @staticmethod
    def update_doc_template_ids_for_flow(
        flow_id: str,
        doc_template_ids: list[str],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ) -> list[dict]:
        try:
            responses = []
            for doc_template_id in doc_template_ids:
                response = QNADocTemplateFile.update_doc_template_ids_for_flow(flow_id, doc_template_id, db)
                logger.debug(f"{response=}")
                responses.append(response)
            logger.debug(f"{responses=}")
            return responses
        except Exception as err:
            raise err

    # @staticmethod
    # async def upload_files(
    #     file: UploadFile,
    #     db: psycopg2.extensions.connection = Depends(get_db_connection),
    # ):
    #     try:
    #         response = await DocTemplateController.submit_doc_template(file, db)
    #         return response
    #     except Exception as ge:
    #         raise ge

    # @staticmethod
    # async def submit_default_doc_template(
    #     db: psycopg2.extensions.connection = Depends(get_db_connection),
    # ) -> list[dict]:
    #     try:
    #         # Get files from default template directory
    #         default_dir = os.path.join(CONFIG.ASSETS_DIR, "status-report-generator")

    #         # Create the save directory if it doesn't exist
    #         save_dir = os.path.join(CONFIG.SHARED_VOLUME, "document-templates")
    #         os.makedirs(save_dir, exist_ok=True)

    #         # Iterate through files in the default directory and copy them to the save directory
    #         responses = []
    #         for file_name in os.listdir(default_dir):
    #             file_type = file_name.split(".")[-1].lower()
    #             source_file = os.path.join(default_dir, file_name)
    #             destination_file_path = os.path.join(CONFIG.SHARED_VOLUME, "document-templates", file_name)
    #             shutil.copy2(source_file, destination_file_path)  # Use shutil for preserving metadata

    #             # Upload DocTemplateFile table with file_path and get ID
    #             response = QNADocTemplateFile.create_doc_template_file(
    #                 file_name,
    #                 destination_file_path,
    #                 file_type,
    #                 db,
    #             )
    #             responses.append(response)
    #         return responses
    #     except Exception as err:
    #         raise err
