from fastapi import Depends
import psycopg2

from api.db.instance import InstanceDBController
from api.db.knowledge import KnowledgeDBController
from helper.custom_errors import AttributeNotFoundError


from settings.db import get_db_connection
from settings.loguru import logger
from helper.aws_embeddings import AWSBedrockEmbeddingsSearch, AWSBedrockGuardrails
from helper.aws_s3 import S3ObjectWrapper


class InstanceController:
    def delete_instance_by_id(
        instance_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            logger.debug(f"Deleting instance with ID: {instance_id}")
            instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
            if instance_details is None:
                raise AttributeNotFoundError(error_message="Instance not found!")

            flow_id = instance_details.get("flow")
            knowledge_ids = instance_details.get("knowledgeIds")
            template_id = instance_details.get("templateId")
            cloud_environment = instance_details.get("cloudEnvironment")
            application_id = instance_details.get("applicationId")
            vector_db = instance_details.get("vectorDb")
            embedding_choice = instance_details.get("embeddingChoice")
            llm_guard = instance_details.get("llmGuard")
            llm_guard_value = instance_details.get("llm_guard_value")
            guardrails_id = instance_details.get("guardrails_id")

            # Check the application type
            fetch_application_query = """
                SELECT type
                FROM genaie_application ga
                WHERE ga.id = %s;
            """
            logger.debug(f"{fetch_application_query=}")
            with db.cursor() as cur:
                cur.execute(
                    fetch_application_query,
                    (str(application_id),),
                )
                application_type = cur.fetchone()
            logger.debug(f"{application_type=}")
            application_type = application_type[0]

            response = {}
            if llm_guard is True and llm_guard_value == "aws_bedrock" and guardrails_id is not None:
                try:
                    delete_guardrail = AWSBedrockGuardrails.delete_aws__guardrails(guardrails_id)
                    logger.debug(f"{delete_guardrail=}")
                    logger.debug("Guardrail Deleted Successfully")
                except Exception as err:
                    logger.error("Guardrail Deleteion Failed")
                    logger.error(f"{err=}")
                    raise err

            match vector_db:
                case "opensearch_serverless":
                    s3_list = []

                    for knowledge in knowledge_ids:
                        knowledge_id = knowledge.get("id")

                        knowledge_base_id = knowledge.get("knowledge_base_id")
                        s3uri = knowledge.get("s3_uri")
                        if s3uri is not None and s3uri not in s3_list:
                            s3_list.append(s3uri)

                        # Remove Instance-Knowledge-Document relation from DB
                        knowledge_instance_response = InstanceDBController.remove_flow_knowledge_relation(
                            instance_id=instance_id,
                            knowledge_id=knowledge_id,
                            db=db,
                        )
                        # Delete knowledge from DB
                        knowledge_deletion_response = KnowledgeDBController.remove_knowledge_from_db(
                            knowledge_id=knowledge_id, db=db
                        )
                        logger.debug(f"{knowledge_base_id=}")
                        logger.debug(f"{s3uri=}")
                        if knowledge_base_id is not None:
                            delete_knowledge_base = AWSBedrockEmbeddingsSearch.delete_knowledge_base(knowledge_base_id)
                            logger.debug(f"{delete_knowledge_base=}")

                    for document_path in s3_list:
                        delete_s3_folder = S3ObjectWrapper.delete_folder(document_path)
                        logger.debug(f"{delete_s3_folder=}")

            instance_deletion_response = InstanceDBController.delete_instance_by_id(
                instance_id, flow_id, template_id, db
            )
            response.update(instance_deletion_response)
            logger.critical(f"instance_deletion_response={response}")
            return {
                "message": "Instance Deleted Successfully",
                "id": instance_id,
            }
        except Exception as err:
            raise err