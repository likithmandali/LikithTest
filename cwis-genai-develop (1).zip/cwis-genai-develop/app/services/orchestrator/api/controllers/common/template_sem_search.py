import psycopg2
from fastapi import Depends
from process_template.opensearch_helper.semantic_search.base_logic import (
    TemplateSemanticSearch,
)
from settings.loguru import logger
from helper.aws_embeddings import AWSBedrockEmbeddingsSearch
from api.db.instance import InstanceDBController
from helper.custom_errors import AttributeNotFoundError
from settings.db import get_db_connection


def create_claude_message(user_query, processed_content):
    """
    Create a message structure for Claude with text and image content.

    Args:
        user_query (str): The user's question
        processed_content (dict): Processed knowledge base content

    Returns:
        list: Message structure for Claude API
    """
    content_parts = []

    # Add text content
    if processed_content["text_content"]:
        context_text = "Based on the following retrieved information:\n\n"
        for i, text_item in enumerate(processed_content["text_content"], 1):
            context_text += f"**Source {i}** (Score: {text_item['score']:.3f}):\n"
            context_text += f"{text_item['text']}\n\n"

        context_text += f"User Question: {user_query}"

        content_parts.append({"type": "text", "text": context_text})

    # Add image content (using base64 format for Claude)
    for image_item in processed_content["image_content"]:
        content_parts.append(
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": image_item["media_type"],
                    "data": image_item["base64_data"],
                },
            }
        )

    # If no content from knowledge base, just use the user query
    if not content_parts:
        content_parts.append({"type": "text", "text": user_query})

    return [{"role": "user", "content": content_parts}]


def aws_temp_render_template(
    prompt_template: str,
    input_text: str,
    k_near_chunks: int,
    instance_id: int,
    vector_db: str = "opensearch_serverless",
    additional_json_context: dict | str | None = None,
    include_references: bool = False,
    embedding_choice: str = "amazon.titan-embed-text-v2:0",
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    Template rendering that populates the original template with retrieved content.

    Args:
        prompt_template: Template string with tags to be populated
        input_text: User's query text
        k_near_chunks: Number of chunks to retrieve
        instance_id: Instance ID
        vector_db: Vector database type
        additional_json_context: Additional context to append
        include_references: Whether to include references in the output
        embedding_choice: Embedding model choice
        db: Database connection

    Returns:
        tuple: (claude_messages, semantic_search_output)
    """
    try:
        # Prepare template
        template_tags = TemplateSemanticSearch.get_template_tags_v2(prompt_template)
        logger.debug(f"{template_tags=}")

        # Add additional context to input text if provided
        processed_input_text = input_text
        if additional_json_context is not None:
            processed_input_text = (
                input_text
                + "\nPlease refer the below json data as reference\n"
                + str(additional_json_context)
            )

        # Initialize template values dictionary
        template_values = {"input_text": processed_input_text}

        # Collect all content for potential Claude messages
        all_text_content = []
        all_image_content = []

        if vector_db == "opensearch_serverless":
            for template_tag in template_tags:
                if "knowledgeid" in template_tag:
                    kb_id = TemplateSemanticSearch.parse_knowledge_id(template_tag)

                    # Perform semantic search for this knowledge base
                    search_results = AWSBedrockEmbeddingsSearch.answer_query(
                        query=processed_input_text,
                        kb_id=kb_id,
                        k_near_chunks=k_near_chunks,
                        db=db,
                    )
                    # Format the retrieved content for this knowledge base
                    kb_content = ""
                    if (
                        "text_content" in search_results
                        and search_results["text_content"]
                    ):
                        for i, text_item in enumerate(
                            search_results["text_content"], 1
                        ):
                            # Validate and build content for the text item
                            content_parts = []
                            if 'score' in text_item:
                                content_parts.append(
                                    f"**Source {i}** (Score: {text_item['score']:.3f}):"
                                )
                            if 'text' in text_item:
                                content_parts.append(text_item['text'])
                            if "url" in text_item:
                                content_parts.append(
                                    f"Document Location: {text_item['url']}"
                                )
                            # Join parts and add to kb_content
                            kb_content += "\n\n".join(content_parts) + "\n\n"

                        # Add to overall collections for Claude messages
                        all_text_content.extend(search_results["text_content"])

                    if (
                        "image_content" in search_results
                        and search_results["image_content"]
                    ):

                        # return
                        all_image_content.extend(search_results["image_content"])

                    # Store the formatted content for this specific knowledge base tag
                    template_values[template_tag.strip()] = kb_content

        # Populate the template using the TemplateSemanticSearch helper
        populated_template = TemplateSemanticSearch.process_template(
            prompt_template, template_values
        )

        # Create Claude messages - if we have images, use multimodal format
        if all_image_content:
            # Create multimodal message with both text and images
            content_parts = [{"type": "text", "text": populated_template}]

            # Add image content
            for image_item in all_image_content:
                content_parts.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": image_item["media_type"],
                            "data": image_item["base64_data"],
                        },
                    }
                )
                i = len(content_parts) - 1
                # Add document location as text after each image
                if "url" in image_item:
                    content_parts.append(
                        {
                            "type": "text",
                            "text": f"For {i}th content, the Document Location: {image_item['url']}"
                        }
                    )

            claude_messages = [{"role": "user", "content": content_parts}]
        else:
            # Simple text-only message
            claude_messages = [{"role": "user", "content": populated_template}]

        # Create semantic search output for compatibility
        processed_content = {
            "text_content": all_text_content,
            "image_content": all_image_content,
        }

        semantic_search_output = {
            "input_text": processed_input_text,
            "processed_content": processed_content,
            "populated_template": populated_template,
            "claude_messages": claude_messages,
            "has_images": bool(all_image_content),
            "has_text": bool(all_text_content),
        }

        logger.debug(
            f"Template rendering complete - Images: {len(all_image_content)}, Text: {len(all_text_content)}"
        )
        logger.debug(f"{claude_messages=}, {semantic_search_output=}")
        return claude_messages, semantic_search_output

    except Exception as e:
        logger.error(f"Error occurred in simplified template rendering: {str(e)}")
        raise e
