from settings.loguru import logger 
from settings.config import CONFIG
from helper.custom_errors import AttributeNotFoundError
import boto3
import os
from botocore.client import Config
from botocore.exceptions import ClientError
from typing import List, Dict, Any
from datetime import datetime, timezone, timedelta

class IngestionJobController:
    """
    Controller class for managing AWS Bedrock knowledge base ingestion jobs.
    Handles operations like listing data sources, managing ingestion jobs, and stopping long-running jobs.
    
    Example Usage:
        >>> controller = IngestionJobController()
        >>> data_sources = controller.get_data_sources_for_knowledge_base("kb-123")
        >>> running_jobs = controller.get_all_running_jobs("kb-123")
        >>> result = controller.stop_all_running_jobs("kb-123")
    
    Attributes:
        boto3_session: AWS Boto3 session instance
        bedrock_agent: AWS Bedrock Agent client
    """
    
    def __init__(self):
        """
        Initialize the IngestionJobController with AWS Bedrock client.
        
        Raises:
            AttributeNotFoundError: If AWS configuration is missing or invalid
        """
        try:
            if CONFIG.LOCAL_TESTING:
                self.boto3_session = boto3.session.Session(
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
                
                self.bedrock_agent = self.boto3_session.client(
                    "bedrock-agent",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                    config=Config(retries={'max_attempts': 3})
                )
            else:
                self.boto3_session = boto3.session.Session(
                    region_name=CONFIG.AWS_REGION,
                )
                
                self.bedrock_agent = self.boto3_session.client(
                    "bedrock-agent",
                    region_name=CONFIG.AWS_REGION,
                    config=Config(retries={'max_attempts': 3})
                )
            
            logger.info("IngestionJobController initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize IngestionJobController: {e}")
            raise AttributeNotFoundError(f"Failed to initialize AWS Bedrock client: {e}")

    @classmethod
    def create_controller(cls) -> 'IngestionJobController':
        """
        Class method to create a new IngestionJobController instance with validation.
        
        Returns:
            IngestionJobController: A new instance of the controller
            
        Raises:
            AttributeNotFoundError: If AWS configuration is invalid
        """
        try:
            controller = cls()
            # Validate the connection by making a simple call
            controller._validate_aws_connection()
            return controller
        except Exception as e:
            logger.error(f"Failed to create IngestionJobController: {e}")
            raise AttributeNotFoundError(f"Cannot create controller: {e}")
    
    def _validate_aws_connection(self) -> bool:
        """
        Validate the AWS connection by making a simple API call.
        
        Returns:
            bool: True if connection is valid
            
        Raises:
            Exception: If connection validation fails
        """
        try:
            # Make a simple call to validate the connection
            response = self.bedrock_agent.list_knowledge_bases(maxResults=1)
            logger.info("AWS Bedrock connection validated successfully")
            return True
        except Exception as e:
            logger.error(f"AWS connection validation failed: {e}")
            raise e

    def get_data_sources_for_knowledge_base(self, knowledge_base_id: str) -> List[Dict[str, Any]]:
        """
        Get all data sources for a specific knowledge base.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            
        Returns:
            List of data source summaries
        """
        data_sources = []
        next_token = None
        
        try:
            while True:
                # Prepare request payload
                request_payload = {"maxResults": 1000}
                if next_token:
                    request_payload["nextToken"] = next_token
                
                logger.info(f"Fetching data sources for knowledge base: {knowledge_base_id}")
                response = self.bedrock_agent.list_data_sources(
                    knowledgeBaseId=knowledge_base_id,
                    **request_payload
                )
                
                # Add data sources to our list
                data_sources.extend(response.get('dataSourceSummaries', []))
                
                # Check if there are more results
                next_token = response.get('nextToken')
                if not next_token:
                    break
            
            logger.info(f"Found {len(data_sources)} data sources for knowledge base: {knowledge_base_id}")
            return data_sources
            
        except ClientError as e:
            logger.error(f"AWS API error while fetching data sources for {knowledge_base_id}: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error while fetching data sources for {knowledge_base_id}: {e}")
            return []
    
    def get_ingestion_jobs_for_data_source(self, knowledge_base_id: str, data_source_id: str) -> List[Dict[str, Any]]:
        """
        Get all ingestion jobs for a specific data source.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            data_source_id: The ID of the data source
            
        Returns:
            List of ingestion job summaries
        """
        ingestion_jobs = []
        next_token = None
        
        try:
            while True:
                # Prepare request payload
                request_payload = {"maxResults": 1000}
                if next_token:
                    request_payload["nextToken"] = next_token
                
                logger.info(f"Fetching ingestion jobs for data source: {data_source_id}")
                response = self.bedrock_agent.list_ingestion_jobs(
                    knowledgeBaseId=knowledge_base_id,
                    dataSourceId=data_source_id,
                    **request_payload
                )
                
                # Add ingestion jobs to our list
                ingestion_jobs.extend(response.get('ingestionJobSummaries', []))
                
                # Check if there are more results
                next_token = response.get('nextToken')
                if not next_token:
                    break
            
            logger.info(f"Found {len(ingestion_jobs)} ingestion jobs for data source: {data_source_id}")
            return ingestion_jobs
            
        except ClientError as e:
            logger.error(f"AWS API error while fetching ingestion jobs for {data_source_id}: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error while fetching ingestion jobs for {data_source_id}: {e}")
            return []
    
    def stop_ingestion_job(self, knowledge_base_id: str, data_source_id: str, ingestion_job_id: str) -> bool:
        """
        Stop a specific ingestion job.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            data_source_id: The ID of the data source
            ingestion_job_id: The ID of the ingestion job
            
        Returns:
            True if successfully stopped, False otherwise
        """
        try:
            logger.info(f"Stopping ingestion job: {ingestion_job_id}")
            response = self.bedrock_agent.stop_ingestion_job(
                knowledgeBaseId=knowledge_base_id,
                dataSourceId=data_source_id,
                ingestionJobId=ingestion_job_id
            )
            
            # Check if the response indicates success
            if response.get('ResponseMetadata', {}).get('HTTPStatusCode') == 202:
                logger.info(f"Successfully stopped ingestion job: {ingestion_job_id}")
                return True
            else:
                logger.warning(f"Unexpected response when stopping job {ingestion_job_id}: {response}")
                return False
                
        except ClientError as e:
            logger.error(f"AWS API error while stopping ingestion job {ingestion_job_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while stopping ingestion job {ingestion_job_id}: {e}")
            return False
    
    def is_job_running(self, job_status: str) -> bool:
        """
        Check if a job is currently running based on its status.
        
        Args:
            job_status: The status of the ingestion job
            
        Returns:
            True if the job is running, False otherwise
        """
        # Common statuses that indicate a job is in progress
        running_statuses = ['STARTING', 'IN_PROGRESS', 'STOPPING']
        return job_status.upper() in running_statuses
    
    
    def get_all_running_jobs(self, knowledge_base_id: str) -> List[Dict[str, Any]]:
        """
        Get all currently running ingestion jobs for a knowledge base.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            
        Returns:
            List of running ingestion jobs with their details
        """
        running_jobs = []
        
        try:
            # Get all data sources for the knowledge base
            data_sources = self.get_data_sources_for_knowledge_base(knowledge_base_id)
            
            for data_source in data_sources:
                data_source_id = data_source.get('dataSourceId')
                if not data_source_id:
                    continue
                
                # Get ingestion jobs for this data source
                ingestion_jobs = self.get_ingestion_jobs_for_data_source(knowledge_base_id, data_source_id)
                
                # Filter for running jobs
                for job in ingestion_jobs:
                    job_status = job.get('status', '').upper()
                    if self.is_job_running(job_status):
                        job_details = {
                            'knowledge_base_id': knowledge_base_id,
                            'data_source_id': data_source_id,
                            'ingestion_job_id': job.get('ingestionJobId'),
                            'status': job_status,
                            'started_at': job.get('startedAt'),
                            'updated_at': job.get('updatedAt')
                        }
                        running_jobs.append(job_details)
            
            logger.info(f"Found {len(running_jobs)} running jobs for knowledge base: {knowledge_base_id}")
            return running_jobs
            
        except Exception as e:
            logger.error(f"Error getting running jobs for knowledge base {knowledge_base_id}: {e}")
            return []
    
    def stop_all_running_jobs(self, knowledge_base_id: str) -> Dict[str, Any]:
        """
        Stop all running ingestion jobs for a knowledge base.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            
        Returns:
            Dictionary with summary of stopped jobs and any errors
        """
        result = {
            "stopped_jobs": [],
            "failed_stops": [],
            "total_jobs_found": 0,
            "successfully_stopped": 0
        }
        
        try:
            running_jobs = self.get_all_running_jobs(knowledge_base_id)
            result["total_jobs_found"] = len(running_jobs)
            
            for job in running_jobs:
                job_id = job.get('ingestion_job_id')
                data_source_id = job.get('data_source_id')
                
                if not job_id or not data_source_id:
                    result["failed_stops"].append({
                        "job": job,
                        "reason": "Missing job ID or data source ID"
                    })
                    continue
                
                success = self.stop_ingestion_job(knowledge_base_id, data_source_id, job_id)
                
                if success:
                    result["stopped_jobs"].append(job)
                    result["successfully_stopped"] += 1
                else:
                    result["failed_stops"].append({
                        "job": job,
                        "reason": "Failed to stop job"
                    })
            
            logger.info(f"Stopped {result['successfully_stopped']} out of {result['total_jobs_found']} jobs")
            return result
            
        except Exception as e:
            logger.error(f"Error stopping all running jobs for knowledge base {knowledge_base_id}: {e}")
            result["error"] = str(e)
            return result
        
    def get_job_status(self, knowledge_base_id: str, ingestion_job_id: str) -> Dict[str, Any]:
        """
        Get the status of an ingestion job by searching across all data sources in a knowledge base.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            ingestion_job_id: The ID of the ingestion job
            
        Returns:
            Dictionary containing job status and details, or error information
            
        Example:
        """
        try:
            # Get all data sources for the knowledge base
            data_sources = self.get_data_sources_for_knowledge_base(knowledge_base_id)
            
            if not data_sources:
                return {
                    "error": f"No data sources found for knowledge base: {knowledge_base_id}",
                    "status": "NOT_FOUND"
                }
            
            # Search for the job across all data sources
            for data_source in data_sources:
                data_source_id = data_source.get('dataSourceId')
                if not data_source_id:
                    continue
                
                try:
                    # Try to get the job details from this data source
                    response = self.bedrock_agent.get_ingestion_job(
                        knowledgeBaseId=knowledge_base_id,
                        dataSourceId=data_source_id,
                        ingestionJobId=ingestion_job_id
                    )
                    
                    job = response.get('ingestionJob', {})
                    if job:
                        logger.info(f"Found ingestion job {ingestion_job_id} in data source {data_source_id}")
                        return {
                            "status": job.get("status"),
                            "data_source_id": data_source_id,
                            "knowledge_base_id": knowledge_base_id,
                            "ingestion_job_id": ingestion_job_id,
                            "job_details": job,
                            "is_running": self.is_job_running(job.get("status", ""))
                        }
                        
                except ClientError as e:
                    # Job not found in this data source, continue searching
                    if e.response.get('Error', {}).get('Code') == 'ResourceNotFoundException':
                        continue
                    else:
                        logger.error(f"Error checking data source {data_source_id}: {e}")
                        continue
                except Exception as e:
                    logger.error(f"Unexpected error checking data source {data_source_id}: {e}")
                    continue
            
            # Job not found in any data source
            return {
                "error": f"Ingestion job {ingestion_job_id} not found in any data source",
                "status": "NOT_FOUND",
                "knowledge_base_id": knowledge_base_id,
                "ingestion_job_id": ingestion_job_id
            }
            
        except Exception as e:
            logger.error(f"Error getting job status for {ingestion_job_id}: {e}")
            return {
                "error": str(e),
                "status": "ERROR",
                "knowledge_base_id": knowledge_base_id,
                "ingestion_job_id": ingestion_job_id
            }
    
    def is_knowledge_base_job_running(self, knowledge_base_id: str, ingestion_job_id: str = None) -> bool:
        """
        Check if any ingestion job is currently running in a knowledge base.
        If ingestion_job_id is provided, checks that specific job across all data sources.
        If no ingestion_job_id is provided, checks all jobs in the knowledge base.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            ingestion_job_id: Optional specific ingestion job ID to check
            
        Returns:
            bool: True if any job is "IN_PROGRESS", False otherwise
            
        """
        try:
            # Get all data sources for the knowledge base
            data_sources = self.get_data_sources_for_knowledge_base(knowledge_base_id)
            
            if not data_sources:
                logger.warning(f"No data sources found for knowledge base: {knowledge_base_id}")
                return False
            
            # If specific job ID is provided, check that job across all data sources
            if ingestion_job_id:
                for data_source in data_sources:
                    data_source_id = data_source.get('dataSourceId')
                    if not data_source_id:
                        continue
                    
                    try:
                        # Try to get the specific job from this data source
                        response = self.bedrock_agent.get_ingestion_job(
                            knowledgeBaseId=knowledge_base_id,
                            dataSourceId=data_source_id,
                            ingestionJobId=ingestion_job_id
                        )
                        
                        job = response.get('ingestionJob', {})
                        if job:
                            job_status = job.get('status', '').upper()
                            logger.info(f"Found job {ingestion_job_id} in data source {data_source_id} with status: {job_status}")
                            
                            if job_status == "IN_PROGRESS":
                                logger.info(f"Job {ingestion_job_id} is IN_PROGRESS in knowledge base {knowledge_base_id}")
                                return True
                            
                    except ClientError as e:
                        # Job not found in this data source, continue searching
                        if e.response.get('Error', {}).get('Code') == 'ResourceNotFoundException':
                            continue
                        else:
                            logger.error(f"Error checking job {ingestion_job_id} in data source {data_source_id}: {e}")
                            continue
                    except Exception as e:
                        logger.error(f"Unexpected error checking job {ingestion_job_id} in data source {data_source_id}: {e}")
                        continue
            
            else:
                # No specific job ID provided, check all jobs in all data sources
                for data_source in data_sources:
                    data_source_id = data_source.get('dataSourceId')
                    if not data_source_id:
                        continue
                    
                    # Get all ingestion jobs for this data source
                    ingestion_jobs = self.get_ingestion_jobs_for_data_source(knowledge_base_id, data_source_id)
                    
                    # Check if any job is running
                    for job in ingestion_jobs:
                        job_status = job.get('status', '').upper()
                        if job_status == "IN_PROGRESS":
                            job_id = job.get('ingestionJobId')
                            logger.info(f"Found running job {job_id} in data source {data_source_id}")
                            return True
            
            logger.info(f"No running jobs found in knowledge base {knowledge_base_id}")
            return False
            
        except Exception as e:
            logger.error(f"Error checking if knowledge base {knowledge_base_id} has running jobs: {e}")
            return False

    def get_ingestion_job(self, kb_id, data_source_id, ingestion_job_id):
        try:
            return self.bedrock_agent.get_ingestion_job(
                knowledgeBaseId=kb_id,
                dataSourceId=data_source_id,
                ingestionJobId=ingestion_job_id,
            )
        except Exception as e:
            logger.error(f"Error getting ingestion job: {e}")
            return {"error": str(e)}

    def stop_ingestion_job(self, knowledge_base_id: str, data_source_id: str, ingestion_job_id: str) -> bool:
        """
        Stop a specific ingestion job.
        
        Args:
            knowledge_base_id: The ID of the knowledge base
            data_source_id: The ID of the data source
            ingestion_job_id: The ID of the ingestion job
            
        Returns:
            True if successfully stopped, False otherwise
        """
        try:
            logger.info(f"Stopping ingestion job: {ingestion_job_id}")
            response = self.bedrock_agent.stop_ingestion_job(
                knowledgeBaseId=knowledge_base_id,
                dataSourceId=data_source_id,
                ingestionJobId=ingestion_job_id
            )
            
            # Check if the response indicates success
            if response.get('ResponseMetadata', {}).get('HTTPStatusCode') == 202:
                logger.info(f"Successfully stopped ingestion job: {ingestion_job_id}")
                return True
            else:
                logger.warning(f"Unexpected response when stopping job {ingestion_job_id}: {response}")
                return False
                
        except ClientError as e:
            logger.error(f"AWS API error while stopping ingestion job {ingestion_job_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error while stopping ingestion job {ingestion_job_id}: {e}")
            return False

    def check_and_stop_long_running_job(self, kb_id, data_source_id, ingestion_job_id):
        """
        Check if an ingestion job has been running for more than 30 minutes and stop it if necessary.
        
        Args:
            kb_id: The knowledge base ID
            data_source_id: The data source ID
            ingestion_job_id: The ingestion job ID
            
        Returns:
            dict: Status information about the job check and action taken
        """
        try:
            # Get the current job status
            job_response = self.get_ingestion_job(kb_id, data_source_id, ingestion_job_id)
            
            if "error" in job_response:
                return {"error": "Failed to get job status", "details": job_response["error"]}
            
            ingestion_job = job_response.get('ingestionJob', {})
            status = ingestion_job.get('status')
            started_at = ingestion_job.get('startedAt')
            
            if not started_at:
                return {"error": "No start time found for the job"}
            
            # Calculate time difference
            current_time = datetime.now(timezone.utc)
            
            # Convert started_at to UTC if it's not already
            if started_at.tzinfo is None:
                started_at = started_at.replace(tzinfo=timezone.utc)
            else:
                started_at = started_at.astimezone(timezone.utc)
            
            time_elapsed = current_time - started_at
            max_ingestion_job_duration = timedelta(minutes=CONFIG.MAX_INGESTION_JOB_DURATION_MINUTES)
            
            logger.info(f"Job {ingestion_job_id} status: {status}, elapsed time: {time_elapsed}")
            
            # Check if job is still in progress and has been running for more than the configured duration
            if status == "IN_PROGRESS" and time_elapsed > max_ingestion_job_duration:
                logger.warning(f"Job {ingestion_job_id} has been running for {time_elapsed}. Stopping it.")
                
                stop_result = self.stop_ingestion_job(kb_id, data_source_id, ingestion_job_id)
                
                if stop_result:
                    return {
                        "action": "stopped",
                        "reason": f"Job running for more than {CONFIG.MAX_INGESTION_JOB_DURATION_MINUTES} minutes",
                        "elapsed_time": str(time_elapsed),
                        "status": "success"
                    }
                else:
                    return {
                        "action": "stop_failed",
                        "reason": f"Job running for more than {CONFIG.MAX_INGESTION_JOB_DURATION_MINUTES} minutes",
                        "elapsed_time": str(time_elapsed),
                        "status": "error"
                    }
            else:
                return {
                    "action": "no_action",
                    "status": status,
                    "elapsed_time": str(time_elapsed),
                    "reason": "Job within time limit or not in progress"
                }
                
        except Exception as e:
            logger.error(f"Error checking job status: {e}")
            return {"error": str(e)}