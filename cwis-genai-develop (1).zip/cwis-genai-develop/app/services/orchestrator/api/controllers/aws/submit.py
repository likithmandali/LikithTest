import json
import asyncio
import re
import os
import uuid
from fastapi import Depends, File, UploadFile
from fastapi.responses import JSONResponse
import psycopg2
from helper.custom_errors import GenericError, AttributeNotFoundError, ExternalAPIError, RateLimitError, ForbiddenError, ValidationError
from api.db.instance import InstanceDBController
from api.db.flow import QNAFlowDBController
from api.db.qna_template import QNATemplateDBController

from helper.render_markdown import render_markdownifying_template
from api.schemas.aws.submit import (
    AWSPromptSubmitMessagesStream,
    AWSPromptSubmitStream,
    AWSPromptSubmit,
)
from helper.aws_bedrock_wrapper import AWSBedrockCaller
from api.controllers.aws.aws_bedrock_controller import BedrockRuntimeInvoker


from api.schemas.common.activity import (
    UpdateActivityStatusInternal,
)
from api.db.activity import ActivityDBController, check_activity_metadata_exists

from api.controllers.common.template_sem_search import aws_temp_render_template
from settings.db import get_db_connection
from settings.config import CONFIG
from settings.loguru import logger

from helper.aws_embeddings import AWSBedrockGuardrails
from api.schemas.common.llm_guard import LLMGuardPromptInput
from api.db.guardrails import GuardrailsDBController


class AWSSubmitController:

    @staticmethod
    async def aws_submit_prompt_stream(
        prompt_submit_stream: AWSPromptSubmitStream,
        activity_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            import psycopg2
            from settings.db import CONFIG  # Import your DB config

            # Create a direct connection using the full database URL
            new_db = psycopg2.connect(CONFIG.POSTGRES_URI)
            instance_id = prompt_submit_stream.instance_id
            instance_details = InstanceDBController.get_instance_by_id(
                instance_id, new_db
            )
            if instance_details is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            # Get Template from template table using [Instance ID -> Flow ID -> Template table]
            # Call SmartGPT Core Azure OAI endpoints based on model type
            # return response
            model = prompt_submit_stream.model.value
            logger.debug(f"{model=} {type(model)}")
            input_text = prompt_submit_stream.input_text.replace("\\'", "'")
            logger.debug(f"{input_text=}")
            additional_json_context = prompt_submit_stream.additional_json_context
            include_references = prompt_submit_stream.include_references

            # Step 1 - flow_id = # get from instance table
            flow_id = instance_details.get("flow")
            k_near_chunks = instance_details.get("kNearChunks")
            render_markdown = instance_details.get("renderMarkdown")
            query_expansion = instance_details.get("queryExpansion")
            vector_db = instance_details.get("vectorDb")
            embedding_choice = instance_details.get("embeddingChoice")
            logger.debug(f"{flow_id=}")

            # Step 2 - template = # get from flow table
            flow_details = QNAFlowDBController.get_flow_by_id(flow_id, new_db)
            template_id = flow_details.get("templateId")
            template_details = QNATemplateDBController.get_template_by_id(
                template_id, new_db
            )
            prompt_template = template_details.get("promptTemplate")
            temperature = flow_details.get("temperature")

            # Decise on whether to render markdown or not
            if render_markdown:
                prompt_template = render_markdownifying_template(
                    prompt_template=prompt_template
                )
            logger.debug(f"{template_details=}")
            logger.debug(f"{prompt_template=} {temperature=}")

            if "anthropic" in model:
                prompt_template = AWSBedrockCaller.enhance_model_template(
                    prompt_template
                )

            # Step 3 - Call template parser logic on smartgpt core
            match query_expansion:
                case False:
                    input_prompt = {
                        "prompt_template": prompt_template,
                        "input_text": input_text,
                        "k_near_chunks": k_near_chunks,
                        "additional_json_context": additional_json_context,
                        "include_references": include_references,
                        "vector_db": vector_db,
                        "embedding_choice": embedding_choice,
                        "instance_id": instance_id,
                        "db": new_db,
                    }
                    temp_render_response, semantic_search_output = (
                        aws_temp_render_template(**input_prompt)
                    )
                    # logger.debug(f"Temp render response: {temp_render_response}")
            
            # temp_render_response is now always Claude-ready messages from simplified template rendering
            rendered_template = temp_render_response
            # logger.debug(f"Claude messages from template rendering: {rendered_template}")
            
            # Step 4 - Call LLM API using unified Claude messages method
            token_check = AWSBedrockCaller.check_token_limit(rendered_template, model)
            response_str = ""
            if token_check:
                # Use unified method - no need to check content type since it's always Claude messages
                async for chunk in BedrockRuntimeInvoker.invoke_llm(
                    messages=rendered_template,
                    temperature=temperature,
                    model_id=model,
                    stream=True
                ):
                    response_str += chunk
                    yield chunk
                token_pricing = AWSBedrockCaller.TokenPricing(
                    input_messages=rendered_template,
                    output_messages=response_str,
                    total_pricing=True,
                    model=model,
                )

                # fetch metadata info in activity details if exists
                activity_details = ActivityDBController.get_activity_by_id(
                    activity_id, new_db
                )
                activity_metadata = activity_details.get("metaData")
                if check_activity_metadata_exists(activity_metadata):
                    activity_metadata.append(
                        {"semantic_search_output": semantic_search_output}
                    )
                else:
                    activity_metadata = [
                        {"semantic_search_output": semantic_search_output}
                    ]

                # update activity metadata
                activity_status_update = UpdateActivityStatusInternal(
                    activityId=activity_id,
                    status="Complete",
                    output_text=response_str,
                    meta_data=activity_metadata,
                    input_token_count=token_pricing.get("usage").get(
                        "input_token_count"
                    ),
                    output_token_count=token_pricing.get("usage").get(
                        "output_token_count"
                    ),
                    input_token_cost=token_pricing.get("price").get(
                        "input_token_price"
                    ),
                    output_token_cost=token_pricing.get("price").get(
                        "output_token_price"
                    ),
                    total_cost=token_pricing.get("total_pricing"),
                    llm_model=model,
                )
                activity_response = (
                    ActivityDBController.update_activity_metadata_status(
                        activity_status_update=activity_status_update, db=new_db
                    )
                )
                logger.debug(f"{activity_response=}")

            else:
                raise GenericError(
                    status_code=500,
                    error_message="Token limit exceeded. Please use a larger model!",
                )
        except Exception as err:
            raise err

    @staticmethod
    async def aws_submit_prompt_stream_with_grs(
        prompt_submit: AWSPromptSubmitStream,
        activity_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # Initial setup and validation
            model = prompt_submit.model.value
            input_text = prompt_submit.input_text
            instance_id = prompt_submit.instance_id
            additional_json_context = prompt_submit.additional_json_context
            include_references = prompt_submit.include_references

            # Get instance details and validate
            instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
            if instance_details is None:
                raise AttributeNotFoundError(error_message="Instance not found!")

            # Get configuration details
            flow_id = instance_details.get("flow")
            k_near_chunks = instance_details.get("kNearChunks")
            render_markdown = instance_details.get("renderMarkdown")
            query_expansion = instance_details.get("queryExpansion")
            vector_db = instance_details.get("vectorDb")
            embedding_choice = instance_details.get("embeddingChoice")

            # Get flow and template details
            flow_details = QNAFlowDBController.get_flow_by_id(flow_id, db)
            if not flow_details.get("id"):
                raise AttributeNotFoundError("Flow not found!")
            if not flow_details.get("templateId"):
                raise AttributeNotFoundError("Please provide the valid template!")

            # Get template
            template_id = flow_details.get("templateId")
            template_details = QNATemplateDBController.get_template_by_id(
                template_id, db
            )
            prompt_template = template_details.get("promptTemplate")
            temperature = flow_details.get("temperature")

            # Handle markdown rendering
            if render_markdown:
                prompt_template = render_markdownifying_template(
                    prompt_template=prompt_template
                )

            # Enhance template for Anthropic models
            if "anthropic" in model:
                prompt_template = AWSBedrockCaller.enhance_model_template(
                    prompt_template
                )

            # Template rendering based on query expansion
            match query_expansion:
                case False:
                    input_prompt = {
                        "prompt_template": prompt_template,
                        "input_text": input_text,
                        "k_near_chunks": k_near_chunks,
                        "additional_json_context": additional_json_context,
                        "include_references": include_references,
                        "vector_db": vector_db,
                        "embedding_choice": embedding_choice,
                        "instance_id": instance_id,
                        "db": db,
                    }
                    rendered_template, semantic_search_output = aws_temp_render_template(**input_prompt)

            if instance_details.get("guardrails_id"):
                guardrails_id = instance_details.get("guardrails_id")
                llm_guard = instance_details.get("llmGuard")
                llm_guard_value = instance_details.get("llm_guard_value")
            elif prompt_submit.guardrails_id:
                guardrails_id = prompt_submit.guardrails_id
                llm_guard = True
                llm_guard_value = "aws_bedrock"
            else:
                guardrails_id = None
                llm_guard = False
                llm_guard_value = None

            masked_mappings = None

            if llm_guard:
                activity_grs = ActivityDBController.update_guardrails_id(
                    activity_id=activity_id, guardrails_id=guardrails_id, db=db
                )
                logger.debug(f"{activity_grs=}")
                guardrails_details = GuardrailsDBController.get_guardrails_by_id(guardrails_id, db)
                scanner_configs = guardrails_details.get("scanner_configs")
                if llm_guard_value == "aws_bedrock":
                    # AWS Bedrock Guardrails masking
                    guardrail_id = guardrails_details.get("guardrails_id")
                    prompt_input = LLMGuardPromptInput(
                        prompt=input_text,
                        # prompt=prompt_submit.input_text,
                        instance_id=instance_id,
                    )
                    try:
                        llm_guard_response = AWSBedrockGuardrails.bedrock_guardrails_input(
                            input_text=prompt_input.prompt,
                            g_id=guardrail_id,
                            service_name="aws_submit_prompt_stream_with_grs",
                            db=db,
                        )
                        if llm_guard_response.get("sanitized_prompt"):
                            masked_mappings = llm_guard_response.get("masked_mappings")
                            
                            # Update text content in Claude messages format
                            for message in rendered_template:
                                if "content" in message and isinstance(message["content"], list):
                                    for content_item in message["content"]:
                                        if content_item.get("type") == "text" and "text" in content_item:
                                            if input_text in content_item["text"]:
                                                content_item["text"] = content_item["text"].replace(
                                                    input_text,
                                                    " " + llm_guard_response.get("sanitized_prompt"),
                                                )
                            
                            sanitized_message = llm_guard_response.get("sanitized_prompt")
                            logger.critical(f"Updating the input text with sanitized prompt------- {sanitized_message}")
                            logger.debug(f"Updating template with sanitized prompt------- {rendered_template}")
                    except Exception as err:
                        if hasattr(err, "error_message"):
                            raise ExternalAPIError(error_message=f"{err.error_message}")
                        raise ExternalAPIError(error_message="LLM Guard validation failed!")
            # Token limit check - extract text content from Claude messages for counting
            text_for_token_check = ""
            for message in rendered_template:
                if "content" in message and isinstance(message["content"], list):
                    for content_item in message["content"]:
                        if content_item.get("type") == "text" and "text" in content_item:
                            text_for_token_check += content_item["text"] + " "
            token_check = AWSBedrockCaller.check_token_limit(rendered_template, model)
            if not token_check:
                raise GenericError(
                    status_code=500,
                    error_message="Token limit exceeded. Please use a larger model!",
                )
            # Stream response with real-time unmasking
            async def stream_response():
                import psycopg2
                from settings.db import CONFIG  # Import your DB config

                logger.debug("Creating new DB connection...")
                # Create a direct connection that won't be managed by FastAPI
                new_db = new_db = psycopg2.connect(CONFIG.POSTGRES_URI)
                response_str = ""
                # yield json.dumps({"metadata": True, "sanitized_prompt": rendered_template}) + "\n\n"

                if llm_guard and llm_guard_value == "aws_bedrock" and masked_mappings:
                    # For AWS Bedrock Guardrails with real-time unmasking
                    try:
                        async for chunk in BedrockRuntimeInvoker.invoke_llm(
                            messages=rendered_template,
                            temperature=temperature,
                            model_id=model,
                            stream=True
                        ):
                            response_str += chunk
                            # Unmask each chunk before yielding
                            try:
                                unmasking_output = {
                                    "text": chunk,
                                    "masked_mappings": masked_mappings,
                                }
                                unmasked_response = AWSBedrockGuardrails.unmask_placeholders_for_streaming(unmasking_output)
                                yield unmasked_response.get("text", chunk)
                            except Exception as e:
                                logger.error(f"Error in unmasking chunk: {str(e)}")
                                yield chunk
                    except RateLimitError as rate_error:
                        # Send rate limit error as a special stream event
                        logger.error(f"Rate limit error in streaming with masking: {rate_error}")
                        # raise rate_error
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "rate_limit",
                            "error_code": 429,
                            "error_message": str(rate_error.error_message),
                            "retry_after": 60  # Suggest retry after 60 seconds
                        })
                        yield f"System is busy right now. Please try after some time\n\n"
                        return  # End the stream gracefully
                    except ForbiddenError as forbidden_error:
                        # Send forbidden error as a special stream event
                        logger.error(f"Forbidden error in streaming with masking: {forbidden_error}")
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "forbidden",
                            "error_code": 403,
                            "error_message": str(forbidden_error.error_message)
                        })
                        yield f"Forbidden, not accessible\n\n"
                        return  # End the stream gracefully
                    except ValidationError as validation_error:
                        # Send validation error as a special stream event
                        logger.error(f"Validation error in streaming with masking: {validation_error}")
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "validation",
                            "error_code": 400,
                            "error_message": str(validation_error.error_message)
                        })
                        yield f"Facing issues while contacting server. Please try after some time\n\n"
                        return  # End the stream gracefully

                    except GenericError as generic_error:
                        # Send generic error as a special stream event
                        
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "generic",
                            "error_code": generic_error.status_code,
                            "error_message": str(generic_error.error_message)
                        })
                        logger.error(f"Generic error in streaming with masking: {error_event}")
                        yield f"{generic_error.error_message}\n\n"
                        return  # End the stream gracefully
                    except Exception as streaming_error:
                        # Send unexpected error as a special stream event
                        logger.error(f"Unexpected streaming error in BedrockRuntimeInvoker.invoke_llm with masking: {streaming_error}")
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "unexpected",
                            "error_code": 500,
                            "error_message": f"Unexpected streaming error: {str(streaming_error)}"
                        })
                        yield f"Unexpected streaming error: {str(streaming_error)}\n\n"
                        return  # End the stream gracefully
                else:
                    # For standard LLM Guard or no masking
                    try:
                        async for chunk in BedrockRuntimeInvoker.invoke_llm(
                            messages=rendered_template, temperature=temperature, model_id=model, stream=True
                        ):
                            response_str += chunk
                            yield chunk
                    except RateLimitError as rate_error:
                        # Send rate limit error as a special stream event
                        logger.error(f"Rate limit error in streaming: {rate_error}")
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "rate_limit",
                            "error_code": 429,
                            "error_message": str(rate_error.error_message),
                            "retry_after": 60  # Suggest retry after 60 seconds
                        })
                        yield f"System is busy right now. Please try after some time\n\n"
                        return  # End the stream gracefully
                    except ForbiddenError as forbidden_error:
                        # Send forbidden error as a special stream event
                        logger.error(f"Forbidden error in streaming: {forbidden_error}")
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "forbidden",
                            "error_code": 403,
                            "error_message": str(forbidden_error.error_message)
                        })
                        yield f"Forbidden, not accessible\n\n"
                        return  # End the stream gracefully
                    except ValidationError as validation_error:
                        # Send validation error as a special stream event
                        logger.error(f"Validation error in streaming with masking: {validation_error}")
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "validation",
                            "error_code": 400,
                            "error_message": str(validation_error.error_message)
                        })
                        yield f"The system is currently busy. Please try again in a few minutes.\n\n"
                        return  # End the stream gracefully

                    except GenericError as generic_error:
                        # Send generic error as a special stream event
                        
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "generic",
                            "error_code": generic_error.status_code,
                            "error_message": str(generic_error.error_message)
                        })
                        logger.error(f"Generic error in streaming: {error_event}")
                        yield f"{generic_error.error_message}\n\n"
                        return  # End the stream gracefully
                    except Exception as streaming_error:
                        # Send unexpected error as a special stream event
                        logger.error(f"Unexpected streaming error in BedrockRuntimeInvoker.invoke_llm: {streaming_error}")
                        error_event = json.dumps({
                            "error": True,
                            "error_type": "unexpected",
                            "error_code": 500,
                            "error_message": f"Unexpected streaming error: {str(streaming_error)}"
                        })
                        yield f"Unexpected streaming error: {str(streaming_error)}\n\n"
                        return  # End the stream gracefully

                # Calculate token pricing - extract text content from Claude messages
                text_for_pricing = ""
                for message in rendered_template:
                    if "content" in message and isinstance(message["content"], list):
                        for content_item in message["content"]:
                            if content_item.get("type") == "text" and "text" in content_item:
                                text_for_pricing += content_item["text"] + " "
                token_pricing = AWSBedrockCaller.TokenPricing(
                    input_messages=rendered_template,
                    output_messages=response_str,
                    total_pricing=True,
                    model=model,
                )
                # Update activity metadata
                activity_details = ActivityDBController.get_activity_by_id(
                    activity_id, new_db
                )
                logger.debug(f"{activity_details=}")
                activity_metadata = activity_details.get("metaData") or []
                if check_activity_metadata_exists(activity_metadata):
                    activity_metadata.append(
                        {"semantic_search_output": semantic_search_output}
                    )
                else:
                    activity_metadata = [
                        {"semantic_search_output": semantic_search_output}
                    ]

                # Update activity status
                activity_status_update = UpdateActivityStatusInternal(
                    activityId=activity_id,
                    status="Complete",
                    output_text=response_str,
                    meta_data=activity_metadata,
                    input_token_count=token_pricing.get("usage").get(
                        "input_token_count"
                    ),
                    output_token_count=token_pricing.get("usage").get(
                        "output_token_count"
                    ),
                    input_token_cost=token_pricing.get("price").get(
                        "input_token_price"
                    ),
                    output_token_cost=token_pricing.get("price").get(
                        "output_token_price"
                    ),
                    total_cost=token_pricing.get("total_pricing"),
                    llm_model=model,
                )
                logger.debug(f"{activity_status_update=}")
                ActivityDBController.update_activity_metadata_status(
                    activity_status_update=activity_status_update, db=new_db
                )

            return stream_response(), sanitized_message
        except Exception as err:
            logger.error(f"Error in aws_submit_prompt_stream_with_grs: {str(err)}")
            raise err

    @staticmethod
    async def aws_submit_prompt_messages_stream_with_grs(
        aws_prompt_submit_messages: AWSPromptSubmitMessagesStream,
        activity_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            instance_id = aws_prompt_submit_messages.instance_id
            instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
            if instance_details is None:
                raise AttributeNotFoundError(error_message="Instance not found!")

            model_id = aws_prompt_submit_messages.model.value
            additional_json_context = aws_prompt_submit_messages.additional_json_context
            include_references = aws_prompt_submit_messages.include_references

            # Extract messages and system prompt
            messages = [
                message.dict()
                for message in aws_prompt_submit_messages.messages
                if message.role != "system"
            ]
            system_prompt = next(
                (
                    message.content
                    for message in aws_prompt_submit_messages.messages
                    if message.role == "system"
                ),
                None,
            )

            # Get configuration details
            flow_id = instance_details.get("flow")
            k_near_chunks = instance_details.get("kNearChunks")
            render_markdown = instance_details.get("renderMarkdown")
            query_expansion = instance_details.get("queryExpansion")
            vector_db = instance_details.get("vectorDb")
            embedding_choice = instance_details.get("embeddingChoice")

            # Get flow and template details
            flow_details = QNAFlowDBController.get_flow_by_id(flow_id, db)
            if not flow_details.get("id"):
                raise AttributeNotFoundError("Flow not found!")
            if not flow_details.get("templateId"):
                raise AttributeNotFoundError("Please provide the valid template!")

            template_id = flow_details.get("templateId")
            template_details = QNATemplateDBController.get_template_by_id(
                template_id, db
            )
            prompt_template = template_details.get("promptTemplate")
            temperature = flow_details.get("temperature")

            # Handle markdown rendering
            if render_markdown:
                markdown_prompt = """
                You are a helpful assistant who renders the final response in markdown format ensuring that headers,
                subheaders, bulleted points, numbered lists, tables,
                and any other appropriate formatting elements are applied as necessary.
                Add appropriate title size for headers and subheaders.
                But don't add backticks in the start and end, just give the markdown formatted text
                """
                system_prompt = system_prompt + "\n" + markdown_prompt

            # Extract user prompt and apply template rendering
            user_prompt = next((message["content"] for message in reversed(messages)))

            # Template rendering based on query expansion
            match query_expansion:
                case False:
                    input_prompt = {
                        "prompt_template": prompt_template,
                        "input_text": user_prompt,
                        "additional_json_context": additional_json_context,
                        "k_near_chunks": k_near_chunks,
                        "include_references": include_references,
                        "vector_db": vector_db,
                        "embedding_choice": embedding_choice,
                        "instance_id": instance_id,
                        "db": db,
                    }
                    rendered_template, semantic_search_output = aws_temp_render_template(**input_prompt)
            
            # rendered_template is now always Claude-ready messages from simplified template rendering
            logger.debug(f"Claude messages from template rendering: {rendered_template}")
            
            # Update the user prompt with rendered template (which is already in Claude message format)
            for message in reversed(messages):
                if message["role"] == "user":
                    # rendered_template is already a complete Claude message structure
                    # Extract the content part for this specific message update
                    if rendered_template and len(rendered_template) > 0:
                        message["content"] = rendered_template[0]["content"]
                    break

            # LLM Guard masking
            llm_guard = instance_details.get("llmGuard")
            guardrails_id = instance_details.get("guardrails_id")
            guardrails_details = GuardrailsDBController.get_guardrails_by_id(
                guardrails_id, db
            )
            scanner_configs = guardrails_details.get("scanner_configs")
            masked_mappings = None
            sanitized_message = None

            if llm_guard:
                if instance_details.get("llm_guard_value") == "aws_bedrock":
                    guardrail_id = guardrails_details.get("guardrails_id")
                    # guardrail_id = instance_details.get("aws_guardrail_id")
                    llm_guard_input = ""
                    user_contents = [
                        message.content
                        for message in aws_prompt_submit_messages.messages
                        if message.role == "user"
                    ]
                    llm_guard_input = " <SEP> ".join(user_contents)

                    prompt_input = LLMGuardPromptInput(
                        prompt=llm_guard_input,
                        instance_id=instance_id,
                    )

                    logger.info(f"{prompt_input=}")
                    try:
                        llm_guard_response = AWSBedrockGuardrails.bedrock_guardrails_input(
                            input_text=prompt_input.prompt,
                            g_id=guardrail_id,
                            service_name="aws_submit_prompt_messages_stream_with_grs",
                            db=db,
                        )
                    except Exception as err:
                        if hasattr(err, "error_message"):
                            raise ExternalAPIError(error_message=f"{err.error_message}")
                        else:
                            raise ExternalAPIError(
                                error_message="LLM Guard validation failed!"
                            )

                logger.critical(f"AWS LLM GUARD RESPOPNSE -------{llm_guard_response}")
                if llm_guard_response.get("sanitized_prompt"):
                    sanitized_prompt = llm_guard_response.get("sanitized_prompt")
                    masked_mappings = llm_guard_response.get("masked_mappings")
                    # Extract the message content and update message list
                    sanitized_prompt_list = sanitized_prompt.split(" <SEP> ")
                    logger.critical(
                        f"Sanitized prompt parts------- length: {len(sanitized_prompt_list)}"
                    )
                    if instance_details.get("llm_guard_value") == "aws_bedrock":
                        # Find the number of 'user' contents in the original list
                        user_contents_count = sum(
                            1 for item in messages if item["role"] == "user"
                        )
                        logger.critical(
                            f"User prompt parts------- count: {user_contents_count}"
                        )
                        final_index = 0
                        for item in messages:
                            if (
                                item["role"] == "user"
                                and final_index < user_contents_count
                            ):
                                # Check if the index is valid before accessing the list
                                if final_index < len(sanitized_prompt_list):
                                    item["content"] = sanitized_prompt_list[final_index]
                                    final_index += 1
                                else:
                                    logger.warning(
                                        f"Index {final_index} out of range for sanitized_prompt_list with length {len(sanitized_prompt_list)}"
                                    )
                        final_sanitized_query = messages[-1].get("content")
                        final_original_query = aws_prompt_submit_messages.messages[
                            -1
                        ].content

                        # Handle masking for Claude message format
                        # Update text content in the rendered template
                        for message in rendered_template:
                            if "content" in message and isinstance(message["content"], list):
                                for content_item in message["content"]:
                                    if content_item.get("type") == "text" and "text" in content_item:
                                        if final_original_query in content_item["text"]:
                                            content_item["text"] = content_item["text"].replace(
                                                final_original_query, " " + final_sanitized_query
                                            )
                        
                        logger.info(f"NEW RENDERED TEMPLATE WITH SANITIZED PROMPT {rendered_template=}")
                        
                        # Update the user prompt with rendered template (extract content from Claude message format)
                        for message in reversed(messages):
                            if message["role"] == "user":
                                if rendered_template and len(rendered_template) > 0:
                                    message["content"] = rendered_template[0]["content"]
                                break

                        sanitized_message = messages[-1].get("content")
                        logger.info(
                            f"ADDING NEW RENDERED TEMPLATE TO MESSAGES {messages}"
                        )
                    else:
                        final_sanitized_query = ""
                        sanitized_prompt_list[-1] = sanitized_prompt_list[-1].split(
                            " <SEP> "
                        )[0]
                        logger.info(f"{sanitized_prompt_list=}")
                        for i, message in enumerate(messages):
                            message["content"] = sanitized_prompt_list[i]
                        sanitized_message = messages[-1].get("content")
                        logger.debug(
                            f"Updating the input text with sanitized prompt {sanitized_prompt}"
                        )
                        logger.debug(f" {sanitized_message}")

                else:
                    llm_guard_message = llm_guard_response.get("response_message")
                    activity_status_update = UpdateActivityStatusInternal(
                        activityId=activity_id,
                        status="Failed",
                        output_text=llm_guard_message,
                    )
                    activity_response = (
                        ActivityDBController.update_activity_metadata_status(
                            activity_status_update=activity_status_update, db=db
                        )
                    )
                    logger.debug(f"{activity_response=}")
                    return {"llm_response": llm_guard_message}
            logger.debug(f"{messages=}")

# Token limit check - extract text content from Claude messages for counting
            text_for_token_check = ""
            for message in rendered_template:
                if "content" in message and isinstance(message["content"], list):
                    for content_item in message["content"]:
                        if content_item.get("type") == "text" and "text" in content_item:
                            text_for_token_check += content_item["text"] + " "
            token_check = AWSBedrockCaller.check_token_limit(text_for_token_check, model)
            if not token_check:
                error_message = "Token limit exceeded. Please use a larger model!"
                # Update activity status
                activity_status_update = UpdateActivityStatusInternal(
                    activityId=activity_id,
                    status="Failed",
                    output_text=error_message,
                )
                ActivityDBController.update_activity_metadata_status(
                    activity_status_update=activity_status_update, db=db
                )
                raise GenericError(status_code=500, error_message=error_message)

            # # Stream response with real-time unmasking
            async def create_stream_generator():
                try:
                    import psycopg2
                    from settings.db import CONFIG  # Import your DB config

                    # Create a direct connection using the full database URL
                    new_db = psycopg2.connect(CONFIG.POSTGRES_URI)
                    # Stream response with real-time unmasking
                    response_str = ""

                    # Filter out any messages with empty content right before streaming
                    filtered_messages = [
                        message
                        for message in messages
                        if message.get("content", "").strip() != ""
                    ]
                    if not filtered_messages or not any(
                        msg.get("role") == "user" for msg in filtered_messages
                    ):
                        error_message = "No valid user messages after content filtering"

                        activity_status_update = UpdateActivityStatusInternal(
                            activityId=activity_id,
                            status="Failed",
                            output_text=error_message,
                        )
                        ActivityDBController.update_activity_metadata_status(
                            activity_status_update=activity_status_update, db=new_db
                        )
                        raise GenericError(status_code=500, error_message=error_message)

                    if (
                        llm_guard
                        and instance_details.get("llm_guard_value") == "aws_bedrock"
                        and masked_mappings
                    ):
                        # For AWS Bedrock Guardrails with real-time unmasking
                        async for (
                            chunk
                        ) in BedrockRuntimeInvoker.invoke_llm(
                            messages=filtered_messages,
                            temperature=temperature,
                            model_id=model_id,
                            system_prompt=system_prompt,
                            stream=True
                        ):
                            response_str += chunk
                            try:
                                unmasking_output = {
                                    "text": chunk,
                                    "masked_mappings": masked_mappings,
                                }
                                unmasked_response = AWSBedrockGuardrails.unmask_placeholders_for_streaming(
                                    unmasking_output
                                )
                                yield unmasked_response.get("text", chunk)
                            except Exception as e:
                                logger.error(f"Error in unmasking chunk: {str(e)}")
                                yield chunk

                    else:
                        # For standard LLM Guard or no masking
                        async for (
                            chunk
                        ) in BedrockRuntimeInvoker.invoke_llm(
                            messages=messages,
                            temperature=temperature,
                            model_id=model_id,
                            system_prompt=system_prompt,
                            stream=True
                        ):
                            response_str += chunk

                            yield chunk

                    # Calculate token pricing
                    token_pricing = AWSBedrockCaller.TokenPricing(
                        input_messages=messages,
                        output_messages=response_str,
                        total_pricing=True,
                        model=model_id,
                    )

                    # Update activity metadata
                    activity_details = ActivityDBController.get_activity_by_id(
                        activity_id, new_db
                    )
                    activity_metadata = activity_details.get("metaData") or []
                    semantic_search_output.update({"llm_messages": messages})
                    if check_activity_metadata_exists(activity_metadata):
                        activity_metadata.append(
                            {"semantic_search_output": semantic_search_output}
                        )
                    else:
                        activity_metadata = [
                            {"semantic_search_output": semantic_search_output}
                        ]

                    # Update activity status
                    activity_status_update = UpdateActivityStatusInternal(
                        activityId=activity_id,
                        status="Complete",
                        output_text=response_str,
                        meta_data=activity_metadata,
                        input_token_count=token_pricing.get("usage").get(
                            "input_token_count"
                        ),
                        output_token_count=token_pricing.get("usage").get(
                            "output_token_count"
                        ),
                        input_token_cost=token_pricing.get("price").get(
                            "input_token_price"
                        ),
                        output_token_cost=token_pricing.get("price").get(
                            "output_token_price"
                        ),
                        total_cost=token_pricing.get("total_pricing"),
                        llm_model=model_id,
                    )
                    ActivityDBController.update_activity_metadata_status(
                        activity_status_update=activity_status_update, db=new_db
                    )

                except Exception as err:
                    logger.error(f"Error in stream_response: {str(err)}")
                    raise err

            return create_stream_generator(), final_sanitized_query  # sanitized_message

        except Exception as err:
            logger.error(f"Error in aws_submit_prompt_messages_stream_with_grs: {str(err)}")
            raise err

    @staticmethod
    async def submit_prompt_streaming(
        messages: list,
        model: str,
        temperature: float,
        prompt_template: str,
        aws_guardrails_id: str = None,  # Accept direct AWS guardrails ID instead of guardrails_id
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # Apply guardrails if aws_guardrails_id is provided
            masked_mappings = None
            sanitized_message = None

            if aws_guardrails_id:
                # Combine message content for guardrails processing
                llm_guard_input = ""
                for message in messages:
                    if message.get("role") == "user":
                        llm_guard_input += message.get("content", "")
                        llm_guard_input += " <SEP> "

                if llm_guard_input:
                    try:
                        # Process with AWS Bedrock guardrails using direct ID
                        prompt_input = LLMGuardPromptInput(
                            prompt=llm_guard_input,
                            instance_id=None,  # Pass-through API doesn't have instance_id
                        )

                        llm_guard_response = (
                            AWSBedrockGuardrails.bedrock_guardrails_input(
                                input_text=prompt_input.prompt,
                                g_id=aws_guardrails_id,  # Use the directly provided ID
                                service_name="aws_submit_prompt_streaming",
                                db=db,
                            )
                        )

                        if llm_guard_response.get("sanitized_prompt"):
                            sanitized_prompt = llm_guard_response.get(
                                "sanitized_prompt"
                            )
                            masked_mappings = llm_guard_response.get("masked_mappings")

                            # Extract sanitized content parts
                            sanitized_prompt_list = sanitized_prompt.split(" <SEP> ")

                            # Update messages with sanitized content
                            user_content_index = 0
                            for i, message in enumerate(messages):
                                if message.get("role") == "user":
                                    if user_content_index < len(sanitized_prompt_list):
                                        messages[i]["content"] = sanitized_prompt_list[
                                            user_content_index
                                        ]
                                        user_content_index += 1

                            sanitized_message = (
                                messages[-1].get("content") if messages else None
                            )
                            logger.debug(
                                f"Sanitized message after guardrails: {sanitized_message}"
                            )
                        else:
                            # If guardrails blocked the content, return error message
                            llm_guard_message = llm_guard_response.get(
                                "response_message", "Content blocked by guardrails"
                            )
                            yield llm_guard_message
                            return

                    except Exception as err:
                        logger.error(f"Error in AWS guardrails processing: {str(err)}")
                        # Continue with original messages if guardrails processing fails

            logger.debug(f"{prompt_template=}")
            response_data = ""

            # Handle streaming with guardrails unmasking if needed
            if masked_mappings:
                # For AWS Bedrock Guardrails with real-time unmasking
                async for chunk in AWSBedrockCaller.message_stream(
                    messages, temperature, model, system_prompt=prompt_template
                ):
                    response_data += chunk
                    # Unmask each chunk before yielding
                    try:
                        unmasking_output = {
                            "text": chunk,
                            "masked_mappings": masked_mappings,
                        }
                        unmasked_response = (
                            AWSBedrockGuardrails.unmask_placeholders_for_streaming(
                                unmasking_output
                            )
                        )
                        yield unmasked_response.get("text", chunk)
                    except Exception as e:
                        logger.error(f"Error in unmasking chunk: {str(e)}")
                        yield chunk
            else:
                # Standard streaming without unmasking
                async for chunk in AWSBedrockCaller.message_stream(
                    messages, temperature, model, system_prompt=prompt_template
                ):
                    response_data += chunk
                    yield chunk
            token_pricing = AWSBedrockCaller.TokenPricing(
                input_messages=messages,
                output_messages=response_data,
                total_pricing=True,
                model=model,
            )
            logger.debug(f"{token_pricing=}")

            # activity_update_with_costs = (
            #     await AWSSubmitController.create_activity_with_costs_pass_through_apis_streaming(
            #         user_id=userId,
            #         response=response_data,
            #         model=model,
            #         input_text=messages,
            #         activity_type=activitytype,
            #         token_pricing=token_pricing,
            #         project_id=projectid,
            #         application_id=applicationid,
            #         guardrails_id=aws_guardrails_id,  # Pass-through API uses direct ID
            #         db=db,
            #     )
            # )
            # logger.debug(f"{activity_update_with_costs=}")
        except Exception as err:
            raise err