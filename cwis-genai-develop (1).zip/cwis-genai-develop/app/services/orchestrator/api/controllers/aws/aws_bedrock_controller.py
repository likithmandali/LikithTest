import asyncio
import json
import boto3 as boto
from botocore.exceptions import ClientError
import tiktoken
import random
import time
from functools import wraps
from helper.custom_errors import GenericError, RateLimitError, ForbiddenError, ValidationError
from api.schemas.aws.submit import AWSBedrockModel, ModelParams
from settings.config import CONFIG
from settings.loguru import logger
from botocore.config import Config
from utils.param_validator import ensure_claude_v4_arn


def retry_with_exponential_backoff_and_jitter(max_retries: int = 5, base_delay: float = 0.1, max_delay: float = 60.0):
    """
    Decorator that implements retry logic with exponential backoff and jitter for handling throttling exceptions.
    
    Args:
        max_retries: Maximum number of retry attempts (default: 5)
        base_delay: Base delay in seconds for the first retry (default: 0.1)
        max_delay: Maximum delay in seconds (default: 60.0)
    """
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    if asyncio.iscoroutinefunction(func):
                        return await func(*args, **kwargs)
                    else:
                        return func(*args, **kwargs)
                except ClientError as e:
                    error_code = e.response.get('Error', {}).get('Code', '')
                    
                    # Check if this is a throttling exception that should be retried
                    if error_code in ['ThrottlingException', 'TooManyRequestsException', 'ServiceQuotaExceededException']:
                        if retries >= max_retries - 1:
                            logger.error(f"Max retries ({max_retries}) reached for {func.__name__}. Error: {str(e)}")
                            raise RateLimitError(error_message=f"AWS Bedrock API rate limit exceeded. Service is temporarily throttled. Please try again later.")
                        
                        # Calculate delay with exponential backoff and jitter
                        exponential_delay = min(base_delay * (2 ** retries), max_delay)
                        jitter = random.uniform(0, exponential_delay * 0.1)  # Add up to 10% jitter
                        total_delay = exponential_delay + jitter
                        
                        logger.warning(
                            f"Throttling detected in {func.__name__} (attempt {retries + 1}/{max_retries}). "
                            f"Retrying in {total_delay:.2f} seconds. Error: {str(e)}"
                        )
                        
                        await asyncio.sleep(total_delay)
                        retries += 1
                    else:
                        # For non-throttling errors, don't retry
                        logger.error(f"Non-retryable error in {func.__name__}: {str(e)}")
                        raise e
                except Exception as e:
                    # For non-ClientError exceptions, don't retry
                    logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
                    raise e
            
            # This should never be reached, but just in case
            raise Exception(f"Retry decorator failed after {max_retries} attempts")
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except ClientError as e:
                    error_code = e.response.get('Error', {}).get('Code', '')
                    
                    # Check if this is a throttling exception that should be retried
                    if error_code in ['ThrottlingException', 'TooManyRequestsException', 'ServiceQuotaExceededException']:
                        if retries >= max_retries - 1:
                            logger.error(f"Max retries ({max_retries}) reached for {func.__name__}. Error: {str(e)}")
                            raise RateLimitError(error_message=f"AWS Bedrock API rate limit exceeded. Service is temporarily throttled. Please try again later.")
                        
                        # Calculate delay with exponential backoff and jitter
                        exponential_delay = min(base_delay * (2 ** retries), max_delay)
                        jitter = random.uniform(0, exponential_delay * 0.1)  # Add up to 10% jitter
                        total_delay = exponential_delay + jitter
                        
                        logger.warning(
                            f"Throttling detected in {func.__name__} (attempt {retries + 1}/{max_retries}). "
                            f"Retrying in {total_delay:.2f} seconds. Error: {str(e)}"
                        )
                        
                        time.sleep(total_delay)
                        retries += 1
                    else:
                        # For non-throttling errors, don't retry
                        logger.error(f"Non-retryable error in {func.__name__}: {str(e)}")
                        raise e
                except Exception as e:
                    # For non-ClientError exceptions, don't retry
                    logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
                    raise e
            
            # This should never be reached, but just in case
            raise Exception(f"Retry decorator failed after {max_retries} attempts")
        
        # Return the appropriate wrapper based on whether the function is async
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


class BedrockRuntimeInvoker:
    """This helps to Invoke the Bedrock runtime wrapper functionalities"""

    async def invoke(
        message: str,
        temperature: float,
        model_id: str,
        stream: bool = False,
        modelParams: ModelParams = ModelParams(),
    ):
        logger.debug(f"Invoking: {model_id}")
        logger.debug(f"message: {message}")

        wrapper = BedrockRuntimeWrapper()

        try:
            if model_id in (
                AWSBedrockModel.CLAUDE_V2_100K.value,
                AWSBedrockModel.CLAUDE_V2_1_200K.value,
            ):
                completion = wrapper.invoke_claude(model_id, message, temperature, modelParams, stream)

            elif model_id in (
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET_v2.value,
                AWSBedrockModel.AWS_CLAUDE_V37_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET.value,
                
            ):
                model_id = ensure_claude_v4_arn(model_id)
                if stream:
                    completion = wrapper.invoke_claude_messages_api_stream(
                        model_id,
                        [{"role": "user", "content": message}],
                        temperature,
                        None,
                        modelParams,
                    )
                else:
                    completion = wrapper.invoke_claude_messages_yield(
                        model_id,
                        [{"role": "user", "content": message}],
                        temperature,
                        None,
                        modelParams,
                    )

            elif model_id in (
                AWSBedrockModel.TITAN_TEXT_G1_EXPRESS.value,
                AWSBedrockModel.TITAN_TEXT_G1_PREMIER.value,
                AWSBedrockModel.TITAN_TEXT_LITE.value
            ):
                completion = wrapper.invoke_bedrock_titan_express(model_id, message, temperature, modelParams, stream)

            elif model_id == AWSBedrockModel.TITAN_MULTIMODAL_EMBED_V1.value:
                completion = wrapper.invoke_titan_multimodal_embeddings(model_id, message, modelParams)

            else:
                raise GenericError(
                    status_code=500,
                    error_message=f"""Given Model Id {model_id} is not been supported. Please check the right Id and
                    try again""",
                )

            if stream:
                async for chunk in completion:
                    await asyncio.sleep(0.01)
                    yield chunk
            else:
                yield completion

        except ClientError as e:
            logger.exception("Couldn't invoke model %s", model_id)
            raise GenericError(status_code=500, error_message=str(e))

    def messages_api_invoke(
        message: list,
        temperature: float,
        model_id: str,
        system_prompt: str | None = None,
        modelParams: ModelParams = ModelParams(),
    ):
        logger.debug(f"Invoking: {model_id}")
        logger.debug(f"message: {message}")

        wrapper = BedrockRuntimeWrapper()

        try:
            if model_id in (
                AWSBedrockModel.CLAUDE_V2_100K.value,
                AWSBedrockModel.CLAUDE_V2_1_200K.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET_v2.value,
                AWSBedrockModel.AWS_CLAUDE_V37_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET.value,
            ):
                model_id = ensure_claude_v4_arn(model_id)

                completion = wrapper.invoke_claude_messages_api(
                    model_id, message, temperature, system_prompt, modelParams
                )
                return completion
            elif model_id in (
                AWSBedrockModel.TITAN_TEXT_G1_EXPRESS.value,
                AWSBedrockModel.TITAN_TEXT_G1_PREMIER.value,
                AWSBedrockModel.TITAN_TEXT_LITE.value
            ):
                completion = wrapper.invoke_titan_text_api(
                    model_id, message, temperature, system_prompt, modelParams
                )
                return completion
            else:
                raise GenericError(
                    status_code=500,
                    error_message=f"""Given Model Id {model_id} is not been supported. Please check the right Id and
                    try again""",
                )

        except ClientError as e:
            logger.exception("Couldn't invoke model %s", model_id)
            raise GenericError(status_code=500, error_message=str(e))

    async def messages_api_invoke_stream(
        message: list,
        temperature: float,
        model_id: str,
        system_prompt: str | None = None,
        modelParams: ModelParams = ModelParams(),
    ):
        logger.debug(f"Invoking: {model_id}")
        logger.debug(f"message: - {message}")

        wrapper = BedrockRuntimeWrapper()

        try:
            if model_id in (
                AWSBedrockModel.CLAUDE_V2_100K.value,
                AWSBedrockModel.CLAUDE_V2_1_200K.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET_v2.value,
                AWSBedrockModel.AWS_CLAUDE_V37_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN.value,
            ):
                model_id = ensure_claude_v4_arn(model_id)

                async for completion in wrapper.invoke_claude_messages_api_stream(
                    model_id, message, temperature, system_prompt, modelParams
                ):
                    await asyncio.sleep(0.01)
                    yield completion
            else:
                raise GenericError(
                    status_code=500,
                    error_message=f"""Given Model Id {model_id} is not been supported. Please check the right Id and
                    try again""",
                )

        except ClientError as e:
            logger.exception("Couldn't invoke model %s", model_id)
            raise GenericError(status_code=500, error_message=str(e))


    @staticmethod
    async def invoke_llm(
        messages: list,
        temperature: float,
        model_id: str,
        stream: bool = True,
        system_prompt: str | None = None,
        modelParams: ModelParams = ModelParams()
    ):
        """
        Unified method to invoke Claude with messages (text-only or mixed content).
        This replaces both invoke() and invoke_with_mixed_content() for the simplified pipeline.
        
        :param messages: Claude-ready message list from template rendering
        :param temperature: Temperature for response generation
        :param model_id: The model ID to use
        :param stream: Whether to stream the response
        :param system_prompt: Optional system prompt
        :param modelParams: Model parameters
        :return: Async generator yielding response chunks
        """
        logger.debug(f"Invoking Claude with unified method: {model_id}")
        # logger.debug(f"messages: {json.dumps(messages, indent=2, default=str)}")
        
        wrapper = BedrockRuntimeWrapper()
        try:
            if model_id in (
                AWSBedrockModel.CLAUDE_V2_100K.value,
                AWSBedrockModel.CLAUDE_V2_1_200K.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET_v2.value,
                AWSBedrockModel.AWS_CLAUDE_V37_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN.value,
            ):
                model_id = ensure_claude_v4_arn(model_id)
                if stream:
                    async for completion in wrapper.invoke_claude_messages_api_stream_for_mixed_content(
                        model_id, messages, temperature, system_prompt, modelParams
                    ):
                        await asyncio.sleep(0.01)
                        yield completion
                else:
                    completion = wrapper.invoke_claude_messages_api(
                        model_id, messages, temperature, system_prompt, modelParams
                    )
                    yield completion
            elif model_id in (
                AWSBedrockModel.TITAN_TEXT_G1_PREMIER.value,
                AWSBedrockModel.TITAN_TEXT_G1_EXPRESS.value,

            ):
                if stream:
                    async for completion in wrapper.invoke_titan_text_api_stream(
                        model_id, messages, temperature, system_prompt, modelParams
                    ):
                        await asyncio.sleep(0.01)
                        yield completion
                else:
                    completion = wrapper.invoke_titan_text_api(
                        model_id, messages, temperature, system_prompt, modelParams
                    )
                    yield completion
            else:
                raise GenericError(
                    status_code=400,
                    error_message=f"Model {model_id} not supported by unified Claude messages method. Please use Claude models.",
                )

        except Exception as e:
            logger.error(f"ClientError occurred while invoking Claude model: {e}")
            raise e


class BedrockRuntimeWrapper:
    """Encapsulates Amazon Bedrock Runtime actions."""

    def __init__(self):
        """
        :param bedrock_runtime_client: A low-level client representing Amazon Bedrock Runtime.
                                       Describes the API operations for running inference using
                                       Bedrock models.
        """
        self.claude_sonnet_4_max_output_tokens = CONFIG.CLAUDE_SONNET_4_MAX_OUTPUT_TOKENS
        
        # Configure retry settings with adaptive retry mode and higher max attempts
        retry_config = Config(
            retries={
                'max_attempts': 8,  # Increased from default 3
                'mode': 'adaptive'  # Use adaptive retry mode for better handling of throttling
            },
            # Add connection timeout and read timeout
            connect_timeout=60,
            read_timeout=300
        )
        
        if CONFIG.LOCAL_TESTING:
            self.bedrock_runtime_client = boto.client(
                "bedrock-runtime",
                region_name=CONFIG.AWS_REGION,
                aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                config=retry_config
            )
        else:
            self.bedrock_runtime_client = boto.client(
                "bedrock-runtime",
                region_name=CONFIG.AWS_REGION,
                config=retry_config
            )
        

    def tokenizer(self, input_str: str):
        encoding = tiktoken.encoding_for_model("text-davinci-003")
        encoded = encoding.encode(input_str)
        return len(encoded)

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_claude(
        self,
        model_id,
        prompt: str,
        temperature: float = 0.5,
        modelParams: ModelParams = ModelParams(),
        stream: bool = False,
    ):
        """
        Invokes the Anthropic Claude models to run an inference using the input
        provided in the request body.

        :param prompt: The prompt that you want Claude to complete.
        :return: Inference response from the model.
        """

        try:
            # Claude requires you to enclose the prompt as follows:
            enclosed_prompt = "Human: " + prompt + "\n\nAssistant:"

            logger.debug(f"Claude prompt template - {enclosed_prompt}")

            prompt_tokens = self.tokenizer(enclosed_prompt)

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "prompt": enclosed_prompt,
                "max_tokens_to_sample": self.claude_sonnet_4_max_output_tokens,
                "temperature": temperature,
                "top_p": modelParams.top_p,
            }

            if stream:
                async for chunk in self.invoke_model_with_response_stream(modelId=model_id, body=json.dumps(body)):
                    await asyncio.sleep(0.01)
                    yield chunk

            else:
                response = self.bedrock_runtime_client.invoke_model(modelId=model_id, body=json.dumps(body))
                response_body = json.loads(response["body"].read())

                response_tokens = self.tokenizer(response_body["completion"])

                completion = {
                    "response": {
                        "output": response_body["completion"],
                        "usage": {
                            "prompt_tokens": prompt_tokens,
                            "completion_tokens": response_tokens,
                            "total_tokens": (prompt_tokens + response_tokens),
                        },
                    }
                }
                logger.debug(f"Response from claude llm - {completion}")

                # completion = response_body["completion"]
                yield completion

        except ClientError as e:
            logger.error(f"Couldn't invoke Anthropic Claude. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    def invoke_claude_messages_api(
        self,
        model_id,
        messages,
        temperature: float = 0.5,
        system_prompt: str | None = None,
        modelParams: ModelParams = ModelParams(),
    ):
        """
        Invokes the Anthropic Claude models to run an inference using the input
        provided in the request body.

        :param prompt: The prompt that you want Claude to complete.
        :return: Inference response from the model.
        """

        try:
            if system_prompt is None:
                system_prompt = """You are Claude, an useful AI assistant to be helpful,
                            harmless, and honest. Your goal is to provide informative and substantive responses
                            to queries while avoiding potential harms."""
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.claude_sonnet_4_max_output_tokens,
                "temperature": temperature,
                "top_p": modelParams.top_p,
                "system": system_prompt,
                "messages": messages,
            }
            response = self.bedrock_runtime_client.invoke_model(modelId=model_id, body=json.dumps(body))
            response_body = json.loads(response["body"].read())

            completion = {
                "response": {
                    "output": response_body["content"][0]["text"],
                    "usage": {
                        "prompt_tokens": response_body["usage"]["input_tokens"],
                        "completion_tokens": response_body["usage"]["output_tokens"],
                        "total_tokens": (
                            response_body["usage"]["input_tokens"] + response_body["usage"]["output_tokens"]
                        ),
                    },
                }
            }

            return completion

        except ClientError as e:
            logger.error(f"Couldn't invoke Anthropic Claude. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_claude_messages_yield(
        self,
        model_id,
        messages,
        temperature: float = 0.5,
        system_prompt: str | None = None,
        modelParams: ModelParams = ModelParams(),
    ):
        """
        Invokes the Anthropic Claude 3.5 Sonnet model non-stream with messages and yielding.

        :param prompt: The prompt that you want Claude to complete.
        :return: Inference response from the model.
        """

        try:
            if system_prompt is None:
                system_prompt = """You are Claude, an useful AI assistant to be helpful,
                            harmless, and honest. Your goal is to provide informative and substantive responses
                            to queries while avoiding potential harms."""
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.claude_sonnet_4_max_output_tokens,
                "temperature": temperature,
                "top_p": modelParams.top_p,
                "system": system_prompt,
                "messages": messages,
            }

            response = self.bedrock_runtime_client.invoke_model(modelId=model_id, body=json.dumps(body))

            response_body = json.loads(response["body"].read())

            completion = {
                "response": {
                    "output": response_body["content"][0]["text"],
                    "usage": {
                        "prompt_tokens": response_body["usage"]["input_tokens"],
                        "completion_tokens": response_body["usage"]["output_tokens"],
                        "total_tokens": (
                            response_body["usage"]["input_tokens"] + response_body["usage"]["output_tokens"]
                        ),
                    },
                }
            }

            yield completion

        except ClientError as e:
            logger.error(f"Couldn't invoke Anthropic Claude. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_bedrock_titan_express(
        self,
        model_id,
        prompt,
        temperature: float = 0.0,
        modelParams: ModelParams = ModelParams(),
        stream: bool = False,
    ):
        """
        Invokes the Titan Text G1 - Express large-language model to run an inference
        using the input provided in the request body.

        :param prompt: The prompt that you want Titan Text Express to complete.
        :return: Inference response from the model.
        """

        try:
            body = {
                "inputText": prompt,
                "textGenerationConfig": {
                    "maxTokenCount": 3072,
                    "stopSequences": [],
                    "temperature": temperature,
                    "topP": modelParams.top_p,
                },
            }

            # Model ID - amazon.titan-text-express-v1

            if stream:
                async for chunk in self.invoke_model_with_response_stream(modelId=model_id, body=json.dumps(body)):
                    await asyncio.sleep(0.01)
                    yield chunk
            else:
                response = self.bedrock_runtime_client.invoke_model(modelId=model_id, body=json.dumps(body))

                response_body = json.loads(response["body"].read())
                logger.debug(f"response_body = {response_body}")

                completion = {
                    "response": {
                        "output": response_body["results"][0]["outputText"],
                        "usage": {
                            "prompt_tokens": response_body["inputTextTokenCount"],
                            "completion_tokens": response_body["results"][0]["tokenCount"],
                            "total_tokens": (
                                response_body["inputTextTokenCount"] + response_body["results"][0]["tokenCount"]
                            ),
                        },
                    }
                }

                # completion = response_body["results"][0]["outputText"]

                yield completion

        except ClientError as e:
            logger.error(f"Couldn't invoke bedrock titan model. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_titan_multimodal_embeddings(
        self,
        model_id,
        content,
        modelParams: ModelParams = ModelParams(),
    ):
        """
        Invokes the Titan Multimodal Embeddings G1 model to generate embeddings
        for text, image, or combined input.

        :param model_id: The model ID to use (amazon.titan-embed-image-v1)
        :param content: The content to generate embeddings for
        :param modelParams: Model parameters
        :return: Embeddings response from the model
        """
        try:
            import base64
            
            # Default embedding configuration
            output_embedding_length = 256
            
            # Parse content based on type
            if isinstance(content, str):
                # Text-only input
                body = {
                    "inputText": content,
                    "embeddingConfig": {
                        "outputEmbeddingLength": output_embedding_length
                    }
                }
            elif isinstance(content, dict):
                body = {"embeddingConfig": {"outputEmbeddingLength": output_embedding_length}}
                
                # Handle text input
                if "text" in content:
                    body["inputText"] = content["text"]
                
                # Handle image input
                if "image" in content:
                    # Assume image is already base64 encoded or is a file path
                    if content["image"].startswith("data:"):
                        # Extract base64 data from data URL
                        image_data = content["image"].split(",")[1]
                    elif content["image"].startswith("/") or content["image"].startswith("./"):
                        # File path - encode to base64
                        with open(content["image"], "rb") as image_file:
                            image_data = base64.b64encode(image_file.read()).decode('utf8')
                    else:
                        # Assume it's already base64 encoded
                        image_data = content["image"]
                    
                    body["inputImage"] = image_data
            elif isinstance(content, list):
                # Handle mixed content from messages API
                body = {"embeddingConfig": {"outputEmbeddingLength": output_embedding_length}}
                
                text_parts = []
                image_data = None
                
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") == "text":
                            text_parts.append(item.get("text", ""))
                        elif item.get("type") == "image":
                            # Handle image from mixed content
                            image_source = item.get("source", {})
                            if image_source.get("type") == "base64":
                                image_data = image_source.get("data")
                
                if text_parts:
                    body["inputText"] = " ".join(text_parts)
                if image_data:
                    body["inputImage"] = image_data
            else:
                raise GenericError(
                    status_code=400,
                    error_message="Invalid content format for Titan embeddings"
                )

            logger.debug(f"Titan embeddings body keys: {list(body.keys())}")
            
            response = self.bedrock_runtime_client.invoke_model(
                modelId=model_id, 
                body=json.dumps(body)
            )

            response_body = json.loads(response["body"].read())
            
            # Check for errors in response
            finish_reason = response_body.get("message")
            if finish_reason is not None:
                raise GenericError(
                    status_code=500,
                    error_message=f"Embeddings generation error: {finish_reason}"
                )

            # Format response similar to other models
            completion = {
                "response": {
                    "embeddings": response_body.get("embedding", []),
                    "embedding_length": len(response_body.get("embedding", [])),
                    "usage": {
                        "input_tokens": response_body.get("inputTextTokenCount", 0),
                        "total_tokens": response_body.get("inputTextTokenCount", 0),
                    },
                }
            }

            yield completion

        except ClientError as e:
            logger.error(f"Couldn't invoke Titan multimodal embeddings. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))
        except Exception as e:
            logger.error(f"Error in Titan multimodal embeddings: {e}")
            raise GenericError(status_code=500, error_message=str(e))

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_model_with_response_stream(self, modelId, body):
        """
        Invokes the LLM model to run an inference and process the response stream.

        :param prompt: The prompt that you want Claude to complete.
        :return: Inference response from the model.
        """

        try:
            if modelId in (
                AWSBedrockModel.CLAUDE_V2_100K.value,
                AWSBedrockModel.CLAUDE_V2_1_200K.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V35_SONNET_v2.value,
                AWSBedrockModel.AWS_CLAUDE_V37_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET.value,
                AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN.value,
            ):
                model_id = ensure_claude_v4_arn(model_id)
                response = self.bedrock_runtime_client.invoke_model_with_response_stream(modelId=modelId, body=body)

                for event in response.get("body"):
                    chunk = json.loads(event["chunk"]["bytes"].decode())["completion"]
                    await asyncio.sleep(0.01)
                    yield chunk

            elif modelId in (
                AWSBedrockModel.TITAN_TEXT_G1_EXPRESS.value,
                AWSBedrockModel.TITAN_TEXT_G1_PREMIER.value,
                AWSBedrockModel.TITAN_TEXT_LITE.value
            ):
                response = self.bedrock_runtime_client.invoke_model_with_response_stream(modelId=modelId, body=body)

                for event in response.get("body"):
                    chunk = json.loads(event["chunk"]["bytes"].decode())["outputText"]
                    await asyncio.sleep(0.01)
                    yield chunk

            elif modelId in (
                AWSBedrockModel.AWS_LLAMA_32_1B_INSTRUCT.value,
                AWSBedrockModel.AWS_LLAMA_32_3B_INSTRUCT.value,
                AWSBedrockModel.AWS_LLAMA_32_11B_VISION_INSTRUCT.value,
            ):
                response = self.bedrock_runtime_client.invoke_model_with_response_stream(modelId=modelId, body=body)

                for event in response.get("body"):
                    chunk = json.loads(event["chunk"]["bytes"].decode())["generation"]
                    await asyncio.sleep(0.01)
                    yield chunk

            elif modelId == AWSBedrockModel.AWS_LLAMA_32_90B_VISION_INSTRUCT.value:
                response = self.bedrock_runtime_client.invoke_model_with_response_stream(modelId=modelId, body=body)

                for event in response.get("body"):
                    chunk = json.loads(event["chunk"]["bytes"].decode())["generation"]
                    await asyncio.sleep(0.01)
                    yield chunk

        except Exception as e:
            logger.error(f"Couldn't invoke model with response stream. Error is {e}")
            raise e

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_claude_messages_api_stream(
        self,
        model_id,
        messages,
        temperature: float = 0.5,
        system_prompt: str = None,
        modelParams: ModelParams = ModelParams(),
    ):
        """
        Invokes the Anthropic Claude models to run an inference using the input
        provided in the request body.

        :param prompt: The prompt that you want Claude to complete.
        :return: Inference response from the model.
        """

        try:
            if system_prompt is None:
                system_prompt = """You are Claude, an useful AI assistant to be helpful,
                            harmless, and honest. Your goal is to provide informative and substantive responses
                            to queries while avoiding potential harms."""

            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.claude_sonnet_4_max_output_tokens,
                "temperature": temperature,
                "top_p": modelParams.top_p,
                "system": system_prompt,
                "messages": messages,
            }
            
            response = self.bedrock_runtime_client.invoke_model_with_response_stream(
                modelId=model_id, body=json.dumps(body)
            )
            try:
                for event in response.get("body"):
                    try:
                        logger.debug(f"Response from claude stream is {event}")
                        chunk = json.loads(event["chunk"]["bytes"].decode())
                        if chunk.get("type") == "message_stop":
                            chunk = ""
                        elif chunk.get("message"):
                            chunk = chunk["message"]["content"]
                            if len(chunk) == 0:
                                chunk = ""
                            else:
                                chunk = chunk[0]["text"]
                        elif chunk.get("content_block"):
                            chunk = chunk["content_block"]["text"]
                        elif chunk.get("delta"):
                            if chunk.get("delta").get("stop_reason") == "end_turn":
                                chunk = ""
                            else:
                                chunk = chunk.get("delta").get("text")
                        elif chunk.get("type") == "content_block_stop":
                            chunk = ""
                        logger.debug(f"{chunk=}")
                        await asyncio.sleep(0.01)
                        yield f"{chunk}"
                    except Exception as e:
                        logger.error(f"Error occurred while processing chunk: {e}")
                        continue
            except Exception as e:
                logger.error(f"Error occurred while processing streaming response from Claude model: {e}")
                raise e
        except Exception as e:
            logger.error(f"Error occurred while invoking Claude model: {e}")
            raise e

    
    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_claude_messages_api_stream_for_mixed_content(
        self,
        model_id,
        messages,
        temperature: float = 0.0,
        system_prompt: str = None,
        modelParams: ModelParams = ModelParams(),
    ):
        """
        Invokes the Anthropic Claude models to run an inference using the input
        provided in the request body with mixed content (text + images).
        Messages are already in the proper Claude format from template rendering.

        :param messages: The Claude-ready messages with mixed content
        :return: Inference response from the model.
        """

        try:
            if system_prompt is None:
                system_prompt = """You are Claude, an useful AI assistant to be helpful,
                            harmless, and honest. Your goal is to provide informative and substantive responses
                            to queries while avoiding potential harms."""
            
            # Messages are already validated by template rendering, no additional validation needed
            
            # Properly format the body for AWS Bedrock API
            body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.claude_sonnet_4_max_output_tokens,
                "temperature": temperature,
                "top_p": modelParams.top_p,
                "system": system_prompt,
                "messages": messages,
            }
            
            
            logger.debug(f"Request body for Claude: {json.dumps(body, indent=2, default=str)}")
            # Convert to JSON string as required by AWS Bedrock
            response = self.bedrock_runtime_client.invoke_model_with_response_stream(
                modelId=model_id, body=json.dumps(body)
            )
            
            try:
                for event in response.get("body"):
                    try:
                        logger.debug(f"Response from claude stream is {event}")
                        chunk = json.loads(event["chunk"]["bytes"].decode())
                        if chunk.get("type") == "message_stop":
                            chunk = ""
                        elif chunk.get("message"):
                            chunk = chunk["message"]["content"]
                            if len(chunk) == 0:
                                chunk = ""
                            else:
                                chunk = chunk[0]["text"]
                        elif chunk.get("content_block"):
                            chunk = chunk["content_block"]["text"]
                        elif chunk.get("delta"):
                            if chunk.get("delta").get("stop_reason") == "end_turn":
                                chunk = ""
                            else:
                                chunk = chunk.get("delta").get("text")
                        elif chunk.get("type") == "content_block_stop":
                            chunk = ""
                        logger.debug(f"{chunk=}")
                        await asyncio.sleep(0.01)
                        yield f"{chunk}"
                    except Exception as e:
                        logger.error(f"Error occurred while processing chunk: {e}")
                        continue
            except ClientError as e:
                logger.error(f"Couldn't invoke Anthropic Claude. Error is {e}")
                raise GenericError(status_code=500, error_message=str(e))
        except ClientError as e:
            logger.error(f"Couldn't invoke Anthropic Claude. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    def invoke_titan_text_api(
        self,
        model_id,
        messages,
        temperature: float = 0.5,
        system_prompt: str | None = None,
        modelParams: ModelParams = ModelParams(),
    ):
        """
        Invokes the Titan Text model using messages format.
        Converts messages to simple text format required by Titan.

        :param model_id: The Titan model ID
        :param messages: List of messages (Claude format)
        :param temperature: Temperature for response generation
        :param system_prompt: Optional system prompt
        :param modelParams: Model parameters
        :return: Inference response from the model
        """
        try:
            # Convert messages to simple text prompt
            prompt = self._convert_messages_to_titan_prompt(messages, system_prompt)
            
            # Format the request payload using the model's native structure
            native_request = {
                "inputText": prompt,
                "textGenerationConfig": {
                    "maxTokenCount": 3072,
                    "stopSequences": [],
                    "temperature": temperature,
                    "topP": modelParams.top_p,
                },
            }

            response = self.bedrock_runtime_client.invoke_model(
                modelId=model_id, 
                body=json.dumps(native_request)
            )

            response_body = json.loads(response["body"].read())
            logger.debug(f"Titan response_body = {response_body}")

            completion = {
                "response": {
                    "output": response_body["results"][0]["outputText"],
                    "usage": {
                        "prompt_tokens": response_body["inputTextTokenCount"],
                        "completion_tokens": response_body["results"][0]["tokenCount"],
                        "total_tokens": (
                            response_body["inputTextTokenCount"] + response_body["results"][0]["tokenCount"]
                        ),
                    },
                }
            }

            return completion

        except ClientError as e:
            logger.error(f"Couldn't invoke Titan text model. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))

    @retry_with_exponential_backoff_and_jitter(max_retries=5, base_delay=1.0, max_delay=60.0)
    async def invoke_titan_text_api_stream(
        self,
        model_id,
        messages,
        temperature: float = 0.5,
        system_prompt: str | None = None,
        modelParams: ModelParams = ModelParams(),
    ):
        """
        Invokes the Titan Text model using messages format with streaming.
        Converts messages to simple text format required by Titan.

        :param model_id: The Titan model ID
        :param messages: List of messages (Claude format)
        :param temperature: Temperature for response generation
        :param system_prompt: Optional system prompt
        :param modelParams: Model parameters
        :return: Async generator yielding response chunks
        """
        try:
            # Convert messages to simple text prompt
            prompt = self._convert_messages_to_titan_prompt(messages, system_prompt)
            
            # Format the request payload using the model's native structure
            native_request = {
                "inputText": prompt,
                "textGenerationConfig": {
                    "maxTokenCount": 3072,
                    "stopSequences": [],
                    "temperature": temperature,
                    "topP": modelParams.top_p,
                },
            }

            logger.debug(f"Titan streaming request: {native_request}")

            response = self.bedrock_runtime_client.invoke_model_with_response_stream(
                modelId=model_id, 
                body=json.dumps(native_request)
            )

            for event in response.get("body"):
                chunk = json.loads(event["chunk"]["bytes"].decode())["outputText"]
                await asyncio.sleep(0.01)
                yield chunk

        except ClientError as e:
            logger.error(f"Couldn't invoke Titan text model stream. Error is {e}")
            raise GenericError(status_code=500, error_message=str(e))

    def _convert_messages_to_titan_prompt(
        self, 
        messages, 
        system_prompt: str | None = None
    ):
        """
        Convert Claude-style messages to a simple text prompt for Titan.
        Extracts only text content and ignores images.

        :param messages: List of messages in Claude format
        :param system_prompt: Optional system prompt
        :return: Simple text prompt string
        """
        prompt_parts = []
        
        # Add system prompt if provided
        if system_prompt:
            prompt_parts.append(f"System: {system_prompt}\n")
        
        for message in messages:
            role = message.get("role", "")
            content = message.get("content", "")
            
            # Extract text content only
            text_parts = []
            if isinstance(content, list):
                # Handle mixed content - extract only text parts
                for content_item in content:
                    if isinstance(content_item, dict) and content_item.get("type") == "text":
                        text_parts.append(content_item.get("text", ""))
            elif isinstance(content, str):
                # Handle simple text content
                text_parts.append(content)
            
            # Only add if there's text content
            if text_parts:
                text_content = " ".join(text_parts)
                if role.lower() == "user":
                    prompt_parts.append(f"Human: {text_content}")
                elif role.lower() == "assistant":
                    prompt_parts.append(f"Assistant: {text_content}")
                else:
                    prompt_parts.append(f"{role}: {text_content}")
        
        # Add assistant prompt at the end for completion
        prompt_parts.append("Assistant:")
        
        return "\n\n".join(prompt_parts)


class BulkBedrockRuntimeWrapper:
    """Encapsulates Amazon Bedrock Runtime actions for bulk generation."""

    def __init__(self):
        """
        :param bedrock_runtime_client: A low-level client representing Amazon Bedrock Runtime.
                                       Describes the API operations for running inference using
                                       Bedrock models.
        """
        # Enhanced retry configuration for bulk operations
        timeout_config = Config(
            retries={
                'max_attempts': 8,  # Increased from default 3
                'mode': 'adaptive'  # Use adaptive retry mode for better handling of throttling
            },
            # Add connection timeout and read timeout for bulk operations
            connect_timeout=60,
            read_timeout=300
        )
        
        if CONFIG.LOCAL_TESTING:
            self.bedrock_runtime_client = boto.client(
                "bedrock-runtime",
                region_name=CONFIG.AWS_REGION,
                aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                config=timeout_config,
            )
        else:
            self.bedrock_runtime_client = boto.client(
                "bedrock-runtime",
                region_name=CONFIG.AWS_REGION,
                config=timeout_config,
            )

    def tokenizer(self, input_str: str):
        encoding = tiktoken.encoding_for_model("text-davinci-003")
        encoded = encoding.encode(input_str)
        return len(encoded)
