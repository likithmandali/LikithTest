from typing import Any, Dict, List

import psycopg2
from botocore.exceptions import ClientError

from api.db.qna_document import QNADocumentDBController
from api.db.knowledge import KnowledgeDBController
from api.schemas.common.knowledge import DeleteDocumentsInput
from helper.aws_s3 import S3ObjectWrapper
from helper.custom_errors import BadRequestError
from settings.config import CONFIG
from settings.loguru import logger
from settings.security import check_project_application_access, User
from api.controllers.common.ingestion_job import IngestionJobController
from helper.aws_lambda import LambdaWrapper


class AWSKnowledgeController:
	@staticmethod
	def delete_documents_from_knowledge_bedrock(
		*,
		payload: DeleteDocumentsInput,
		current_user: User,
		db: psycopg2.extensions.connection,
		request_id: str | None,
	) -> Dict[str, Any]:
		"""
		Controller for deleting documents from an AWS knowledge base and triggering re-ingestion.

		Returns a plain dict; the router wraps it in JSONResponse.
		"""
		document_ids: List[int] = payload.document_ids
		if not document_ids:
			raise BadRequestError(error_message="No document IDs provided.")

		# Resolve base context
		first_ctx = QNADocumentDBController.fetch_instance_by_document_id(
			document_ids[0], db
		)
		base_knowledge_id = int(first_ctx.get("knowledgeId"))
		base_project_id = int(first_ctx.get("projectId"))
		base_application_id = int(first_ctx.get("applicationId"))

		# Authorization
		user_id = (
			current_user[0].get("id")
			if isinstance(current_user, list)
			else getattr(current_user, "id", None)
		)
		check_project_application_access(
			user_id=user_id,
			project_id=base_project_id,
			application_id=base_application_id,
			db=db,
		)

		# Validate all contexts are in same knowledge/project/app
		doc_contexts = []
		for did in document_ids:
			ctx = QNADocumentDBController.fetch_instance_by_document_id(did, db)
			if (
				int(ctx.get("knowledgeId")) != base_knowledge_id
				or int(ctx.get("projectId")) != base_project_id
				or int(ctx.get("applicationId")) != base_application_id
			):
				raise BadRequestError(
					error_message="All documents must belong to the same knowledge and project/application."
				)
			doc_contexts.append(ctx)

		# Knowledge details
		knowledge = KnowledgeDBController.get_knowledge_by_id(base_knowledge_id, db)
		data_source_id = knowledge.get("data_source_id")
		knowledge_base_id = knowledge.get("knowledge_base_id")
		s3_uri = knowledge.get("s3_uri")

		if not data_source_id or not knowledge_base_id or not s3_uri:
			raise BadRequestError(
				error_message="Knowledge base details are incomplete for this knowledge."
			)

		# Guard: ingestion job
		is_running = IngestionJobController().is_knowledge_base_job_running(
			knowledge_base_id=knowledge_base_id
		)
		if is_running:
			raise BadRequestError(
				error_message=(
					"Knowledge base ingestion job is already running. Please wait for it to complete before deleting documents."
				)
			)

		# Determine folder path for S3 keys
		prefix = f"s3://{CONFIG.AWS_STORAGE_BUCKET_NAME}/"
		if s3_uri.startswith(prefix):
			folder_path = s3_uri[len(prefix) :]
		elif s3_uri.startswith("s3://"):
			rem = s3_uri[5:]
			folder_path = rem.split("/", 1)[1] if "/" in rem else ""
		else:
			folder_path = s3_uri
		if not folder_path.endswith("/"):
			folder_path = folder_path + "/"

		deleted = []
		for ctx in doc_contexts:
			doc_name = ctx.get("documentName")
			object_key = f"{folder_path}{doc_name}"

			try:
				s3_obj = S3ObjectWrapper(
					CONFIG.AWS_STORAGE_BUCKET_NAME, dest_file_path=object_key
				)
				s3_obj.delete()
			except ClientError as e:
				code = (
					e.response.get("Error", {}).get("Code") if hasattr(e, "response") else None
				)
				if code == "NoSuchKey":
					logger.warning(
						f"S3 object not found for deletion: bucket={CONFIG.AWS_STORAGE_BUCKET_NAME}, key={object_key}"
					)
				else:
					raise

			QNADocumentDBController.remove_qna_document_from_knowledge_id(
				base_knowledge_id, doc_name, db
			)
			deleted.append(
				{"documentId": int(ctx.get("documentId", 0)) or None, "name": doc_name}
			)

		remaining_documents = QNADocumentDBController.get_qna_document_with_knowledge_id(
			base_knowledge_id, db
		)

		# Trigger update/re-ingestion
		function_params = {
			"data_source_id": data_source_id,
			"knowledge_base_id": knowledge_base_id,
			"aws_folder_path": s3_uri,
		}
		lambda_response = LambdaWrapper.invoke_update_function(
			function_name=CONFIG.AWS_LAMBDA_KNOWLEDGE_BASE_UPDATE,
			function_params=function_params,
			request_id=request_id,
			knowledge_id=base_knowledge_id,
			documentids=[],
			get_log=True,
		)

		ingestion_job_id = None
		try:
			payload_obj = lambda_response.get("Payload")
			if isinstance(payload_obj, dict):
				ingestion_job_id = payload_obj.get("ingestionJobId") or payload_obj.get(
					"knowledge_ingestion_job_id"
				)
		except Exception:
			ingestion_job_id = None

		return {
			"message": "Documents deleted successfully.",
			"deleted": deleted,
			"remainingDocuments": remaining_documents,
			"knowledgeBaseId": knowledge_base_id,
			"ingestionJobId": ingestion_job_id,
		}
