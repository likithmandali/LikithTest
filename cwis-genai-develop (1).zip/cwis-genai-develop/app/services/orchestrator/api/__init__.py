from fastapi import APIRouter
from . import routers


api_router = APIRouter()

api_router.include_router(routers.v1_router)
# api_router.include_router(routers.v1_ui_router)
# api_router.include_router(routers.v2_router)
