from datetime import datetime
import psycopg2
from fastapi import Depends
from helper.custom_errors import AttributeNotFoundError
from settings.loguru import logger
from settings.db import get_db_connection


class QNADocumentDBController:
    @staticmethod
    def create_qna_document(
        file_name: str,
        file_path: str,
        knowledge_id: int,
        status: str = "In Progress",
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # create document
            insert_sql = """
                INSERT INTO qna_document (
                    name, upload_file_path, knowledge_id, created_at, updated_at, status
                )
                VALUES (
                    %s, %s, %s, %s, %s, %s
                )
                RETURNING id, name, upload_file_path, knowledge_id, status;
            """
            logger.debug(f"{insert_sql=}")
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        str(file_name),
                        str(file_path),
                        str(knowledge_id),
                        str(datetime.now()),  # createdAt
                        str(datetime.now()),  # updatedAt
                        str(status),
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"create qna_document: {row}")
            response = {
                "id": row[0],
                "name": row[1],
                "uploadFilePath": row[2],
                "knowledgeId": row[3],
                "status": row[4],
            }
            return response
        except Exception as err:
            raise err

    @staticmethod
    def get_qna_document_with_knowledge_id(
        knowledge_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT qd.id, qd.name, qd.upload_file_path, qd.status, qd.request_id
                FROM qna_document qd
                WHERE qd.knowledge_id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(knowledge_id),),
                )
                rows = cur.fetchall()
            logger.debug(f"{rows=}")
            response = [
                {
                    "id": row[0],
                    "name": row[1],
                    "uploadFilePath": row[2],
                    "status": row[3],
                    "requestId": row[4],
                }
                for row in rows
            ]
            return response
        except Exception as err:
            raise err

    @staticmethod
    def remove_qna_document_from_knowledge_id(
        knowledge_id: int,
        document_name: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            removal_query = """
                DELETE FROM qna_document qd
                WHERE qd.knowledge_id = %s
                AND qd.name = %s;
            """
            logger.debug(f"{removal_query=}")
            with db.cursor() as cur:
                cur.execute(
                    removal_query,
                    (
                        str(knowledge_id),
                        str(document_name),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")

            fetch_query = """
                SELECT qd.id, qd.name, qd.knowledge_id
                FROM qna_document qd
                WHERE qd.knowledge_id = %s;
            """
            logger.debug(f"{fetch_query=}")
            with db.cursor() as cur:
                cur.execute(
                    fetch_query,
                    (str(knowledge_id),),
                )
                rows = cur.fetchall()
            logger.debug(f"{rows=}")
            response = [{"id": row[0], "name": row[1], "knowledgeId": row[2]} for row in rows]
            return response
        except Exception as err:
            raise err

    @staticmethod
    def update_document_status(
        document_id: int,
        status: str,
        request_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            update_sql = """
                UPDATE qna_document
                SET status = %s, request_id = %s, updated_at = %s
                WHERE id = %s
                RETURNING id, name, status;
            """
            with db.cursor() as cur:
                cur.execute(update_sql, (status, request_id, datetime.now(), document_id))
                db.commit()
                row = cur.fetchone()
                if row:
                    response = {"id": row[0], "name": row[1], "status": row[2]}
                    return response
                else:
                    raise Exception(f"Document {document_id} not found or no rows updated.")
        except Exception as e:
            logger.error(f"Error updating document status: {e}")
            raise e

    @staticmethod
    def fetch_instance_by_document_id(
        document_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        fetch_instance_query = """
            SELECT qd.name, qd.knowledge_id, qfk.flow_id, gi.id as instance_id,
            gi.application_id, gi.project_id, gi.cloud_environment , gi.embedding_choice 
            FROM qna_document qd 
            INNER JOIN qna_flow_knowledge qfk 
            ON qfk.knowledge_id = qd.knowledge_id
            INNER JOIN genaie_instance gi 
            ON gi.flow = qfk.flow_id 
            WHERE qd.id = %s;
        """
        with db.cursor() as cur:
            cur.execute(
                fetch_instance_query,
                (str(document_id),),
            )
            db.commit()
            document_instance = cur.fetchone()

        if document_instance is None:
            raise AttributeNotFoundError("Document not found. Please check the Document ID!")

        formatted_response = {
            "documentName": document_instance[0],
            "knowledgeId": document_instance[1],
            "flowId": document_instance[2],
            "instanceId": document_instance[3],
            "applicationId": document_instance[4],
            "projectId": document_instance[5],
            "cloudEnvironment": document_instance[6],
            "embeddingChoice": document_instance[7],
        }
        logger.debug(f"{formatted_response=}")
        return formatted_response
