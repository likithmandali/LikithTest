from datetime import datetime
import psycopg2
from fastapi import Depends
from settings.loguru import logger
from helper.custom_errors import AttributeNotFoundError
from api.schemas.common.system_template import (
    CreateSystemTemplate,
)
from settings.db import get_db_connection


class QNATemplateDBController:
    @staticmethod
    def get_all_system_templates(
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT id, name, template
                FROM genaie_systemtemplate gs;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                )
                rows = cur.fetchall()
            logger.debug(f"{rows=}")
            formatted_data = {
                "templates": [
                    {
                        "id": row[0],
                        "name": row[1],
                        "template": row[2],
                    }
                    for row in rows
                ]
            }
            return formatted_data
        except Exception as err:
            raise err

    @staticmethod
    def create_system_template(
        create_system_template: CreateSystemTemplate,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            insert_sql = """
                INSERT INTO genaie_systemtemplate (name, template, created_at, updated_at)
                VALUES (%s, %s, %s, %s)
                RETURNING id, name, template;
            """
            logger.debug(f"{insert_sql}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        create_system_template.name,
                        create_system_template.template,
                        str(datetime.now()),
                        str(datetime.now()),
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"{row=}")
            create_template_response = {
                "id": row[0],
                "name": row[1],
                "template": row[2],
            }
            return create_template_response
        except Exception as err:
            raise err

    @staticmethod
    def delete_template_by_id(
        template_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            delete_template_query = """
                    DELETE FROM qna_template qt
                    WHERE qt.id = %s;
            """
            logger.debug(f"{delete_template_query=}")
            with db.cursor() as cur:
                cur.execute(
                    delete_template_query,
                    (str(template_id),),
                )
                db.commit()
                template_del_count = cur.rowcount
            logger.debug(f"{template_del_count=}")
            if template_del_count == 0:
                raise AttributeNotFoundError("Template not deleted!!!")
        except Exception as err:
            raise err
