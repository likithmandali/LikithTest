import psycopg2
from psycopg2.extras import Json
from datetime import datetime
from settings.loguru import logger
from helper.custom_errors import (
    UnprocessableEntityError,
)
from api.schemas.common.guardrails import CreateGuardrailsInput


class GuardrailsDBController:
    @staticmethod
    def create_guardrails(
        create_guardrails_input: CreateGuardrailsInput,
        db: psycopg2.extensions.connection,
    ) -> dict:
        """
        Create guardrails for a specific instance.

        Args:
            create_guardrails_input (CreateGuardrailsInput): The guardrails data to be created.
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            dict: The created guardrails data.
        """
        try:
            insert_sql = """
                INSERT INTO genaie_guardrails (guardrails_id, scanner_configs, cloud_provider, is_public, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING guardrails_id, scanner_configs, cloud_provider, created_at, updated_at;
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        create_guardrails_input.guardrails_id,
                        Json(create_guardrails_input.scanner_configs),
                        create_guardrails_input.cloud_provider,
                        False,  # is_public
                        str(datetime.now()),  # createdAt
                        str(datetime.now()),  # updatedAt
                    ),
                )

                db.commit()
                row = cur.fetchone()
            logger.debug(f"Step 2 - create genaie instance {row}")
            create_guardrails_response = {"guardrails_id": row[0]}
            logger.debug(f"{create_guardrails_response=}")
            return create_guardrails_response
        except Exception as e:
            logger.error(f"Error creating guardrails: {e}")
            raise UnprocessableEntityError("Failed to create guardrails.") from e

    @staticmethod
    def get_guardrails_by_id(
        guardrails_id: str,
        db: psycopg2.extensions.connection,
    ) -> dict:
        """
        Retrieve guardrails by ID.

        Args:
            guardrails_id (str): The ID of the guardrails to retrieve.
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            dict: The guardrails data.
        """
        try:
            select_sql = """
                SELECT guardrails_id, scanner_configs, cloud_provider, is_public, created_at, updated_at
                FROM genaie_guardrails
                WHERE guardrails_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(select_sql, (guardrails_id,))
                row = cur.fetchone()
            if row is None:
                return None
            return {
                "guardrails_id": row[0],
                "scanner_configs": row[1],
                "cloud_provider": row[2],
                "is_public": row[3],
            }
        except Exception as e:
            logger.error(f"Error retrieving guardrails by ID: {e}")
            raise UnprocessableEntityError("Failed to retrieve guardrails by ID.") from e

    @staticmethod
    def get_all_guardrails(
        db: psycopg2.extensions.connection,
    ) -> list:
        """
        Retrieve all guardrails.

        Args:
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            list: A list of all guardrails.
        """
        try:
            select_sql = """
                SELECT guardrails_id, scanner_configs, cloud_provider, is_public, created_at, updated_at
                FROM genaie_guardrails;
            """
            with db.cursor() as cur:
                cur.execute(select_sql)
                rows = cur.fetchall()
            return [
                {
                    "guardrails_id": row[0],
                    "scanner_configs": row[1],
                    "cloud_provider": row[2],
                    "is_public": row[3],
                }
                for row in rows
            ]
        except Exception as e:
            logger.error(f"Error retrieving all guardrails: {e}")
            raise UnprocessableEntityError("Failed to retrieve all guardrails.") from e

    @staticmethod
    def get_guardrails_by_public_status(
        is_public: bool,
        db: psycopg2.extensions.connection,
    ) -> list:
        """
        Retrieve guardrails by public status.

        Args:
            is_public (bool): The public status of the guardrails.
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            list: A list of guardrails with the specified public status.
        """
        try:
            select_sql = """
                SELECT guardrails_id, scanner_configs, cloud_provider, is_public, created_at, updated_at
                FROM genaie_guardrails
                WHERE is_public = %s;
            """
            with db.cursor() as cur:
                cur.execute(select_sql, (is_public,))
                rows = cur.fetchall()
            return [
                {
                    "guardrails_id": row[0],
                    "scanner_configs": row[1],
                    "cloud_provider": row[2],
                    "is_public": row[3],
                }
                for row in rows
            ]
        except Exception as e:
            logger.error(f"Error retrieving guardrails by public status: {e}")
            raise UnprocessableEntityError("Failed to retrieve guardrails by public status.") from e

    @staticmethod
    def delete_guardrails(
        guardrails_id: str,
        db: psycopg2.extensions.connection,
    ) -> dict:
        """
        Delete guardrails by ID.

        Args:
            guardrails_id (str): The ID of the guardrails to delete.
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            dict: Confirmation of deletion.
        """
        try:
            delete_sql = """
                DELETE FROM genaie_guardrails
                WHERE guardrails_id = %s
                RETURNING guardrails_id;
            """
            with db.cursor() as cur:
                cur.execute(delete_sql, (guardrails_id,))
                row = cur.fetchone()
            if row is None:
                return {"message": "Guardrails not found."}
            db.commit()
            return {"message": "Guardrails deleted successfully.", "id": row[0]}
        except Exception as e:
            logger.error(f"Error deleting guardrails: {e}")
            raise UnprocessableEntityError("Failed to delete guardrails.") from e

    @staticmethod
    def update_guardrails(
        guardrails_id: str,
        update_data: CreateGuardrailsInput,
        db: psycopg2.extensions.connection,
    ) -> dict:
        """
        Update guardrails by ID.

        Args:
            guardrails_id (str): The ID of the guardrails to update.
            update_data (CreateGuardrailsInput): The updated guardrails data.
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            dict: The updated guardrails data.
        """
        try:
            update_sql = """
                UPDATE genaie_guardrails
                SET guardrails_id = %s, scanner_configs = %s, cloud_provider = %s, updated_at = %s
                WHERE guardrails_id = %s
                RETURNING guardrails_id, scanner_configs, cloud_provider, created_at, updated_at;
            """
            with db.cursor() as cur:
                cur.execute(
                    update_sql,
                    (
                        update_data.guardrails_id,
                        Json(update_data.scanner_configs),
                        update_data.cloud_provider,
                        str(datetime.now()),  # updatedAt
                        guardrails_id,
                    ),
                )
                row = cur.fetchone()
            if row is None:
                return {"message": "Guardrails not found."}
            db.commit()
            return {"guardrails_id": row[0]}
        except Exception as e:
            logger.error(f"Error updating guardrails: {e}")
            raise UnprocessableEntityError("Failed to update guardrails.") from e

    @staticmethod
    def update_guardrails_public_status(
        guardrails_id: str,
        is_public: bool,
        db: psycopg2.extensions.connection,
    ) -> dict:
        """
        Update the public status of guardrails by ID.

        Args:
            guardrails_id (str): The ID of the guardrails to update.
            is_public (bool): The new public status.
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            dict: Confirmation of the update.
        """
        try:
            update_sql = """
                UPDATE genaie_guardrails
                SET is_public = %s, updated_at = %s
                WHERE guardrails_id = %s
                RETURNING guardrails_id;
            """
            with db.cursor() as cur:
                cur.execute(update_sql, (is_public, str(datetime.now()), guardrails_id))
                row = cur.fetchone()
            if row is None:
                return {"message": "Guardrails not found."}
            db.commit()
            return {"message": "Guardrails public status updated successfully.", "guardrails_id": row[0]}
        except Exception as e:
            logger.error(f"Error updating guardrails public status: {e}")
            raise UnprocessableEntityError("Failed to update guardrails public status.") from e

    @staticmethod
    def get_guardrails_by_ids(
        guardrails_ids: list[str],
        db: psycopg2.extensions.connection,
    ) -> list:
        """
        Retrieve multiple guardrails by their IDs.

        Args:
            guardrails_ids (list[str]): The list of guardrails IDs to retrieve.
            db (psycopg2.extensions.connection): Database connection object.

        Returns:
            list: A list of guardrails matching the provided IDs.
        """
        try:
            # Convert the list of IDs to a tuple for the SQL query
            ids_tuple = tuple(guardrails_ids)

            # Handle single ID case differently due to SQL syntax requirements
            if len(ids_tuple) == 1:
                select_sql = """
                    SELECT guardrails_id, scanner_configs, cloud_provider, is_public, created_at, updated_at
                    FROM genaie_guardrails
                    WHERE guardrails_id = %s;
                """
                with db.cursor() as cur:
                    cur.execute(select_sql, (guardrails_ids[0],))
                    rows = cur.fetchall()
            else:
                select_sql = """
                    SELECT guardrails_id, scanner_configs, cloud_provider, is_public, created_at, updated_at
                    FROM genaie_guardrails
                    WHERE guardrails_id IN %s;
                """
                with db.cursor() as cur:
                    cur.execute(select_sql, (ids_tuple,))
                    rows = cur.fetchall()

            return [
                {
                    "guardrails_id": row[0],
                    "scanner_configs": row[1],
                    "cloud_provider": row[2],
                    "is_public": row[3],
                }
                for row in rows
            ]
        except Exception as e:
            logger.error(f"Error retrieving guardrails by IDs: {e}")
            raise UnprocessableEntityError("Failed to retrieve guardrails by IDs.") from e
