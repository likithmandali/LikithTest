import psycopg2
from fastapi import Depends, Query
from settings.loguru import logger
from helper.custom_errors import AttributeNotFoundError
from settings.db import get_db_connection


class AppDBController:
    @staticmethod
    def get_apps(
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                    SELECT id, name, type, description, application_group
                    FROM genaie_application;
                """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                )

                response = cur.fetchall()
            formatted_data = [
                {
                    "id": str(item[0]),
                    "name": item[1],
                    "type": item[2],
                    "description": item[3],
                    "applicationGroup": item[4],
                }
                for item in response
            ]
            return formatted_data
        except Exception as err:
            raise err

    @staticmethod
    def get_apps_by_user_id(
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        """
        try:
            sql_query = """
                    SELECT id, name, type, description, application_group
                    FROM genaie_application AS ga
                    WHERE ga.user_id = %s;
                """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(sql_query, (user_id,))

                response = cur.fetchall()
            formatted_data = [
                {
                    "id": str(item[0]),
                    "name": item[1],
                    "type": item[2],
                    "description": item[3],
                    "applicationGroup": item[4],
                }
                for item in response
            ]
            return formatted_data
        except Exception as err:
            raise err

    @staticmethod
    def get_apps_by_project_id(project_id: int, db: psycopg2.extensions.connection = Depends(get_db_connection)):
        try:
            sql_query = """SELECT
                    project.project_id AS projectId,
                    app.id AS applicationId,
                    app.name AS applicationName,
                    app.type AS type,
                    app.description as description,
                    app.application_group as applicationGroup
                FROM
                    genaie_application_project AS project
                INNER JOIN
                    genaie_application AS app ON project.application_id = app.id
                WHERE
                    project.project_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(sql_query, (project_id,))

                response = cur.fetchall()

            logger.debug(f"{response=}")
            modified_response = [
                {
                    "projectId": str(item[0]),  # projectid
                    "id": str(item[1]),  # applicationid
                    "name": str(item[2]),  # applicationname
                    "type": str(item[3]),  # applicationtype
                    "description": str(item[4]),  # description
                    "applicationGroup": str(item[5]),  # applicationgroup
                }
                for item in response
            ]
            return modified_response
        except Exception as err:
            raise err

    @staticmethod
    def get_apps_by_project_id_user_id(
        project_id: int,
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """SELECT
                    gap.project_id AS projectId,
                    app.id AS applicationId,
                    app.name AS applicationName,
                    app.type AS type,
                    app.description as description,
                    app.application_group as applicationGroup
                FROM genaie_application_project AS gap
                INNER JOIN genaie_application AS app ON gap.application_id = app.id
                WHERE gap.project_id = %s
            """
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(project_id),),
                )

                response = cur.fetchall()

            logger.debug(f"{response=}")
            modified_response = [
                {
                    "projectId": str(item[0]),  # projectid
                    "id": str(item[1]),  # applicationid
                    "name": str(item[2]),  # applicationname
                    "type": str(item[3]),  # applicationtype
                    "description": str(item[4]),  # description
                    "applicationGroup": str(item[5]),  # applicationgroup
                }
                for item in response
            ]
            return modified_response
        except Exception as err:
            raise err

    @staticmethod
    def get_app_by_id(
        application_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT ga.id, ga.name, ga.type, ga.application_group, ga.description
                FROM genaie_application ga
                WHERE ga.id = %s;
            """
            logger.debug(f"{sql_query=}")
            logger.debug(f"{application_id=}   {type(application_id)=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(application_id),),
                )

                row = cur.fetchone()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError("Application doesnt exist. Please check the Id!")
            Application = {
                "id": str(row[0]),
                "name": row[1],
                "type": row[2],
                "applicationGroup": row[3],
                "description": row[4],
            }
            return Application
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_all_apps_in_each_project(
        projectname: str = Query(None),
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """SELECT
                    gap.project_id AS projectId,
                    app.id AS applicationId,
                    app.name AS applicationName,
                    app.type AS type,
                    app.description as description,
                    app.application_group as applicationGroup,
                    gp.name as projectName
                FROM genaie_application_project AS gap
                INNER JOIN genaie_application AS app ON gap.application_id = app.id
                INNER JOIN genaie_project AS gp ON gap.project_id = gp.id
            """

            if projectname is not None:
                sql_query += " WHERE gp.name = %s"
                query_params = (projectname,)
            else:
                query_params = ()

            with db.cursor() as cur:
                cur.execute(sql_query, query_params)
                response = cur.fetchall()

            logger.debug(f"{response=}")
            modified_response = [
                {
                    "projectId": str(item[0]),  # projectid
                    "applicationId": str(item[1]),  # applicationid
                    "applicationName": str(item[2]),  # applicationname
                    "applicationtype": str(item[3]),  # applicationtype
                    "description": str(item[4]),  # description
                    "applicationGroup": str(item[5]),  # applicationgroup
                    "projectName": str(item[6]),  # projectname
                }
                for item in response
            ]
            return modified_response
        except Exception as err:
            raise err
