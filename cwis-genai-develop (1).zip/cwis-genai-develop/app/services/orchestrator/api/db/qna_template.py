from datetime import datetime
import psycopg2
from fastapi import Depends
from settings.loguru import logger
from helper.custom_errors import AttributeNotFoundError
from settings.db import get_db_connection
from typing import Optional
import json


def get_prompt_template(metadata: dict, mode: bool, prompt_template: str) -> str:
    default_template = """You're an AI assistant who is an expert in generating meticulous and descriptive test scripts, with a focus on
    Quality Assurance (QA). Your task is to generate test scripts based on the input provided, ensuring that positive test scenarios are exhaustively covered.
           {{input_text}}"""

    return prompt_template


class QNATemplateDBController:
    @staticmethod
    def create_template_sql(
        name: str,
        prompt_template: str,
        mode: bool,
        metadata: dict,
        output_columns: Optional[list[str]] = None,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            prompt_template = get_prompt_template(metadata, mode, prompt_template)

            insert_sql = """
                INSERT INTO qna_template (name, prompt_template, created_at, updated_at, output_columns, mode, metadata)
                VALUES (%s, %s, %s, %s, %s, %s, %s )
                RETURNING id, name, prompt_template, output_columns, mode, metadata;
            """
            logger.debug(f"{insert_sql}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        name,
                        prompt_template,
                        str(datetime.now()),
                        str(datetime.now()),
                        output_columns,
                        mode,
                        json.dumps(metadata),
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"{row=}")
            create_template_response = {
                "id": row[0],
                "name": row[1],
                "prompt_template": row[2],
                "output_columns": row[3],
                "mode": row[4],
                "metadata": row[5],
            }
            return create_template_response
        except Exception as err:
            raise err

    @staticmethod
    def update_template_by_id(
        template_id: int,
        prompt_template: str,
        mode: bool = True,
        metadata: dict = {},
        output_columns: Optional[list[str]] = None,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            prompt_template = get_prompt_template(metadata, mode, prompt_template)

            sql_update_query = """
                UPDATE qna_template AS qt
                SET prompt_template = %s, output_columns = %s, mode = %s, metadata = %s,  updated_at = %s
                WHERE qt.id = %s;
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        prompt_template,
                        output_columns,
                        mode,
                        json.dumps(metadata),
                        str(datetime.now()),
                        str(template_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            if rows == 0:
                raise AttributeNotFoundError("Prompt template not updated. Please check the Id!")
            return {"id": template_id}
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_template_by_id(
        template_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT id, name, prompt_template, output_columns, mode, metadata
                FROM qna_template qt
                WHERE qt.id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(template_id),),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError("Flow not found. Please check the flow id!")
            template_details = {
                "id": row[0],
                "name": row[1],
                "promptTemplate": row[2],
                "outputColumns": row[3],
                "mode": row[4],
                "metadata": row[5],
            }
            return template_details
        except Exception as err:
            raise err
