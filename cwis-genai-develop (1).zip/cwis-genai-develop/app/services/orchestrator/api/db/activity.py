from datetime import datetime, timedelta
import json
import uuid
import pandas as pd
import io
import psycopg2
from api.db.instance import InstanceDBController
from settings.security import check_project_application_access
from settings.loguru import logger
from fastapi import Depends
from api.schemas.common.activity import (
    UpdateActivityStatusInternal,
    UpdateUserActivity,
    UserActivityCreate,
    UserActivityCreateInternal,
    UpdateActivityStatusInternalTemplate,
    OverallStatus,
)
from settings.db import get_db_connection
from helper.custom_errors import AttributeNotFoundError
# from helper.azure_blob_wrapper import upload_to_blob_return_sas_bulk_gen


class ActivityDBController:
    @staticmethod
    def create_activity(
        activity_data: UserActivityCreate,
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # step 1 - get user group id
            get_user_group_query = """
                SELECT aug.id, aug.user_id, aug.group_id
                FROM auth_user_groups aug
                WHERE aug.user_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(
                    get_user_group_query,
                    (str(user_id),),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"step 1 - get genaie user groupid :{row=}")
            group_id = row[2]

            # Step 2 - Create genaie activity
            insert_sql = """
                INSERT INTO genaie_activity (
                    _type, input_text, instance_id,
                    created_at, updated_at,
                    output_text, feedback, application_id, project_id, request_id
                )
                VALUES (
                    %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
                )
                RETURNING id, _type, input_text, output_text, feedback, instance_id, application_id, project_id;
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        str(activity_data.type),
                        str(activity_data.input_text),
                        activity_data.instance_id,
                        str(datetime.now()),  # createdAt
                        str(datetime.now()),  # updatedAt
                        str(activity_data.output_text),
                        str(activity_data.feedback),
                        activity_data.application_id,
                        activity_data.project_id,
                        activity_data.request_id,
                    ),
                )

                db.commit()
                row = cur.fetchone()
            logger.debug(f"Step 2 - create genaie activity {row}")
            create_activity_response = {
                "id": row[0],
                "_type": row[1],
                "inputText": row[2],
                "outputText": row[3],
                "feedback": row[4],
                "instanceId": str(row[5]),
                "applicationId": str(row[6]),
                "projectId": str(row[7]),
            }
            logger.debug(f"{create_activity_response=}")

            # Step 3 - create activity user table record
            insert_sql_instance_user = """
                INSERT INTO genaie_activity_users (activity_id, user_id)
                VALUES (%s, %s)
                RETURNING id, activity_id, user_id 
            """
            with db.cursor() as cur:
                cur.execute(
                    insert_sql_instance_user,
                    (create_activity_response.get("id"), user_id),
                )
                db.commit()
                user_row = cur.fetchone()
            logger.debug(f"Step 3 - insert_sql_iactivity_user {row}")
            create_activity_user_response = {
                "id": user_row[0],
                "activity_id": user_row[1],
                "user_id": user_row[2],
            }
            logger.debug(f"{create_activity_user_response=}")

            # Step 4 - create activity group table record
            insert_sql_instance_group = """
                INSERT INTO genaie_activity_group (activity_id, group_id)
                VALUES (%s, %s)
                RETURNING id, activity_id, group_id 
            """
            with db.cursor() as cur:
                cur.execute(
                    insert_sql_instance_group,
                    (create_activity_response.get("id"), group_id),
                )
                db.commit()
                group_row = cur.fetchone()
            logger.debug(f"Step 3 - insert_sql_iactivity_group {row}")
            create_activity_user_response = {
                "id": group_row[0],
                "activity_id": group_row[1],
                "group_id": group_row[2],
            }
            logger.debug(f"{create_activity_user_response=}")
            # step 5 - update instance last_updated if instance_id is present
            if row[5]:
                instance_response = InstanceDBController.update_last_updated_time(
                    instance_id=create_activity_response.get("instanceId"), db=db
                )
                logger.debug(f"{instance_response=}")
            return {"genaieActivity": create_activity_response}
        except Exception as err:
            raise err

    
    @staticmethod
    def get_all_user_questions(
        user_id: int,
        type: str = None,
        project_id: str = None,
        limit: int = 15,  # Keep existing default but make it configurable
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """Optimized version with LIMIT to prevent large data loads"""
        try:
            # Ensure limit is reasonable
            limit = min(max(1, limit), 100)

            base_query = """
                SELECT ga.id, ga._type, ga.input_text, ga.output_text, ga.llm_model, 
                       ga.input_token_count, ga.output_token_count, ga.feedback, 
                       ga.status, ga.task_id, ga.created_at, ga.input_token_cost, 
                       ga.output_token_cost, ga.total_cost,
                       au.username, gi.name as instance_name,
                       COALESCE(gp.name, gp2.name) as project_name
                FROM genaie_activity ga
                INNER JOIN genaie_activity_users gau ON ga.id = gau.activity_id
                INNER JOIN auth_user au ON gau.user_id = au.id
                LEFT JOIN genaie_instance gi ON ga.instance_id = gi.id
                LEFT JOIN genaie_project gp ON gi.project_id = gp.id
                LEFT JOIN genaie_project gp2 ON ga.project_id = gp2.id
                WHERE gau.user_id = %s
            """

            params = [user_id]

            if project_id:
                base_query += """
                    AND (ga.project_id = %s OR EXISTS (
                        SELECT 1 FROM genaie_instance gi 
                        LEFT JOIN genaie_project gp ON gi.project_id = gp.id 
                        WHERE ga.instance_id = gi.id AND gp.id = %s
                    ))
                """
                params.extend([project_id, project_id])

            if type:
                base_query += " AND ga._type = %s"
                params.append(type)

            base_query += " ORDER BY ga.created_at DESC LIMIT %s"
            params.append(limit)

            logger.debug(f"{base_query=}")
            with db.cursor() as cur:
                cur.execute(base_query, params)
                rows = cur.fetchall()

            activities = []
            for row in rows:
                # Parse feedback JSON if it exists
                feedback_data = {}
                if row[7]:  # feedback field
                    try:
                        if isinstance(row[7], str):
                            feedback_data = json.loads(row[7])
                        elif isinstance(row[7], dict):
                            feedback_data = row[7]
                    except (json.JSONDecodeError, TypeError):
                        feedback_data = {}
                
                activity = {
                    "id": str(row[0]),
                    "_type": row[1],
                    "inputText": row[2] if row[2] else "",
                    "outputText": row[3] if row[3] else "",
                    "llmModel": row[4] if row[4] else "",
                    "inputTokenUsage": row[5] if row[5] else 0,
                    "outputTokenUsage": row[6] if row[6] else 0,
                    "feedback": feedback_data,
                    "status": row[8],
                    "taskId": row[9],
                    "createdAt": row[10].strftime("%d-%m-%Y %H:%M:%S") if row[10] else "",
                    "totalPricing": float(row[13]) if row[13] else 0.0,
                    "username": row[14] if row[14] else "",
                    "instanceName": row[15] if row[15] else "",
                    "projectName": row[16] if row[16] else "",
                }
                activities.append(activity)

            return {"edges": [{"node": activity} for activity in activities]}

        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def update_activity_feedback(
        update_feedback_input: UpdateUserActivity,
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_update_query = """
                UPDATE genaie_activity AS ga
                SET feedback = %s, updated_at = %s
                FROM genaie_activity_users AS gau
                WHERE ga.id = %s
                AND ga.id = gau.activity_id
                AND gau.user_id = %s
                RETURNING ga.id, ga.instance_id;
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        json.dumps(update_feedback_input.feedback),
                        str(datetime.now()),
                        str(update_feedback_input.activityId),
                        str(user_id),
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if len(row) == 0:
                raise AttributeNotFoundError("Activity doesnt exist. Please check the Id!")
            instance_id = row[1]
            # if instance id is present then update last_updated
            if instance_id:
                instance_response = InstanceDBController.update_last_updated_time(instance_id=instance_id, db=db)
                logger.debug(f"{instance_response=}")
            return {"response": "Successful"}

        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_user_activity_by_id(
        activity_id: int,
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT  ga.id, ga._type, ga.input_text, ga.output_text, ga.feedback, ga.instance_id, ga.meta_data, 
                ga.status FROM genaie_activity ga
                INNER JOIN genaie_activity_users gau 
                ON ga.id = gau.activity_id 
                WHERE ga.id = %s AND gau.user_id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (activity_id, user_id),
                )

                row = cur.fetchall()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError("Activity doesnt exist. Please check the Id!")
            activity = {
                "id": str(row[0][0]),
                "_type": row[0][1],
                "inputText": row[0][2],
                "outputText": row[0][3],
                "feedback": row[0][4],
                "instanceId": row[0][5],
                "meta_data": row[0][6],
                "status": row[0][7],
            }
            return activity
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    
    @staticmethod
    def get_activity_by_id(
        activity_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT  ga.id, ga._type, ga.input_text, 
                ga.output_text,ga.feedback, ga.instance_id,
                ga.status, ga.meta_data, ga.task_id, ga.application_id, ga.project_id, ga.request_id
                FROM genaie_activity ga
                WHERE ga.id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(activity_id),),
                )
                row = cur.fetchall()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError("Activity doesnt exist. Please check the Id!")
            activity = {
                "id": str(row[0][0]),
                "_type": row[0][1],
                "inputText": row[0][2],
                "outputText": row[0][3],
                "feedback": row[0][4],
                "instanceId": row[0][5],
                "status": row[0][6],
                "metaData": row[0][7],
                "taskId": row[0][8],
                "applicationId": row[0][9],
                "projectId": row[0][10],
            }
            if row[0][11]:
                activity["requestId"] = row[0][11]
            return activity
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_activity_costs_by_id(
        activity_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT  ga.id, ga._type, ga.input_text, 
                ga.output_text,ga.feedback, ga.instance_id,
                ga.status, ga.meta_data, ga.task_id, ga.application_id, ga.project_id, ga.request_id,ga.token_usage,ga.input_token_count,ga.output_token_count,ga.input_token_cost,ga.output_token_cost,ga.total_cost
                FROM genaie_activity ga
                WHERE ga.id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(activity_id),),
                )
                row = cur.fetchall()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError("Activity doesnt exist. Please check the Id!")
            activity = {
                "id": str(row[0][0]),
                "_type": row[0][1],
                "inputText": row[0][2],
                "outputText": row[0][3],
                "feedback": row[0][4],
                "instanceId": row[0][5],
                "status": row[0][6],
                "metaData": row[0][7],
                "taskId": row[0][8],
                "applicationId": row[0][9],
                "projectId": row[0][10],
                "tokenUsage": row[0][12],
                "inputTokenCount": row[0][13],
                "outputTokenCount": row[0][14],
                "inputTokenCost": row[0][15],
                "outputTokenCost": row[0][16],
                "totalCost": row[0][17],
            }
            if row[0][11]:
                activity["requestId"] = row[0][11]
            return activity
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def update_activity_metadata_status(
        activity_status_update: UpdateActivityStatusInternal,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_update_query = """
                UPDATE genaie_activity AS ga
                SET status = %s, output_text = %s, meta_data = %s, updated_at = %s, 
                input_token_count = %s, output_token_count = %s, 
                input_token_cost = %s, output_token_cost = %s, total_cost = %s, llm_model = %s
                WHERE ga.id = %s
                RETURNING ga.id, ga.instance_id;
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        str(activity_status_update.status),
                        str(activity_status_update.output_text),
                        json.dumps(activity_status_update.meta_data),
                        str(datetime.now()),
                        int(activity_status_update.input_token_count),
                        int(activity_status_update.output_token_count),
                        float(activity_status_update.input_token_cost),
                        float(activity_status_update.output_token_cost),
                        float(activity_status_update.total_cost),
                        str(activity_status_update.llm_model),
                        str(activity_status_update.activityId),
                    ),
                )
                db.commit()
                row = cur.fetchone()  # return no. of rows affected by query
            logger.debug(f"{row=}")
            if len(row) == 0:
                raise AttributeNotFoundError("Activity doesnt exist. Please check the Id!")
            instance_id = row[1]
            if instance_id:
                instance_response = InstanceDBController.update_last_updated_time(instance_id=instance_id, db=db)
                logger.debug(f"{instance_response=}")
            return {"activityId": activity_status_update.activityId}

        except Exception as err:
            logger.error(f"{err=}")
            raise err

    
    @staticmethod
    def get_all_user_activity(
        user_id: int,
        ids: str = None,
        type: str = None,
        project_id: str = None,
        limit: int = 50,  # Default page size
        offset: int = 0,  # For offset-based pagination
        cursor_id: int = None,  # For cursor-based pagination (more efficient)
        sort_by: str = "created_at",  # Default sort field
        sort_direction: str = "DESC",  # Default sort direction
        start_date: datetime = None,  # Added date filtering
        end_date: datetime = None,  # Added date filtering
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Optimized version of get_all_user_activity with pagination, sorting, date filtering and better indexing.

        Args:
            user_id: User ID to filter activities
            ids: Comma-separated list of activity IDs (max 100)
            type: Activity type filter
            project_id: Project ID filter
            limit: Number of records to return (max 1000)
            offset: Offset for pagination (use cursor_id for better performance)
            cursor_id: Activity ID cursor for cursor-based pagination
            sort_by: Field to sort results by (default: created_at)
            sort_direction: Sort direction - ASC or DESC (default: DESC)
            start_date: Start date for filtering (datetime object)
            end_date: End date for filtering (datetime object)
            db: Database connection

        Returns:
            dict: Paginated activities with metadata
        """
        try:
            # Input validation and sanitization
            limit = min(max(1, limit), 1000)  # Limit between 1-1000
            offset = max(0, offset)

            # Validate and sanitize sort parameters
            allowed_sort_fields = {
                "created_at": "ga.created_at",
                "id": "ga.id",
                "type": "ga._type",
                "input_text": "ga.input_text",
                "status": "ga.status",
                "total_cost": "ga.total_cost",
                "username": "au.last_name",
            }

            # Default sort if invalid field provided
            sort_field = allowed_sort_fields.get(sort_by.lower(), "ga.created_at")

            # Validate sort direction
            sort_direction = "DESC" if sort_direction.upper() not in ["ASC", "DESC"] else sort_direction.upper()

            # Base query optimized for the new indexes
            base_select = """
                SELECT ga.id, ga._type, ga.input_text, ga.output_text, ga.feedback, 
                    ga.meta_data, ga.status, ga.task_id, ga.created_at, 
                    au.last_name, au.first_name, gi.name as instance_name,
                    COALESCE(gp.name, gp2.name) as project_name,
                    ga.input_token_count, ga.output_token_count, 
                    ga.input_token_cost, ga.output_token_cost, ga.total_cost, ga.llm_model, ga.guardrails_id
                FROM genaie_activity ga
                INNER JOIN genaie_activity_users gau ON ga.id = gau.activity_id
                INNER JOIN auth_user au ON gau.user_id = au.id
                LEFT JOIN genaie_instance gi ON ga.instance_id = gi.id
                LEFT JOIN genaie_project gp ON gi.project_id = gp.id
                LEFT JOIN genaie_project gp2 ON ga.project_id = gp2.id
                WHERE gau.user_id = %s
            """

            params = [user_id]

            # Add date range filtering
            if start_date and end_date:
                base_select += " AND ga.created_at BETWEEN %s AND %s"
                params.extend([start_date, end_date])
            elif start_date:
                base_select += " AND ga.created_at >= %s"
                params.append(start_date)
            elif end_date:
                base_select += " AND ga.created_at <= %s"
                params.append(end_date)

            # Handle specific ID queries (highest priority)
            if ids:
                ids_list = [id_val.strip() for id_val in ids.split(",") if id_val.strip() and id_val.strip().isdigit()]
                if not ids_list:
                    return {"edges": [], "pagination": {"hasNext": False, "total": 0}}

                # Limit to prevent abuse
                ids_list = ids_list[:100]
                placeholders = ",".join(["%s"] * len(ids_list))

                sql_query = (
                    base_select
                    + f"""
                    AND ga.id IN ({placeholders})
                    ORDER BY {sort_field} {sort_direction}, ga.id {sort_direction}
                    LIMIT %s
                """
                )
                params.extend(ids_list + [limit + 1])  # +1 to check for more records

            else:
                # Add cursor condition for efficient pagination
                if cursor_id:
                    # Adjust cursor condition based on sort direction
                    if sort_direction == "DESC":
                        if sort_field != "ga.id":
                            # For non-id fields, need a more complex condition to handle ties
                            cursor_query = """
                            SELECT {sort_field} FROM genaie_activity WHERE id = %s
                            """.format(sort_field=sort_field)

                            with db.cursor() as cur:
                                cur.execute(cursor_query, [cursor_id])
                                cursor_value = cur.fetchone()

                            if cursor_value:
                                base_select += f" AND ({sort_field} < %s OR ({sort_field} = %s AND ga.id < %s))"
                                params.extend([cursor_value[0], cursor_value[0], cursor_id])
                            else:
                                base_select += " AND ga.id < %s"
                                params.append(cursor_id)
                        else:
                            base_select += " AND ga.id < %s"
                            params.append(cursor_id)
                    else:  # ASC
                        if sort_field != "ga.id":
                            cursor_query = """
                            SELECT {sort_field} FROM genaie_activity WHERE id = %s
                            """.format(sort_field=sort_field)

                            with db.cursor() as cur:
                                cur.execute(cursor_query, [cursor_id])
                                cursor_value = cur.fetchone()

                            if cursor_value:
                                base_select += f" AND ({sort_field} > %s OR ({sort_field} = %s AND ga.id > %s))"
                                params.extend([cursor_value[0], cursor_value[0], cursor_id])
                            else:
                                base_select += " AND ga.id > %s"
                                params.append(cursor_id)
                        else:
                            base_select += " AND ga.id > %s"
                            params.append(cursor_id)

                # Add filters
                if project_id:
                    base_select += " AND (ga.project_id = %s OR gp.id = %s)"
                    params.extend([project_id, project_id])

                if type:
                    base_select += " AND ga._type = %s"
                    params.append(type)

                # Use cursor-based pagination if cursor_id provided, otherwise offset
                if cursor_id:
                    sql_query = (
                        base_select
                        + f"""
                        ORDER BY {sort_field} {sort_direction}, ga.id {sort_direction}
                        LIMIT %s
                    """
                    )
                    params.append(limit + 1)
                else:
                    sql_query = (
                        base_select
                        + f"""
                        ORDER BY {sort_field} {sort_direction}, ga.id {sort_direction}
                        LIMIT %s OFFSET %s
                    """
                    )
                    params.extend([limit + 1, offset])

            logger.debug(f"Executing query with params: {len(params)} parameters")
            logger.debug(f"Sort by: {sort_field}, direction: {sort_direction}")
            if start_date or end_date:
                logger.debug(f"Date filtering: {start_date} to {end_date}")

            with db.cursor() as cur:
                cur.execute(sql_query, params)
                rows = cur.fetchall()

            # Check if there are more records for pagination
            has_next = len(rows) > limit
            if has_next:
                rows = rows[:limit]  # Remove the extra record

            next_cursor = rows[-1][0] if rows and cursor_id is not None else None

            # Transform results
            activities = []
            for row in rows:
                activity = {
                    "id": str(row[0]),
                    "_type": row[1],
                    "inputText": row[2] if row[2] else "",
                    "outputText": row[3] if row[3] else "",
                    "feedback": row[4] if row[4] else {},
                    "metaData": row[5] if row[5] else {},
                    "status": row[6],
                    "taskId": row[7],
                    "createdAt": row[8].strftime("%d-%m-%Y %H:%M:%S") if row[8] else "",
                    "username": f"{row[9] or ''}, {row[10] or ''}".strip(", "),
                    "instanceName": row[11] if row[11] else "",
                    "projectName": row[12] if row[12] else "",
                    "inputTokenUsage": row[13] if row[13] else 0,
                    "outputTokenUsage": row[14] if row[14] else 0,
                    "totalPricing": float(row[17]) if row[17] else 0.0,
                    "llmModel": row[18] if row[18] else "",
                    "guardrailsId": row[19] if row[19] else "",
                }
                activities.append(activity)

            # Get total count for offset-based pagination (only when needed and not using IDs)
            total_count = None
            if not ids and cursor_id is None:
                count_query = """
                    SELECT COUNT(*)
                    FROM genaie_activity ga
                    INNER JOIN genaie_activity_users gau ON ga.id = gau.activity_id
                    WHERE gau.user_id = %s
                """
                count_params = [user_id]

                # Add date range filtering to count query
                if start_date and end_date:
                    count_query += " AND ga.created_at BETWEEN %s AND %s"
                    count_params.extend([start_date, end_date])
                elif start_date:
                    count_query += " AND ga.created_at >= %s"
                    count_params.append(start_date)
                elif end_date:
                    count_query += " AND ga.created_at <= %s"
                    count_params.append(end_date)

                if project_id:
                    count_query += """
                        AND (ga.project_id = %s OR EXISTS (
                            SELECT 1 FROM genaie_instance gi 
                            WHERE ga.instance_id = gi.id AND gi.project_id = %s
                        ))
                    """
                    count_params.extend([project_id, project_id])

                if type:
                    count_query += " AND ga._type = %s"
                    count_params.append(type)

                with db.cursor() as cur:
                    cur.execute(count_query, count_params)
                    total_count = cur.fetchone()[0]

            # Build response
            pagination_info = {"limit": limit, "hasNext": has_next, "sortBy": sort_by, "sortDirection": sort_direction}

            if cursor_id is not None:
                pagination_info["nextCursor"] = next_cursor
            else:
                pagination_info.update({"offset": offset, "total": total_count})

            response = {"edges": [{"node": activity} for activity in activities], "pagination": pagination_info}

            logger.debug(f"Returning {len(activities)} activities")
            return response

        except Exception as err:
            logger.error(f"Error in get_all_user_activity: {err}", exc_info=True)
            raise err

    
    
    
    @staticmethod
    def delete_activity_by_id(
        activity_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # Delete Activity-User relationship
            delete_activity_user_query = """
                DELETE FROM genaie_activity_users gau
                WHERE gau.activity_id = %s;
            """
            logger.debug(f"{delete_activity_user_query=}")
            with db.cursor() as cur:
                cur.execute(
                    delete_activity_user_query,
                    (str(activity_id),),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                logger.debug("Activity-User doesnt exist!")

            # Delete Activity-Group relationship
            delete_activity_group_query = """
                DELETE FROM genaie_activity_group gag
                WHERE gag.activity_id = %s;
            """
            logger.debug(f"{delete_activity_group_query=}")
            with db.cursor() as cur:
                cur.execute(
                    delete_activity_group_query,
                    (str(activity_id),),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                logger.debug("Activity-Group doesnt exist!")

            delete_activity_query = """
                DELETE FROM genaie_activity
                WHERE id = %s;
            """
            logger.debug(f"{delete_activity_query=}")
            with db.cursor() as cur:
                cur.execute(
                    delete_activity_query,
                    (str(activity_id),),
                )
                db.commit()
                rows = cur.rowcount  # return no. of rows affected by query
            logger.debug(f"{rows=}")
            if rows == 0:
                raise AttributeNotFoundError("Activity doesnt exist. Please check the Id!")
            return {"response": "Successful"}

        except Exception as err:
            logger.error(f"{err=}")
            raise err

    
    
    @staticmethod
    def get_app_info_by_id(
        project_id: int,
        start_date: datetime,
        end_date: datetime,
        limit: int = 100,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Optimized application info by project analysis
        """
        try:
            limit = min(max(5, limit), 500)

            sql_query = """
            WITH ProjectActivities AS (
                SELECT
                    COALESCE(gp.id, gp2.id) AS project_id,
                    COUNT(*) AS activities,
                    SUM(ga.total_cost) AS total_cost,
                    MAX(COALESCE(gp.last_updated, gp2.last_updated)) AS last_updated
                FROM genaie_activity ga
                LEFT JOIN genaie_instance gi ON ga.instance_id = gi.id
                LEFT JOIN genaie_project gp ON gi.project_id = gp.id
                LEFT JOIN genaie_project gp2 ON ga.project_id = gp2.id
                WHERE ga.created_at BETWEEN %s AND %s
                    AND COALESCE(gp.id, gp2.id) = %s
                    AND ga.total_cost IS NOT NULL
                GROUP BY COALESCE(gp.id, gp2.id)
            ),
            ApplicationActivityCounts AS (
                SELECT
                    COALESCE(p.id, p2.id) AS project_id,
                    app.name AS application_name,
                    COUNT(*) AS activities,
                    SUM(a.total_cost) as app_cost
                FROM genaie_activity a
                LEFT JOIN genaie_instance i ON a.instance_id = i.id
                LEFT JOIN genaie_project p ON i.project_id = p.id
                LEFT JOIN genaie_project p2 ON a.project_id = p2.id
                LEFT JOIN genaie_application app ON COALESCE(i.application_id, a.application_id) = app.id
                WHERE a.created_at BETWEEN %s AND %s
                    AND COALESCE(p.id, p2.id) = %s
                    AND a.total_cost IS NOT NULL
                    AND app.name IS NOT NULL
                GROUP BY COALESCE(p.id, p2.id), app.name
                ORDER BY app_cost DESC
                LIMIT %s
            )
            SELECT
                pa.project_id AS "projectId",
                pa.activities,
                pa.total_cost AS "totalCost",
                pa.last_updated AS "lastUpdated",
                JSONB_AGG(
                    JSONB_BUILD_OBJECT(
                        'applicationName', aac.application_name,
                        'activities', aac.activities,
                        'cost', aac.app_cost
                    ) ORDER BY aac.app_cost DESC
                ) FILTER (WHERE aac.project_id IS NOT NULL) AS "applicationInformation"
            FROM ProjectActivities pa
            LEFT JOIN ApplicationActivityCounts aac ON pa.project_id = aac.project_id
            GROUP BY pa.project_id, pa.activities, pa.total_cost, pa.last_updated
            """

            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(sql_query, (start_date, end_date, project_id, start_date, end_date, project_id, limit))
                row = cur.fetchone()

            if row:
                cost = {
                    "projectId": row[0],
                    "activities": row[1],
                    "totalCost": float(row[2]) if row[2] else 0.0,
                    "lastUpdated": row[3].isoformat() if row[3] else None,
                    "applicationInformation": row[4] if row[4] else [],
                }
            else:
                cost = {}

            return cost

        except Exception as err:
            logger.error(f"{err=}")
            raise err

    def verify_activity_access(
        activity_id: int,
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ) -> None:
        """
            Verify the access of a user to an activity.
        Args:
            activity_id (int): The ID of the activity.
            user_id (int): The ID of the user.
            db (psycopg2.extensions.connection, optional): The database connection.
            Defaults to Depends(get_db_connection).
        Raises:
            ValueError: If the activity details are invalid.
        Returns:
            None
        """
        activity_details = ActivityDBController.get_activity_by_id(activity_id, db)
        # First check if activity has project and application id
        if activity_details.get("applicationId") is not None and activity_details.get("projectId") is not None:
            auth_response = check_project_application_access(
                user_id=user_id,
                project_id=int(activity_details.get("projectId")),
                application_id=int(activity_details.get("applicationId")),
                db=db,
            )
        else:
            # If not, fetch those details from instance
            instance_id = activity_details.get("instanceId")
            if instance_id is not None:
                instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
                auth_response = check_project_application_access(
                    user_id=user_id,
                    project_id=int(instance_details.get("projectId")),
                    application_id=int(instance_details.get("applicationId")),
                    db=db,
                )
            else:
                raise ValueError("Invalid activity details")
        logger.debug(f"{auth_response=}")

    @staticmethod
    def add_project_to_activity(
        project_id: int,
        app_name: str,
        limit: int = 1000,  # Add limit for safety
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            limit = min(max(10, limit), 5000)

            search_sql = """
                SELECT id
                FROM genaie_activity
                WHERE project_id IS NULL
                AND _type = %s
                ORDER BY created_at DESC
                LIMIT %s;
            """

            logger.debug(f"{search_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    search_sql,
                    (app_name, limit),
                )
                db.commit()
                rows = cur.fetchall()

            logger.debug(f"{rows=}")

            if len(rows) > 0:
                # Use batch update for better performance
                activity_ids = [row[0] for row in rows]
                placeholders = ",".join(["%s"] * len(activity_ids))

                update_sql = f"""
                    UPDATE genaie_activity
                    SET project_id = %s
                    WHERE id IN ({placeholders});
                """

                with db.cursor() as cur:
                    cur.execute(update_sql, [project_id] + activity_ids)
                    db.commit()

                return True, True
            else:
                return True, False
        except Exception as err:
            raise err

    @staticmethod
    def create_apilog_activity(
        apitype: str,
        requestbody: dict = {},
        overallstatus: str = OverallStatus.PENDING.value,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            insert_sql = """
                INSERT INTO genaie_apilog (
                    id,api_type, created_at, request_body,overall_status
                )
                VALUES (
                    %s, %s, %s, %s, %s
                )
                RETURNING id, api_type, created_at, request_body,overall_status;
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        str(uuid.uuid4()),
                        str(apitype),
                        (datetime.now()),  # createdAt
                        json.dumps(requestbody),
                        overallstatus,
                    ),
                )

                db.commit()
                row = cur.fetchone()
                logger.debug(f"{row=}")

            return row
        except Exception as err:
            raise err

    @staticmethod
    def get_apilog_by_id(
        log_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            select_sql = """
                SELECT id, api_type, created_at, updated_at,request_body,response_body,response_status_code, overall_status
                FROM genaie_apilog
                WHERE id = %s;
            """
            logger.debug(f"{select_sql=}")
            with db.cursor() as cur:
                cur.execute(select_sql, (log_id,))
                row = cur.fetchone()

            return {
                "Id": row[0],
                "api_type": row[1],
                "created_at": row[2],
                "updated_at": row[3],
                "request_body": row[4],
                "response_body": row[5],
                "response_status_code": row[6],
                "overall_status": row[7],
            }
        except Exception as err:
            raise err

    @staticmethod
    def update_apilog_activity(
        id: str,
        responsebody: dict = "{}",
        overallstatus: str = OverallStatus.SUCCESS.value,
        responsestatuscode: int = 200,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            update_sql = """
                UPDATE genaie_apilog
                SET updated_at = %s,
                    response_body = %s,
                    response_status_code = %s,
                    overall_status = %s
                WHERE id = %s
                RETURNING id, api_type, created_at, request_body, overall_status;
            """
            logger.debug(f"{update_sql=}")

            with db.cursor() as cur:
                cur.execute(
                    update_sql,
                    (
                        datetime.now(),
                        responsebody,
                        responsestatuscode,
                        overallstatus,
                        id,
                    ),
                )

                db.commit()
                row = cur.fetchone()
                logger.debug(f"{row=}")

            return row
        except Exception as err:
            raise err

    # Additional optimized methods for streaming large datasets
    
    # Summary methods for dashboard/overview pages
    
    @staticmethod
    def update_guardrails_id(
        activity_id: int,
        guardrails_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                UPDATE genaie_activity
                SET guardrails_id = %s
                WHERE id = %s
                RETURNING id, guardrails_id;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        guardrails_id,
                        activity_id,
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if len(row) == 0:
                raise AttributeNotFoundError("Activity doesnt exist. Please check the Id!")
            return {"activityId": activity_id, "guardrailsId": row[1]}
        except Exception as err:
            raise err


def check_activity_metadata_exists(metadata: list | None) -> bool:
    if metadata is None:
        return False
    elif isinstance(metadata, list):
        if len(metadata) == 1 and len(metadata[0]) == 0 or len(metadata) == 0:
            return False
        else:
            return True