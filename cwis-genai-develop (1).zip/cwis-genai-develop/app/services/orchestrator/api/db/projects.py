import psycopg2
from datetime import datetime
from settings.loguru import logger
from fastapi import Depends
from settings.db import get_db_connection
from api.schemas.common.activity import (
    CreateProject,
)


class ProjectDBController:
    @staticmethod
    def get_projects(
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                    SELECT project.id, project.name, project.last_updated
                    FROM genaie_project AS project
                    WHERE project.is_deleted = FALSE
                    AND project.is_active = TRUE;
                """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                )

                rows = cur.fetchall()
                projects = [
                    {
                        "id": str(row[0]),
                        "name": row[1],
                        "lastUpdated": row[2].strftime("%Y-%m-%d %H:%M:%S"),
                    }
                    for row in rows
                ]
            return projects
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_projects_by_user_id(
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            logger.debug(f"{user_id=}")
            sql_query = """
                    SELECT project.id, project.name, project.last_updated
                    FROM genaie_project AS project
                    INNER JOIN genaie_project_users AS project_users
                    ON project.id = project_users.project_id
                    WHERE project_users.user_id = %s
                    AND project.is_deleted = FALSE
                    AND project.is_active = TRUE;
                """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (user_id,),
                )

                projects = cur.fetchall()
            output_list = []
            for tpl in projects:
                id, name, last_updated = tpl
                projects_dict = {
                    "name": name,
                    "id": id,
                    "lastUpdated": last_updated.strftime("%Y-%m-%d %H:%M:%S"),
                }
                output_list.append(projects_dict)
                logger.debug(f"{projects_dict=}")
            return output_list
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def create_new_project(
        new_project: CreateProject,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Creates a new project.

        """
        try:
            sql_query = """
                    INSERT INTO genaie_project (
                        name, is_active,is_deleted,updated_at,
                        created_at,last_updated
                    )
                    VALUES (
                        %s, %s, %s,%s,%s,%s
                    )
                    RETURNING id,name;
                """
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        new_project.projectname,
                        True,
                        False,
                        datetime.now(),
                        datetime.now(),
                        datetime.now(),
                    ),
                )

                db.commit()
                row = cur.fetchone()

            return row[0]
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def assign_apps_to_project(
        project_id: int,
        app_id_list: list[int],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Assigns apps to a project.

        """
        try:
            sql_query = """
                    INSERT INTO genaie_application_project (
                        application_id,project_id
                    )
                    VALUES (
                        %s, %s
                    )
                    RETURNING project_id;
                """
            with db.cursor() as cur:
                for app_id in app_id_list:
                    cur.execute(
                        sql_query,
                        (app_id, project_id),
                    )

                    db.commit()
                    row = cur.fetchone()
            return True, row[0]
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def add_groups_to_project(
        project_id: int,
        grp_id_list: list[int],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Add groups to a project.

        """
        try:
            add_groups_to_project_sql_query = """
                    INSERT INTO genaie_project_group (
                        project_id,group_id
                    )
                    VALUES (
                        %s,%s
                    )
                    RETURNING project_id,group_id;
                """
            with db.cursor() as cur:
                for group_id in grp_id_list:
                    cur.execute(
                        add_groups_to_project_sql_query,
                        (
                            project_id,
                            group_id,
                        ),
                    )

                    db.commit()
                    row = cur.fetchone()

            return row[0]
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def users_in_each_project(
        project_name: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Get all users in each project.

        """
        try:
            get_users_in_project_sql_query = """
                SELECT 
                    gpu.project_id,
                    gpu.user_id,
                    au.email,
                    au.username,
                    gp.name as project_name
                FROM 
                    genaie_project_users gpu
                JOIN 
                    auth_user au ON gpu.user_id = au.id
                JOIN 
                    genaie_project gp ON gpu.project_id = gp.id
                WHERE 
                    gp.name = %s;
            """
            with db.cursor() as cur:
                cur.execute(get_users_in_project_sql_query, (project_name,))
                rows = cur.fetchall()

            users_in_projects = [
                {
                    "projectId": str(row[0]),
                    "userId": str(row[1]),
                    "email": row[2],
                    "username": row[3],
                    "projectName": row[4],
                }
                for row in rows
            ]
            logger.debug(f"{users_in_projects=}")

            return users_in_projects
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def groups_in_each_project(
        project_name: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Get all users in each project.

        """
        try:
            get_users_in_project_sql_query = """
            SELECT 
                gp.id,
                gp.name as project_name,
                ag.name as group_name,
                ag.id as group_id
            FROM 
                genaie_project gp
            JOIN 
                genaie_project_group gpg ON gp.id = gpg.project_id
            JOIN 
                auth_group ag ON gpg.group_id = ag.id
            WHERE 
                gp.name = %s;
        """
            with db.cursor() as cur:
                cur.execute(get_users_in_project_sql_query, (project_name,))
                rows = cur.fetchall()

            users_in_projects = [
                {
                    "projectId": str(row[0]),
                    "projectName": row[1],
                    "groupName": row[2],
                    "groupID": row[3],
                }
                for row in rows
            ]
            logger.debug(f"{users_in_projects=}")

            return users_in_projects
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_projects_by_user_email_id(
        email: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            user_projects_sql_query = """
                SELECT project.id, project.name, project.last_updated
                FROM auth_user
                JOIN genaie_project_users ON auth_user.id = genaie_project_users.user_id
                JOIN genaie_project AS project ON genaie_project_users.project_id = project.id
                WHERE auth_user.email = %s
                AND project.is_deleted = FALSE
                AND project.is_active = TRUE;
            """

            with db.cursor() as cur:
                cur.execute(
                    user_projects_sql_query,
                    (email,),
                )

                project_list = cur.fetchall()
                logger.debug(f"{project_list=}")

            output_list = []
            for tpl in project_list:
                id, name, last_updated = tpl
                projects_dict = {
                    "project_name": name,
                    "project_id": id,
                    "lastUpdated": last_updated.strftime("%Y-%m-%d %H:%M:%S"),
                }
                output_list.append(projects_dict)
            if len(output_list) > 0:
                return True, output_list
            else:
                return False, output_list

        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def add_user_into_existing_project(
        user_id: int,
        project_id_list: list[int],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Adds a user to the given project ids according to the user id.

        """
        try:
            ##ADD user to existing projects

            add_users_to_existing_project_sql_query = """
                    INSERT INTO genaie_project_users (
                        user_id, project_id
                    )
                    VALUES (
                        %s, %s
                    )
                    RETURNING user_id;
                """
            with db.cursor() as cur:
                for i in project_id_list:
                    cur.execute(
                        add_users_to_existing_project_sql_query,
                        (user_id, i),
                    )
                    db.commit()
                    row = cur.fetchone()

            return True, row[0]
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def update_last_updated_time(
        project_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Updates the last updated time of a project.

        """
        try:
            update_last_updated_time_sql_query = """
                    UPDATE genaie_project
                    SET last_updated = %s
                    WHERE id = %s
                    RETURNING id;
                """
            with db.cursor() as cur:
                cur.execute(
                    update_last_updated_time_sql_query,
                    (datetime.now(), project_id),
                )
                db.commit()
                row = cur.fetchone()

            return True, row[0]
        except Exception as err:
            logger.error(f"{err=}")
            raise err
