from datetime import datetime
import psycopg2
from fastapi import Depends
from settings.loguru import logger
from helper.custom_errors import AttributeNotFoundError
from settings.db import get_db_connection


class QNAFlowDBController:
    @staticmethod
    def get_prompt_template_by_flowid(
        flow_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT qf.name, qf.temperature, qf.template_id, qt.prompt_template, qt.output_columns, qt.name, qt.metadata, qt.mode
                FROM qna_flow qf
                INNER JOIN qna_template qt
                ON qf.template_id = qt.id
                WHERE qf.id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(flow_id),),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError("Prompt template not found. Please check the flow id!")
            flow_details = {
                "name": row[0],
                "temperature": row[1],
                "templateId": row[2],
                "promptTemplate": row[3],
                "outputColumns": row[4],
                "templateName": row[5],
                "metadata": row[6],
                "mode": row[7],
            }
            return flow_details
        except Exception as err:
            raise err

    @staticmethod
    def get_flow_by_id(
        flow_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT id, name, template_id, temperature
                FROM qna_flow qf
                WHERE qf.id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(flow_id),),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError("Flow not found. Please check the flow id!")
            flow_details = {
                "id": row[0],
                "name": row[1],
                "templateId": row[2],
                "temperature": row[3],
            }
            return flow_details
        except Exception as err:
            raise err

    @staticmethod
    def get_doctemplatefiles_by_flowid(
        flow_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT qfdtf.doctemplatefile_id as id, qd.upload_file_path , qd.file_type
                FROM qna_flow_doc_template_files qfdtf
                INNER JOIN qna_doctemplatefile qd 
                ON qfdtf.doctemplatefile_id = qd.id
                WHERE qfdtf.flow_id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(flow_id),),
                )
                rows = cur.fetchall()
                logger.debug(f"{rows=}")
                doc_template_files = [
                    {
                        "id": str(row[0]),
                        "docTemplates": {"uploadFilePath": row[1], "fileType": row[2]},
                    }
                    for row in rows
                ]
                return doc_template_files
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def update_flow_by_id(
        flow_id: int,
        template_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        from api.db.instance import InstanceDBController

        try:
            sql_update_query = """
                UPDATE qna_flow AS qf
                SET template_id = %s, updated_at = %s
                WHERE qf.id = %s;
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        str(template_id),
                        str(datetime.now()),
                        str(flow_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            if rows == 0:
                raise AttributeNotFoundError("Flow not updated. Please check the Id!")
            # update the instance table last updated time
            instance_details = InstanceDBController.get_instance_by_flow_id(flow_id, db)
            instance_id = instance_details.get("instanceId")
            InstanceDBController.update_last_updated_time(instance_id, db)
            return flow_id
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    def update_flow_temperature_template_by_id(
        flow_id: int,
        template_id: int,
        temperature: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        from api.db.instance import InstanceDBController

        try:
            sql_update_query = """
                UPDATE qna_flow AS qf
                SET template_id = %s, temperature = %s, updated_at = %s
                WHERE qf.id = %s;
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        str(template_id),
                        str(temperature),
                        str(datetime.now()),
                        str(flow_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            if rows == 0:
                raise AttributeNotFoundError("Flow not updated. Please check the Id!")
            # update the instance table last updated time
            instance_details = InstanceDBController.get_instance_by_flow_id(flow_id, db)
            instance_id = instance_details.get("instanceId")
            InstanceDBController.update_last_updated_time(instance_id, db)
            return flow_id
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def create_qna_flow_knowledge(
        flow_id: int,
        knowledge_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        from api.db.instance import InstanceDBController

        try:
            insert_sql = """
                INSERT INTO qna_flow_knowledge (
                    flow_id, knowledge_id
                )
                VALUES (
                    %s, %s
                )
                RETURNING id;
            """
            logger.debug(f"{insert_sql=}")
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        str(flow_id),
                        str(knowledge_id),
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"create qna_flow_knowledge: {row}")
            response = {
                "id": row[0],
            }
            # update the instance table last updated time
            instance_details = InstanceDBController.get_instance_by_flow_id(flow_id, db)
            instance_id = instance_details.get("instanceId")
            InstanceDBController.update_last_updated_time(instance_id, db)
            return response
        except Exception as err:
            raise err
