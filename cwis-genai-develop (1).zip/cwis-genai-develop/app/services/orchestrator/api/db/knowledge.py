from datetime import datetime
import psycopg2
from fastapi import Depends
from api.db.qna_document import QNADocumentDBController
from settings.loguru import logger
from helper.custom_errors import AttributeNotFoundError
from api.schemas.common.knowledge import CreateKnowledgeInput
from settings.db import get_db_connection


class KnowledgeDBController:
    @staticmethod
    def create_knowledge(
        create_knowledge_input: CreateKnowledgeInput,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            insert_sql = """
                INSERT INTO qna_knowledge (
                    name, created_at, updated_at
                )
                VALUES (
                    %s, %s, %s
                )
                RETURNING id;
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        str(create_knowledge_input.name),
                        str(datetime.now()),  # createdAt
                        str(datetime.now()),  # updatedAt
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"create knowledge {row=}")
            response = {"id": row[0]}
            logger.debug(f"{response=}")
            return response
        except Exception as err:
            raise err

    @staticmethod
    def get_knowledge_by_id(
        knowledge_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT qk.id, qk.name, qk.data_source_id, qk.knowledge_base_id, qk.s3_uri, qk.knowledge_ingestion_job_id
                FROM qna_knowledge qk
                WHERE qk.id = %s;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(knowledge_id),),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError(error_message="knowledge not found. Please check the knowledge id!")
            knowledge = {
                "id": str(row[0]),
                "name": str(row[1]),
                "data_source_id": row[2],
                "knowledge_base_id": row[3],
                "s3_uri": row[4],
            }
            return knowledge
        except Exception as err:
            raise err

    @staticmethod
    def get_knowledges_by_flow_id(
        flow_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # get knowledge_id, name using flow_id

            sql_query = """
                SELECT qk.id, qk.name,qk.data_source_id,qk.knowledge_base_id,qk.s3_uri,qk.knowledge_ingestion_job_id
                FROM qna_knowledge qk
                INNER JOIN qna_flow_knowledge qfk
                ON qk.id = qfk.knowledge_id 
                WHERE qfk.flow_id = %s;
            """

            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(flow_id),),
                )
                rows = cur.fetchall()
                logger.debug(f"{rows=}")
                knowledges = [
                    {
                        "id": row[0],
                        "name": row[1],
                        "datasourceid": row[2] if row[2] is not None else None,
                        "knowledge_base_id": row[3] if row[3] is not None else None,
                        "s3_uri": row[4] if row[4] is not None else None,
                        "knowledge_ingestion_job_id": row[5] if row[5] is not None else None,
                    }
                    for row in rows
                ]
                logger.debug(f"{knowledges=}")

            # get document name and status from qna_document using knowledge_id
            for knowledge in knowledges:
                knowledge_id = knowledge.get("id")
                qna_documents = QNADocumentDBController.get_qna_document_with_knowledge_id(knowledge_id, db)
                doc_names = [row.get("name") for row in qna_documents]
                doc_details = [{"documentId": row.get("id"), "documentName": row.get("name")} for row in qna_documents]
                doc_status = [row.get("status") for row in qna_documents]
                knowledge["status"] = (
                    "Failed"
                    if "Failed" in doc_status
                    else "In Progress"
                    if "In Progress" in doc_status
                    else "Completed"
                )
                error_id = None
                for row in reversed(qna_documents):
                    if row.get("status") == "Failed":
                        error_id = row.get("requestId")
                        break
                if error_id:
                    knowledge["errorId"] = error_id
                knowledge["documentName"] = doc_names
                knowledge["documentDetails"] = doc_details
            logger.debug(f"final response : {knowledges=}")
            return knowledges
        except Exception as err:
            raise err

    @staticmethod
    def update_knowledge_with_aws_knowledge_base_details(
        
        knowledgebaseid,
        datasourceid,
        knowledge_id:int,
        s3uri,
        knowledge_ingestion_job_id=None,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            insert_sql = """
            UPDATE qna_knowledge
            SET data_source_id = %s, knowledge_base_id = %s,s3_uri = %s, knowledge_ingestion_job_id = %s
            WHERE id = %s
            RETURNING id;
        """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (str(datasourceid), str(knowledgebaseid), str(s3uri), str(knowledge_ingestion_job_id), str(knowledge_id)),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"create knowledge {row=}")
            response = {"id": row[0]}
            logger.debug(f"{response=}")
            return response
        except Exception as err:
            raise err

    @staticmethod
    def remove_knowledge_from_db(
        knowledge_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            knowledge_document_removal_response = {}
            # Remove all Document-Knowledge F-Key relationship from qna_document table
            retrieve_knowledge_docs_query = """
                SELECT qd.name
                FROM qna_document qd
                WHERE qd.knowledge_id = %s
            """
            logger.debug(f"{retrieve_knowledge_docs_query=}")
            with db.cursor() as cur:
                cur.execute(
                    retrieve_knowledge_docs_query,
                    (str(knowledge_id),),
                )
                existing_docs = cur.fetchall()
            logger.debug(f"{existing_docs=}")
            knowledge_documents_count = len(existing_docs)

            # Remove documents from knowledge one-by-one
            document_deletion_count = 0
            for document_name in existing_docs:
                document_removal_query = """
                    DELETE FROM qna_document qd
                    WHERE qd.knowledge_id = %s
                    AND qd.name = %s;
                """
                logger.debug(f"{document_removal_query=}")
                with db.cursor() as cur:
                    cur.execute(
                        document_removal_query,
                        (
                            str(knowledge_id),
                            str(document_name[0]),
                        ),
                    )
                    db.commit()
                    document_removal_count = cur.rowcount
                logger.debug(f"{document_removal_count=}")
                document_deletion_count += document_removal_count

            if document_deletion_count == knowledge_documents_count:
                logger.debug(f"Deleted {document_deletion_count} documents from knowledge")
                knowledge_document_removal_response["Documents Deletion Status"] = "Success"
            elif document_deletion_count == 0:
                logger.debug(f"No documents found for knowledge {knowledge_id}")
                knowledge_document_removal_response["Documents Deletion Status"] = "No Documents Found"
            else:
                logger.debug(f"Deleted {document_deletion_count} documents from knowledge")
                knowledge_document_removal_response["Documents Deletion Status"] = "Partial Success"

            # Delete knowledge from DB
            remove_knowledge_query = """
                DELETE FROM qna_knowledge qk
                WHERE qk.id = %s;
            """
            logger.debug(f"{remove_knowledge_query=}")
            with db.cursor() as cur:
                cur.execute(
                    remove_knowledge_query,
                    (str(knowledge_id),),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")

            if rows == 0:
                raise AttributeNotFoundError("Knowledge ID not found in database!!!")
            knowledge_document_removal_response["Knowledge Deletion Status"] = "Success"
            return {f"Knowledge ID {knowledge_id}": knowledge_document_removal_response}

        except Exception as err:
            raise err

    @staticmethod
    def get_flow_id_by_knowledge_id(
        knowledge_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            flow_id_query = """
                SELECT qfk.flow_id
                FROM qna_flow_knowledge qfk
                WHERE qfk.knowledge_id = %s;
            """
            logger.debug(f"{flow_id_query=}")
            with db.cursor() as cur:
                cur.execute(
                    flow_id_query,
                    (str(knowledge_id),),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if not row:
                raise AttributeNotFoundError(error_message="knowledge not found. Please check the knowledge id!")
            flow = {
                "id": int(row[0]),
            }
            logger.debug(f"{flow=}")
            return flow
        except Exception as err:
            raise err

    @staticmethod
    def update_knowledge_datasource_and_ingestion_job(
        datasourceid,
        knowledge_id: int,
        knowledge_ingestion_job_id=None,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Update only the datasource_id and knowledge_ingestion_job_id for a knowledge record
        """
        logger.info(f"Updating knowledge {knowledge_id} with datasource_id: {datasourceid}, ingestion_job_id: {knowledge_ingestion_job_id}")
        try:
            update_sql = """
            UPDATE qna_knowledge
            SET data_source_id = %s, knowledge_ingestion_job_id = %s, updated_at = %s
            WHERE id = %s
            RETURNING id;
            """
            logger.debug(f"{update_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    update_sql,
                    (str(datasourceid), str(knowledge_ingestion_job_id), str(datetime.now()), str(knowledge_id)),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"Updated knowledge {row=}")
            response = {"id": row[0]}
            logger.debug(f"{response=}")
            return response
        except Exception as err:
            logger.error(f"Error updating knowledge datasource and ingestion job: {str(err)}")
            raise err
