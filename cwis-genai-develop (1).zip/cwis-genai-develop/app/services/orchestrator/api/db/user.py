from datetime import datetime, timedelta
from enum import Enum
import math
import psycopg2
from helper.custom_errors import UnprocessableEntityError
from api.db.group import new_pass
from helper.filename_generator import generate_random_string
from settings.loguru import logger
from fastapi import Depends
from settings.db import get_db_connection
import re


def is_email_address(email_id):
    regex = r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$"
    return re.match(regex, email_id)


class UserRoles(str, Enum):
    CONTRIBUTOR = "contributor"
    ADMIN = "admin"
    SUPERADMIN = "superadmin"


class UserDBController:
    @staticmethod
    def verify_user_by_email_id(
        email_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            email_id = email_id.lower()
            if is_email_address(email_id):
                sql_query = """
                        SELECT id, first_name, last_name, email, username, password
                        FROM auth_user au
                        WHERE au.email = %s
                        AND au.is_active = true
                    """
            else:
                sql_query = """
                        SELECT id, first_name, last_name, email, username, password
                        FROM auth_user au
                        WHERE au.username = %s
                        AND au.is_active = true
                    """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(sql_query, (email_id,))

                rows = cur.fetchall()
            projects = [
                {
                    "id": str(row[0]),
                    "first_name": row[1],
                    "last_name": row[2],
                    "email": row[3],
                    "username": row[4],
                    "hashed_password": row[5],
                }
                for row in rows
            ]
            return projects
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def check_user_role(
        email_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            email_id = email_id.lower()
            sql_query = """
                SELECT au.is_active, au.is_staff, au.is_superuser
                FROM auth_user au
                WHERE au.email = %s
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(sql_query, (email_id,))
                row = cur.fetchone()
            logger.debug(f"{row=}")
            # using the UserRoles Enum to check the user role
            if row[2]:
                return UserRoles.SUPERADMIN.value
            elif row[1]:
                return UserRoles.ADMIN.value
            elif row[0]:
                return UserRoles.CONTRIBUTOR.value
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_project_application_by_user(user_id: str, db: psycopg2.extensions.connection = Depends(get_db_connection)):
        try:
            # Get applications corresponding to the user's projects
            query = """
                SELECT gpu.project_id, gap.application_id
                FROM genaie_project_users gpu
                JOIN genaie_application_project gap ON gpu.project_id = gap.project_id
                WHERE gpu.user_id = %s
            """
            with db.cursor() as cur:
                cur.execute(query, (user_id,))
                rows = cur.fetchall()

            # Organize the results into a dictionary with project IDs as keys
            project_apps = {}
            for project_id, application_id in rows:
                if project_id not in project_apps:
                    project_apps[project_id] = []
                project_apps[project_id].append(application_id)

            logger.debug(f"{project_apps=}")
            return project_apps
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def create_new_user(
        user_data: dict,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            email = str(user_data["email"])
            username = str(user_data["username"])
            first_name = user_data.get("firstname")
            last_name = user_data.get("lastname")
            if first_name is None or (isinstance(first_name, float) and math.isnan(first_name)):
                first_name = ""
            if last_name is None or (isinstance(last_name, float) and math.isnan(last_name)):
                last_name = ""
            if user_data.get("password"):
                password = new_pass(str(user_data["password"]))
            else:
                password = new_pass(generate_random_string(9))
            # STEP 1: check if the user already exists
            sql_query = """
                SELECT id
                FROM auth_user
                WHERE email = %s
                OR username = %s
            """
            with db.cursor() as cur:
                cur.execute(sql_query, (email, username))
                row = cur.fetchone()
            if row:
                raise UnprocessableEntityError(
                    error_message=f"User with email {email} or username {username} already exists."
                )
            # STEP 2: create the user
            sql_query = """
                INSERT INTO auth_user (password, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, last_login)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id,username,email;
            """
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        password,
                        False,
                        username,
                        first_name,
                        last_name,
                        email,
                        True,
                        True,
                        datetime.now(),
                        datetime.now(),
                    ),
                )
                user_row = cur.fetchone()
                user_id = user_row[0]
                logger.debug(f"{user_row=}")

            #  Step 3: ADD Permissions to the new user
            add_permissions_sql_query = """
                    INSERT INTO auth_user_user_permissions (
                        user_id, permission_id
                    )
                    VALUES (
                        %s, %s
                    )
                """
            permissions_list = [28, 32, 36, 37, 38, 39, 40]
            with db.cursor() as cur:
                for i in permissions_list:
                    cur.execute(
                        add_permissions_sql_query,
                        (user_id, i),
                    )
                    db.commit()
            logger.debug("permissions added")
            return user_row
        except Exception as err:
            raise err

    @staticmethod
    def get_old_users(
        time_period: int,  # in minutes
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT au.id, au.username, au.email, au.is_staff, au.is_active
                FROM auth_user au
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM genaie_activity_users gau
                    JOIN genaie_activity ga ON gau.activity_id = ga.id
                    WHERE gau.user_id = au.id
                    AND ga.updated_at >= %s
                )
                AND au.date_joined <= %s
                AND au.last_login <= %s
                AND au.is_superuser = %s;
            """
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        str(datetime.now() - timedelta(minutes=time_period)),
                        str(datetime.now() - timedelta(minutes=time_period)),
                        str(datetime.now() - timedelta(minutes=time_period)),
                        False,
                    ),
                )
                rows = cur.fetchall()
            if len(rows) == 0:
                return []
            response = [
                {
                    "id": row[0],
                    "username": row[1],
                    "email": row[2],
                    "is_staff": row[3],
                    "is_active": row[4],
                }
                for row in rows
            ]
            return response
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def delete_user_by_id(
        user_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # delete the project_user mapping
            delete_project_user_sql_query = """
                DELETE FROM genaie_project_users
                WHERE user_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(delete_project_user_sql_query, (user_id,))
                db.commit()
                proj_row_count = cur.rowcount
                logger.debug(f"{proj_row_count=}")

            # delete the user_permissions mapping
            delete_user_permissions_sql_query = """
                DELETE FROM auth_user_user_permissions
                WHERE user_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(delete_user_permissions_sql_query, (user_id,))
                db.commit()
                perm_row_count = cur.rowcount
                logger.debug(f"{perm_row_count=}")

            # delete the activity_user mapping
            delete_activity_user_sql_query = """
                DELETE FROM genaie_activity_users
                WHERE user_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(delete_activity_user_sql_query, (user_id,))
                db.commit()
                act_row_count = cur.rowcount
                logger.debug(f"{act_row_count=}")

            # delete the user_group mapping
            delete_user_group_sql_query = """
                DELETE FROM auth_user_groups
                WHERE user_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(delete_user_group_sql_query, (user_id,))
                db.commit()
                user_group_row_count = cur.rowcount
                logger.debug(f"{user_group_row_count=}")

            # delete the user
            sql_query = """
                DELETE FROM auth_user
                WHERE id = %s;
            """
            with db.cursor() as cur:
                cur.execute(sql_query, (user_id,))
                db.commit()
                user_row_count = cur.rowcount
                logger.debug(f"{user_row_count=}")
            return {"message": "User deleted successfully."}
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def update_last_login(
        user_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                UPDATE auth_user
                SET last_login = %s
                WHERE id = %s;
            """
            with db.cursor() as cur:
                cur.execute(sql_query, (datetime.now(), user_id))
                db.commit()
            return {"message": "Last login updated successfully."}
        except Exception as err:
            logger.error(f"{err=}")
            raise err
