from datetime import datetime
import psycopg2
from fastapi import Depends
from settings.loguru import logger
from helper.custom_errors import DuplicateDataError
from settings.db import get_db_connection


class QNADocTemplateFile:
    @staticmethod
    def create_doc_template_file(
        file_name: str,
        upload_file_path: str,
        file_type: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            insert_sql = """
                INSERT INTO qna_doctemplatefile (name, upload_file_path, file_type, created_at, updated_at)
                VALUES (%s, %s, %s,%s, %s)
                RETURNING id, name, upload_file_path, file_type
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        file_name,
                        upload_file_path,
                        file_type,
                        str(datetime.now()),
                        str(datetime.now()),
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"{row=}")
            response = {
                "id": row[0],
                "name": row[1],
                "uploadFilePath": row[2],
                "fileType": row[3],
            }
            logger.debug(f"{response=}")
            # formatted_response = {"_": {"_": {"node": response}}}
            logger.debug(f"{response=}")
            return response
        except Exception as err:
            raise err

    @staticmethod
    def update_doc_template_ids_for_flow(
        flow_id: str,
        doc_template_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        from api.db.instance import InstanceDBController

        try:
            insert_sql = """
                INSERT INTO qna_flow_doc_template_files (doctemplatefile_id, flow_id)
                VALUES (%s, %s)
                RETURNING id, flow_id, doctemplatefile_id
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                cur.execute(
                    insert_sql,
                    (
                        doc_template_id,
                        flow_id,
                    ),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"{row=}")
            response = {"id": row[0], "flowId": row[1], "doctemplatefile_id": row[2]}
            logger.debug(f"{response=}")
            # update the instance table last updated time
            instance_details = InstanceDBController.get_instance_by_flow_id(flow_id, db)
            instance_id = instance_details.get("instanceId")
            InstanceDBController.update_last_updated_time(instance_id, db)
            return response
        except psycopg2.errors.UniqueViolation:
            raise DuplicateDataError("doctemplatefile_id and flow_id has to be unique!")
        except Exception as err:
            raise err

    @staticmethod
    def delete_doc_template_by_id(
        doc_template_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # Delete Doc template - Flow relation
            delete_flow_doc_template_query = """
                DELETE FROM qna_flow_doc_template_files
                WHERE doctemplatefile_id = %s;
            """
            logger.debug(f"{delete_flow_doc_template_query=}")
            with db.cursor() as cur:
                cur.execute(
                    delete_flow_doc_template_query,
                    (str(doc_template_id),),
                )
                db.commit()
                flow_doc_temp_count = cur.rowcount
            logger.debug(f"{flow_doc_temp_count=}")

            # Delete Doc template
            delete_doc_template_query = """
                DELETE FROM qna_doctemplatefile
                WHERE id = %s;
            """
            logger.debug(f"{delete_doc_template_query=}")
            with db.cursor() as cur:
                cur.execute(
                    delete_doc_template_query,
                    (doc_template_id,),
                )
                db.commit()
                doc_temp_count = cur.rowcount
            logger.debug(f"{doc_temp_count=}")
            return doc_temp_count
        except Exception as err:
            raise err
