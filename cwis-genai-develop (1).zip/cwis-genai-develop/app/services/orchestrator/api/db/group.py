from datetime import datetime
import psycopg2
from passlib.hash import django_pbkdf2_sha256
from settings.loguru import logger
from fastapi import Depends

from settings.db import get_db_connection
from api.schemas.common.activity import (
    CreateUserGroupID,
)
from helper.filename_generator import (
    generate_random_string,
)


def new_pass(plain_password):
    verified = django_pbkdf2_sha256.hash(plain_password)
    return verified


class GroupsDBController:
    @staticmethod
    def add_groups_to_user(
        user_id: int,
        group_id_list: list[int],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Adds the user to the group ids according to the user id.

        """
        try:
            ##ADD Groups to the new user

            add_groups_sql_query = """
                    INSERT INTO auth_user_groups (
                        user_id, group_id
                    )
                    VALUES (
                        %s, %s
                    )
                    RETURNING user_id;
                """
            with db.cursor() as cur:
                for i in group_id_list:
                    cur.execute(
                        add_groups_sql_query,
                        (user_id, i),
                    )
                    db.commit()
                    row = cur.fetchone()
            return True, row[0]
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def create_new_user(
        new_user,  # Made generic to accept both CreateUserProjectID and CreateUserGroupID
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Creates a new user .
        Accepts both CreateUserProjectID and CreateUserGroupID models.
        """
        try:
            new_password = new_pass(generate_random_string(9))
            username = new_user.email
            username = username.split("@")[0]
            sql_query = """
                    INSERT INTO auth_user (
                        password, is_superuser,
                        username, first_name, last_name,email,is_staff,is_active,date_joined
                    )
                    VALUES (
                        %s, %s, %s, %s, %s, %s, %s, %s, %s
                    )
                    RETURNING id,username,email;
                """
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        new_password,
                        new_user.is_superuser,
                        username,
                        username,
                        username,
                        new_user.email,
                        new_user.is_staff,
                        new_user.is_active,
                        datetime.now(),
                    ),
                )

                db.commit()
                row = cur.fetchone()
                user_id = row[0]

            ##ADD Permissions to the new user

            add_permissions_sql_query = """
                    INSERT INTO auth_user_user_permissions (
                        user_id, permission_id
                    )
                    VALUES (
                        %s, %s
                    )
                """
            permissions_list = [28, 32, 36, 37, 38, 39, 40]
            with db.cursor() as cur:
                for i in permissions_list:
                    cur.execute(
                        add_permissions_sql_query,
                        (user_id, i),
                    )
                    db.commit()
            return row
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def create_new_group(
        group_name: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Creates a new group .
        """
        try:
            logger.debug(f"{group_name=}")
            sql_query = """
                    INSERT INTO auth_group (
                        name
                    )
                    VALUES (
                        %s
                    )
                    RETURNING id,name;
                """
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (group_name,),
                )

                db.commit()
                row = cur.fetchone()
                group_id = row[0]
            logger.debug(f"{row=}")

            ##ADD Permissions to the new group

            add_permissions_sql_query = """
                    INSERT INTO auth_group_permissions (
                        group_id, permission_id
                    )
                    VALUES (
                        %s, %s
                    )
                """
            permissions_list = [28, 32, 36, 37, 38, 40]
            with db.cursor() as cur:
                for i in permissions_list:
                    cur.execute(
                        add_permissions_sql_query,
                        (group_id, i),
                    )
                    db.commit()
            return row
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_groups_by_user_email_id(
        email: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_groups_by_email_sql = """
                SELECT auth_group.id, auth_group.name
                FROM auth_user
                JOIN auth_user_groups ON auth_user.id = auth_user_groups.user_id
                JOIN auth_group ON auth_user_groups.group_id = auth_group.id
                WHERE auth_user.email = %s;
            """

            with db.cursor() as cur:
                cur.execute(
                    get_groups_by_email_sql,
                    (email,),
                )
                groups_list = cur.fetchall()

            output_list = []
            for tpl in groups_list:
                id, name = tpl
                groups_dict = {"group_name": name, "group_id": id}
                output_list.append(groups_dict)

            if len(output_list) > 0:
                return True, output_list
            else:
                return False, output_list

        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def get_all_groups(
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_all_groups_sql = """
                SELECT auth_group.id, auth_group.name
                FROM auth_group;
            """

            with db.cursor() as cur:
                cur.execute(
                    get_all_groups_sql,
                )
                groups_list = cur.fetchall()

            output_list = []
            for tpl in groups_list:
                id, name = tpl
                groups_dict = {"group_name": name, "group_id": id}
                output_list.append(groups_dict)
            return output_list
        except Exception as err:
            raise err
