import json
import psycopg2
from datetime import datetime, timedelta
from api.db.template import QNATemplateDBController
from api.db.qna_doctemplatefile import QNADocTemplateFile
from settings.loguru import logger
from fastapi import Depends
from api.schemas.common.instance import (
    CreateInstanceInput,
    PatchInstanceInput,
)
from helper.custom_errors import (
    AttributeNotFoundError,
    DuplicateDataError,
    UnprocessableEntityError,
)
from api.db.flow import QNAFlowDBController
from api.db.knowledge import KnowledgeDBController
from settings.db import get_db_connection
from api.schemas.common.instance import ChunkingParams
from api.controllers.common.ingestion_job import IngestionJobController

def _parse_chunking_params(chunking_params_data):
    """Helper function to safely parse chunking_params JSON"""
    if not chunking_params_data:
        return None

    # If it's already a dict/object (from PostgreSQL JSONField), return as-is
    if isinstance(chunking_params_data, (dict, list)):
        return chunking_params_data

    # If it's a string, try to parse it as JSON
    if isinstance(chunking_params_data, (str, bytes, bytearray)):
        try:
            return json.loads(chunking_params_data)
        except (json.JSONDecodeError, TypeError) as e:
            logger.warning(f"Failed to parse chunking_params JSON: {e}")
            return None

    # For any other type, log and return None
    logger.warning(f"Unexpected chunking_params type: {type(chunking_params_data)}")
    return None


class InstanceDBController:
    @staticmethod
    def get_instances_by_project_application_id(
        project_id: int,
        application_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """SELECT gi.id, name, flow, is_active, project_id, application_id,
                    cloud_environment, render_markdown, llm_guard, llm_model, last_updated
                    FROM genaie_instance gi 
                    WHERE gi.application_id = %s 
                    AND gi.project_id = %s
                    AND gi.is_active = true
                """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        application_id,
                        project_id,
                    ),
                )

                rows = cur.fetchall()
            logger.debug(f"{rows=}")
            projects = [
                {
                    "id": str(row[0]),
                    "name": row[1],
                    "flow": row[2],
                    "isActive": row[3],
                    "projectId": str(row[4]),
                    "applicationId": str(row[5]),
                    "cloudEnvironment": str(row[6]),
                    "renderMarkdown": row[7],
                    "llmGuard": row[8],
                    "llmModel": row[9],
                    "lastUpdated": row[10].strftime("%Y-%m-%d %H:%M:%S"),
                }
                for row in rows
            ]
            return projects
        except Exception as err:
            logger.error(f"{err=}")
            raise err

    @staticmethod
    def create_instance(
        create_instance_input: CreateInstanceInput,
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # step 1 - get user group id
            get_user_group_query = """
                SELECT aug.id, aug.user_id, aug.group_id
                FROM auth_user_groups aug
                WHERE aug.user_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(
                    get_user_group_query,
                    (str(user_id),),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"step 1 - get genaie user groupid :{row=}")

            # Step 2 - create genaie instance
            insert_sql = """
                INSERT INTO genaie_instance (name, project_id, application_id, 
                chunking_strategy, k_near_chunks, chunk_size, is_active,
                created_at, updated_at, cloud_environment, render_markdown, llm_guard, 
                llm_model, query_expansion, vector_db, embedding_choice, last_updated, 
                is_updated_model, guardrails_id, chunking_params)
                VALUES (%s, %s, %s, %s, %s, %s, true, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id, name, application_id, flow, project_id, chunking_strategy, 
                k_near_chunks, chunk_size, cloud_environment, render_markdown, llm_guard, 
                llm_model, query_expansion, vector_db, embedding_choice, is_updated_model, chunking_params;
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                chunking_params_json = None
                if create_instance_input.chunking_params:
                    try:
                        chunking_params_json = json.dumps(
                            create_instance_input.chunking_params.model_dump()
                        )
                    except (TypeError, ValueError) as e:
                        logger.error(f"Failed to serialize chunking_params: {e}")

                cur.execute(
                    insert_sql,
                    (
                        create_instance_input.name,
                        create_instance_input.projectId,
                        create_instance_input.applicationId,
                        create_instance_input.chunkingStrategy,
                        create_instance_input.kNearChunks,
                        create_instance_input.chunkSize,
                        str(datetime.now()),  # createdAt
                        str(datetime.now()),  # updatedAt
                        create_instance_input.cloud_environment,
                        create_instance_input.render_markdown,
                        create_instance_input.llm_guard,
                        create_instance_input.llm_model,
                        create_instance_input.query_expansion,
                        create_instance_input.vector_db,
                        create_instance_input.embedding_choice,
                        str(datetime.now()),  # last_updated
                        create_instance_input.is_updated_model,
                        create_instance_input.guardrails_id,
                        chunking_params_json,
                    ),
                )

                db.commit()
                row = cur.fetchone()
            logger.debug(f"Step 2 - create genaie instance {row}")
            create_instance_response = {
                "id": row[0],
                "name": row[1],
                "applicationId": str(row[2]),
                "flow": row[3],
                "projectId": str(row[4]),
                "chunkingStrategy": row[5],
                "kNearChunks": row[6],
                "chunkSize": row[7],
                "cloudEnvironment": row[8],
                "renderMarkdown": row[9],
                "llmGuard": row[10],
                "llmModel": row[11],
                "queryExpansion": row[12],
                "vectorDb": row[13],
                "embeddingChoice": row[14],
                "isUpdatedModel": row[15],
                "chunkingParams": _parse_chunking_params(row[16]),
            }
            logger.debug(f"{create_instance_response=}")

            # Step 3 - create instance_user table record with instance id and user id
            insert_sql_instance_user = """
                INSERT INTO genaie_instance_users (instance_id, user_id)
                VALUES (%s, %s)
                RETURNING id, instance_id, user_id 
            """
            with db.cursor() as cur:
                cur.execute(
                    insert_sql_instance_user,
                    (create_instance_response.get("id"), user_id),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"Step 3 - insert_sql_instance_user {row}")
            create_instance_user_response = {
                "id": row[0],
                "instanceId": row[1],
                "userId": row[2],
            }
            logger.debug(f"{create_instance_user_response=}")

            # Step 4 - Create QNA Flow record
            insert_qna_flow = """
                INSERT INTO qna_flow (name, is_active, is_deleted, created_at, updated_at, template_id, temperature)
                VALUES (%s, true, false, %s, %s, null, %s)
                RETURNING id, name, template_id, temperature
            """
            with db.cursor() as cur:
                cur.execute(
                    insert_qna_flow,
                    (
                        create_instance_input.name,
                        str(datetime.now()),
                        str(datetime.now()),
                        create_instance_input.temperature,
                    ),
                )
                db.commit()
                row = cur.fetchone()

            logger.debug(f"Step 5 - Create QNA Flow record {row=}")
            create_qna_flow_response = {
                "id": row[0],
                "name": row[1],
                "templateId": row[2],
                "temperature": row[3],
            }
            logger.debug(f"{create_qna_flow_response=}")

            # Step 5 - Update Instance by ID with Flow ID
            update_instance_with_flow_id = """
                UPDATE genaie_instance 
                SET flow = %s, updated_at = %s
                WHERE id = %s; 
            """
            with db.cursor() as cur:
                cur.execute(
                    update_instance_with_flow_id,
                    (
                        create_qna_flow_response.get("id"),
                        str(datetime.now()),
                        create_instance_response.get("id"),
                    ),
                )
                db.commit()
            logger.debug("Step 6 - Update Instance by ID with Flow ID completed")

            # Step 6 - Get Instance by ID, return the o/p as API response
            query_get_instance_by_id = """
                SELECT gi.id, name, application_id, flow, project_id, chunking_strategy,
                k_near_chunks, chunk_size, cloud_environment, render_markdown, llm_guard, 
                llm_model, query_expansion, vector_db, embedding_choice, is_updated_model , chunking_params
                FROM genaie_instance gi 
                WHERE gi.id = %s
            """
            with db.cursor() as cur:
                cur.execute(
                    query_get_instance_by_id,
                    (create_instance_response.get("id"),),
                )
                db.commit()
                row = cur.fetchone()

            logger.debug(f"Step 7 - Get Instance by ID {row=}")
            final_get_instance_by_id = {
                "id": str(row[0]),
                "name": row[1],
                "applicationId": str(row[2]),
                "flow": row[3],
                "projectId": str(row[4]),
                "chunkingStrategy": row[5],
                "kNearChunks": row[6],
                "chunkSize": int(row[7]),
                "cloudEnvironment": row[8],
                "renderMarkdown": row[9],
                "llm_guard": row[10],
                "llm_model": row[11],
                "queryExpansion": row[12],
                "vectorDb": row[13],
                "embeddingChoice": row[14],
                "isUpdatedModel": row[15],
                "chunkingParams": row[16],
            }
            logger.debug(f"Step 7 - Get Instance by ID {final_get_instance_by_id=}")
            return final_get_instance_by_id
        except psycopg2.errors.UniqueViolation:
            raise DuplicateDataError(
                "Instance Name has to be unique. Please setup the instance again."
            )
        except Exception as err:
            raise err

    @staticmethod
    def create_instance_llm_guard(
        create_instance_input: CreateInstanceInput,
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # step 1 - get user group id
            get_user_group_query = """
                SELECT aug.id, aug.user_id, aug.group_id
                FROM auth_user_groups aug
                WHERE aug.user_id = %s;
            """
            with db.cursor() as cur:
                cur.execute(
                    get_user_group_query,
                    (str(user_id),),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"step 1 - get genaie user groupid :{row=}")

            # Step 2 - create genaie instance
            insert_sql = """
                INSERT INTO genaie_instance (name, project_id, application_id, 
                chunking_strategy, k_near_chunks, chunk_size, is_active, 
                created_at, updated_at, cloud_environment, render_markdown, llm_guard, 
                llm_model, query_expansion, vector_db, embedding_choice, last_updated, llm_guard_value, 
                is_updated_model, guardrails_id, chunking_params)
                VALUES (%s, %s, %s, %s, %s, %s, true, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id, name, application_id, flow, project_id, chunking_strategy, 
                k_near_chunks, chunk_size, cloud_environment, render_markdown, llm_guard, 
                llm_model, query_expansion, vector_db, embedding_choice,llm_guard_value, is_updated_model, chunking_params;
            """
            logger.debug(f"{insert_sql=}")
            with db.cursor() as cur:
                chunking_params_json = None
                if create_instance_input.chunking_params:
                    try:
                        chunking_params_json = json.dumps(
                            create_instance_input.chunking_params.model_dump()
                        )
                    except (TypeError, ValueError) as e:
                        logger.error(f"Failed to serialize chunking_params: {e}")
                cur.execute(
                    insert_sql,
                    (
                        create_instance_input.name,
                        create_instance_input.projectId,
                        create_instance_input.applicationId,
                        create_instance_input.chunkingStrategy,
                        create_instance_input.kNearChunks,
                        create_instance_input.chunkSize,
                        str(datetime.now()),  # createdAt
                        str(datetime.now()),  # updatedAt
                        create_instance_input.cloud_environment,
                        create_instance_input.render_markdown,
                        create_instance_input.llm_guard,
                        create_instance_input.llm_model,
                        create_instance_input.query_expansion,
                        create_instance_input.vector_db,
                        create_instance_input.embedding_choice,
                        str(datetime.now()),  # last_updated
                        create_instance_input.llm_guard_value,
                        create_instance_input.is_updated_model,
                        create_instance_input.guardrails_id,
                        chunking_params_json,
                    ),
                )

                db.commit()
                row = cur.fetchone()
            logger.debug(f"Step 2 - create genaie instance {row}")
            create_instance_response = {
                "id": row[0],
                "name": row[1],
                "applicationId": str(row[2]),
                "flow": row[3],
                "projectId": str(row[4]),
                "chunkingStrategy": row[5],
                "kNearChunks": row[6],
                "chunkSize": row[7],
                "cloudEnvironment": row[8],
                "renderMarkdown": row[9],
                "llmGuard": row[10],
                "llm_guard_value": row[15],
                "llmModel": row[11],
                "queryExpansion": row[12],
                "vectorDb": row[13],
                "embeddingChoice": row[14],
                "chunkingParams": _parse_chunking_params(row[16]),
            }
            
            logger.debug(f"{create_instance_response=}")

            # Step 3 - create instance_user table record with instance id and user id
            insert_sql_instance_user = """
                INSERT INTO genaie_instance_users (instance_id, user_id)
                VALUES (%s, %s)
                RETURNING id, instance_id, user_id 
            """
            with db.cursor() as cur:
                cur.execute(
                    insert_sql_instance_user,
                    (create_instance_response.get("id"), user_id),
                )
                db.commit()
                row = cur.fetchone()
            logger.debug(f"Step 3 - insert_sql_instance_user {row}")
            create_instance_user_response = {
                "id": row[0],
                "instanceId": row[1],
                "userId": row[2],
            }
            logger.debug(f"{create_instance_user_response=}")

            # Step 4 - Create QNA Flow record
            insert_qna_flow = """
                INSERT INTO qna_flow (name, is_active, is_deleted, created_at, updated_at, template_id, temperature)
                VALUES (%s, true, false, %s, %s, null, %s)
                RETURNING id, name, template_id, temperature
            """
            with db.cursor() as cur:
                cur.execute(
                    insert_qna_flow,
                    (
                        create_instance_input.name,
                        str(datetime.now()),
                        str(datetime.now()),
                        create_instance_input.temperature,
                    ),
                )
                db.commit()
                row = cur.fetchone()

            logger.debug(f"Step 5 - Create QNA Flow record {row=}")
            create_qna_flow_response = {
                "id": row[0],
                "name": row[1],
                "templateId": row[2],
                "temperature": row[3],
            }
            logger.debug(f"{create_qna_flow_response=}")

            # Step 5 - Update Instance by ID with Flow ID
            update_instance_with_flow_id = """
                UPDATE genaie_instance 
                SET flow = %s, updated_at = %s
                WHERE id = %s; 
            """
            with db.cursor() as cur:
                cur.execute(
                    update_instance_with_flow_id,
                    (
                        create_qna_flow_response.get("id"),
                        str(datetime.now()),
                        create_instance_response.get("id"),
                    ),
                )
                db.commit()
            logger.debug("Step 6 - Update Instance by ID with Flow ID completed")

            # Step 6 - Get Instance by ID, return the o/p as API response
            query_get_instance_by_id = """
                SELECT gi.id, name, application_id, flow, project_id, chunking_strategy,
                k_near_chunks, chunk_size, cloud_environment, render_markdown, llm_guard, 
                llm_model, query_expansion, vector_db, embedding_choice,is_updated_model, chunking_params
                FROM genaie_instance gi 
                WHERE gi.id = %s
            """
            with db.cursor() as cur:
                cur.execute(
                    query_get_instance_by_id,
                    (create_instance_response.get("id"),),
                )
                db.commit()
                row = cur.fetchone()

            logger.debug(f"Step 7 - Get Instance by ID {row=}")
            final_get_instance_by_id = {
                "id": str(row[0]),
                "name": row[1],
                "applicationId": str(row[2]),
                "flow": row[3],
                "projectId": str(row[4]),
                "chunkingStrategy": row[5],
                "kNearChunks": row[6],
                "chunkSize": int(row[7]),
                "cloudEnvironment": row[8],
                "renderMarkdown": row[9],
                "llm_guard": row[10],
                "llm_model": row[11],
                "queryExpansion": row[12],
                "vectorDb": row[13],
                "embeddingChoice": row[14],
                "isUpdatedModel": row[15],
                "chunkingParams":row[16]
            }
            logger.debug(f"Step 7 - Get Instance by ID {final_get_instance_by_id=}")
            return final_get_instance_by_id
        except psycopg2.errors.UniqueViolation:
            raise DuplicateDataError(
                "Instance Name has to be unique. Please setup the instance again."
            )
        except Exception as err:
            raise err

    @staticmethod
    def get_instance_by_id(
        id: int, db: psycopg2.extensions.connection = Depends(get_db_connection)
    ):
        try:
            # dates to check for invalid data
            start_date = "2024-06-26:20:45:01"
            end_date = "2024-07-18:9:30:00"
            start_date = datetime.strptime(start_date, "%Y-%m-%d:%H:%M:%S")
            end_date = datetime.strptime(end_date, "%Y-%m-%d:%H:%M:%S")
            logger.debug(f"{start_date=}, {end_date=}")

            sql_query = """SELECT name, application_id, flow, project_id, k_near_chunks,
            chunk_size, chunking_strategy, cloud_environment, render_markdown, llm_guard,
            scanner_configs, llm_model, query_expansion, vector_db, embedding_choice, last_updated,llm_guard_value,aws_guardrail_id,is_updated_model, guardrails_id, chunking_params,
            CASE
            WHEN created_at BETWEEN %s AND %s THEN true
            ELSE false
            END AS isDataInvalid
            FROM genaie_instance gi 
            WHERE gi.id = %s and gi.is_active = true
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        start_date,
                        end_date,
                        str(id),
                    ),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if row is None:
                raise AttributeNotFoundError(
                    "Instance not found. Please check the Instance Id!"
                )

            flow_sql_query = """
                SELECT qf.name, qf.temperature, qf.template_id, qt.prompt_template, qt.name, qt.output_columns, qt.metadata, qt.mode
                FROM qna_flow qf
                INNER JOIN qna_template qt
                ON qf.template_id = qt.id
                WHERE qf.id = %s;
            """
            logger.debug(f"{flow_sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    flow_sql_query,
                    (str(row[2]),),
                )
                flow_row = cur.fetchone()
            logger.debug(f"{flow_row=}")

            # If flow_row is None, ignore qna_template table and check only in qna_flow
            if flow_row is None:
                # If flow ID exists, get the temperature value
                flow_table_query = """
                    SELECT qf.name, qf.temperature
                    from qna_flow qf
                    where qf.id = %s;
                """
                logger.debug(f"{flow_table_query=}")
                with db.cursor() as cur:
                    cur.execute(
                        flow_table_query,
                        (str(row[2]),),
                    )
                    flow_table_row = cur.fetchone()
                logger.debug(f"{flow_table_row=}")

            knowledge_ids = KnowledgeDBController.get_knowledges_by_flow_id(row[2], db)
            status = [knowledge.get("status") for knowledge in knowledge_ids]
            knowledge_status = (
                "Failed"
                if "Failed" in status
                else "In Progress" if "In Progress" in status else "Completed"
            )
            error_id = None
            if knowledge_status == "Failed":
                for k_id in reversed(knowledge_ids):
                    if k_id.get("status") == "Failed":
                        error_id = k_id.get("errorId")
                        break
            temperature = (
                flow_row[1]
                if flow_row
                else (flow_table_row[1] if flow_table_row else "")
            )

            template_id = flow_row[2] if flow_row else ""
            prompt_template = flow_row[3] if flow_row else ""
            prompt_template_name = flow_row[4] if flow_row else ""
            output_columns = flow_row[5] if flow_row else ""
            metadata = flow_row[6] if flow_row else ""
            mode = flow_row[7] if flow_row else ""
            
            # Parse chunking params and extract parsingStrategy
            chunking_params = _parse_chunking_params(row[20])
            chunking_strategy = str(row[6])  # Default to database value
            

            formatted_data = {
                "name": str(row[0]),
                "applicationId": str(row[1]),
                "flow": row[2],
                "projectId": str(row[3]),
                "kNearChunks": row[4],
                "chunkSize": row[5],
                "chunking_strategy": chunking_strategy,  # Use chunking_strategy from chunkingParams if available
                "cloudEnvironment": str(row[7]),
                "renderMarkdown": row[8],
                "llmGuard": row[9],
                "llm_guard_value": row[16],
                "aws_guardrail_id": row[17],
                "scannerConfigs": row[10],
                "llmModel": row[11],
                "queryExpansion": row[12],
                "vectorDb": row[13],
                "embeddingChoice": row[14],
                "templateId": template_id,
                "temperature": temperature,
                "template": prompt_template,
                "templateName": prompt_template_name,
                "outputColumns": output_columns,
                "knowledgeIds": knowledge_ids,
                "isDataInvalid": row[21],  # This should be the boolean from CASE statement
                "knowledgeStatus": knowledge_status,
                "lastUpdated": row[15].strftime("%Y-%m-%d %H:%M:%S"),
                "metadata": metadata,
                "mode": mode,
                "isUpdatedModel": row[18],
                "guardrails_id": row[19],
                "chunkingParams": chunking_params,  # This should be the JSON
            }
            if error_id:
                formatted_data["errorId"] = error_id
            logger.debug(f"{formatted_data=}")
            return formatted_data
        except Exception as err:
            raise err

    @staticmethod
    def get_refreshed_instance(id: int, db: psycopg2.extensions.connection = Depends(get_db_connection)):
        try:
            # dates to check for invalid data
            start_date = "2024-06-26:20:45:01"
            end_date = "2024-07-18:9:30:00"
            start_date = datetime.strptime(start_date, "%Y-%m-%d:%H:%M:%S")
            end_date = datetime.strptime(end_date, "%Y-%m-%d:%H:%M:%S")
            logger.debug(f"{start_date=}, {end_date=}")

            sql_query = """SELECT name, application_id, flow, project_id, k_near_chunks,
            chunk_size, chunking_strategy, cloud_environment, render_markdown, llm_guard,
            scanner_configs, llm_model, query_expansion, vector_db, embedding_choice, last_updated, llm_guard_value, aws_guardrail_id, is_updated_model, guardrails_id, chunking_params,
            CASE
            WHEN created_at BETWEEN %s AND %s THEN true
            ELSE false
            END AS isDataInvalid
            FROM genaie_instance gi 
            WHERE gi.id = %s and gi.is_active = true
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (
                        start_date,
                        end_date,
                        str(id),
                    ),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if row is None:
                raise AttributeNotFoundError("Instance not found. Please check the Instance Id!")

            flow_sql_query = """
                SELECT qf.name, qf.temperature, qf.template_id, qt.prompt_template, qt.name, qt.output_columns, qt.metadata, qt.mode
                FROM qna_flow qf
                INNER JOIN qna_template qt
                ON qf.template_id = qt.id
                WHERE qf.id = %s;
            """
            logger.debug(f"{flow_sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    flow_sql_query,
                    (str(row[2]),),
                )
                flow_row = cur.fetchone()
            logger.debug(f"{flow_row=}")

            # If flow_row is None, ignore qna_template table and check only in qna_flow
            if flow_row is None:
                # If flow ID exists, get the temperature value
                flow_table_query = """
                    SELECT qf.name, qf.temperature
                    from qna_flow qf
                    where qf.id = %s;
                """
                logger.debug(f"{flow_table_query=}")
                with db.cursor() as cur:
                    cur.execute(
                        flow_table_query,
                        (str(row[2]),),
                    )
                    flow_table_row = cur.fetchone()
                logger.debug(f"{flow_table_row=}")

            knowledge_ids = KnowledgeDBController.get_knowledges_by_flow_id(row[2], db)
            complete_knowledge_status="COMPLETE"
            # error_id = None
            for knowledge in knowledge_ids:
                kb_id = knowledge.get("knowledge_base_id")
                datasourceid = knowledge.get("datasourceid")
                ingestion_job_id = knowledge.get("knowledge_ingestion_job_id")
                
                
                # Get the ingestion job status
                get_job_response = None
                job = {}
                try:
                    get_job_response = IngestionJobController().get_ingestion_job(
                        kb_id=kb_id,
                        data_source_id=datasourceid,
                        ingestion_job_id=ingestion_job_id,
                    )
                    update_job_status=IngestionJobController().check_and_stop_long_running_job(
                        kb_id=kb_id,
                        data_source_id=datasourceid,
                        ingestion_job_id=ingestion_job_id,
                    )
                    job = get_job_response["ingestionJob"]
                    
                    if job["status"] == "FAILED":
                        complete_knowledge_status="FAILED"
                        # error_id = k_id.get("errorId")
                        break
                    elif job["status"] == "IN_PROGRESS" and complete_knowledge_status!="FAILED":
                        complete_knowledge_status="IN_PROGRESS"


                except Exception as e:
                    logger.error(f"Error fetching ingestion job for {kb_id} and {datasourceid}: {e}")
                    continue
            
            # Get scanner_configs from genaie_guardrails table if guardrails_id exists
            guardrails_scanner_configs = row[10]  # Default to instance table value
            if row[19]:  # if guardrails_id exists
                guardrails_query = """
                    SELECT scanner_configs
                    FROM genaie_guardrails
                    WHERE guardrails_id = %s;
                """
                logger.debug(f"{guardrails_query=}")
                with db.cursor() as cur:
                    cur.execute(
                        guardrails_query,
                        (str(row[19]),),
                    )
                    guardrails_row = cur.fetchone()
                logger.debug(f"{guardrails_row=}")
                if guardrails_row:
                    guardrails_scanner_configs = guardrails_row[0]

            temperature = flow_row[1] if flow_row else (flow_table_row[1] if flow_table_row else "")

            template_id = flow_row[2] if flow_row else ""
            prompt_template = flow_row[3] if flow_row else ""
            prompt_template_name = flow_row[4] if flow_row else ""
            output_columns = flow_row[5] if flow_row else ""
            metadata = flow_row[6] if flow_row else ""
            mode = flow_row[7] if flow_row else ""
            
            # Parse chunking params and extract parsing_strategy
            chunking_params = _parse_chunking_params(row[20])
            chunking_strategy = str(row[6])  # Default to database value
            

            formatted_data = {
                "name": str(row[0]),
                "applicationId": str(row[1]),
                "flow": row[2],
                "projectId": str(row[3]),
                "kNearChunks": row[4],
                "chunkSize": row[5],
                "chunking_strategy": chunking_strategy,  # Use chunking_strategy from chunkingParams if available
                "cloudEnvironment": str(row[7]),
                "renderMarkdown": row[8],
                "llmGuard": row[9],
                "llm_guard_value": row[16],
                "aws_guardrail_id": row[17],
                "scannerConfigs": guardrails_scanner_configs,
                "llmModel": row[11],
                "queryExpansion": row[12],
                "vectorDb": row[13],
                "embeddingChoice": row[14],
                "templateId": template_id,
                "temperature": temperature,
                "template": prompt_template,
                "templateName": prompt_template_name,
                "outputColumns": output_columns,
                "knowledgeIds": knowledge_ids,
                "isDataInvalid": row[21],  # This should be the boolean from CASE statement
                "knowledgeStatus": complete_knowledge_status,
                "lastUpdated": row[15].strftime("%Y-%m-%d %H:%M:%S"),
                "metadata": metadata,
                "mode": mode,
                "isUpdatedModel": row[18],
                "guardrails_id": row[19],
                "chunkingParams": chunking_params,  # This should be the JSON
            }
            # if error_id:
            #     formatted_data["errorId"] = error_id
            logger.debug(f"{formatted_data=}")
            return formatted_data
        except Exception as err:
            raise err

    @staticmethod
    def get_instances_by_user_id(
        user_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            sql_query = """
                SELECT name, application_id, flow, project_id, cloud_environment, render_markdown, llm_guard, llm_model, query_expansion, last_updated
                FROM genaie_instance gi
                join genaie_instance_users giu 
                on gi.id = giu.instance_id 
                WHERE giu.user_id = %s and gi.is_active = true;
            """  # noqa: E501
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                )
                response = cur.fetchall()
            logger.debug(f"{response=}")
            formatted_data = [
                {
                    "name": str(item[0]),
                    "applicationId": str(item[1]),
                    "flow": item[2],
                    "projectId": str(item[3]),
                    "cloudEnvironment": str(item[4]),
                    "renderMarkdown": item[5],
                    "llmGuard": item[6],
                    "llmModel": item[7],
                    "queryExpansion": item[8],
                    "lastUpdated": item[9].strftime("%Y-%m-%d %H:%M:%S"),
                }
                for item in response
            ]
            logger.debug(f"{formatted_data=}")
            return formatted_data
        except Exception as err:
            raise err

    @staticmethod
    def patch_instance(
        instance_id: int,
        patch_instance_input: PatchInstanceInput,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            if patch_instance_input.name is None or patch_instance_input.flow is None:
                error_message = "Please provide the name and flow!"
                raise UnprocessableEntityError(error_message)

            get_instance_response = InstanceDBController.get_instance_by_id(
                instance_id, db
            )
            if get_instance_response is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            flow_id = patch_instance_input.flow
            get_flow_response = QNAFlowDBController.get_flow_by_id(flow_id, db)
            if get_flow_response is None:
                raise AttributeNotFoundError(error_message="Flow not found!")
            sql_update_query = """
                UPDATE genaie_instance AS gi
                SET name = %s, flow = %s, updated_at = %s, last_updated = %s
                WHERE gi.id = %s;
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        str(patch_instance_input.name),
                        str(patch_instance_input.flow),
                        str(datetime.now()),
                        str(datetime.now()),
                        str(instance_id),
                    ),
                )
                db.commit()
                rows = cur.fetchone()
            logger.debug(f"{rows=}")
            if len(rows) == 0:
                raise AttributeNotFoundError(
                    "Instance doesnt exist or name already exist. Please check the Id and name!"
                )
            return {"id": instance_id}
        except Exception as err:
            raise err

    @staticmethod
    def update_k_near_chunks(
        instance_id: int,
        k_near_chunks: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_instance_response = InstanceDBController.get_instance_by_id(
                instance_id, db
            )
            if get_instance_response is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            sql_update_query = """
                UPDATE genaie_instance AS gi
                SET k_near_chunks = %s, updated_at = %s, last_updated = %s
                WHERE gi.id = %s
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        str(k_near_chunks),
                        str(datetime.now()),
                        str(datetime.now()),
                        str(instance_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                raise AttributeNotFoundError(
                    "Instance not updated. Please check the Id!"
                )
            return {"id": instance_id}
        except Exception as err:
            raise err

    @staticmethod
    def get_instance_by_flow_id(
        id: int, db: psycopg2.extensions.connection = Depends(get_db_connection)
    ):
        try:
            sql_query = """SELECT id, name, application_id, flow, project_id, k_near_chunks
            FROM genaie_instance gi 
            WHERE gi.flow = %s and gi.is_active = true;
            """
            logger.debug(f"{sql_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_query,
                    (str(id),),
                )
                row = cur.fetchone()
            logger.debug(f"{row=}")
            if row is None:
                raise AttributeNotFoundError(
                    "Instance not found. Please check the Instance Id!"
                )
            formatted_data = {
                "instanceId": row[0],
                "name": str(row[1]),
                "applicationId": str(row[2]),
                "flow": row[3],
                "projectId": str(row[4]),
                "kNearChunks": str(row[5]),
            }
            logger.debug(f"{formatted_data=}")
            return formatted_data
        except Exception as err:
            raise err

    @staticmethod
    def update_temperature_markdown_llm_guard(
        instance_id: int,
        temperature: float,
        llm_guard: bool,
        render_markdown: bool,
        llm_model: str,
        query_expansion: bool,
        chunking_params: ChunkingParams = None,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_instance_response = InstanceDBController.get_instance_by_id(
                instance_id, db
            )
            if get_instance_response is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            sql_update_query = """
                UPDATE genaie_instance AS gi
                SET llm_guard = %s, render_markdown = %s, updated_at = %s, llm_model = %s, query_expansion = %s, last_updated = %s, chunking_params = %s
                WHERE gi.id = %s
            """

            chunking_params_json = None
            if chunking_params is not None:
                try:
                    chunking_params_json = json.dumps(chunking_params.model_dump())
                    logger.debug(
                        f"Successfully serialized chunking_params: {chunking_params_json}"
                    )
                except Exception as e:
                    logger.error(f"Failed to serialize chunking_params: {e}")
                    chunking_params_json = None

            with db.cursor() as cur:
                params = (
                    str(llm_guard),
                    str(render_markdown),
                    str(datetime.now()),
                    str(llm_model),
                    str(query_expansion),
                    str(datetime.now()),
                    chunking_params_json,
                    str(instance_id),
                )

                cur.execute(sql_update_query, params)
                db.commit()
                rows = cur.rowcount

            if rows == 0:
                raise AttributeNotFoundError(
                    "Instance not updated. Please check the Id!"
                )

            # Get Flow ID from Instance ID
            instance_details = InstanceDBController.get_instance_by_id(
                id=instance_id, db=db
            )
            flow_id = instance_details.get("flow")
            logger.debug(f"{flow_id=}")

            # Update temperature in Flow table
            temperature_update_query = """
                UPDATE qna_flow AS qf
                SET temperature = %s, updated_at = %s
                WHERE qf.id = %s;
            """
            logger.debug(f"{temperature_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    temperature_update_query,
                    (
                        str(temperature),
                        str(datetime.now()),
                        str(flow_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                raise AttributeNotFoundError(
                    "Temperature not updated. Please check the Id!"
                )
            return {"id": instance_id}
        except Exception as err:
            raise err

    @staticmethod
    def update_instance_aws_guardrails_id(
        instance_id: str,
        aws_grs_id: str,
        guardrails_params,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_instance_response = InstanceDBController.get_instance_by_id(
                instance_id, db
            )
            if get_instance_response is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            sql_update_query = """
                UPDATE genaie_instance AS gi
                SET aws_guardrail_id = %s ,scanner_configs= %s
                WHERE gi.id = %s
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        str(aws_grs_id),
                        guardrails_params,
                        str(instance_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                raise AttributeNotFoundError(
                    "Instance not updated. Please check the Id!"
                )
            return {"id": instance_id}
        except Exception as err:
            raise err

    @staticmethod
    def update_scanner_configs(
        instance_id: int,
        scanner_configs: json,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_instance_response = InstanceDBController.get_instance_by_id(
                instance_id, db
            )
            if get_instance_response is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            sql_update_query = """
                UPDATE genaie_instance AS gi
                SET scanner_configs = %s, updated_at = %s, last_updated = %s
                WHERE gi.id = %s
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        json.dumps(scanner_configs),
                        str(datetime.now()),
                        str(datetime.now()),
                        str(instance_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                raise AttributeNotFoundError(
                    "Instance not updated. Please check the Id!"
                )
            return {"id": instance_id}
        except Exception as err:
            raise err

    @staticmethod
    def update_instance_guardrails_id(
        instance_id: str,
        guardrails_id: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_instance_response = InstanceDBController.get_instance_by_id(
                instance_id, db
            )
            if get_instance_response is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            sql_update_query = """
                UPDATE genaie_instance AS gi
                SET guardrails_id = %s
                WHERE gi.id = %s
            """
            logger.debug(f"{sql_update_query=}")
            with db.cursor() as cur:
                cur.execute(
                    sql_update_query,
                    (
                        str(guardrails_id),
                        str(instance_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                raise AttributeNotFoundError(
                    "Instance not updated. Please check the Id!"
                )
            return {"id": instance_id}
        except Exception as err:
            raise err

    @staticmethod
    def remove_flow_knowledge_relation(
        instance_id: int,
        knowledge_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
            if instance_details is None:
                raise AttributeNotFoundError(error_message="Instance not found!")

            flow_id = instance_details.get("flow")
            logger.debug(f"{flow_id=}")

            remove_knowledge_query = """
                DELETE FROM qna_flow_knowledge qfk
                WHERE qfk.flow_id = %s
                AND qfk.knowledge_id = %s;
            """
            logger.debug(f"{remove_knowledge_query=}")
            with db.cursor() as cur:
                cur.execute(
                    remove_knowledge_query,
                    (
                        str(flow_id),
                        str(knowledge_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")

            if rows == 0:
                raise AttributeNotFoundError("Flow and Knowledge match not found!!!")
            # update instance last_updated time
            update_instance = InstanceDBController.update_last_updated_time(
                instance_id, db
            )
            logger.debug(f"{update_instance=}")
            instance_details = InstanceDBController.get_instance_by_id(instance_id, db)
            updated_knowledge_ids = instance_details.get("knowledgeIds")
            logger.debug(f"{updated_knowledge_ids=}")
            return {"id": updated_knowledge_ids}

        except Exception as err:
            raise err

    @staticmethod
    def delete_instance_by_id(
        instance_id: int,
        flow_id: int,
        template_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            get_instance_response = InstanceDBController.get_instance_by_id(
                instance_id, db
            )
            if get_instance_response is None:
                raise AttributeNotFoundError(error_message="Instance not found!")
            instance_name = get_instance_response.get("name")

            instance_deletion_response = {}
            # Get Doc templates in the Flow
            get_doc_templates_query = """
                SELECT doctemplatefile_id
                FROM qna_flow_doc_template_files qfdtf
                WHERE qfdtf.flow_id = %s;
            """
            logger.debug(f"{get_doc_templates_query=}")
            with db.cursor() as cur:
                cur.execute(
                    get_doc_templates_query,
                    (str(flow_id),),
                )
                doc_templates_ids = cur.fetchall()
            logger.debug(f"{doc_templates_ids=}")
            doc_templates_ids_count = len(doc_templates_ids)

            # Delete Doc template files
            doc_templates_deletion_count = 0
            for doc_template_id_tuple in doc_templates_ids:
                doc_template_id = doc_template_id_tuple[0]
                deletion_count = QNADocTemplateFile.delete_doc_template_by_id(
                    doc_template_id, db
                )
                doc_templates_deletion_count += deletion_count

            if doc_templates_ids_count == 0:
                logger.debug(
                    "Doc Templates not found. Skipping doc templates deletion!!!"
                )
                instance_deletion_response["Doc Templates Deletion Status"] = (
                    "Doc Templates not Present"
                )
            elif doc_templates_deletion_count == doc_templates_ids_count:
                logger.debug("Doc templates deletion successful!!!")
                instance_deletion_response["Doc Templates Deletion Status"] = (
                    "Successful"
                )
            elif doc_templates_deletion_count == 0:
                logger.debug("Doc templates deletion failed. Please check the Ids!!!")
                instance_deletion_response["Doc Templates Deletion Status"] = "Failed"
            else:
                logger.debug("Doc templates deletion partially successful!!!")
                instance_deletion_response["Doc Templates Deletion Status"] = (
                    "Partially Successful"
                )

            # Delete QNA Flow
            delete_flow_query = """
                DELETE FROM qna_flow qf
                WHERE qf.id = %s;
            """
            logger.debug(f"{delete_flow_query=}")
            with db.cursor() as cur:
                cur.execute(
                    delete_flow_query,
                    (str(flow_id),),
                )
                db.commit()
                delete_flow_count = cur.rowcount
            logger.debug(f"{delete_flow_count=}")
            if delete_flow_count == 0:
                logger.debug("Flow not found. Skipping flow deletion!!!")
                instance_deletion_response["Flow Deletion Status"] = (
                    "Flow not Found or Failed"
                )
            else:
                logger.debug("Flow deletion successful!!!")
                instance_deletion_response["Flow Deletion Status"] = "Successful"

            if template_id != "":
                QNATemplateDBController.delete_template_by_id(template_id, db)
                instance_deletion_response["Template Deletion Status"] = "Successful"
            else:
                logger.debug("Template not found. Skipping template deletion!!!")
                instance_deletion_response["Template Deletion Status"] = (
                    "Template not Present"
                )

            # Get all Acitivies accociated with the instance
            get_instance_activities_query = """
                SELECT ga.id
                FROM genaie_activity ga
                WHERE ga.instance_id = %s;
            """
            logger.debug(f"{get_instance_activities_query=}")
            with db.cursor() as cur:
                cur.execute(
                    get_instance_activities_query,
                    (str(instance_id),),
                )
                instance_activities = cur.fetchall()
            logger.debug(f"{instance_activities=}")
            if len(instance_activities) == 0:
                logger.debug(
                    "Instance does not have any activities associated with. Proceeding with hard deletion..."
                )

                # Delete Instance from genaie_instance_users
                delete_instance_user_query = """
                    DELETE from genaie_instance_users giu
                    WHERE giu.instance_id = %s;
                """
                logger.debug(f"{delete_instance_user_query=}")
                with db.cursor() as cur:
                    cur.execute(
                        delete_instance_user_query,
                        (str(instance_id),),
                    )
                    db.commit()
                    delete_inst_user_count = cur.rowcount
                logger.debug(f"{delete_inst_user_count=}")
                if delete_inst_user_count == 0:
                    logger.debug(
                        "Instance User relation doesnt exist. Skipping deletion!!!"
                    )

                # Delete Instance from genaie_instance
                delete_instance_query = """
                    DELETE from genaie_instance gi
                    WHERE gi.id = %s;
                """
                logger.debug(f"{delete_instance_query=}")
                with db.cursor() as cur:
                    cur.execute(
                        delete_instance_query,
                        (str(instance_id),),
                    )
                    db.commit()
                    delete_inst_count = cur.rowcount
                logger.debug(f"{delete_inst_count=}")
                if delete_inst_count == 0:
                    raise AttributeNotFoundError(
                        "Instance not deleted. Please check the Id!"
                    )
            else:
                logger.debug(
                    "Instance has activities associated with it!!! Proceeding with soft deletion..."
                )
                new_instance_name = (
                    instance_name
                    + "_DELETED_"
                    + datetime.strftime(datetime.now(), "%Y-%m-%d-%H:%M:%S")
                )
                delete_instance_query = """
                    UPDATE genaie_instance AS gi
                    SET is_active = false,
                        deleted_at = %s,
                        name = %s
                    WHERE gi.id = %s;
                """
                with db.cursor() as cur:
                    cur.execute(
                        delete_instance_query,
                        (
                            str(datetime.now()),
                            str(new_instance_name),
                            str(instance_id),
                        ),
                    )
                    db.commit()
                    update_inst_count = cur.rowcount
                logger.debug(f"{update_inst_count=}")
                if update_inst_count == 0:
                    raise AttributeNotFoundError(
                        "Instance not updated. Please check the Id!"
                    )

            return instance_deletion_response
        except Exception as err:
            raise err

    @staticmethod
    def get_activity_by_instance_id(
        instance_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            # Get all Acitivies accociated with the instance
            get_instance_activities_query = """
                SELECT ga.id
                FROM genaie_activity ga
                WHERE ga.instance_id = %s;
            """
            logger.debug(f"{get_instance_activities_query=}")
            with db.cursor() as cur:
                cur.execute(
                    get_instance_activities_query,
                    (str(instance_id),),
                )
                instance_activities = cur.fetchall()
            logger.debug(f"{instance_activities=}")
            return instance_activities
        except Exception as err:
            raise err

    @staticmethod
    def get_old_instances(
        time_period: int,  # in minutes
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            fetch_old_instances_query = """
                SELECT 
                    gi.id, gi.name, gi.application_id, gi.project_id, gi.created_at, gi.last_updated, gi.is_active
                FROM genaie_instance gi
                JOIN genaie_project gp ON gi.project_id = gp.id
                AND gi.created_at <= %s
                AND gi.last_updated <= %s
                AND gi.is_active = TRUE
                AND gp.is_demo = FALSE;
            """
            logger.debug(f"{fetch_old_instances_query=}")
            with db.cursor() as cur:
                cur.execute(
                    fetch_old_instances_query,
                    (
                        str(datetime.now() - timedelta(minutes=time_period)),
                        str(datetime.now() - timedelta(minutes=time_period)),
                    ),
                )
                rows = cur.fetchall()
            response = [
                {
                    "id": row[0],
                    "name": row[1],
                    "applicationId": row[2],
                    "projectId": row[3],
                    "createdAt": row[4],
                    "lastUpdated": row[5].strftime("%Y-%m-%d %H:%M:%S"),
                    "isActive": row[6],
                }
                for row in rows
            ]
            logger.debug(f"{response=}")
            return response
        except Exception as err:
            raise err

    @staticmethod
    def update_last_updated_time(
        instance_id: int,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            update_last_updated_query = """
                UPDATE genaie_instance AS gi
                SET last_updated = %s
                WHERE gi.id = %s;
            """
            logger.debug(f"{update_last_updated_query=}")
            with db.cursor() as cur:
                cur.execute(
                    update_last_updated_query,
                    (
                        str(datetime.now()),
                        str(instance_id),
                    ),
                )
                db.commit()
                rows = cur.rowcount
            logger.debug(f"{rows=}")
            if rows == 0:
                raise AttributeNotFoundError(
                    "Instance not updated. Please check the Id!"
                )
            return {"id": instance_id}
        except Exception as err:
            raise err
