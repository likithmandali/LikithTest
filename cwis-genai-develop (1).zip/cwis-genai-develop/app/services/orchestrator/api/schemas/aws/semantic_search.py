from enum import Enum
from pydantic import BaseModel


class Modes(str, Enum):
    HYBRID: str = "hybrid"
    AUTOCUT: str = "autocut"


class HybridFusion(str, Enum):
    RANKED = "rankedFusion"
    RELATIVE_SCORE = "relativeScoreFusion"


class AdvanceSearchParams(BaseModel):
    mode: Modes = Modes.AUTOCUT
    autocut: int = 1
    query_param: str = ""
    fusion_type: HybridFusion = HybridFusion.RELATIVE_SCORE