from enum import Enum
from pydantic import BaseModel, model_validator
from helper.custom_errors import UnprocessableEntityError
from api.schemas.aws.semantic_search import AdvanceSearchParams
from typing import Optional
from settings.config import CONFIG
from helper.sanitized_string import SanitizedStr

class RoleEnum(str, Enum):
    User = "user"
    Assistant = "assistant"
    System = "system"


class Message(BaseModel):
    role: RoleEnum
    content: str


class ModelParams(BaseModel):
    top_p: int = 1
    frequency_penalty: int = 0
    presence_penalty: int = 0


class AWSBedrockModel(str, Enum):
    CLAUDE_V2_100K = "anthropic.claude-v2"
    CLAUDE_V2_1_200K = "anthropic.claude-v2:1"
    TITAN_V1_TEXT_EMBED_8K = "amazon.titan-embed-text-v1"
    TITAN_TEXT_G1_PREMIER = "amazon.titan-text-premier-v1:0"
    TITAN_TEXT_G1_EXPRESS = "amazon.titan-text-express-v1"
    TITAN_TEXT_LITE = "amazon.titan-text-lite-v1"
    TITAN_MULTIMODAL_EMBED_V1 = "amazon.titan-embed-image-v1"
    AWS_JAMBA_15_MINI = "ai21.jamba-1-5-mini-v1:0"
    AWS_JAMBA_15_LARGE = "ai21.jamba-1-5-large-v1:0"
    AWS_CLAUDE_V35_SONNET = "us.anthropic.claude-3-5-sonnet-20240620-v1:0"
    AWS_CLAUDE_V35_SONNET_v2 = "us.anthropic.claude-3-5-sonnet-20241022-v2:0"
    AWS_CLAUDE_V37_SONNET = "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
    AWS_CLAUDE_V4_SONNET_ARN = f"arn:aws:bedrock:{CONFIG.AWS_REGION}:{CONFIG.AWS_ACCOUNT_ID}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
    AWS_CLAUDE_V4_SONNET = f"us.anthropic.claude-sonnet-4-20250514-v1:0"
    AWS_LLAMA_32_1B_INSTRUCT = "us.meta.llama3-2-1b-instruct-v1:0"
    AWS_LLAMA_32_3B_INSTRUCT = "us.meta.llama3-2-3b-instruct-v1:0"
    AWS_LLAMA_32_11B_VISION_INSTRUCT = "us.meta.llama3-2-11b-instruct-v1:0"
    AWS_LLAMA_32_90B_VISION_INSTRUCT = "us.meta.llama3-2-90b-instruct-v1:0"
    AWS_MISTRAL_7B_INSTRUCT = "mistral.mistral-7b-instruct-v0:2"
    AWS_MIXTRAL_8x_7B_INSTRUCT = "mistral.mixtral-8x7b-instruct-v0:1"
    AWS_MISTRAL_LARGE_2402 = "mistral.mistral-large-2402-v1:0"
    AWS_MISTRAL_SMALL_2402 = "mistral.mistral-small-2402-v1:0"


class AWSPromptSubmitMessages(BaseModel):
    model: AWSBedrockModel = AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN
    messages: list[str] = None
    instance_id: int
    model_params: ModelParams = ModelParams()
    include_references: bool = False

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "instance_id": values.get("instance_id"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        return values


class AWSPromptSubmitStream(BaseModel):
    model: AWSBedrockModel = AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN
    input_text: str = None
    instance_id: int
    additional_json_context: dict | str | None = None
    include_references: bool = False
    render_markdown: bool = False
    guardrails_id: Optional[str] = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "instance_id": values.get("instance_id"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        return values


class AWSPromptSubmit(BaseModel):
    model: AWSBedrockModel = AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN
    input_text: str | None = None
    instance_id: int
    model_params: ModelParams = ModelParams()
    additional_json_context: dict | str | None = None
    include_references: bool = False
    render_markdown: bool = False

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "instance_id": values.get("instance_id"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        return values


class AWSPromptSubmitMessagesStream(BaseModel):
    instance_id: int
    model: AWSBedrockModel = AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN
    messages: list[Message] = None
    include_references: bool = False
    additional_json_context: dict | str | None = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "instance_id": values.get("instance_id"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        return values


class PIIInput(BaseModel):
    content: str

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "content": values.get("content"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        return values


class AWSCaseTimelineInput(BaseModel):
    data: list[dict]
    themes: list[str]
    prompt_template: SanitizedStr | None = None
    model: AWSBedrockModel = AWSBedrockModel.AWS_CLAUDE_V4_SONNET_ARN
    temperature: float = 0.3

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {"data": values.get("data"), "themes": values.get("themes")}

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        return values


class TitanEmbeddingsInput(BaseModel):
    model: AWSBedrockModel = AWSBedrockModel.TITAN_MULTIMODAL_EMBED_V1
    input_text: str | None = None
    input_image: str | None = None  # Base64 encoded image
    output_embedding_length: int = 256
    instance_id: int

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "instance_id": values.get("instance_id"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        # Validate that at least one input is provided
        input_text = values.get("input_text")
        input_image = values.get("input_image")

        if not input_text and not input_image:
            raise UnprocessableEntityError(
                "At least one of 'input_text' or 'input_image' must be provided."
            )

        return values


class ChunkingParams(BaseModel):
    overlapPercent: int = 30
    bufferSize: int = 200
    breakpointChunking: int = 1
    childMaxTokens: int = 300
    parsing_strategy: str = "DEFAULT"
