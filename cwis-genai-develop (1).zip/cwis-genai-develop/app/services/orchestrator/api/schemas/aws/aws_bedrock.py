from enum import Enum
from pydantic import BaseModel
from helper.aws_bedrock_wrapper import Message
from pydantic import model_validator
from settings.config import CONFIG


class Model(str, Enum):
    CLAUDE_V2_100K = "anthropic.claude-v2"
    CLAUDE_V2_1_200K = "anthropic.claude-v2:1"
    AWS_JAMBA_15_MINI = "ai21.jamba-1-5-mini-v1:0"
    AWS_JAMBA_15_LARGE = "ai21.jamba-1-5-large-v1:0"
    TITAN_TEXT_G1_PREMIER = "amazon.titan-text-premier-v1:0"
    TITAN_TEXT_G1_EXPRESS = "amazon.titan-text-express-v1"
    TITAN_TEXT_LITE = "amazon.titan-text-lite-v1"
    AWS_CLAUDE_V35_SONNET = "us.anthropic.claude-3-5-sonnet-20240620-v1:0"
    AWS_CLAUDE_V35_SONNET_v2 = "us.anthropic.claude-3-5-sonnet-20241022-v2:0"
    AWS_CLAUDE_V37_SONNET = "us.anthropic.claude-3-7-sonnet-20250219-v1:0"
    AWS_CLAUDE_V4_SONNET_ARN = f"arn:aws:bedrock:{CONFIG.AWS_REGION}:{CONFIG.AWS_ACCOUNT_ID}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0"
    AWS_CLAUDE_V4_SONNET = "us.anthropic.claude-sonnet-4-20250514-v1:0"  # Model ID only, ARN constructed dynamically
    AWS_LLAMA_32_1B_INSTRUCT = "us.meta.llama3-2-1b-instruct-v1:0"
    AWS_LLAMA_32_3B_INSTRUCT = "us.meta.llama3-2-3b-instruct-v1:0"
    AWS_LLAMA_32_11B_VISION_INSTRUCT = "us.meta.llama3-2-11b-instruct-v1:0"
    AWS_LLAMA_32_90B_VISION_INSTRUCT = "us.meta.llama3-2-90b-instruct-v1:0"
    AWS_MISTRAL_7B_INSTRUCT = "mistral.mistral-7b-instruct-v0:2"
    AWS_MIXTRAL_8x_7B_INSTRUCT = "mistral.mixtral-8x7b-instruct-v0:1"
    AWS_MISTRAL_LARGE_2402 = "mistral.mistral-large-2402-v1:0"
    AWS_MISTRAL_SMALL_2402 = "mistral.mistral-small-2402-v1:0"


class PromptInputStream(BaseModel):
    messages: list[Message]
    model: Model = Model.AWS_CLAUDE_V35_SONNET_v2
    temperature: float = 0.5
    aws_guardrail_id: str | None = None



class PromptInput(BaseModel):
    messages: list[Message]
    model: Model = Model.AWS_CLAUDE_V37_SONNET
    temperature: float = 0.5
    aws_guardrail_id: str | None = None


