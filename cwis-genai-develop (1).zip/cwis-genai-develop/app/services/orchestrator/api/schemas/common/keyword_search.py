from pydantic import BaseModel
from helper.sanitized_string import SanitizedStr


# Deprecated
class KeywordSearchInput(BaseModel):
    keyword: SanitizedStr
    instance_id: int
    k_near_chunks: int = 5
