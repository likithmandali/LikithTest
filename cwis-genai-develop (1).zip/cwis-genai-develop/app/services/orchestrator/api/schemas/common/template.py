from typing import Optional
from pydantic import BaseModel, model_validator
from helper.custom_errors import UnprocessableEntityError
from helper.sanitized_string import SanitizedStr


class CreateTemplateInput(BaseModel):
    name: str
    flow: int
    promptTemplate: SanitizedStr = "You are an AI assistant"
    output_columns: Optional[list[str]] = None
    doc_template_ids: Optional[list[int]] = None
    mode: Optional[bool] = True
    metaData: Optional[dict] = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "name": values.get("name"),
            "flow": values.get("flow"),
        }

        for key, value in required_fields.items():
            if value is None or value == "":
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values


class UpdateTemplateFlow(BaseModel):
    flow_id: int
    template_id: int
    prompt_template: SanitizedStr
    temperature: float
    output_columns: Optional[list[str]] = None
    mode: Optional[bool] = True
    metaData: Optional[dict] = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "flow_id": values.get("flow_id"),
            "template_id": values.get("template_id"),
            "temperature": values.get("temperature"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")
        temperature = values.get("temperature")
        if temperature is not None and (temperature < 0 or temperature > 1):
            raise UnprocessableEntityError("Temperature must be between 0 and 1")

        # Simple blocklist-based safeguard for prompt_template (no length logic added per request)
        prompt = values.get("prompt_template") or ""
        lowered = prompt.lower()
        # Minimal substrings that should not appear (basic XSS vectors)
        blocked = ["<script", "javascript:", "onerror=", "<iframe", "</script"]
        if any(token in lowered for token in blocked):
            raise UnprocessableEntityError("prompt_template contains disallowed substrings.")
        return values
