from enum import Enum
from fastapi import File, UploadFile
from pydantic import BaseModel, model_validator, validator
from helper.custom_errors import UnprocessableEntityError

# from helper.smartgpt_caller import ChunkingStrategy


class ChunkingStrategy(str, Enum):
    HIERARCHICAL: str = "HIERARCHICAL"
    FIXED_SIZE: str = "FIXED_SIZE"
    SEMANTIC: str = "SEMANTIC"


class CreateKnowledgeInput(BaseModel):
    name: str

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {"name": values.get("name")}
        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        return values


class KnowledgeLoadInput(BaseModel):
    knowledge_name: str
    flow_id: int
    chunking_strategy: ChunkingStrategy = ChunkingStrategy.FIXED_SIZE
    files: list[UploadFile] = File(...)

    @validator("knowledge_name")
    def validate_knowledge_name(cls, value):
        if not value:
            raise ValueError("Knowledge name cannot be empty")
        return value

    @validator("flow_id")
    def validate_flow_id(cls, value):
        if value <= 0:
            raise ValueError("Flow ID must be a positive integer")
        return value

    @validator("files")
    def validate_files(cls, value):
        if not value:
            raise ValueError("No files were provided in the request")
        return value


class DeleteDocumentsInput(BaseModel):
    document_ids: list[int]

    @validator("document_ids")
    def validate_document_ids(cls, value):
        if not value:
            raise ValueError("document_ids cannot be empty")
        if not all(isinstance(i, int) and i > 0 for i in value):
            raise ValueError("document_ids must be positive integers")
        return value
