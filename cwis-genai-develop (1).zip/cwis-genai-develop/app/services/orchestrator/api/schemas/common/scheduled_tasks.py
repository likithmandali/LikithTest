from pydantic import BaseModel, model_validator
from helper.custom_errors import UnprocessableEntityError


class ScheduledTaskUpdate(BaseModel):
    task_id: int
    is_active: bool
    interval: int = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "task_id": values.get("task_id"),
            "is_active": values.get("is_active"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values
