from pydantic import BaseModel, model_validator
from helper.custom_errors import UnprocessableEntityError
from helper.sanitized_string import SanitizedStr


class CreateSystemTemplate(BaseModel):
    name: SanitizedStr
    template: SanitizedStr

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "name": values.get("name"),
            "template": values.get("template"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values
