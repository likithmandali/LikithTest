from pydantic import BaseModel
from typing import Optional
from enum import Enum


class CloudProvider(str, Enum):
    AWS: str = "aws"


class GuardrailsRequestBody(BaseModel):
    instance_id: Optional[int] = None
    pii_types: list[str] = []
    content_safety: list = []
    words_to_block: list[str] = []
    cloud_provider: CloudProvider = CloudProvider.AWS


class CreateGuardrailsInput(BaseModel):
    guardrails_id: Optional[str] = None
    scanner_configs: dict = None
    cloud_provider: CloudProvider = CloudProvider.AWS


class GuardrailsIdsRequest(BaseModel):
    guardrails_ids: list[str]
