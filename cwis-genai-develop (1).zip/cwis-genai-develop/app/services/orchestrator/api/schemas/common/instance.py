from enum import Enum
from pydantic import BaseModel, model_validator

# from helper.smartgpt_caller import ChunkingStrategy
from helper.custom_errors import UnprocessableEntityError
from helper.sanitized_string import SanitizedStr
from api.schemas.aws.submit import AWSBedrockModel, ChunkingParams


class ChunkingStrategy(Enum):
    HIERARCHICAL: str = "HIERARCHICAL"
    FIXED_SIZE: str = "FIXED_SIZE"
    SEMANTIC: str = "SEMANTIC"


class CloudEnvironment(str, Enum):
    AWS = "aws"


class VectorDBChoice(str, Enum):
    OpenSearchServerless = "opensearch_serverless"


class EmbeddingChoice(str, Enum):
    AmazonTitanV2 = "amazon.titan-embed-text-v2:0"


class CreateInstanceInput(BaseModel):
    name: SanitizedStr
    projectId: int
    temperature: float
    applicationId: int
    isActive: bool = True
    isDeleted: bool = False
    chunkSize: int = 10
    chunkingStrategy: ChunkingStrategy = ChunkingStrategy.FIXED_SIZE
    kNearChunks: int = 6
    chunking_params: ChunkingParams = ChunkingParams()
    cloud_environment: CloudEnvironment = CloudEnvironment.AWS
    render_markdown: bool = False
    llm_guard: bool = False
    llm_guard_value: str = None
    # Restricted to enum only (removed raw string fallback for security hardening)
    llm_model: AWSBedrockModel
    query_expansion: bool = False
    vector_db: VectorDBChoice = VectorDBChoice.OpenSearchServerless
    embedding_choice: EmbeddingChoice = EmbeddingChoice.AmazonTitanV2
    is_updated_model: bool = False
    guardrails_id: str = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "name": values.get("name"),
            "projectId": values.get("projectId"),
            "temperature": values.get("temperature"),
            "applicationId": values.get("applicationId"),
            "llm_model": values.get("llm_model"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(
                    f"The '{key}' field cannot be null or empty."
                )

        # Handle frontend field mapping
        # Map chunkParams to chunking_params
        if "chunkParams" in values and values["chunkParams"]:
            chunk_params = values["chunkParams"].copy()
            
            # Map parsingStrategy to parsing_strategy if present
            if "parsingStrategy" in chunk_params:
                chunk_params["parsing_strategy"] = chunk_params.pop("parsingStrategy")
                
            # Initialize chunking_params if it doesn't exist
            if "chunking_params" not in values:
                values["chunking_params"] = {}
            
            # Merge the chunk_params into chunking_params
            values["chunking_params"].update(chunk_params)
            # Remove the original chunkParams field
            values.pop("chunkParams", None)
            
        # Also handle standalone parsingStrategy field (fallback)
        if "parsingStrategy" in values:
            if "chunking_params" not in values:
                values["chunking_params"] = {}
            # Only set if not already set from chunkParams
            if "parsing_strategy" not in values["chunking_params"]:
                values["chunking_params"]["parsing_strategy"] = values["parsingStrategy"]
            values.pop("parsingStrategy", None)

        
        return values


class PatchInstanceInput(BaseModel):
    name: SanitizedStr | None = None
    flow: int = None


class EditInstanceParams(BaseModel):
    temperature: float = 0.5
    llm_guard: bool = False
    render_markdown: bool = True
    llm_model: AWSBedrockModel
    query_expansion: bool = False
    chunking_params: ChunkingParams = ChunkingParams()


scanner_config_default = {
    "input_scanners": [
        {
            "type": "Anonymize",
            "params": {
                "allowed_names": ["string"],
                "hidden_names": ["string"],
                "entity_types": ["string"],
                "preamble": "string",
                "use_faker": False,
                "threshold": 0,
                "language": "en",
            },
        }
    ]
}
