from pydantic import BaseModel, model_validator

from helper.custom_errors import UnprocessableEntityError
from helper.sanitized_string import SanitizedStr


class LLMGuardPromptInput(BaseModel):
    prompt: SanitizedStr
    instance_id: int

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "prompt": values.get("prompt"),
            "instance_id": values.get("instance_id"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values


class LLMGuardOutputPromptInput(BaseModel):
    prompt: SanitizedStr | None = None
    output: SanitizedStr
    instance_id: int

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "output": values.get("output"),
            "instance_id": values.get("instance_id"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values
