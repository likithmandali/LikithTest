from jsonschema import ValidationError
from pydantic import BaseModel, model_validator, field_validator
from helper.custom_errors import UnprocessableEntityError
from helper.sanitized_string import SanitizedStr
from typing import Optional, List, Dict, Any
from enum import Enum

class FeedbackResponse(str, Enum):
    YES = "yes"
    NO = "no"

class FeedbackSchema(BaseModel):
    """Schema defining the structure for user feedback"""
    was_it_helpful: FeedbackResponse
    message: Optional[SanitizedStr] = None
    
    model_config = {
        "extra": "forbid"  # This will reject any extra fields
    }

class UserActivityCreate(BaseModel):
    type: SanitizedStr
    input_text: SanitizedStr
    output_text: SanitizedStr
    feedback: dict
    instance_id: int = None
    application_id: int = None
    project_id: int = None
    request_id: str = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "type": values.get("type"),
            "input_text": values.get("input_text"),
            "output_text": values.get("output_text"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values


class UpdateUserActivity(BaseModel):
    activityId: int
    feedback: Dict[str, Any]

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "activityId": values.get("activityId"),
            "feedback": values.get("feedback"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values
    
    @field_validator("feedback")
    @classmethod
    def validate_feedback(cls, v):
        try:
            # Convert dictionary to FeedbackSchema for validation
            FeedbackSchema(**v)
            return v  # Return original dictionary (not the FeedbackSchema object)
        except ValidationError as e:
            raise ValueError(f"Invalid feedback format: {str(e)}")


class UserActivityCreateDetailed(UserActivityCreate):
    messages: list[dict] = [{}]
    semantic_search_context: list[dict] = [{}]
    k_near_chunks: int = None
    status: str = "Pending"
    template: str = None
    instance_id: int = None
    meta_data: list[dict] or dict


class UserActivityCreateInternal(BaseModel):
    type: str
    input_text: str = None
    instance_id: int = None
    task_id: str = None
    meta_data: list[dict] or dict
    status: str = "Pending"
    application_id: int = None
    project_id: int = None
    request_id: str = None

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "type": values.get("type"),
            "task_id": values.get("task_id"),
            "meta_data": values.get("meta_data"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values


class UpdateActivityStatusInternal(BaseModel):
    activityId: int
    status: SanitizedStr = "Pending"
    output_text: SanitizedStr = ""
    meta_data: list[dict] = [{}]
    input_token_count: int = 0
    output_token_count: int = 0
    input_token_cost: float = 0.0
    output_token_cost: float = 0.0
    total_cost: float = 0.0
    llm_model: str = ""

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "activityId": values.get("activityId"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values


class UpdateActivityStatusInternalTemplate(BaseModel):
    activityId: int
    status: SanitizedStr = "Pending"
    output_text: SanitizedStr = ""
    meta_data: list[dict] = [{}]
    input_token_count: int = 0
    output_token_count: int = 0
    input_token_cost: float = 0.0
    output_token_cost: float = 0.0
    total_cost: float = 0.0
    llm_model: str = ""
    template: SanitizedStr = ""

    @model_validator(mode="before")
    def check_key_presence(cls, values):
        required_fields = {
            "activityId": values.get("activityId"),
        }

        for key, value in required_fields.items():
            if value is None:
                raise UnprocessableEntityError(f"The '{key}' field cannot be null or empty.")

        return values


class CreateUserGroupID(BaseModel):
    email: str
    is_staff: bool
    is_active: bool
    is_superuser: bool
    group_ids: list[int]


class CreateProject(BaseModel):
    projectname: str
    app_ids: list[int]
    group_ids: list[int]


class CreateUserApproved(BaseModel):
    email: str
    is_staff: bool
    is_active: bool
    is_superuser: bool
    group_ids: Optional[List[int]] = None
    project_ids: Optional[List[int]] = None


class AddUserGroupOrProject(BaseModel):
    user_id: int
    group_or_project_id_list: list[int]


class AddAppsToProject(BaseModel):
    project_id: int
    app_id_list: list[int]


class AddGroupsToProject(BaseModel):
    project_id: int
    group_id_list: list[int]


class Frequency(str, Enum):
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"


class ActivityDetails(str, Enum):
    ACTIVITYCOUNT = "activity_count"
    ACTIVITYCOST = "activity_cost"


class SplitBy(str, Enum):
    USER = "user"
    PROJECT = "project"
    ENGINE = "engine"


class UpdateApilog(BaseModel):
    id: str
    responsebody: Dict
    statuscode: int = 200
    overallstatus: str = "completed"


class OverallStatus(str, Enum):
    PENDING = "Pending"
    SUCCESS = "Success"
    FAILED = "Failed"