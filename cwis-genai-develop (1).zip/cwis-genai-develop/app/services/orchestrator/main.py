import os
import re
import sys
import uuid

import psycopg2
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

# Add the current directory to Python path to resolve imports correctly
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from api import api_router
from helper.custom_errors import GenericError, AttributeNotFoundError
from settings.config import CONFIG
from settings.context import request_id_var
from settings.db import get_db_connection
from settings.loguru_config import CustomizeLogger


def create_app() -> FastAPI:
    """Create and configure the FastAPI application.
    
    Returns:
        FastAPI: Configured FastAPI application instance
    """
    path = CONFIG.LOG_PATH
    filename = CONFIG.LOG_FILE
    level = CONFIG.LOG_LEVEL
    format = CONFIG.LOG_FORMAT
    platform = CONFIG.LOG_PLATFORM
    app = FastAPI(title="GenAIe Orchestrator BFF")
    CustomizeLogger.make_logger(path, filename, level, format, platform)
    return app


app = create_app()

app.include_router(api_router)

# Strict Accept-Encoding validation middleware
SUPPORTED_ENCODINGS = {"identity", "br", "zstd", "gzip", "deflate"}


def _is_valid_qvalue(param: str) -> bool:
    """Validates q-value parameter in Accept-Encoding header.
    
    Args:
        param: Parameter string like 'q=0.5'
        
    Returns:
        bool: True if valid q-value between 0 and 1
    """
    try:
        # allow case-insensitive 'q='
        if not param.lower().startswith("q="):
            return False
        q = float(param.split("=", 1)[1].strip())
        return 0.0 <= q <= 1.0
    except ValueError:
        return False


def _validate_accept_encoding_header(value: str) -> tuple[bool, str | None]:
    """Validates Accept-Encoding header format and content.
    
    Args:
        value: Accept-Encoding header value
        
    Returns:
        tuple: (is_valid, error_message)
    """
    # Basic length guard to avoid maliciously large headers
    if len(value) > 256:
        return False, "Accept-Encoding header too long"
    
    # If empty value, reject it as malformed
    if not value.strip():
        return False, "Empty Accept-Encoding header not allowed"

    # Split encodings, validate names and optional q params
    for raw_part in value.split(","):
        part = raw_part.strip()
        if not part:
            # empty token indicates malformed list
            return False, "Malformed Accept-Encoding header"

        # Break into coding and optional params
        segments = [s.strip() for s in part.split(";") if s.strip()]
        coding = segments[0].lower()

        # Handle wildcard: allow only if explicitly weighted to 0 (i.e., not acceptable)
        if coding == "*":
            # Check params for q=0
            def _parse_qvalue(param: str) -> float | None:
                if param.lower().startswith("q="):
                    try:
                        q = float(param.split("=", 1)[1].strip())
                        if 0.0 <= q <= 1.0:
                            return q
                    except ValueError:
                        pass
                return None
            has_q_zero = any((_parse_qvalue(p) == 0.0) for p in segments[1:])
            if not has_q_zero:
                return False, "Wildcard '*' must have q=0"

        # token pattern: letters/digits and . _ - per RFC lenient subset
        if not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", coding):
            return False, "Malformed encoding token"

        # Reject any encoding not in our supported list
        if coding not in SUPPORTED_ENCODINGS:
            return False, f"Unsupported encoding: {coding}"

        # Validate optional parameters; accept unknown params by ignoring them
        for param in segments[1:]:
            if param.lower().startswith("q=") and not _is_valid_qvalue(param):
                return False, "Invalid q parameter in Accept-Encoding"

    return True, None


@app.middleware("http")
async def validate_accept_encoding(request: Request, call_next):
    """Middleware to validate Accept-Encoding header for all endpoints."""
    # Bypass CORS preflight
    if request.method.upper() == "OPTIONS":
        return await call_next(request)

    header_val = request.headers.get("accept-encoding")

    # Require Accept-Encoding on all requests and reject empty/missing
    if header_val is None or not str(header_val).strip():
        if not hasattr(request.state, "request_id") or not request.state.request_id:
            rid = str(uuid.uuid4())
            request.state.request_id = rid
            request_id_var.set(rid)
        error_response = {
            "response": None,
            "error": {"errorMessage": "Accept-Encoding header is required"},
            "status": "failure",
            "errorId": request.state.request_id,
        }
        return JSONResponse(
            content=error_response,
            status_code=400,
            headers={"x-api-request-id": request.state.request_id},
        )

    # Validate non-empty headers
    if not hasattr(request.state, "request_id") or not request.state.request_id:
        rid = str(uuid.uuid4())
        request.state.request_id = rid
        request_id_var.set(rid)
    ok, reason = _validate_accept_encoding_header(header_val)
    if not ok:
        error_response = {
            "response": None,
            "error": {"errorMessage": f"Unsupported or malformed Accept-Encoding header: {reason}"},
            "status": "failure",
            "errorId": request.state.request_id,
        }
        return JSONResponse(
            content=error_response,
            status_code=400,
            headers={"x-api-request-id": request.state.request_id},
        )

    response = await call_next(request)
    return response


origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["x-activityid", "x-api-request-id", "x-sanitized-prompt"],
)


@app.middleware("http")
async def add_api_request_id(request: Request, call_next):
    """Middleware to add unique request ID to each request."""
    request_id = str(uuid.uuid4())
    request.state.request_id = request_id
    request_id_var.set(request_id)
    response = await call_next(request)
    response.headers["x-api-request-id"] = request.state.request_id
    return response


app.mount("/static", StaticFiles(directory=CONFIG.SHARED_VOLUME), name="static")


def custom_openapi():
    """Generate custom OpenAPI schema with branding."""
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Orchestrator BFF Service",
        version="0.10.7",
        summary="Powering GenAIe Enterprise apps UI",
        description="",
        routes=app.routes,
    )
    openapi_schema["info"]["x-logo"] = {
        "url": "https://fastapi.tiangolo.com/img/logo-margin/logo-teal.png"
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.exception_handler(GenericError)
async def custom_error_handler(request: Request, exc: GenericError):
    """Handle custom GenericError exceptions."""
    error_detail = exc.error_detail
    error_detail["errorId"] = request.state.request_id
    return JSONResponse(
        content=error_detail,
        status_code=exc.status_code,
        headers={"x-api-request-id": request.state.request_id},
    )


@app.exception_handler(RequestValidationError)
async def handle_request_validation_error(
    request: Request, exc: RequestValidationError
):
    """Handle request validation errors with consistent format."""
    error_message = "Invalid JSON request body"
    error_response = {
        "response": None,
        "error": {"errorMessage": error_message},
        "status": "failure",
        "errorId": request.state.request_id,
    }
    return JSONResponse(
        content=error_response,
        status_code=422,
        headers={"x-api-request-id": request.state.request_id},
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions with consistent format."""
    return JSONResponse(
        content={"error": exc.detail, "errorId": request.state.request_id},
        status_code=exc.status_code,
        headers={"x-api-request-id": request.state.request_id},
    )


@app.exception_handler(Exception)
async def handle_general_exception(request: Request, exc: Exception):
    """Handle all unhandled exceptions with consistent format."""
    error_message = "Internal server error"
    error_response = {
        "response": None,
        "error": {"errorMessage": error_message},
        "status": "failure",
        "errorId": request.state.request_id,
    }
    return JSONResponse(
        content=error_response,
        status_code=500,
        headers={"x-api-request-id": request.state.request_id},
    )