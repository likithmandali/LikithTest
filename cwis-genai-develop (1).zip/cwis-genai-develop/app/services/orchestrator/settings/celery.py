import base64
import json
import os
import traceback
from celery import Celery
from celery import chain
import numpy as np
import requests
from settings.db import get_db_connection_eager
from settings.loguru import logger
from settings.config import CONFIG

# from celery_progress.backend import ProgressRecorder
import time


celery = Celery(
    "orchestrator-worker", broker=CONFIG.CELERY_BROKER, backend=CONFIG.CELERY_BROKER
)

celery.autodiscover_tasks(["api.controllers.aws"], related_name="aws")
celery.autodiscover_tasks(["api.routers.aws"], related_name="aws_router")
celery.autodiscover_tasks(["helper.aws_lambda"], related_name="aws_lambda")
