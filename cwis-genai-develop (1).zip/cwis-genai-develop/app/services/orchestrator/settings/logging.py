import logging
from settings.config import CONFIG


def setup_logging(logging, level: int = logging.INFO):
    logging.critical(f"Logging level {level}")
    logging.basicConfig(
        level=level,  # Set the desired log level (e.g., INFO, DEBUG)
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            # logging.FileHandler(CONFIG.LOG_FILE),  # Log to a file
            logging.StreamHandler(),  # Log to the console
        ],
    )
    return logging


match CONFIG.LOG_LEVEL:
    case "INFO":
        logging = setup_logging(logging, logging.INFO)
    case "DEBUG":
        logging = setup_logging(logging, logging.DEBUG)
    case "WARN":
        logging = setup_logging(logging, logging.WARN)
    case "CRITICAL":
        logging = setup_logging(logging, logging.CRITICAL)
    case "WARNING":
        logging = setup_logging(logging, logging.WARNING)
    case "ERROR":
        logging = setup_logging(logging, logging.ERROR)
    case "_":
        logging = setup_logging(logging, logging.WARNING)


logger = logging.getLogger(__name__)  # noqa
