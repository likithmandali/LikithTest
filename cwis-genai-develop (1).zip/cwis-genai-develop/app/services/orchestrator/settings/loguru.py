from settings.loguru_config import CustomizeLogger
from settings.config import CONFIG


def create_app():
    path = CONFIG.LOG_PATH
    filename = CONFIG.LOG_FILE
    level = CONFIG.LOG_LEVEL
    format = CONFIG.LOG_FORMAT
    platform = CONFIG.LOG_PLATFORM
    logger = CustomizeLogger.make_logger(path, filename, level, format, platform)
    return logger


logger = create_app()  # noqa
