from functools import wraps
import warnings
from typing import Annotated
from fastapi import Depends
import psycopg2
from settings.db import get_db_connection
from settings.security import User, check_project_application_access, get_current_user
from settings.loguru import logger


def check_project_app_access_decorator(function):
    @wraps(function)
    async def access_wrapper(
        project_id: int,
        application_id: int,
        current_user: Annotated[User, Depends(get_current_user)],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
        *args,
        **kwargs,
    ):
        auth_response = check_project_application_access(
            user_id=current_user[0].get("id"),
            project_id=project_id,
            application_id=application_id,
            db=db,
        )
        logger.debug(f"{auth_response=}")
        return await function(
            project_id=project_id,
            current_user=current_user,
            db=db,
            application_id=application_id,
            *args,
            **kwargs,
        )

    return access_wrapper


def check_project_access_decorator(function):
    @wraps(function)
    async def access_wrapper(
        project_id: int,
        current_user: Annotated[User, Depends(get_current_user)],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
        *args,
        **kwargs,
    ):
        auth_response = check_project_application_access(
            user_id=current_user[0].get("id"),
            project_id=project_id,
            db=db,
        )
        logger.debug(f"{auth_response=}")
        return await function(
            project_id=project_id,
            current_user=current_user,
            db=db,
            *args,
            **kwargs,
        )

    return access_wrapper


def deprecated(function: callable) -> callable:
    """
    Decorator to mark a function as deprecated.
    When the decorated function is called, a warning message will be displayed indicating that the function is deprecated.

    Parameters:
    - function (callable): The function to be marked as deprecated.

    Returns:
    - deprecated_warning_handler (callable): The decorated function.

    Example usage:
    @deprecated
    def my_function() -> None:
        pass
    """

    @wraps(function)
    def deprecated_warning_handler(*args, **kwargs) -> callable:
        warnings.warn(
            f"This function '{function.__name__}' is deprecated...",
            category=DeprecationWarning,
        )
        return function(*args, **kwargs)

    return deprecated_warning_handler


def deprecated_class(message: str = "This class is deprecated"):
    """
    Decorator function to mark a class as deprecated.

    Usage:
    @deprecated_class()
    class MyClass:
        ...

    When the class is instantiated, a warning will be raised indicating that the class is deprecated.

    Returns:
    decorator: The decorator function that marks the class as deprecated.
    """
    ...

    def decorator(cls):
        original_init = cls.__init__

        @wraps(cls.__init__)
        def new_init(self, *args, **kwargs):
            warnings.warn(
                f"This class '{cls.__name__}' is deprecated...",
                DeprecationWarning,
                stacklevel=2,
            )
            original_init(self, *args, **kwargs)

        cls.__init__ = new_init
        return cls

    return decorator
