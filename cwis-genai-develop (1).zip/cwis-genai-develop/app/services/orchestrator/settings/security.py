from datetime import datetime, timedelta
from typing import Annotated
from fastapi import Depends, APIRouter, HTTPException, Request, status, Security
from fastapi.security import (
    OAuth2PasswordBearer,
    OAuth2PasswordRequestForm,
    SecurityScopes,
)
from jose import JWTError, jwt
from settings.loguru import logger
from passlib.context import CryptContext
import psycopg2
from passlib.hash import django_pbkdf2_sha256
from pydantic import BaseModel
from api.db.user import UserDBController
from .config import CONFIG
from helper.custom_errors import AuthenticationError, ForbiddenError
from settings.db import get_db_connection

# to get a string like this run:
# openssl rand -hex 32
SECRET_KEY = CONFIG.SECRET_KEY
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days (mins x hrs x days)


class Token(BaseModel):
    access_token: str
    token_type: str


class RefreshToken(BaseModel):
    access_token: str


class User(BaseModel):
    username: str
    email: str | None = None
    disabled: bool | None = None

env=CONFIG.ENVIRONMENT
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# oauth2_scheme = OAuth2PasswordBearer(
#     tokenUrl="/v1/genaie/authentication/token", auto_error=False
# )
oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl=f"/rosa/{env}/v1/genaie/authentication/token", auto_error=False
)
router = APIRouter()


def verify_password(plain_password, hashed_password):
    verified = django_pbkdf2_sha256.verify(plain_password, hashed_password)
    logger.debug(f"{verified=}")
    return verified


def authenticate_user(user_email: str, password: str, db):
    user_details = UserDBController.verify_user_by_email_id(user_email, db)
    if user_details:
        hashed_password = user_details[0].get("hashed_password")
        if not verify_password(password, hashed_password):
            return False
        return user_details
    else:
        return False


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def get_current_user(
    token: Annotated[str, Depends(oauth2_scheme)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    try:
        if not token:
            raise AuthenticationError("Authorization header is missing in the request.")
        logger.debug("get current user")
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        logger.debug(f"{payload=}")
        user_email: str = payload.get("sub")
        logger.debug(f"{user_email=}")
        user_details = UserDBController.verify_user_by_email_id(user_email, db)
        if len(user_details) == 0:
            raise AuthenticationError(
                "User is not registered in the system. Please contact the GenAIe Administrator!"
            )
        user_details[0].pop("hashed_password")
        logger.debug(f"{user_details=}")
    except JWTError:
        raise AuthenticationError("Token is invalid. Please try again.")
    return user_details


def get_current_user_scope(
    security_scopes: SecurityScopes,
    token: Annotated[str, Depends(oauth2_scheme)],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    try:
        if not token:
            raise AuthenticationError("Authorization header is missing in the request.")
        logger.debug("get current user")
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        logger.debug(f"{payload=}")
        user_email: str = payload.get("sub")
        logger.debug(f"{user_email=}")
        token_scopes = payload.get("role")
        user_role = UserDBController.check_user_role(user_email, db)
        logger.debug(f"{token_scopes=}")
        logger.debug(f"{user_role=}")
        if user_role != token_scopes:
            raise ForbiddenError("Token is invalid. Please try again.")
        logger.debug(f"{security_scopes.scopes=}")
        if token_scopes not in security_scopes.scopes:
            raise ForbiddenError(
                "Insufficient permissions to perform this action. Please contact the GenAIe Administrator!"
            )

        user_details = UserDBController.verify_user_by_email_id(user_email, db)
        if len(user_details) == 0:
            raise AuthenticationError(
                "User is not registered in the system. Please contact the GenAIe Administrator!"
            )
        for user in user_details:
            user.pop("hashed_password")
        user_id = user_details[0].get("id")
        user_details[0]["user_role"] = user_role
        UserDBController.update_last_login(user_id=user_id, db=db)
        logger.debug(f"{user_details=}")
    except JWTError:
        raise AuthenticationError("Token is invalid. Please try again.")
    return user_details


async def get_current_user_superadmin(
    current_user: Annotated[
        User,
        Security(get_current_user_scope, scopes=["superadmin"]),
    ],
):
    return current_user


async def get_current_user_staff(
    current_user: Annotated[
        User,
        Security(get_current_user_scope, scopes=["superadmin", "admin"]),
    ],
):
    return current_user


async def get_current_user_normal(
    current_user: Annotated[
        User,
        Security(get_current_user_scope, scopes=["superadmin", "admin", "contributor"]),
    ],
):
    return current_user


def check_project_application_access(
    user_id: int,
    project_id: int,
    application_id: int | None = None,
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    project_apps = UserDBController.get_project_application_by_user(user_id, db)
    if project_id not in project_apps:
        raise AuthenticationError(
            "You are not authorized to access this project. Please contact the GenAIe Administrator!"
        )
    if application_id and application_id not in project_apps[project_id]:
        raise AuthenticationError(
            "This application is not registered with this project. Please contact the GenAIe Administrator!"
        )
    return True


def decode_token(client_request: Request):
    try:
        if "authorization" in client_request.headers:
            authorization_token = client_request.headers.get("authorization")
            authorization_token = authorization_token.split(" ")[1]
            logger.debug(f"{authorization_token=}")
            decoded_token = jwt.decode(
                authorization_token, SECRET_KEY, algorithms=[ALGORITHM]
            )
            return decoded_token
        else:
            raise AuthenticationError("Authorization header is missing in the request.")
    except JWTError:
        raise AuthenticationError("Token is invalid. Please try again.")
    except Exception as err:
        raise err


async def check_user_authorization(client_request: Request, db):
    try:
        decoded_token = decode_token(client_request)
        logger.debug(f"{decoded_token=}")
        if decoded_token:
            user_email = decoded_token.get("sub")
            logger.debug(f"{user_email=}")
            user_details = UserDBController.verify_user_by_email_id(user_email, db)
            if user_details:
                return user_details
            else:
                raise AuthenticationError(
                    "User is not registered in the system. Please contact the GenAIe Administrator!"
                )
    except Exception as err:
        raise err


@router.post("/token", response_model=Token)
async def login_for_access_token(
    form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for obtaining an access token by providing user credentials. This endpoint allows users to obtain an access token by providing their credentials.**

    Args:
    - **form_data** (Annotated[OAuth2PasswordRequestForm, Depends()]): OAuth2 password request form containing user credentials.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.

    Raises:
    - **HTTPException**: If credentials are invalid.

    Returns:
    - **Token**: A JSON Web Token (JWT) containing access and refresh tokens.
    """  # noqa: E501
    user_details = authenticate_user(form_data.username, form_data.password, db)
    if not user_details:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    email_id = user_details[0].get("email")
    user_role = UserDBController.check_user_role(email_id, db)
    access_token = create_access_token(
        data={"sub": email_id, "role": user_role},
        expires_delta=access_token_expires,
    )
    return {"access_token": access_token, "token_type": "Bearer"}


@router.get("/users/me/")
async def read_users_me(
    current_user: Annotated[User, Depends(get_current_user_normal)],
):
    """
    **Endpoint to retrieve information about the currently authenticated user.**

    **This endpoint returns information about the user who is currently authenticated.**

    Args:
    - **current_user** (Annotated[User, Depends(get_current_user)]): The current authenticated user.

    Returns:
    - **User**: Information about the currently authenticated user.
    """
    try:
        return current_user[0]
    except Exception as err:
        raise err


@router.post("/token-refresh")
async def token_refresh(
    token: RefreshToken,
    db: psycopg2.extensions.connection = Depends(get_db_connection),
):
    """
    **Endpoint for obtaining an access token by providing user credentials. This endpoint allows users to obtain an access token by providing their credentials.**
    Args:
    - **access_token** (str): Existing token.
    - **db** (psycopg2.extensions.connection, optional): Database connection object.
    Raises:
    - **HTTPException**: If credentials are invalid.
    Returns:
    - **Token**: A JSON Web Token (JWT) containing new tokens.
    """  # noqa: E501
    try:
        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        payload = jwt.decode(token.access_token, SECRET_KEY, algorithms=[ALGORITHM])
        logger.debug(f"{payload=}")
        email_id: str = payload.get("sub")
        user_role = UserDBController.check_user_role(email_id, db)
        access_token = create_access_token(
            data={"sub": email_id, "role": user_role},
            expires_delta=access_token_expires,
        )
        return {"access_token": access_token, "token_type": "Bearer"}
    except JWTError:
        raise AuthenticationError("Token is invalid. Please try again.")
