import os
from decouple import config
import boto3

class CONFIG:
    LOCAL_TESTING = config("LOCAL_TESTING", default=False, cast=bool)
    SHARED_VOLUME = config("SHARED_VOLUME", default="/app/shared_volume")
    ASSETS_DIR = config("ASSETS_DIR", "/app/assets")

    LOG_LEVEL = config("LOG_LEVEL", default="INFO")
    LOG_PATH = config("LOG_PATH", default="/tmp/logs")
    LOG_FILE = config("LOG_FILE", default="orchestrator.log")
    LOG_FORMAT = config(
        "LOG_FORMAT",
        default=(
            "<level>{level: <8}</level>"
            " - <level>{extra[request_id]}</level>  "
            "{time:YYYY-MM-DD HH:mm:ss.SSS}"
            " - <cyan>{name}</cyan>:<cyan>{function}</cyan>"
            " - <level>{message}</level>"
            " {extra[traceback]}"
        ),
    )
    LOG_PLATFORM = config("LOG_PLATFORM", default="LOCAL")
    SECRET_KEY = config("SECRET_KEY")

    CELERY_BROKER = config("CELERY_BROKER", default="redis://redis:6379/0")
    CELERY_QUEUE_NAME = config("CELERY_QUEUE_NAME", default="orchestrator-queue")
    UPLOAD_DIRECTORY = config(
        "UPLOAD_DIRECTORY", default="/app/shared_volume/uploads/documents/"
    )
    POSTGRES_URI = config("POSTGRES_URI")

    # Prefer standard AWS env names, keep backward compatibility with older names
    AWS_ACCESS_KEY = config("AWS_ACCESS_KEY", default=None)
    if AWS_ACCESS_KEY is None:
        AWS_ACCESS_KEY = config("AWS_ACCESS_KEY_ID", default=None)

    AWS_SECRET_KEY = config("AWS_SECRET_KEY", default=None)
    if AWS_SECRET_KEY is None:
        AWS_SECRET_KEY = config("AWS_SECRET_ACCESS_KEY", default=None)

    AWS_REGION = config("AWS_REGION", default="us-east-1")
    # Prefer AWS_ACCOUNT_ID; support legacy ACCOUNT_ID; finally fall back to STS when running with a role
    AWS_ACCOUNT_ID = (
        config("AWS_ACCOUNT_ID", default=None)
        or config("ACCOUNT_ID", default=None)
    )

    # Attempt late binding from STS if not explicitly provided and boto3 has credentials (e.g., task/instance role)
    if AWS_ACCOUNT_ID in (None, ""):
        try:
            if boto3 is not None:
                # Create STS client with explicit credentials if available
                if AWS_ACCESS_KEY and AWS_SECRET_KEY:
                    sts = boto3.client(
                        "sts", 
                        region_name=AWS_REGION,
                        aws_access_key_id=AWS_ACCESS_KEY,
                        aws_secret_access_key=AWS_SECRET_KEY
                    )
                else:
                    sts = boto3.client("sts", region_name=AWS_REGION)
                
                caller_identity = sts.get_caller_identity()
                AWS_ACCOUNT_ID = caller_identity.get("Account")
        except Exception as e:
            # Leave as None if discovery fails (e.g., local without creds)
            AWS_ACCOUNT_ID = None
    AWS_STORAGE_BUCKET_NAME = config("AWS_STORAGE_BUCKET_NAME")

    # AWS Lamda Function
    AWS_LAMBDA_KNOWLEDGE_BASE_CREATE = config("AWS_LAMBDA_KNOWLEDGE_BASE_CREATE")
    AWS_LAMBDA_KNOWLEDGE_BASE_UPDATE = config("AWS_LAMBDA_KNOWLEDGE_BASE_UPDATE")

    DATA_RETENTION_PERIOD = config(
        "DATA_RETENTION_PERIOD", default=90
    )  # number of days to keep the data in the database

    # # aws llm model default cost
    CLAUDE_V2_100K_INPUT_COST = config("anthropic.claude-v2", default=0.000008)
    CLAUDE_V2_1_200K_INPUT_COST = config("anthropic.claude-v2:1", default=0.000008)
    TITAN_V1_TEXT_EMBED_8K_INPUT_COST = config(
        "amazon.titan-embed-text-v1", default=0.0000001
    )
    TITAN_TEXT_G1_EXPRESS_INPUT_COST = config(
        "amazon.titan-text-express-v1", default=0.0000002
    )
    CLAUDE_V2_100K_OUTPUT_COST = config("anthropic.claude-v2", default=0.000024)
    CLAUDE_V2_1_200K_OUTPUT_COST = config("anthropic.claude-v2:1", default=0.000024)
    TITAN_V1_TEXT_EMBED_8K_OUTPUT_COST = config(
        "amazon.titan-embed-text-v1", default=0.0
    )
    TITAN_TEXT_G1_EXPRESS_OUTPUT_COST = config(
        "amazon.titan-text-express-v1", default=0.0000006
    )
    TITAN_TEXT_G1_PREMIER_INPUT_COST = config(
        "amazon.titan-text-premier-v1:0", default=0.0000002
    )
    TITAN_TEXT_G1_PREMIER_OUTPUT_COST = config(
        "amazon.titan-text-premier-v1:0", default=0.0000006
    )
    TITAN_TEXT_LITE_INPUT_COST = config("amazon.titan-text-lite-v1", default=0.0000002)
    TITAN_TEXT_LITE_OUTPUT_COST = config("amazon.titan-text-lite-v1", default=0.0000006)
    # AWS Anthropics Claude Sonnet model
    AWS_CLAUDE_V35_SONNET_INPUT_COST = config(
        "AWS_CLAUDE_V35_SONNET_INPUT_COST", default=0.000003
    )
    AWS_CLAUDE_V35_SONNET_OUTPUT_COST = config(
        "AWS_CLAUDE_V35_SONNET_OUTPUT_COST", default=0.000015
    )
    AWS_CLAUDE_V37_SONNET_INPUT_COST = config(
        "AWS_CLAUDE_V37_SONNET_INPUT_COST", default=0.000003
    )
    AWS_CLAUDE_V37_SONNET_OUTPUT_COST = config(
        "AWS_CLAUDE_V37_SONNET_OUTPUT_COST", default=0.000015
    )
    AWS_CLAUDE_V4_SONNET_INPUT_COST = config(
        "AWS_CLAUDE_V4_SONNET_INPUT_COST", default=0.000003
    )
    AWS_CLAUDE_V4_SONNET_OUTPUT_COST = config(
        "AWS_CLAUDE_V4_SONNET_OUTPUT_COST", default=0.000015
    )

    AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN = config(
        "AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN", default=""
    )
    AWS_OPENSEARCH_COLLECTION_ARN = config("AWS_OPENSEARCH_COLLECTION_ARN", default="")
    AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = config(
        "AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME",
        default="serverless-index-poc-bedrock",
    )

    # Recommended LLM models for cloud providers
    RECOMMENDED_AWS_MODEL = config(
        "RECOMMENDED_AWS_MODEL", default="us.anthropic.claude-3-7-sonnet-20240620-v1:0"
    )

    # Ingestion job configuration
    MAX_INGESTION_JOB_DURATION_MINUTES = config(
        "MAX_INGESTION_JOB_DURATION_MINUTES", default=60, cast=int
    )
    RERANK_MODEL_ID = config("RERANK_MODEL_ID", default="cohere.rerank-v3-5:0")
    CLAUDE_SONNET_4_MAX_OUTPUT_TOKENS=config("CLAUDE_SONNET_4_MAX_OUTPUT_TOKENS", default=8192)
    ENVIRONMENT=config("ENVIRONMENT", default="dev")
    # # add mermaid
    # MERMAID_URL = config("MERMAID_URL", default="http://mermaid2png:5005")

    # # Azure Guardrails
    # TEXT_ANALYTICS_KEY = config("TEXT_ANALYTICS_KEY")
    # TEXT_ANALYTICS_ENDPOINT = config("TEXT_ANALYTICS_ENDPOINT")
    # CONTENT_SAFETY_KEY = config("CONTENT_SAFETY_KEY")
    # CONTENT_SAFETY_ENDPOINT = config("CONTENT_SAFETY_ENDPOINT")
    # CONTENT_SAFETY_SEVERITY_THRESHOLD = config("CONTENT_SAFETY_SEVERITY_THRESHOLD", default=3)

    # @retry(wait=wait_random_exponential(min=1, max=60), stop=stop_after_attempt(5))
    # def create_weaviate_client_v4() -> weaviate.WeaviateClient:
    #     """
    #     Creates and returns a Weaviate client instance for local connection.

    #     This function initializes a connection to a local Weaviate instance using the configuration
    #     parameters specified in the CONFIG object. It handles authentication if an API key is provided.

    #     Returns:
    #         weaviate.Client: A configured Weaviate client instance connected to the local server.

    #     Configuration Parameters Used:
    #         - WEAVIATE_API_KEY: Optional API key for authentication
    #         - WEAVIATE_HOST_ADDRESS: Host address of the Weaviate instance
    #         - WEAVIATE_PORT_HTTP: HTTP port for the Weaviate server
    #         - WEAVIATE_PORT_GRPC: GRPC port for the Weaviate server
    #         - WEAVIATE_TIMEOUT_CONFIG: Additional timeout configuration

    #     Note:
    #         The function uses weaviate.connect_to_local() method instead of the standard client
    #         initialization, specifically for local Weaviate instances.
    #     """
    #     AUTH_CREDENTIALS = Auth.api_key(CONFIG.WEAVIATE_API_KEY) if CONFIG.WEAVIATE_API_KEY is not None else None
    #     WEAVIATE_CLIENT = weaviate.connect_to_local(
    #         host=CONFIG.WEAVIATE_HOST_ADDRESS,
    #         port=CONFIG.WEAVIATE_PORT_HTTP,
    #         grpc_port=CONFIG.WEAVIATE_PORT_GRPC,
    #         auth_credentials=AUTH_CREDENTIALS,
    #         additional_config=CONFIG.WEAVIATE_TIMEOUT_CONFIG,
    #     )
    #     return WEAVIATE_CLIENT
