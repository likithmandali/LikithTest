import psycopg2
from fastapi import HTTPException
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from tenacity import retry, stop_after_attempt, wait_exponential
from settings.config import CONFIG
from settings.loguru import logger

postgres_uri = CONFIG.POSTGRES_URI

# Create a SQLAlchemy engine
engine = create_engine(postgres_uri)
# Create a session
Session = sessionmaker(bind=engine)


def get_db_session():
    """SQL ALchemy session object used for Vision QA API

    Returns:
        sqlalchemy.Session: Session object with PgSQL connection
    """
    session = Session()
    try:
        yield session
    finally:
        session.close()


# Database dependency using psycopg2
def get_db_connection():
    try:
        conn = psycopg2.connect(dsn=CONFIG.POSTGRES_URI)
        yield conn
    finally:
        conn.close()


# For celery worker
@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
def get_db_connection_eager():
    try:
        conn = psycopg2.connect(
            dsn=CONFIG.POSTGRES_URI,
            connect_timeout=10,
            keepalives=1,
            keepalives_idle=30,
            keepalives_interval=10,
            keepalives_count=5,
        )
        return conn
    except psycopg2.OperationalError as e:
        logger.error(f"Database connection failed: {str(e)}")
        raise


# Exception handler for database connection errors
def handle_db_connection_error():
    raise HTTPException(status_code=500, detail="Database connection error")
