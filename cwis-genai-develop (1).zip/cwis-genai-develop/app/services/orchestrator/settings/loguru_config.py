import sys
import json
import logging
from pathlib import Path
import traceback
from loguru import logger
from helper.custom_errors import LoggingConfigError
from settings.context import request_id_var


class InterceptHandler(logging.Handler):
    loglevel_mapping = {
        50: "CRITICAL",
        40: "ERROR",
        30: "WARNING",
        20: "INFO",
        10: "DEBUG",
        5: "TRACE",
        0: "NOTSET",
    }

    def emit(self, record):
        try:
            level = logger.level(record.levelname).name
        except (AttributeError, ValueError):
            level = self.loglevel_mapping[record.levelno]

        frame, depth = logging.currentframe(), 2
        while frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        log = logger.bind(request_id="app")
        log.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


class CustomizeLogger:
    @classmethod
    def make_logger(
        cls,
        path: str,
        filename: str,
        level: str,
        format: str,
        platform: str,
        rotation: str = None,
        retention: str = None,
    ):
        logger = cls.customize_logging(
            path,
            filename,
            level=level,
            format=format,
            platform=platform,
        )
        return logger


    @classmethod
    def customize_logging(cls, path: Path, filename: str, level: str, format: str, platform: str):
        logger.remove()

        def format_record(record: logging.LogRecord):
            request_id = request_id_var.get()
            if request_id:
                record["extra"]["request_id"] = request_id
            else:
                record["extra"]["request_id"] = "app"
            if record["exception"]:
                traceback_str = "".join(traceback.format_exception(*record["exception"]))
                record["extra"]["traceback"] = traceback_str
            else:
                record["extra"]["exception"] = ""
                record["extra"]["traceback"] = ""
            return format

        # Always add stdout logger for all environments
        logger.add(
            sys.stdout,
            enqueue=True,
            backtrace=False,
            level=level.upper(),
            format=format_record,
        )
        
        # Handle platform-specific logging
        match platform.upper():
            case "LOCAL":
                # Store logs to file only in LOCAL environment with rotation
                logger.add(
                    f"{path}/{filename}",
                    rotation="100 MB",  # Rotate when file reaches 100MB
                    retention="30 days",  # Keep logs for 30 days
                    enqueue=True,
                    backtrace=True,
                    level=level.upper(),
                    format=format_record,
                )
            case "PROD" | "DEV" | "STAGING":
                # For cloud environments, logs go to stdout only
                # Container orchestration systems will handle log collection
                pass
            case _:
                raise LoggingConfigError(error_message="Platform should be LOCAL, DEV, STAGING, or PROD")
        
        # Integrate with Python's standard logging
        logging.basicConfig(handlers=[InterceptHandler()], level=0)
        logging.getLogger("uvicorn.access").handlers = [InterceptHandler()]
        for _log in ["uvicorn", "fastapi", "celery"]:
            _logger = logging.getLogger(_log)
            _logger.handlers = [InterceptHandler()]

        return logger.bind(request_id=None, method=None)

    @classmethod
    def load_logging_config(cls, config_path):
        config = None
        with open(config_path) as config_file:
            config = json.load(config_file)
        return config
