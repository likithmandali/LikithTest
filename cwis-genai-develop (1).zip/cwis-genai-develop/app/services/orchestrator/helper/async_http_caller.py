import asyncio
import traceback
import aiohttp
import secrets

DEFAULT_TIMEOUT = 600  # 5 mins timeout


class Requests:
    def __init__(self):
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=DEFAULT_TIMEOUT))

    async def get(self, url, params=None, headers=None, **kwargs):
        async with self.session.get(url, params=params, headers=headers, **kwargs) as response:
            return await self._process_response(response)

    async def post(self, url, data=None, headers=None, **kwargs):
        async with self.session.post(url, data=data, headers=headers, **kwargs) as response:
            return await self._process_response(response)

    async def put(self, url, data=None, headers=None, **kwargs):
        async with self.session.put(url, data=data, headers=headers, **kwargs) as response:
            return await self._process_response(response)

    async def delete(self, url, headers=None, **kwargs):
        async with self.session.delete(url, headers=headers, **kwargs) as response:
            return await self._process_response(response)

    async def _process_response(self, response):
        response_text = await response.text()
        return {
            "status_code": response.status,
            "headers": dict(response.headers),
            "body": response_text,
        }

    async def close(self):
        await self.session.close()


async def requests_stream(url, json: dict = None, headers: dict = None):
    async with aiohttp.ClientSession(raise_for_status=True) as session:
        async with session.post(url, json=json, headers=headers) as r:
            async for line in r.content.iter_any():
                await asyncio.sleep(0.1)
                yield line


async def requests_stream_with_retry(
    url,
    json: dict = None,
    headers: dict = None,
    max_retries=6,
    base_delay=2,
    max_delay=30,
):
    from settings.loguru import logger

    retries = 0
    while retries < max_retries:
        try:
            async with aiohttp.ClientSession(raise_for_status=True) as session:
                async with session.post(url, json=json, headers=headers) as r:
                    async for line in r.content.iter_any():
                        await asyncio.sleep(0.1)
                        yield line
            break
        except aiohttp.ClientResponseError as e:
            status_code = e.status
            retries += 1
            if retries == 1:
                delay = base_delay
            else:
                # Use cryptographically secure random for delay calculation
                jitter = secrets.SystemRandom().uniform(0, base_delay * retries)
                delay = min(base_delay + jitter, max_delay)
            logger.error(
                f"Azure openai llm call failed with status code {status_code}. Retrying in {delay:.2f} seconds... ({retries}/{max_retries})"
            )
            logger.error(traceback.format_exc())
            await asyncio.sleep(delay)
            continue
        except aiohttp.ClientConnectionError as e:
            retries += 1
            if retries == 1:
                delay = base_delay
            else:
                # Use cryptographically secure random for delay calculation
                jitter = secrets.SystemRandom().uniform(0, base_delay * retries)
                delay = min(base_delay + jitter, max_delay)
            logger.error(f"Connection error: {e}. Retrying in {delay:.2f} seconds... ({retries}/{max_retries})")
            logger.error(traceback.format_exc())
            await asyncio.sleep(delay)
            continue