from settings.config import CONFIG


def get_recommended_llm_model(cloud_environment: str) -> str:
    """
    Returns the recommended LLM (Large Language Model) based on the specified cloud environment.
    Args:
        cloud_environment (str): The cloud environment for which the recommended LLM model is needed.
                                 Expected values are "aws".
    Returns:
        str: The recommended LLM model for the specified cloud environment.
    Raises:
        ValueError: If the cloud_environment is not one of the expected values.
    """
    match cloud_environment:
        case "aws":
            llm_model = CONFIG.RECOMMENDED_AWS_MODEL
        case _:
            raise ValueError(f"Invalid cloud environment: {cloud_environment}")

    return llm_model
