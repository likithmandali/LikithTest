import boto3
from botocore.client import Config
from botocore.exceptions import ClientError
from helper.custom_errors import GenericError
from settings.config import CONFIG
from settings.loguru import logger


class S3ObjectWrapper:
    """Encapsulates S3 object actions."""

    def __init__(self, bucket_name, dest_file_path):
        """
        :param s3_object: A Boto3 Object resource. This is a high-level resource in Boto3
                          that wraps object actions in a class-like structure.
        """
        if CONFIG.LOCAL_TESTING:
            self.s3_res = boto3.resource(
                "s3",
                region_name=CONFIG.AWS_REGION,
                aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
            )
        else:
            self.s3_res = boto3.resource(
                "s3",
                region_name=CONFIG.AWS_REGION,
            )
        self.bucket = self.s3_res.Bucket(bucket_name)
        self.object = self.bucket.Object(dest_file_path)

    def put(self, data):
        """
        Upload data to the object.

        :param data: The data to upload. This can either be bytes or a string. When this
                     argument is a string, it is interpreted as a file name, which is
                     opened in read bytes mode.
        """
        put_data = data
        if isinstance(data, str):
            try:
                with open(data, "rb") as file:
                    put_data = file.read()
            except IOError:
                logger.debug("Expected file name or binary data, got '%s'.", data)
                raise

        try:
            self.object.put(Body=put_data)
            self.object.wait_until_exists()
            logger.debug(
                "Put object '%s' to bucket '%s'.",
                self.object.key,
                self.object.bucket_name,
            )
        except ClientError as e:
            logger.debug(
                "Couldn't put object '%s' to bucket '%s'.",
                self.object.key,
                self.object.bucket_name,
            )
            raise GenericError(status_code=500, error_message=f"{e}", error=e)
        finally:
            if getattr(put_data, "close", None):
                put_data.close()

    def get(self):
        """
        Gets the object.

        :return: The object data in bytes.
        """
        try:
            body = self.object.get()["Body"].read()
            logger.debug(
                "Got object '%s' from bucket '%s'.",
                self.object.key,
                self.object.bucket_name,
            )
        except ClientError:
            logger.debug(
                "Couldn't get object '%s' from bucket '%s'.",
                self.object.key,
                self.object.bucket_name,
            )
            raise
        else:
            return body

    # snippet-end:[python.example_code.s3.GetObject]

    # snippet-start:[python.example_code.s3.ListObjects]
    @staticmethod
    def list(bucket, prefix=None):
        """
        Lists the objects in a bucket, optionally filtered by a prefix.

        :param bucket: The bucket to query. This is a Boto3 Bucket resource.
        :param prefix: When specified, only objects that start with this prefix are listed.
        :return: The list of objects.
        """
        try:
            if not prefix:
                objects = list(bucket.objects.all())
            else:
                objects = list(bucket.objects.filter(Prefix=prefix))
            logger.debug(
                "Got objects %s from bucket '%s'", [o.key for o in objects], bucket.name
            )
        except ClientError:
            logger.debug("Couldn't get objects for bucket '%s'.", bucket.name)
            raise
        else:
            return objects

    # snippet-end:[python.example_code.s3.ListObjects]

    # snippet-start:[python.example_code.s3.CopyObject]
    def copy(self, dest_object):
        """
        Copies the object to another bucket.

        :param dest_object: The destination object initialized with a bucket and key.
                            This is a Boto3 Object resource.
        """
        try:
            dest_object.copy_from(
                CopySource={"Bucket": self.object.bucket_name, "Key": self.object.key}
            )
            dest_object.wait_until_exists()
            logger.debug(
                "Copied object from %s:%s to %s:%s.",
                self.object.bucket_name,
                self.object.key,
                dest_object.bucket_name,
                dest_object.key,
            )
        except ClientError:
            logger.debug(
                "Couldn't copy object from %s/%s to %s/%s.",
                self.object.bucket_name,
                self.object.key,
                dest_object.bucket_name,
                dest_object.key,
            )
            raise

    # snippet-end:[python.example_code.s3.CopyObject]

    # snippet-start:[python.example_code.s3.DeleteObject]
    def delete(self):
        """
        Deletes the object.
        """
        try:
            self.object.delete()
            self.object.wait_until_not_exists()
            logger.debug(
                f"Deleted object '{self.object.key}' from bucket '{self.object.bucket_name}'."
            )
        except ClientError:
            logger.debug(
                f"Couldn't delete object '{self.object.key}' from bucket '{self.object.bucket_name}'."
            )
            raise

    def delete_folder(folder_path):
        """
        Deletes the folder and all its contents.

        :param folder_path: The path of the folder to delete.
        """
        try:
            if CONFIG.LOCAL_TESTING:
                s3_client = boto3.client(
                    "s3",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                s3_client = boto3.client(
                    "s3",
                    region_name=CONFIG.AWS_REGION,
                )

            prefix = f"s3://{CONFIG.AWS_STORAGE_BUCKET_NAME}/"
            folder_path = folder_path[len(prefix) :]

            # List objects within the folder
            response = s3_client.list_objects_v2(
                Bucket=CONFIG.AWS_STORAGE_BUCKET_NAME, Prefix=folder_path
            )

            logger.debug(f"S3 OBJECTS LIST-----{response=}")

            if "Contents" in response:
                objects_to_delete = [
                    {"Key": obj["Key"]} for obj in response["Contents"]
                ]

                # Delete the objects
                s3_client.delete_objects(
                    Bucket=CONFIG.AWS_STORAGE_BUCKET_NAME,
                    Delete={"Objects": objects_to_delete},
                )

                logger.debug(
                    f"Deleted {len(objects_to_delete)} objects from folder '{folder_path}'"
                )
                return True
            else:
                logger.debug(f"No objects found in folder '{folder_path}'")
                return False
        except ClientError:
            logger.debug(
                f"Couldn't delete folder '{folder_path}' from bucket '{folder_path}'."
            )
            raise


class S3PublicUrlGenerator:
    def __init__(self) -> None:
        if CONFIG.LOCAL_TESTING:
            self.s3_client = boto3.client(
                "s3",
                aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                region_name=CONFIG.AWS_REGION,
                config=Config(signature_version="s3v4"),
            )
        else:
            self.s3_client = boto3.client(
                "s3",
                region_name=CONFIG.AWS_REGION,
                config=Config(signature_version="s3v4"),
            )

    def upload_to_s3(self, bucket_name: str, file_name: str, file_bytes: bytes) -> None:
        self.s3_client.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=file_bytes,
        )

    def generate_presigned_url(
        self, bucket_name: str, file_name: str, expires_in: int = 60 * 60 * 24 * 7
    ) -> str:
        """
        Generate Presigned URL for the given S3 item.

        Args:
            bucket_name (str): Name of the S3 bucket
            file_name (str): File name including it's path inside the bucket
            expires_in (int): Expiry in seconds (default 7 days)

        Returns:
            str: Presigned URL for the given file
        """
        signed_url = self.s3_client.generate_presigned_url(
            ClientMethod="get_object",
            Params={
                "Bucket": bucket_name,
                "Key": file_name,
            },
            ExpiresIn=expires_in,
        )
        return signed_url
