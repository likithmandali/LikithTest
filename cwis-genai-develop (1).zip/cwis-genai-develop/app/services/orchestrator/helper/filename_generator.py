import secrets
import string
import os
from datetime import datetime


def generate_random_string(length: int) -> str:
    """Generates a random letter combination based on the input

    Args:
        length (int): length of the random string to create

    Returns:
        str: random string with 'length' no. of characters
    """
    letters = string.ascii_letters
    return "".join(secrets.choice(letters) for _ in range(length))


def generate_unique_filename(file_path: str) -> str:
    """
    Given a file_path, this function seperates the file_name from it.
    Then a random 7 letter combination is appended at the end to make the filename unique

    Args:
        file_path (str): dir/filename, where the file was supposed to be saved

    Returns:
        str: returns a new unique file name
    """
    file_name, file_extension = os.path.splitext(file_path)
    random_string = generate_random_string(7)
    new_file_name = f"{file_name}_{random_string}{file_extension}"
    while os.path.exists(new_file_name):
        random_string = generate_random_string(7)
        new_file_name = f"{file_name}_{random_string}{file_extension}"
    return new_file_name


def generate_unique_filename_timestamp(file_path: str) -> str:
    """
    Given a file_path, this function seperates the file_name from it.
    Then a random 7 letter combination is appended at the end to make the filename unique

    Args:
        file_path (str): dir/filename, where the file was supposed to be saved

    Returns:
        str: returns a new unique file name
    """
    file_name, file_extension = os.path.splitext(file_path)
    local_datetime = datetime.now()
    local_iso_str = datetime.strftime(local_datetime, "%Y-%m-%dT%H:%M:%S.%f")[:-3]
    new_file_name = f"{file_name}_Response_{local_iso_str}{file_extension}"
    while os.path.exists(new_file_name):
        local_datetime = datetime.now()
        local_iso_str = datetime.strftime(local_datetime, "%Y-%m-%dT%H:%M:%S.%f")[:-3]
        new_file_name = f"{file_name}_Response_{local_iso_str}{file_extension}"
    return new_file_name
