import boto3
import json
import base64
from settings.config import CONFIG
from settings.loguru import logger
from settings.celery import celery
from api.db.qna_document import QNADocumentDBController
from settings.db import get_db_connection_eager
from api.db.knowledge import KnowledgeDBController


class LambdaWrapper:
    @staticmethod
    def _handle_error(function_name, error_msg, request_id, documentids=None):
        """
        Common error handling logic
        """
        logger.error(error_msg)
        try:
            db = get_db_connection_eager()
            
            if documentids:
                for document_id in documentids:
                    QNADocumentDBController.update_document_status(document_id, "Failed", request_id, db)
        except Exception as db_err:
            logger.exception(f"Error updating document status: {str(db_err)}")
                
        return RuntimeError(error_msg)

    @staticmethod
    def _process_lambda_response(response, function_name, function_params, request_id, documentids=None):
        """
        Process AWS Lambda response and handle common error patterns
        """
        try:
            # Check for AWS Lambda's built-in FunctionError
            if response.get("FunctionError"):
                error_msg = f"Lambda function {function_name} failed with error: {response.get('FunctionError')}"
                
                # Try to extract more detailed error message from the payload
                payload = response["Payload"].read().decode("utf-8")
                try:
                    parsed_payload = json.loads(payload)
                    if isinstance(parsed_payload, dict) and "errorMessage" in parsed_payload:
                        error_details = parsed_payload.get("errorMessage", "")
                        error_type = parsed_payload.get("errorType", "UnhandledError")
                        error_msg = f"Lambda execution error ({error_type}): {error_details}"
                except (json.JSONDecodeError, TypeError):
                    # If payload can't be parsed, use log result if available
                    if 'LogResult' in response:
                        log_result = base64.b64decode(response.get('LogResult', '')).decode('utf-8')
                        if log_result:
                            error_msg = f"Lambda function {function_name} failed with error: {response.get('FunctionError')}. Log details: {log_result}"
                
                raise LambdaWrapper._handle_error(function_name, error_msg, request_id, documentids)
                
            # Read and decode the payload for normal processing
            payload = response["Payload"].read().decode("utf-8")
            
            try:
                parsed_payload = json.loads(payload)
                
                # Check for Lambda function errors in payload
                status_code = parsed_payload.get("status_code", 200)
                if status_code >= 400:
                    error_message = parsed_payload.get("error_message", "Unknown error")
                    error_type = parsed_payload.get("error_type", "LambdaError")
                    error_msg = f"Lambda execution error ({error_type}): {error_message}"
                    raise LambdaWrapper._handle_error(function_name, error_msg, request_id, documentids)
                    
                return parsed_payload
                
            except json.JSONDecodeError:
                error_msg = f"Lambda function {function_name} returned invalid JSON: {payload}"
                raise LambdaWrapper._handle_error(function_name, error_msg, request_id, documentids)
        except Exception as err:
            logger.exception(f"Unexpected error processing Lambda response: {str(err)}")
            raise RuntimeError(f"Error processing Lambda response: {str(err)}")

    @staticmethod
    @celery.task(queue=CONFIG.CELERY_QUEUE_NAME)
    def invoke_function(
        function_name,
        function_params,
        knowledge_id,
        request_id: str,
        documentids: list = [],
        get_log=False,
    ):
        """
        Invokes a Lambda function.

        :param function_name: The name of the function to invoke.
        :param function_params: The parameters of the function as a dict. This dict
                                is serialized to JSON before it is sent to Lambda.
        :param get_log: When true, the last 4 KB of the execution log are included in
                        the response.
        :return: The response from the function invocation.
        """
        db = None
        try:
            if CONFIG.LOCAL_TESTING:
                lambda_client = boto3.client(
                    "lambda",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                lambda_client = boto3.client(
                    "lambda",
                    region_name=CONFIG.AWS_REGION,
                )

            response = lambda_client.invoke(
                FunctionName=function_name,
                Payload=json.dumps(function_params),
                LogType="Tail" if get_log else "None",
            )
            
            logger.debug("Invoked function %s.", function_name)
            
            # Process response and handle errors
            parsed_payload = LambdaWrapper._process_lambda_response(
                response, function_name, function_params, request_id, documentids
            )
            
            aws_knowledge_base_id = parsed_payload.get("knowledge_base_id")
            aws_datasource_id = parsed_payload.get("datasource_id")
            aws_knowledge_ingestion_job_id = parsed_payload.get("knowledge_ingestion_job_id")

            logger.debug(f"payload={json.dumps(parsed_payload)}")
            logger.debug(f"aws_knowledge_base_id={aws_knowledge_base_id}")
            logger.debug(f"aws_datasource_id={aws_datasource_id}")

            db = get_db_connection_eager()
            aws_folder_path = function_params["destination_file_name"]

            if (
                aws_datasource_id is None
                or aws_knowledge_base_id is None
                or not aws_datasource_id
                or not aws_knowledge_base_id
            ):
                for document_id in documentids:
                    QNADocumentDBController.update_document_status(document_id, "Failed", request_id, db)

                raise AttributeError(
                    "AWS Knowledge Base has not been created. A maximum of 100 knowledge bases can only be created."
                )

            KnowledgeDBController.update_knowledge_with_aws_knowledge_base_details(
                knowledgebaseid=aws_knowledge_base_id,
                datasourceid=aws_datasource_id,
                knowledge_id=knowledge_id,
                s3uri=f"s3://{CONFIG.AWS_STORAGE_BUCKET_NAME}/{aws_folder_path}",
                knowledge_ingestion_job_id=aws_knowledge_ingestion_job_id,
                db=db,
            )

            for document_id in documentids:
                QNADocumentDBController.update_document_status(document_id, "Completed", request_id, db)

            response["Payload"] = parsed_payload
            return response
        
        except Exception as err:
            logger.exception(f"Error invoking function {function_name}: {str(err)}")
            if db is None:
                db = get_db_connection_eager()
                
            for document_id in documentids:
                QNADocumentDBController.update_document_status(document_id, "Failed", request_id, db)
                
            raise

    @staticmethod
    @celery.task(queue=CONFIG.CELERY_QUEUE_NAME)
    def invoke_update_function(
        function_name,
        function_params,
        knowledge_id,
        request_id: str,
        documentids: list = [],
        get_log=False,
    ):
        """
        Invokes a Lambda function for updating knowledge.

        :param function_name: The name of the function to invoke.
        :param function_params: The parameters of the function as a dict. This dict
                                is serialized to JSON before it is sent to Lambda.
        :param get_log: When true, the last 4 KB of the execution log are included in
                        the response.
        :return: The response from the function invocation.
        """
        db = None
        try:
            logger.debug(f"{function_name=}  {function_params=}")
            if CONFIG.LOCAL_TESTING:
                lambda_client = boto3.client(
                    "lambda",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                lambda_client = boto3.client(
                    "lambda",
                    region_name=CONFIG.AWS_REGION,
                )

            response = lambda_client.invoke(
                FunctionName=function_name,
                Payload=json.dumps(function_params),
                LogType="Tail" if get_log else "None",
            )

            logger.debug(f"{response=}")
            logger.debug("Invoked function %s.", function_name)
            task_id = LambdaWrapper.invoke_update_function.request.id
            logger.debug(f"Updating activity record for {task_id=}")
            
            # Process response and handle errors
            parsed_payload = LambdaWrapper._process_lambda_response(
                response, function_name, function_params, request_id, documentids
            )
            
            aws_knowledge_base_id = parsed_payload.get("knowledge_base_id")
            aws_datasource_id = parsed_payload.get("datasource_id")
            aws_knowledge_ingestion_job_id = parsed_payload.get("ingestionJobId")
            aws_folder_path = function_params["aws_folder_path"]
            db = get_db_connection_eager()
            KnowledgeDBController.update_knowledge_datasource_and_ingestion_job(
                datasourceid=aws_datasource_id,
                knowledge_id=knowledge_id,
                knowledge_ingestion_job_id=aws_knowledge_ingestion_job_id,
                db=db,
            )
            
            for document_id in documentids:
                QNADocumentDBController.update_document_status(document_id, "Completed", request_id, db)

            response["Payload"] = parsed_payload
            return response
            
        except Exception as err:
            logger.exception(f"Error updating function {function_name}: {str(err)}")
            if db is None:
                db = get_db_connection_eager()
                
            for document_id in documentids:
                QNADocumentDBController.update_document_status(document_id, "Failed", request_id, db)
                
            raise
