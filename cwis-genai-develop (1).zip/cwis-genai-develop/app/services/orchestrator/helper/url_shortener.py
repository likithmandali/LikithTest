import pyshorteners
from settings.loguru import logger


def shorten_url(url: str, timeout: int = 5) -> str:
    """
    Shortens a URL using multiple URL shortening services with fallback.

    Args:
        url (str): The URL to be shortened.
        timeout (int): Timeout in seconds for the HTTP request. Default is 5.

    Returns:
        str: The shortened URL, or original URL if shortening fails.
    """
    shortener = pyshorteners.Shortener(timeout=timeout)

    # Try primary service (da.gd)
    try:
        return shortener.dagd.short(url)
    except Exception as e:
        logger.warning(f"da.gd shortener failed: {e}")

    # Fallback to TinyURL
    try:
        return shortener.tinyurl.short(url)
    except Exception as e:
        logger.error(f"All URL shortening attempts failed: {e}")
        return url
