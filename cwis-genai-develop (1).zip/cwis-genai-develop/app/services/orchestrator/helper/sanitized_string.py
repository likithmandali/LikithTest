"""Reusable sanitized string type for user-supplied prompt text.

Goals:
 - Allow normal punctuation, code snippets & Markdown (retain usability).
 - Block *high-risk* active content vectors & hidden control chars.
 - Avoid mutating the original value (validation only, no rewriting).

Additions vs. initial version:
 - Reject ASCII control characters (except TAB / LF / CR) & NUL.
 - Expanded pattern list: ``vbscript:``, selected ``data:`` URI types,
     ``srcdoc=``, ``file://`` plus original script/iframe/svg/event handlers.
 - Optional multi-pass (bounded) decode to collapse simple double-encoding.
 - (2025-09) Leading punctuation heuristic: blocks suspicious opening symbol
     clusters (e.g. ";;", "' ;", "$$$", "/";alert(") while preserving benign
     prefixes (#, ``` fences, JSON starts, $schema, comments). Tunable via
     ``LEADING_PUNCT_HEURISTIC_ENABLED`` and ``_LEADING_ALLOWED_PREFIXES``.

Heuristic rationale:
 Many injection probes begin with punctuation intended to terminate a surrounding
 string / attribute context before executing code. Legitimate user content rarely
 starts with a run of >=2-3 mixed breakpoint symbols unless it is structured
 markdown, code fences, JSON or schema metadata. We allowlist these to reduce
 false positives while catching common exploratory payloads early (faster fail
 before full regex evaluation).

Tuning guidance:
 - To relax: disable ``LEADING_PUNCT_HEURISTIC_ENABLED`` or add project-specific
     prefixes (e.g. "$metadata").
 - To tighten: adjust `_SUSPICIOUS_LEADING_CHARS` or lower the cluster length
     thresholds, but re-run tests for markdown/code/json samples.

Out of scope:
 Comprehensive HTML/JS sanitization. Downstream rendering MUST still apply
 context-appropriate escaping / templating safeguards. This layer is a guardrail,
 not a full sanitizer.
"""
from __future__ import annotations

import html
import re
import urllib.parse
from typing import Annotated
from pydantic import AfterValidator
from helper.custom_errors import UnprocessableEntityError

__all__ = ["SanitizedStr"]

# Optional heuristic toggle: block inputs that BEGIN with a suspicious run of punctuation
# unless they match a known benign prefix (Markdown heading, code fence, JSON, etc.).
# Rationale: Many probing / injection payloads start with quote/semicolon/angle/percent
# clusters whose only intent is context break-out. We keep this narrow and overrideable.
LEADING_PUNCT_HEURISTIC_ENABLED = True

# Allowlist of lowercase prefixes considered normal even if they start with punctuation.
# These are compared against the original (lowercased) value.
_LEADING_ALLOWED_PREFIXES = (
    "#",          # Single # heading
    "##",         # Deeper headings
    "###",        # etc.
    "```",        # Code fence
    "{",          # JSON / object config
    "[",          # JSON array
    "$schema",    # Common JSON schema key (may appear at start of snippet)
    "$ref",       # JSON schema refs
    "//",         # Harmless code comment snippet
    "/*",         # Block comment start
    "<!doctype",  # HTML doctype examples
)

# Characters considered when forming a suspicious leading cluster. These are chosen as they
# frequently appear in crafted breakout attempts but a long uninterrupted run is uncommon in benign text.
_SUSPICIOUS_LEADING_CHARS = set("'\";:%@/\\<>&$!`|*-_=+^(){}[]#?,")

# Max length of cluster to examine; we stop scanning once we encounter a non candidate char.
_MAX_LEADING_CLUSTER = 6


_MAX_DECODE_PASSES = 2  # Upper bound to prevent pathological expansion.

# High-risk patterns (case-insensitive):
#  - <script / </script (incl. whitespace-obfuscated variants via \s*)
#  - javascript:, vbscript:
#  - data: (html/js payloads)
#  - on<event>= inline handlers
#  - <iframe, <svg, <meta, <object, <embed, <link, <style, <body
#  - srcdoc= iframe attribute
#  - file:// URI scheme
#  - CSS expression(
_DISALLOWED = re.compile(
    r"(?is)("
    # Script tags (with whitespace obfuscation)
    r"<\s*s\s*c\s*r\s*i\s*p\s*t"
    r"|</\s*s\s*c\s*r\s*i\s*p\s*t"
    
    # Script execution schemes
    r"|javascript:"
    r"|vbscript:"
    r"|livescript:"
    r"|mocha:"
    
    # Dangerous data URIs
    r"|data:\s*(?:text/html|application/javascript|text/javascript|text/ecmascript|application/ecmascript|text/vbscript)"
    
    # Event handlers (expanded list)
    r"|on[a-z0-9]+\s*="
    r"|fscommand\s*="
    
    # HTML tags that can execute scripts
    r"|<\s*iframe"
    r"|<\s*svg"
    r"|<\s*meta"
    r"|<\s*object"
    r"|<\s*embed"
    r"|<\s*link"
    r"|<\s*style"
    r"|<\s*body"
    r"|<\s*form"
    r"|<\s*input"
    # NOTE: <img removed (allowed) – primarily illustrative content; raw HTML rendering must still escape contextually.
    # r"|<\s*img"  # removed to reduce false positives for harmless HTML examples
    r"|<\s*video"
    r"|<\s*audio"
    r"|<\s*source"
    r"|<\s*track"
    r"|<\s*frame"
    r"|<\s*frameset"
    r"|<\s*applet"
    r"|<\s*base"
    r"|<\s*bgsound"
    r"|<\s*isindex"
    r"|<\s*layer"
    r"|<\s*ilayer"
    r"|<\s*blink"
    r"|<\s*marquee"
    
    # Dangerous attributes
    r"|srcdoc\s*="
    r"|src\s*=\s*[\"']?\s*javascript:"
    r"|href\s*=\s*[\"']?\s*javascript:"
    r"|action\s*=\s*[\"']?\s*javascript:"
    r"|formaction\s*=\s*[\"']?\s*javascript:"
    r"|background\s*=\s*[\"']?\s*javascript:"
    r"|lowsrc\s*=\s*[\"']?\s*javascript:"
    r"|dynsrc\s*=\s*[\"']?\s*javascript:"
    
    # File and dangerous protocols
    r"|file:\s*//"
    r"|ftp:\s*//"
    r"|gopher:"
    r"|ldap:"
    r"|chrome:"
    r"|chrome-extension:"
    r"|moz-extension:"
    
    # CSS-based attacks
    r"|expression\s*\("
    r"|behavior\s*:"
    r"|-moz-binding\s*:"
    r"|@import"
    r"|binding\s*="
    
    # JS execution patterns
    r"|eval\s*\("
    r"|setTimeout\s*\("
    r"|setInterval\s*\("
    r"|Function\s*\("
    r"|execScript\s*\("
    
    # Breakout patterns (expanded to allow leading slashes before starting quote)
    r"|^/*[\"']\s*;\s*(?:alert|confirm|prompt|eval|setTimeout|setInterval)\s*\("
    r"|<!--\s*-->"
    r"|\]\]>"
    
    # Template placeholder patterns (removed due to high benign usage in prompt engineering / docs):
    # r"|\{\{\s*"   # Handlebars / Jinja style – now allowed
    # r"|\{%\s*"    # Jinja control block – now allowed
    r"|\$\{\s*"   # JS template literal – now allowed
    # r"|<%\s*"      # JSP / ERB style – now allowed

    # Spaced inline event handlers obfuscation (e.g. <div o n l o a d=...>) – target common events
    r"|<[^>]*o\s*n\s*l\s*o\s*a\s*d\s*="
    r"|<[^>]*o\s*n\s*e\s*r\s*r\s*o\s*r\s*="
    r"|<[^>]*o\s*n\s*c\s*l\s*i\s*c\s*k\s*="

    # Function call inside an HTML tag attribute block (e.g. <br size='1' alert(1)> or obfuscated variants):
    # This aims to catch patterns like the tested payload <BR SIZE=' &(alert ('XSS' )}'› where a JS function call
    # is smuggled into a tag context. Conservative upper bound on attribute span to avoid catastrophic backtracking.
    r"|<[a-z][^>]{0,200}\b(alert|confirm|prompt)\s*\("
    
    # XML/XSLT patterns
    r"|<\?\s*xml"
    r"|<xsl:"
    r"|xmlns\s*="
    
    # Flash/ActiveX
    r"|application/x-shockwave-flash"
    r"|clsid\s*:"
    r"|activex"
    
    # HTML entity sequences
    r"|&#[0-9]+;"
    r"|&#x[0-9a-f]+;"
    r"|&[a-z]+;"
    
    r")"
)


def _normalize(v: str) -> str:
    """Decode up to ``_MAX_DECODE_PASSES`` rounds (HTML entities + URL encoding).

    Stops early if a pass produces no change. Bounded to keep behavior
    predictable & cheap while defeating simple double-encodings like
    ``%253Cscript`` (-> ``%3Cscript`` -> ``<script``).
    """
    out = v
    for _ in range(_MAX_DECODE_PASSES):
        try:
            new_val = urllib.parse.unquote(html.unescape(out))
        except Exception:
            break
        if new_val == out:
            break
        out = new_val
    return out


def _validate_sanitized(value: str | None) -> str | None:
    if value is None:
        return value

    # Reject control characters (except common whitespace) early.
    # (Includes explicit NUL check.)
    if any(
        (ord(c) < 0x20 and c not in ("\n", "\r", "\t")) or ord(c) == 0x7F
        for c in value
    ):
        raise UnprocessableEntityError("control characters not allowed")

    # Leading punctuation heuristic (opt-in via flag). Intention: catch payloads that begin
    # with clusters like \";alert(, /";alert(, %%%, $$$, ;;-- etc. while not blocking
    # common legitimate starts (Markdown headings, code fences, JSON, comments, schema keys).
    if LEADING_PUNCT_HEURISTIC_ENABLED and value:
        lv = value.lstrip()  # ignore leading whitespace for heuristic purposes
        lv_lower = lv.lower()
        # Allowlist prefixes short-circuit
        if not lv_lower.startswith(_LEADING_ALLOWED_PREFIXES):
            # Extract leading cluster of suspicious chars
            cluster = []
            for ch in lv[:_MAX_LEADING_CLUSTER]:
                if ch in _SUSPICIOUS_LEADING_CHARS:
                    cluster.append(ch)
                else:
                    break
            if cluster:
                # Heuristic rule: block if cluster length >=2 and contains at least one quote or semicolon
                # OR cluster length >=3 consisting solely of symbols (no alnum) and includes at least one of ; ' " < % $
                cluster_str = ''.join(cluster)
                if (
                    (len(cluster_str) >= 2 and any(c in cluster_str for c in "'\";"))
                    or (len(cluster_str) >= 3 and all(not c.isalnum() for c in cluster_str) and any(c in cluster_str for c in ";'\"<%$"))
                ):
                    raise UnprocessableEntityError("disallowed active content (leading-special-char) detected")

    canonical = _normalize(value.lower())
    m = _DISALLOWED.search(canonical)
    if m:
        snippet = m.group(0)
        # Lightweight category inference (avoid heavy re-matching):
        if 'script' in snippet:
            cat = 'script-tag-or-protocol'
        elif snippet.startswith('data:'):
            cat = 'data-uri'
        elif snippet.startswith('<'):
            if 'on' in snippet and '=' in snippet:
                cat = 'inline-event'
            else:
                cat = 'html-active-tag'
        elif snippet.startswith('javascript:') or 'javascript:' in snippet:
            cat = 'js-protocol'
        elif 'eval' in snippet or 'settimeout' in snippet or 'setinterval' in snippet:
            cat = 'js-exec-call'
        elif 'alert' in snippet or 'prompt' in snippet or 'confirm' in snippet:
            cat = 'js-function-call'
        else:
            cat = 'active-content'
        raise UnprocessableEntityError(f"disallowed active content ({cat}) detected")

    return value  # Preserve original form (no mutation).


SanitizedStr = Annotated[str, AfterValidator(_validate_sanitized)]
