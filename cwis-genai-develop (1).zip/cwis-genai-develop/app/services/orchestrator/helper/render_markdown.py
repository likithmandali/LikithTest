def render_markdownifying_template(prompt_template: str):
    render_markdown_template = """
        Please provide the response into proper markdown format,
        ensuring that headers, subheaders, bulleted points, numbered lists, tables, and
        any other appropriate formatting elements are applied as necessary.
        Add appropriate title size for headers and subheaders
        But don't add backticks in the start and end, just give the markdown formatted text
    """  # noqa: E501

    prompt_template = prompt_template + "\n" + render_markdown_template

    return prompt_template
