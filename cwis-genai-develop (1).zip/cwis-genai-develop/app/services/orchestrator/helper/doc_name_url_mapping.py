# Document name to URL mapping
# This file contains the mapping between document names and their public URLs
# Used by the aws_embeddings.py to provide public URLs instead of presigned URLs

doc_name_doc_url_mapping = {
    "Adoptions_September_-2025.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Adoptions_September_-2025.pdf",
    "Cross-Functions-October-2025.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Cross-Functions-October-2025.pdf",
    "Evidence-Based Prevention Services Policy 3-17-2025.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Evidence-Based-Prevention-Services-Policy-3-17-2025.pdf",
    "In-Home-Manual_PATHNC_Updates_April2026.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/In-Home-Manual_PATH-NC-Updates-April-2026-3.pdf",
    "Interstate Compact on the Placement of Children.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/icpc.pdf",
    "NC SDM FSNA_CSNA Manual_FINAL 2025.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/NC-SDM-FSNA_CSNA-Manual_%E2%80%8CFINAL-2025.pdf",
    "North Carolina SDM Risk Assessment_FINAL 2025.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/North-Carolina-SDM-Risk-Assessment_FINAL-2025-1.pdf",
    "North-Carolina-SDM-Safety-Manual.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/North-Carolina-SDM-Safety-Manual_FINAL-2025.pdf",
    "PATH-NC-Assessments-October-2025.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/PATH-NC-Assessments-October-2025.pdf",
    "PATH-NC-Intake-Policy-October-2025.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/PATH-NC-Intake-Policy-October-2025.pdf",
    "Permanency-Planning-Manual_PATHNC_Updates_April2026.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Permanency-Planning-Manual_PATH-NC-Updates-April-2026.pdf",
    "Appendix-3-6-Adoption-Assistance-Funding_7-2024.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Appendix-3-6-Adoption-Assistance-Funding_7-2024.pdf",
    "Appendix-3.5_Child-Welfare-Funding-Foster-Care_PATHNC.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Appendix-3.5-Child-Welfare-Funding-%E2%80%93-Foster-Care-PATH-NC-April-2026-1.pdf",
    "Appendix-3.7_KinGAP-and-GAP-Payments_April2026.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Appendix-3.7-KinGAP-GAP-Payments-April-2026.pdf",
    "LINKS-as-an-Outcome-Based-Service-Resource-Guide_April2026.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/LINKS-as-an-Outcome-Based-Service-Resource-Guide-April-2026.pdf",
    "LINKS-Vehicle-Resource-Guide_April2026.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/LINKS-Vehicle-Resource-Guide-April-2026.pdf",
    "Authentic-Youth-Engagement-Resource-Guide_April2026.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Authentic-Youth-Engagement-Resource-Guide-April-2026.pdf",
    "Consumer-Credit-Reports-Resource-Guide_April2026.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Consumer-Credit-Reports-Resource-Guide-April-2026.pdf",
    "Transitional-Living-Plan-for-14-17-year-olds-instructions.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/DSS-5096a-ins.pdf",
    "Emancipation-Plan-for-17-21-year-olds-Instructions.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/DSS-5096b-ins.pdf",
    "In-Home-Family-Case-Plan-Instructions_DSS-5239_PATHNC.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/DSS-5239ins_In-Home-Family-Case-Plan_Instructions-DSS-5239ins-PATH-NC.pdf",
    "Permanency-Planning-Family-Case-Plan-Instructions_PATH_DSS-5240_PATHNC.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/DSS-5240ins-PATH-NC.pdf",
    "Near-Fatality-and-Fatality-Policy_1.14.2026-1.pdf":"https://policies.ncdhhs.gov/wp-content/uploads/Near-Fatality-and-Fatality-Policy_1.14.2026.pdf"
}