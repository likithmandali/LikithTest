import boto3
import secrets
import time
import re
import psycopg2
import requests
import base64
from PIL import Image
import io
from pydantic import BaseModel
from enum import Enum
from typing import List
from fastapi import Depends
import json
from helper.url_shortener import shorten_url
from settings.config import CONFIG
from settings.loguru import logger
from helper.aws_s3 import S3ObjectWrapper, S3PublicUrlGenerator
from settings.db import get_db_connection
from api.db.activity import ActivityDBController
from api.schemas.common.activity import (
    OverallStatus,
)
from helper.custom_errors import ExternalAPIError

from api.db.knowledge import KnowledgeDBController
from helper.doc_name_url_mapping import doc_name_doc_url_mapping
# Use cryptographically secure random number generation
suffix = secrets.randbelow(1000000000000)


def download_image_to_base64(image_url, max_width=1024, max_height=1024, quality=85):
    """
    Download an image from URL, resize it for optimal token usage, and convert to base64.

    Args:
        image_url (str): URL of the image to download
        max_width (int): Maximum width in pixels (default: 1024)
        max_height (int): Maximum height in pixels (default: 1024)
        quality (int): JPEG quality for compression (1-100, default: 85)

    Returns:
        tuple: (base64_data, media_type) or (None, None) on error
    """
    try:
        response = requests.get(image_url, timeout=30)
        response.raise_for_status()

        # Open image with PIL
        image = Image.open(io.BytesIO(response.content))
        original_size = len(response.content)
        original_width, original_height = image.size

        # Convert to RGB if needed (for JPEG compatibility and smaller size)
        if image.mode in ("RGBA", "LA", "P"):
            # Create white background for transparent images
            rgb_image = Image.new("RGB", image.size, (255, 255, 255))
            if image.mode == "P":
                image = image.convert("RGBA")
            if image.mode in ("RGBA", "LA"):
                rgb_image.paste(image, mask=image.split()[-1])
            else:
                rgb_image.paste(image)
            image = rgb_image
        elif image.mode != "RGB":
            image = image.convert("RGB")

        # Calculate new dimensions while maintaining aspect ratio
        width, height = image.size
        if width > max_width or height > max_height:
            # Calculate scaling factor
            scale_factor = min(max_width / width, max_height / height)
            new_width = int(width * scale_factor)
            new_height = int(height * scale_factor)

            # Resize image using high-quality resampling
            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            logger.info(
                f"Resized image from {original_width}x{original_height} to {new_width}x{new_height}"
            )

        # Save to bytes with JPEG compression for smaller size
        output_buffer = io.BytesIO()
        image.save(output_buffer, format="JPEG", quality=quality, optimize=True)
        compressed_content = output_buffer.getvalue()

        # Check size limit (Claude has 3.75MB limit, but aim for much smaller)
        content_length = len(compressed_content)
        max_size = 3.75 * 1024 * 1024  # 3.75MB in bytes
        if content_length > max_size:
            logger.warning(
                f"Image size {content_length} bytes still exceeds Claude's 3.75MB limit after compression"
            )
            return None, None

        # Convert to base64
        base64_data = base64.b64encode(compressed_content).decode("utf-8")

        compression_ratio = (
            (original_size - content_length) / original_size * 100
            if original_size > 0
            else 0
        )
        logger.info(
            f"Successfully processed image: original {original_size} bytes -> compressed {content_length} bytes "
            f"({compression_ratio:.1f}% reduction)"
        )

        return base64_data, "image/jpeg"

    except Exception as e:
        logger.error(f"Error downloading and processing image from {image_url}: {e}")
        return None, None


def generate_s3_presigned_url(s3_uri, expiration=60 * 60 * 24 * 7):
    """
    Generate a presigned URL for an S3 object.

    Args:
        s3_uri (str): S3 URI in format s3://bucket/key
        expiration (int): URL expiration time in seconds

    Returns:
        str: Presigned URL
    """
    try:
        # Parse S3 URI
        if not s3_uri.startswith("s3://"):
            raise ValueError("Invalid S3 URI format")

        parts = s3_uri[5:].split("/", 1)
        bucket = parts[0]
        key = parts[1] if len(parts) > 1 else ""

    # Create S3 client with proper AWS credentials
        if CONFIG.LOCAL_TESTING:
            s3_client = boto3.client(
                "s3",
                region_name=CONFIG.AWS_REGION,
                aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
            )
        else:
            s3_client = boto3.client(
                "s3",
                region_name=CONFIG.AWS_REGION,
            )

    # Generate presigned URL
        url = s3_client.generate_presigned_url(
            "get_object", Params={"Bucket": bucket, "Key": key}, ExpiresIn=expiration
        )

        return url
    except Exception as e:
        logger.error(f"Error generating presigned URL for {s3_uri}: {e}")
        return None


def generate_s3_presigned_url_for_img(s3_uri, expiration=60 * 60 * 24 * 7):
    """
    Generate a presigned URL for an S3 object, specifically optimized for image files.

    Args:
        s3_uri (str): S3 URI in format s3://bucket/key (e.g., s3://genaie-data-bucket/aws/bedrock/knowledge_bases/4HI6TMPE0B/ZTVWPPWOJD/79ad9bd2-0f73-42be-88f5-4c03b86476f4.png)
    expiration (int): URL expiration time in seconds (default: 7 days)

    Returns:
        str: Presigned URL or None if generation fails
    """
    try:
        # Validate input
        if not s3_uri or not isinstance(s3_uri, str):
            raise ValueError("S3 URI must be a non-empty string")

        if not s3_uri.startswith("s3://"):
            raise ValueError(
                f"Invalid S3 URI format. Expected format: s3://bucket/key, got: {s3_uri}"
            )

        # Parse S3 URI - remove s3:// prefix and split bucket from key
        uri_without_prefix = s3_uri[5:]  # Remove 's3://'

        if not uri_without_prefix:
            raise ValueError("S3 URI cannot be just 's3://'")

        parts = uri_without_prefix.split("/", 1)
        bucket = parts[0]
        key = parts[1] if len(parts) > 1 else ""

        # Validate bucket and key
        if not bucket:
            raise ValueError("Bucket name cannot be empty")

        if not key:
            raise ValueError("Object key cannot be empty")

        logger.debug(f"Parsing S3 URI: {s3_uri} -> Bucket: {bucket}, Key: {key}")

        # Create S3 client with proper AWS credentials
        if CONFIG.LOCAL_TESTING:
            s3_client = boto3.client(
                "s3",
                region_name=CONFIG.AWS_REGION,
                aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
            )
        else:
            s3_client = boto3.client(
                "s3",
                region_name=CONFIG.AWS_REGION,
            )

        # Generate presigned URL
        url = s3_client.generate_presigned_url(
            "get_object", Params={"Bucket": bucket, "Key": key}, ExpiresIn=expiration
        )

        logger.debug(f"Successfully generated presigned URL for {s3_uri}")
        return url

    except Exception as e:
        logger.error(f"Error generating presigned URL for {s3_uri}: {e}")
        return None


def process_knowledge_base_results(retrieval_results):
    """
    Process knowledge base retrieval results and extract relevant content.

    Args:
        retrieval_results (list): List of retrieval results from knowledge base

    Returns:
        dict: Processed content with text and image information
    """
    try:
        processed_content = {"text_content": [], "image_content": []}

        for result in retrieval_results:
            content = result.get('content', {})
            metadata = result.get('metadata', {})
            location = result.get('location', {})
             # Handle text content
            
            # The source uri would be present for both the pdfs and images. For images, it would still give the source_uri of pdf from where the img was extracted
            source_uri= metadata.get('x-amz-bedrock-kb-source-uri', '')
            s3_location = location.get('s3Location', {})
            s3_uri = s3_location.get('uri')
            document_name=source_uri.split('/')[-1] if source_uri else 'document_name'
            url=get_url(document_name,s3_uri=s3_uri)
            if content.get('type') == 'TEXT':
                text_content = content.get('text', '')
                if text_content:
                    processed_content['text_content'].append({
                        'text': text_content,
                        'source': metadata.get('x-amz-bedrock-kb-source-uri', ''),
                        'page_number': metadata.get('x-amz-bedrock-kb-document-page-number'),
                        'score': result.get('score', 0),
                        'chunk_id': metadata.get('x-amz-bedrock-kb-chunk-id', ''),
                        'data_source_id': metadata.get('x-amz-bedrock-kb-data-source-id', ''),
                        'url': url
                    })
            
            # Extract text description (for backward compatibility)
            description = metadata.get('x-amz-bedrock-kb-description', '')
            if description and content.get('type') != 'TEXT':  # Avoid duplicates
                processed_content['text_content'].append({
                    'text': description,
                    'source': metadata.get('x-amz-bedrock-kb-source-uri', ''),
                    'page_number': metadata.get('x-amz-bedrock-kb-document-page-number'),
                    'score': result.get('score', 0)
                })
            
            # Handle image content
            if content.get('type') == 'IMAGE':
                
                if 'x-amz-bedrock-kb-byte-content-source' in metadata:
                    presigned_url = generate_s3_presigned_url_for_img(metadata['x-amz-bedrock-kb-byte-content-source'])
                    if presigned_url:
                        base64_data, media_type = download_image_to_base64(
                            presigned_url
                        )
                        if base64_data:
                            processed_content['image_content'].append({
                                's3_uri': s3_uri,
                                'base64_data': base64_data,
                                'media_type': media_type,
                                'source': metadata.get('x-amz-bedrock-kb-source-uri', ''),
                                'page_number': metadata.get('x-amz-bedrock-kb-document-page-number'),
                                'url': url,
                                'score': result.get('score', 0)
                            }) 
        return processed_content
    except Exception as e:
        logger.error(f"Error processing knowledge base results: {e}")
        return {"text_content": [], "image_content": []}



def get_url(document_name,s3_uri):
    try:
        if document_name in doc_name_doc_url_mapping:
            return doc_name_doc_url_mapping[document_name]
        else:
            return generate_s3_presigned_url(s3_uri=s3_uri)
    except Exception as e:
        logger.error(f"Error getting public URL for {document_name}: {e}")
        return "https://example.com/default_public_url"


class PIIEntityType(Enum):
    """
    Enumeration of PII entity types for detection and classification.
    These are NOT actual credentials - they are string constants used for PII entity recognition.
    """
    ADDRESS = "ADDRESS"
    AGE = "AGE"
    # These are PII entity type identifiers, not actual AWS credentials
    AWS_ACCESS_KEY = "AWS_ACCESS_KEY"  # nosec - This is a PII type identifier, not a real key
    AWS_SECRET_KEY = "AWS_SECRET_KEY"  # nosec - This is a PII type identifier, not a real key
    CA_HEALTH_NUMBER = "CA_HEALTH_NUMBER"
    CA_SOCIAL_INSURANCE_NUMBER = "CA_SOCIAL_INSURANCE_NUMBER"
    CREDIT_DEBIT_CARD_CVV = "CREDIT_DEBIT_CARD_CVV"
    CREDIT_DEBIT_CARD_EXPIRY = "CREDIT_DEBIT_CARD_EXPIRY"
    CREDIT_DEBIT_CARD_NUMBER = "CREDIT_DEBIT_CARD_NUMBER"
    DRIVER_ID = "DRIVER_ID"
    EMAIL = "EMAIL"
    INTERNATIONAL_BANK_ACCOUNT_NUMBER = "INTERNATIONAL_BANK_ACCOUNT_NUMBER"
    IP_ADDRESS = "IP_ADDRESS"
    LICENSE_PLATE = "LICENSE_PLATE"
    MAC_ADDRESS = "MAC_ADDRESS"
    NAME = "NAME"
    PASSWORD = "PASSWORD"
    PHONE = "PHONE"
    PIN = "PIN"
    SWIFT_CODE = "SWIFT_CODE"
    UK_NATIONAL_HEALTH_SERVICE_NUMBER = "UK_NATIONAL_HEALTH_SERVICE_NUMBER"
    UK_NATIONAL_INSURANCE_NUMBER = "UK_NATIONAL_INSURANCE_NUMBER"
    UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER = "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER"
    URL = "URL"
    USERNAME = "USERNAME"
    US_BANK_ACCOUNT_NUMBER = "US_BANK_ACCOUNT_NUMBER"
    US_BANK_ROUTING_NUMBER = "US_BANK_ROUTING_NUMBER"
    US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER = "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER"
    US_PASSPORT_NUMBER = "US_PASSPORT_NUMBER"
    US_SOCIAL_SECURITY_NUMBER = "US_SOCIAL_SECURITY_NUMBER"
    VEHICLE_IDENTIFICATION_NUMBER = "VEHICLE_IDENTIFICATION_NUMBER"


class GuardrailsCreateUpdateRequest(BaseModel):
    instance_id: int
    pii_types: List[PIIEntityType] = []
    words_to_block: list[str] = []
    content_filter: list = []


class AWSEmbeddings:
    def __init__(self, embed_model_name: str):
        """
        :param s3_object: A Boto3 Object resource. This is a high-level resource in Boto3
                          that wraps object actions in a class-like structure.
        """
        try:
            if CONFIG.LOCAL_TESTING:
                self.boto3_session = boto3.session.Session(
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )

                self.bedrock_agent_client = self.boto3_session.client(
                    "bedrock-agent",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
                self.bedrock_agent_runtime_client = boto3.client(
                    "bedrock-agent-runtime",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                self.boto3_session = boto3.session.Session(
                    region_name=CONFIG.AWS_REGION,
                )

                self.bedrock_agent_client = self.boto3_session.client(
                    "bedrock-agent",
                    region_name=CONFIG.AWS_REGION,
                )
                self.bedrock_agent_runtime_client = boto3.client(
                    "bedrock-agent-runtime",
                    region_name=CONFIG.AWS_REGION,
                )
            self.embeddingModelArn = f"arn:aws:bedrock:{CONFIG.AWS_REGION}::foundation-model/{embed_model_name}"
            self.roleArn = CONFIG.AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN

            self.opensearchcollerctionArn = CONFIG.AWS_OPENSEARCH_COLLECTION_ARN
            self.opensearchServerlessConfiguration = {
                "collectionArn": self.opensearchcollerctionArn,
                "vectorIndexName": CONFIG.AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME,
                "fieldMapping": {
                    "vectorField": "embeddings",
                    "textField": "raw-text-chunk",
                    "metadataField": "knowledge-metadata",
                },
            }
        except Exception as e:
            logger.error(f"Error initializing AWSEmbeddings: {e}")
            raise

    # @retry(wait_random_min=1000, wait_random_max=2000, stop_max_attempt_number=7)
    async def create_knowledge_base_func(self, knowledge_base_name):
        try:
            create_kb_response = self.bedrock_agent_client.create_knowledge_base(
                name=knowledge_base_name,
                description=knowledge_base_name,
                roleArn=self.roleArn,
                knowledgeBaseConfiguration={
                    "type": "VECTOR",
                    "vectorKnowledgeBaseConfiguration": {
                        "embeddingModelArn": self.embeddingModelArn
                    },
                },
                storageConfiguration={
                    "type": "OPENSEARCH_SERVERLESS",
                    "opensearchServerlessConfiguration": self.opensearchServerlessConfiguration,
                },
            )
            return create_kb_response["knowledgeBase"]
        except Exception as e:
            logger.error(f"Error creating knowledge base: {e}")
            raise

    async def create_data_source_to_knowledge_base(
        self, datasourcename, datsourcedescription, kb_id, chunk_config, s3_config
    ):
        try:
            create_ds_response = self.bedrock_agent_client.create_data_source(
                name=datasourcename,
                description=datsourcedescription,
                knowledgeBaseId=kb_id,
                dataDeletionPolicy="DELETE",
                dataSourceConfiguration={
                    # # For S3
                    "type": "S3",
                    "s3Configuration": s3_config,
                    # # For Web URL
                    # "type": "WEB",
                    # "webConfiguration":webConfiguration
                },
                vectorIngestionConfiguration={"chunkingConfiguration": chunk_config},
            )
            return create_ds_response
        except Exception as e:
            logger.error(f"Error creating data source: {e}")
            raise

    async def data_source_ingestion(self, datasourceid, kb_id):
        try:
            time.sleep(10)
            start_job_response = self.bedrock_agent_client.start_ingestion_job(
                knowledgeBaseId=kb_id, dataSourceId=datasourceid
            )
            job = start_job_response["ingestionJob"]

            while job["status"] != "COMPLETE":
                get_job_response = self.bedrock_agent_client.get_ingestion_job(
                    knowledgeBaseId=kb_id,
                    dataSourceId=datasourceid,
                    ingestionJobId=job["ingestionJobId"],
                )
                job = get_job_response["ingestionJob"]
                time.sleep(40)

            return job["status"]
        except Exception as e:
            logger.error(f"Error in data source ingestion: {e}")
            raise

    def aws_embedding_chunking(chunking_strategy: str):
        try:
            match chunking_strategy:
                case "NONE":
                    chunkingStrategyConfiguration = {"chunkingStrategy": "NONE"}
                    return chunkingStrategyConfiguration
                case "FIXED_SIZE":
                    chunkingStrategyConfiguration = {
                        "chunkingStrategy": "FIXED_SIZE",
                        "fixedSizeChunkingConfiguration": {
                            "maxTokens": 2000,
                            "overlapPercentage": 15,
                        },
                    }
                    return chunkingStrategyConfiguration
                case "HIERARCHICAL":
                    chunkingStrategyConfiguration = {
                        "chunkingStrategy": "HIERARCHICAL",
                        "hierarchicalChunkingConfiguration": {
                            "levelConfigurations": [
                                {"maxTokens": 1500},
                                {"maxTokens": 300},
                            ],
                            "overlapTokens": 60,
                        },
                    }

                    return chunkingStrategyConfiguration
                case "SEMANTIC":
                    chunkingStrategyConfiguration = {
                        "semanticChunkingConfiguration": {
                            "breakpointPercentileThreshold": 95,
                            "bufferSize": 1,
                            "maxTokens": 300,
                        }
                    }
                    return chunkingStrategyConfiguration

                case _:
                    raise ValueError(f"Invalid LLM model value: {chunking_strategy}")
        except Exception as e:
            logger.error(f"Error in aws_embedding_chunking: {e}")
            raise

    async def create_and_upload_metadata_datasource(self, filename, kb_id):
        try:
            s3_uri = f"s3://{CONFIG.AWS_STORAGE_BUCKET_NAME}/{filename}"
            logger.debug(f"{s3_uri=}")

            # Define the new data
            new_data = {
                "metadataAttributes": {
                    "x-amz-bedrock-kb-data-source-id": kb_id,
                    "x-amz-bedrock-kb-source-uri": s3_uri,
                }
            }

            full_metadatafilename = filename + ".metadata.json"

            logger.debug(f"{full_metadatafilename=}")

            file_contents_bytes = json.dumps(new_data).encode("utf-8")
            s3_obj = S3ObjectWrapper(
                CONFIG.AWS_STORAGE_BUCKET_NAME, dest_file_path=full_metadatafilename
            )
            s3_obj.put(file_contents_bytes)

            return full_metadatafilename
        except Exception as e:
            logger.error(f"Error creating and uploading metadata datasource: {e}")
            raise


class AWSBedrockEmbeddingsSearch:
    @staticmethod
    def _get_image_format(source_uri: str) -> str:
        """Determine image format from file extension."""
        try:
            file_extension = source_uri.split(".")[-1].lower()
            format_mapping = {
                "jpg": "jpeg",
                "jpeg": "jpeg",
                "png": "png",
                "gif": "gif",
                "webp": "webp",
            }
            return format_mapping.get(file_extension, "png")
        except Exception as e:
            logger.error(f"Error getting image format: {e}")
            return "png"  # default fallback

    @staticmethod
    def _create_image_data(source_uri: str, image_format: str) -> dict:
        """Create image data structure for AWS Bedrock."""
        try:
            return {
                "type": "image",
                "source": {
                    "type": "url",
                    "url": source_uri,
                    "media_type": image_format,
                },
            }
        except Exception as e:
            logger.error(f"Error creating image data: {e}")
            raise

    @staticmethod
    def _create_presigned_url(source_uri: str) -> str:
        """Create presigned URL from S3 URI."""
        try:
            s3_file_path = source_uri.split(f"s3://{CONFIG.AWS_STORAGE_BUCKET_NAME}/")[
                1
            ]
            s3_processor = S3PublicUrlGenerator()
            presigned_uri = s3_processor.generate_presigned_url(
                bucket_name=CONFIG.AWS_STORAGE_BUCKET_NAME,
                file_name=s3_file_path,
            )
            return shorten_url(presigned_uri)
        except Exception as e:
            logger.error(f"Error creating presigned URL: {e}")
            raise

    @staticmethod
    def _process_image_result(result: dict, include_references: bool) -> list:
        """Process image result and return formatted data."""
        try:
            extracted_data = []
            metadata = result.get("metadata")
            if not metadata:
                return extracted_data

            source_uri = metadata.get("x-amz-bedrock-kb-byte-content-source")
            if not source_uri:
                return extracted_data

            image_format = AWSBedrockEmbeddingsSearch._get_image_format(source_uri)
            image_data = AWSBedrockEmbeddingsSearch._create_image_data(
                source_uri, image_format
            )
            extracted_data.append(image_data)

            if include_references:
                page_number = metadata.get("x-amz-bedrock-kb-document-page-number")
                shortened_uri = AWSBedrockEmbeddingsSearch._create_presigned_url(
                    source_uri
                )

                extracted_data.append(
                    {
                        "text": f"Image reference: {shortened_uri}, Page: {page_number}",
                        "s3_source_uri": source_uri,
                        "document_page_number": page_number,
                        "content_type": "image_reference",
                    }
                )

            return extracted_data
        except Exception as e:
            logger.error(f"Error processing image result: {e}")
            return []

    @staticmethod
    def _process_text_result(result: dict, include_references: bool) -> dict:
        """Process text result and return formatted data."""
        try:
            text = result["content"]["text"]

            if not include_references:
                return {"text": text}

            metadata = result.get("metadata")
            if not metadata:
                return {"text": text}

            source_uri = metadata.get("x-amz-bedrock-kb-source-uri")
            page_number = metadata.get("x-amz-bedrock-kb-document-page-number")

            if source_uri:
                shortened_uri = AWSBedrockEmbeddingsSearch._create_presigned_url(
                    source_uri
                )
                return {
                    "text": text,
                    "s3_source_uri": shortened_uri,
                    "document_page_number": page_number,
                }

            return {"text": text}
        except Exception as e:
            logger.error(f"Error processing text result: {e}")
            return {"text": result.get("content", {}).get("text", "")}

    # Uncomment this code when you want to use the direct Bedrock Rerank API
    @staticmethod
    def rerank_documents(
        query: str,
        documents: list,
        rerank_model_arn: str,
        number_of_results: int = None,
    ):
        """
        Rerank documents using the direct Bedrock Rerank API
        """
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                )

            # Prepare sources for reranking
            sources = []
            for doc in documents:
                source = {
                    "type": "INLINE",
                    "inlineDocumentSource": {
                        "type": "TEXT",
                        "textDocument": {"text": doc["content"]["text"]},
                    },
                }
                sources.append(source)

            # Prepare rerank request
            rerank_request = {
                "queries": [{"type": "TEXT", "textQuery": {"text": query}}],
                "sources": sources,
                "rerankingConfiguration": {
                    "type": "BEDROCK",
                    "bedrockRerankingConfiguration": {
                        "modelConfiguration": {"modelArn": rerank_model_arn}
                    },
                },
            }

            # Add number of results if specified
            if number_of_results:
                rerank_request["rerankingConfiguration"][
                    "bedrockRerankingConfiguration"
                ]["numberOfResults"] = number_of_results

            logger.debug(f"Rerank request: {rerank_request}")

            # Call rerank API
            rerank_response = bedrock_runtime_client.rerank(**rerank_request)

            logger.debug(f"Rerank response: {rerank_response}")

            # Map reranked results back to original document format
            reranked_documents = []
            for result in rerank_response["results"]:
                original_index = result["index"]
                original_doc = documents[original_index].copy()

                # Add relevance score from reranking
                original_doc["relevanceScore"] = result["relevanceScore"]

                reranked_documents.append(original_doc)

            logger.info(f"Successfully reranked {len(reranked_documents)} documents")
            return reranked_documents

        except Exception as e:
            logger.error(f"Error in rerank_documents: {e}")
            # Return original documents if reranking fails
            logger.warning("Reranking failed, returning original documents")
            return documents

    @staticmethod
    def answer_query(
        query,
        kb_id,
        k_near_chunks,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        """
        Simplified knowledge base query that returns Claude-ready format.

        Args:
            query: Search query text
            kb_id: Knowledge base ID
            k_near_chunks: Number of results to retrieve
            db: Database connection

        Returns:
            dict: Processed content with 'text_content' and 'image_content' lists
        """
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-agent-runtime",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-agent-runtime",
                    region_name=CONFIG.AWS_REGION,
                )

            # Get knowledge base details
            knowledgeId_details = KnowledgeDBController.get_knowledge_by_id(
                knowledge_id=kb_id, db=db
            )
            datasourceid = knowledgeId_details.get("data_source_id")
            s3_folder_uri = knowledgeId_details.get("s3_uri")
            knowledgeBaseId = knowledgeId_details.get("knowledge_base_id")

            # Perform retrieval
            response = bedrock_agent_runtime_client.retrieve(
                retrievalQuery={"text": query},
                knowledgeBaseId=knowledgeBaseId,
                retrievalConfiguration={
                    "vectorSearchConfiguration": {
                        "numberOfResults": k_near_chunks,
                        "filter": {
                            "orAll": [
                                {
                                    "startsWith": {
                                        "key": "x-amz-bedrock-kb-source-uri",
                                        "value": s3_folder_uri,
                                    }
                                },
                                {
                                    "equals": {
                                        "key": "x-amz-bedrock-kb-data-source-id",
                                        "value": datasourceid,
                                    }
                                },
                            ]
                        },
                    }
                },
            )

            # Process results using simplified logic from working example
            processed_content = process_knowledge_base_results(
                response["retrievalResults"]
            )

            return processed_content

        except Exception as e:
            logger.error(f"Error in AWSBedrockEmbeddingsSearch.answer_query: {e}")
            raise ExternalAPIError(
                error_message="Failed to retrieve data from AWS Bedrock Embeddings Search."
            )

    @staticmethod
    def delete_knowledge_base(knowledge_base_id: str):
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-agent",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-agent",
                    region_name=CONFIG.AWS_REGION,
                )

            response = bedrock_agent_runtime_client.delete_knowledge_base(
                knowledgeBaseId=knowledge_base_id
            )

            return response
        except Exception as e:
            logger.error(f"Error deleting knowledge base: {e}")
            raise


class AWSBedrockGuardrails:
    def all_filters_none(filters):
        try:
            return all(filter.get("strength") == "NONE" for filter in filters)
        except Exception as e:
            logger.error(f"Error checking filter strength: {e}")
            return False

    @staticmethod
    def list_bedrock_guardrails():
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                )
            response = bedrock_agent_runtime_client.list_guardrails()
            return response
        except Exception as e:
            logger.error(f"{e=}")
            raise e

    def number_duplicate_placeholders_pii(response):
        try:
            text = response["outputs"][0]["text"]
            counters = {}

            mappings = response.get("masked_mappings", {})
            value_to_key = {}

            pii_entities = response["assessments"][0]["sensitiveInformationPolicy"][
                "piiEntities"
            ]

            for entity in pii_entities:
                entity_type = entity["type"]
                original_value = entity["match"]

                if original_value in value_to_key:
                    existing_key = value_to_key[original_value]
                    mappings[existing_key] = {
                        "original_value": original_value,
                        "type": entity_type,
                    }
                else:
                    if entity_type not in counters:
                        counters[entity_type] = 1

                    new_key = f"{{{entity_type}_{counters[entity_type]}}}"
                    mappings[new_key] = {
                        "original_value": original_value,
                        "type": entity_type,
                    }
                    value_to_key[original_value] = new_key
                    counters[entity_type] += 1

            for entity in pii_entities:
                original_value = entity["match"]
                key_to_use = value_to_key[original_value]
                text = text.replace(f"{{{entity['type']}}}", key_to_use, 1)

            response["outputs"][0]["aws_response_text_formatted"] = text
            response["masked_mappings"] = mappings
            return response

        except Exception as e:
            logger.error(f"Error numbering placeholders: {e}")
            return response

    def number_duplicate_placeholders_custom_words(response):
        try:
            text = response["outputs"][0]["original_input_text"]
            word_counter = {}
            mappings = {}
            counter = 1

            custom_words = response["assessments"][0]["wordPolicy"]["customWords"]

            for word in custom_words:
                match_word = word["match"]
                if match_word not in word_counter:
                    word_counter[match_word] = counter
                    counter += 1

            for word in custom_words:
                match_word = word["match"]
                number = word_counter[match_word]
                redacted_key = f"{{REDACTED_NAME_{number}}}"

                mappings[redacted_key] = {
                    "original_value": match_word,
                    "type": "CUSTOM_WORD",
                }

                text = text.replace(match_word, redacted_key)

            response["outputs"][0]["custom_words_formatted_response"] = text
            response["masked_mappings"] = mappings
            return response

        except Exception as e:
            logger.error(f"Error processing custom words: {e}")
            return response

    #### TO CHECK FOR BOTH CASES
    def number_duplicate_placeholders_custom_words_both_cases(response):
        try:
            text = response["outputs"][0]["original_input_text"]
            word_counter = {}
            mappings = {}
            counter = 1

            custom_words = response["assessments"][0]["wordPolicy"]["customWords"]
            for word in custom_words:
                match_word = word["match"]
                match_word_lower = match_word.lower()
                if match_word_lower not in word_counter:
                    word_counter[match_word_lower] = {
                        "number": counter,
                        "original_case": match_word,
                    }
                    counter += 1

            for word in custom_words:
                match_word = word["match"]
                match_word_lower = match_word.lower()
                number = word_counter[match_word_lower]["number"]
                first_occurrence = word_counter[match_word_lower]["original_case"]
                redacted_key = f"{{REDACTED_NAME_{number}}}"

                mappings[redacted_key] = {
                    "original_value": first_occurrence,
                    "type": "CUSTOM_WORD",
                }

                pattern = re.compile(re.escape(match_word), re.IGNORECASE)
                text = pattern.sub(redacted_key, text)

            response["outputs"][0]["custom_words_formatted_response"] = text
            response["masked_mappings"] = mappings
            return response

        except Exception as e:
            logger.error(f"Error processing custom words: {e}")
            return response

    def unmask_placeholders_for_streaming(response):
        """Process streaming placeholders by maintaining a buffer across chunks until complete."""
        try:
            # Initialize buffer if not present
            if not hasattr(
                AWSBedrockGuardrails.unmask_placeholders_for_streaming, "buffer"
            ):
                AWSBedrockGuardrails.unmask_placeholders_for_streaming.buffer = ""

            text = response.get("text", "")
            mappings = response.get("masked_mappings", {})

            if not text or not mappings:
                return response

            # Always add new text to buffer
            buffer = (
                AWSBedrockGuardrails.unmask_placeholders_for_streaming.buffer + text
            )

            # Process buffer to look for complete placeholders
            result = ""
            position = 0

            while position < len(buffer):
                # Find open brace
                open_brace = buffer.find("{", position)
                if open_brace == -1:
                    # No opening brace, add remaining text to result
                    result += buffer[position:]
                    buffer = ""
                    break

                # Add text before the opening brace to result
                result += buffer[position:open_brace]

                # Find closing brace after the opening position
                close_brace = buffer.find("}", open_brace)
                if close_brace == -1:
                    # No closing brace yet, keep collecting
                    buffer = buffer[open_brace:]
                    break

                # Found a complete placeholder pattern
                potential_placeholder = buffer[open_brace : close_brace + 1]

                # Check if it's in our mappings
                if potential_placeholder in mappings:
                    # Replace with original value
                    result += mappings[potential_placeholder]["original_value"]
                else:
                    # Not a valid replacement, keep as is
                    result += potential_placeholder

                position = close_brace + 1

            # Save remaining buffer for next call
            if position < len(buffer):
                AWSBedrockGuardrails.unmask_placeholders_for_streaming.buffer = buffer[
                    position:
                ]
            else:
                AWSBedrockGuardrails.unmask_placeholders_for_streaming.buffer = ""

            # Update response with the processed text
            response["sanitized_output"] = result
            response["text"] = result
            return response
        except Exception as e:
            logger.error(f"Error unmasking streaming placeholders: {e}")
            return response

    def unmask_placeholders(response):
        try:
            text = response["text"]

            logger.debug(f"{text=}")
            mappings = response.get("masked_mappings", {})

            logger.debug(f"{mappings=}")

            for key, value_dict in mappings.items():
                if key in text:
                    text = text.replace(key, value_dict["original_value"])

            response["sanitized_output"] = text
            return response

        except Exception as e:
            logger.error(f"Error unmasking placeholders: {e}")
            return response

    @staticmethod
    def test_bedrock_guardrails(input_text: str, g_id):
        try:
            data = {
                "text": {
                    "text": input_text,
                }
            }

            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                )

            response = bedrock_agent_runtime_client.apply_guardrail(
                guardrailIdentifier=g_id,
                guardrailVersion="DRAFT",
                source="OUTPUT",
                content=[
                    data,
                ],
            )

            logger.debug(f"{response=}")
            response["outputs"][0]["original_input_text"] = input_text
            if response["action"] == "GUARDRAIL_INTERVENED":
                for i in response["assessments"][0]:
                    if i == "wordPolicy":
                        if response["assessments"][0]["wordPolicy"]["customWords"]:
                            new_response = AWSBedrockGuardrails.number_duplicate_placeholders_custom_words_both_cases(
                                response
                            )
                            masking_info = new_response.get("masked_mappings", {})
                            logger.debug(f"{masking_info=}")
                            newtext = new_response.get("outputs")[0][
                                "custom_words_formatted_response"
                            ]
                            response["sanitized_prompt"] = new_response.get("outputs")[
                                0
                            ]["custom_words_formatted_response"]
                            response["text"] = new_response.get("outputs")[0][
                                "custom_words_formatted_response"
                            ]

                            logger.debug(f"{newtext=}")

                            second_grs_call = (
                                bedrock_agent_runtime_client.apply_guardrail(
                                    guardrailIdentifier=g_id,
                                    guardrailVersion="DRAFT",
                                    source="OUTPUT",
                                    content=[
                                        {
                                            "text": {
                                                "text": newtext,
                                            }
                                        },
                                    ],
                                )
                            )
                            logger.debug(f"{second_grs_call=}")

                            if (
                                second_grs_call.get("action") == "GUARDRAIL_INTERVENED"
                                and len(second_grs_call["assessments"][0]) > 0
                                and "sensitiveInformationPolicy"
                                in second_grs_call["assessments"][0]
                            ):
                                logger.debug("SECOND GUARDRAIL INTERVENED")
                                response["outputs"][0]["second_grs_Call"] = (
                                    second_grs_call["outputs"][0]["text"]
                                )
                                second_grs_call["masked_mappings"] = masking_info
                                final_response = AWSBedrockGuardrails.number_duplicate_placeholders_pii(
                                    second_grs_call
                                )

                                logger.debug(f"{final_response=}")

                                response["sanitized_prompt"] = final_response.get(
                                    "outputs"
                                )[0]["aws_response_text_formatted"]
                                response["masked_mappings"] = final_response.get(
                                    "masked_mappings", {}
                                )
                                response["text"] = final_response.get("outputs")[0][
                                    "aws_response_text_formatted"
                                ]
                                response["assessments"].append(
                                    second_grs_call["assessments"][0]
                                )

                                logger.debug("RESPONSE")
                                logger.debug(f"{response=}")

                    if i == "sensitiveInformationPolicy":
                        if response["assessments"][0]["sensitiveInformationPolicy"][
                            "piiEntities"
                        ]:
                            new_response = (
                                AWSBedrockGuardrails.number_duplicate_placeholders_pii(
                                    response
                                )
                            )

                            response["sanitized_prompt"] = new_response.get("outputs")[
                                0
                            ]["aws_response_text_formatted"]
                            response["masked_mappings"] = new_response.get(
                                "masked_mappings", {}
                            )
                            response["text"] = new_response.get("outputs")[0][
                                "aws_response_text_formatted"
                            ]

                logger.debug(f"{response=}")

                logger.debug("UNMASKING")

                reponse = AWSBedrockGuardrails.unmask_placeholders(response)

                return reponse
            return response
        except Exception as e:
            logger.error(f"{e=}")

    @staticmethod
    def bedrock_guardrails_input(
        input_text: str,
        g_id: str,
        service_name: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            data = {
                "text": {
                    "text": input_text,
                }
            }

            create_apilog = ActivityDBController.create_apilog_activity(
                apitype="LLM-Guard-Analyze-Prompt-Input-" + service_name,
                requestbody=data,
                db=db,
            )
            logger.debug(f"{create_apilog=}")

            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                )

            response = bedrock_agent_runtime_client.apply_guardrail(
                guardrailIdentifier=g_id,
                guardrailVersion="DRAFT",
                source="OUTPUT",
                content=[
                    data,
                ],
            )
            if not response["outputs"]:
                response["outputs"] = [{}]

            response["outputs"][0]["original_input_text"] = input_text

            logger.info(f"{response=}")

            status_code = response.get("ResponseMetadata").get("HTTPStatusCode")

            if status_code != 200:
                overallstatus = OverallStatus.FAILED.value
            else:
                overallstatus = OverallStatus.SUCCESS.value

            apilog_details = ActivityDBController.get_apilog_by_id(create_apilog[0], db)

            if status_code != 200:
                logger.error(f"{status_code=}")
                logger.error(f"{data=}")
                logger.error(f"{response=}")
                if (
                    apilog_details.get("updated_at") is None
                    and apilog_details.get("response_body") is None
                ):
                    overallstatus = OverallStatus.FAILED.value
                    update_apilog = ActivityDBController.update_apilog_activity(
                        id=create_apilog[0],
                        responsebody=json.dumps(response),
                        responsestatuscode=500,
                        overallstatus=overallstatus,
                        db=db,
                    )
                    logger.debug(f"{update_apilog=}")
                raise ExternalAPIError(error_message="LLM Guard validation failed!")
            else:
                action_taken = response.get("action")
                logger.debug(f"{action_taken=}")
                if action_taken == "GUARDRAIL_INTERVENED":
                    for i in response["assessments"][0]:
                        if i == "contentPolicy":
                            if (
                                apilog_details.get("updated_at") is None
                                and apilog_details.get("response_body") is None
                            ):
                                overallstatus = OverallStatus.FAILED.value
                                update_apilog = (
                                    ActivityDBController.update_apilog_activity(
                                        id=create_apilog[0],
                                        responsebody=json.dumps(response),
                                        responsestatuscode=500,
                                        overallstatus=overallstatus,
                                        db=db,
                                    )
                                )
                            filters = response["assessments"][0]["contentPolicy"][
                                "filters"
                            ]
                            filter_types = [f["type"].lower() for f in filters]
                            message = (
                                "LLM Guard validation failed due to violation of "
                                + " and ".join(filter_types)
                                + " content present in the user input."
                            )
                            raise ExternalAPIError(
                                error_message=message,
                            )

                        if i == "wordPolicy":
                            if response["assessments"][0]["wordPolicy"]["customWords"]:
                                custom_words_formatted_response = AWSBedrockGuardrails.number_duplicate_placeholders_custom_words_both_cases(
                                    response
                                )
                                masking_info = custom_words_formatted_response.get(
                                    "masked_mappings", {}
                                )
                                logger.debug(f"{masking_info=}")
                                custom_words_formatted_response_text = (
                                    custom_words_formatted_response.get("outputs")[0][
                                        "custom_words_formatted_response"
                                    ]
                                )

                                response["sanitized_prompt"] = (
                                    custom_words_formatted_response.get("outputs")[0][
                                        "custom_words_formatted_response"
                                    ]
                                )

                                logger.info(f"{custom_words_formatted_response_text=}")

                                call_guardrail_for_pii = bedrock_agent_runtime_client.apply_guardrail(
                                    guardrailIdentifier=g_id,
                                    guardrailVersion="DRAFT",
                                    source="OUTPUT",
                                    content=[
                                        {
                                            "text": {
                                                "text": custom_words_formatted_response_text,
                                            }
                                        },
                                    ],
                                )
                                logger.info(f"{call_guardrail_for_pii=}")

                                if (
                                    call_guardrail_for_pii.get("action")
                                    == "GUARDRAIL_INTERVENED"
                                    and len(call_guardrail_for_pii["assessments"][0])
                                    > 0
                                    and "sensitiveInformationPolicy"
                                    in call_guardrail_for_pii["assessments"][0]
                                ):
                                    logger.info("SECOND PII GUARDRAIL INTERVENED")

                                    response["outputs"][0]["call_guardrail_for_pii"] = (
                                        call_guardrail_for_pii["outputs"][0]["text"]
                                    )
                                    call_guardrail_for_pii["masked_mappings"] = (
                                        masking_info
                                    )
                                    pii_and_custom_words_masked_response = AWSBedrockGuardrails.number_duplicate_placeholders_pii(
                                        call_guardrail_for_pii
                                    )

                                    logger.info(
                                        f"{pii_and_custom_words_masked_response=}"
                                    )

                                    response["sanitized_prompt"] = (
                                        pii_and_custom_words_masked_response.get(
                                            "outputs"
                                        )[0]["aws_response_text_formatted"]
                                    )
                                    response["masked_mappings"] = (
                                        pii_and_custom_words_masked_response.get(
                                            "masked_mappings", {}
                                        )
                                    )
                                    response["assessments"].append(
                                        call_guardrail_for_pii["assessments"][0]
                                    )

                                    logger.info(f"{response=}")

                        if i == "sensitiveInformationPolicy":
                            if response["assessments"][0]["sensitiveInformationPolicy"][
                                "piiEntities"
                            ]:
                                new_response = AWSBedrockGuardrails.number_duplicate_placeholders_pii(
                                    response
                                )

                                response["sanitized_prompt"] = new_response.get(
                                    "outputs"
                                )[0]["aws_response_text_formatted"]
                                response["masked_mappings"] = new_response.get(
                                    "masked_mappings", {}
                                )

                    if (
                        apilog_details.get("updated_at") is None
                        and apilog_details.get("response_body") is None
                    ):
                        update_apilog = ActivityDBController.update_apilog_activity(
                            id=create_apilog[0],
                            responsebody=json.dumps(response),
                            responsestatuscode=status_code,
                            overallstatus=overallstatus,
                            db=db,
                        )

                    return response
                if action_taken == "NONE":
                    response["sanitized_prompt"] = input_text
                    response_message = """NO action taken from AWS Guardrails."""
                    response["response_message"] = response_message

                    if (
                        apilog_details.get("updated_at") is None
                        and apilog_details.get("response_body") is None
                    ):
                        update_apilog = ActivityDBController.update_apilog_activity(
                            id=create_apilog[0],
                            responsebody=json.dumps(response),
                            responsestatuscode=status_code,
                            overallstatus=overallstatus,
                            db=db,
                        )
                    return response
                return response

        except Exception as e:
            logger.error(f"{e=}")
            apilog_details = ActivityDBController.get_apilog_by_id(create_apilog[0], db)
            if (
                apilog_details.get("updated_at") is None
                and apilog_details.get("response_body") is None
            ):
                overallstatus = OverallStatus.FAILED.value
                responsebody = {"error": repr(e)}
                update_apilog = ActivityDBController.update_apilog_activity(
                    id=create_apilog[0],
                    responsebody=json.dumps(responsebody),
                    responsestatuscode=500,
                    overallstatus=overallstatus,
                    db=db,
                )
            raise e

    @staticmethod
    def bedrock_guardrails_output(
        input_text: str,
        g_id: str,
        service_name: str,
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            data = {
                "text": {
                    "text": input_text,
                }
            }

            create_apilog = ActivityDBController.create_apilog_activity(
                apitype="LLM-Guard-Analyze-Prompt-Input-" + service_name,
                requestbody=data,
                db=db,
            )
            logger.debug(f"{create_apilog=}")

            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock-runtime",
                    region_name=CONFIG.AWS_REGION,
                )

            response = bedrock_agent_runtime_client.apply_guardrail(
                guardrailIdentifier=g_id,
                guardrailVersion="DRAFT",
                source="OUTPUT",
                content=[
                    data,
                ],
            )

            logger.info(f"{response=}")
            status_code = response.get("ResponseMetadata").get("HTTPStatusCode")

            if status_code != 200:
                overallstatus = OverallStatus.FAILED.value
            else:
                overallstatus = OverallStatus.SUCCESS.value

            update_apilog = ActivityDBController.update_apilog_activity(
                id=create_apilog[0],
                responsebody=json.dumps(response),
                responsestatuscode=status_code,
                overallstatus=overallstatus,
                db=db,
            )

            logger.debug(f"{update_apilog=}")

            if status_code != 200:
                logger.error(f"{status_code=}")
                logger.error(f"{data=}")
                logger.error(f"{response=}")
                raise ExternalAPIError(error_message="LLM Guard validation failed!")
            else:
                action_taken = response.get("action")
                logger.info(f"{action_taken=}")
                if action_taken == "GUARDRAIL_INTERVENED":
                    new_response = (
                        AWSBedrockGuardrails.number_duplicate_placeholders_pii(response)
                    )
                    response["sanitized_output"] = new_response.get("outputs")[0][
                        "text"
                    ]
                    response["masked_mappings"] = new_response.get(
                        "masked_mappings", {}
                    )
                    return response
                if action_taken == "NONE":
                    response_message = """NO action taken from AWS Guardrails."""
                    logger.info(f"{response_message=}")
                    response["response_message"] = response_message
                    return response
                return response

        except Exception as e:
            logger.error(f"{e=}")
            apilog_details = ActivityDBController.get_apilog_by_id(create_apilog[0], db)
            if (
                apilog_details.get("updated_at") is None
                and apilog_details.get("response_body") is None
            ):
                overallstatus = OverallStatus.FAILED.value
                responsebody = {"error": repr(e)}
                update_apilog = ActivityDBController.update_apilog_activity(
                    id=create_apilog[0],
                    responsebody=json.dumps(responsebody),
                    responsestatuscode=500,
                    overallstatus=overallstatus,
                    db=db,
                )
            raise e

    @staticmethod
    def create_bedrock_guardrails(
        grs_name: str = None,
        pii_types: List[PIIEntityType] = [],
        action_taken: str = "ANONYMIZE",
        word_to_block: list[str] = [],
        content_policy_filter: list = [],
    ):
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                )

            # Base parameters
            guardrail_params = {
                "name": grs_name,
                "description": grs_name,
                "blockedInputMessaging": "Input prompt Blocked due to guardrail intervention",
                "blockedOutputsMessaging": "Output response is Blocked due to guardrail intervention",
            }

            # Add PII config if present
            if len(pii_types) > 0:
                pii_config = [
                    {"type": pii.value, "action": action_taken} for pii in pii_types
                ]
                guardrail_params["sensitiveInformationPolicyConfig"] = {
                    "piiEntitiesConfig": pii_config
                }

            # Add word policy config
            word_policy_config = {"managedWordListsConfig": [{"type": "PROFANITY"}]}
            if len(word_to_block) > 0:
                word_policy_config["wordsConfig"] = [
                    {"text": word} for word in word_to_block
                ]
            guardrail_params["wordPolicyConfig"] = word_policy_config

            # Add content policy config if present
            if len(content_policy_filter) > 0:
                check_filters = AWSBedrockGuardrails.all_filters_none(
                    content_policy_filter
                )
                logger.debug(f"{check_filters=}")
                if not check_filters:
                    content_filter_config = [
                        {
                            "inputStrength": filter.get("strength"),
                            "outputStrength": filter.get("strength"),
                            "type": filter.get("type"),
                        }
                        for filter in content_policy_filter
                    ]
                    guardrail_params["contentPolicyConfig"] = {
                        "filtersConfig": content_filter_config
                    }

            logger.debug(f"{guardrail_params=}")

            response = bedrock_agent_runtime_client.create_guardrail(**guardrail_params)
            logger.debug(f"{response=}")
            return response, guardrail_params

        except Exception as e:
            logger.error(f"{e=}")

            raise e

    @staticmethod
    def delete_aws__guardrails(
        guardrail_id: str = None,
    ):
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                )
            if guardrail_id:
                response = bedrock_agent_runtime_client.delete_guardrail(
                    guardrailIdentifier=guardrail_id,
                )
                logger.info("Guardrail deleted successfully")
                return response
            else:
                logger.error("Error deleting guardrail")
                return None

        except Exception as e:
            logger.error(f"{e=}")

            raise e

    @staticmethod
    def update_aws__guardrails(
        guardrail_name: str = None,
        guardrail_id: str = None,
        pii_types: List[PIIEntityType] = [],
        action_taken: str = "ANONYMIZE",
        word_to_block: list[str] = [],
        content_policy_filter: list = [],
        db: psycopg2.extensions.connection = Depends(get_db_connection),
    ):
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                )
            if guardrail_id:
                # Base parameters
                guardrail_params = {
                    "name": guardrail_name,
                    "blockedInputMessaging": "Input prompt Blocked due to guardrail intervention",
                    "blockedOutputsMessaging": "Output response is Blocked due to guardrail intervention",
                    "guardrailIdentifier": guardrail_id,
                }

                # Add PII config if present
                if len(pii_types) > 0:
                    pii_config = [
                        {"type": pii.value, "action": action_taken} for pii in pii_types
                    ]
                    guardrail_params["sensitiveInformationPolicyConfig"] = {
                        "piiEntitiesConfig": pii_config
                    }

                # Add word policy config
                word_policy_config = {"managedWordListsConfig": [{"type": "PROFANITY"}]}
                if len(word_to_block) > 0:
                    word_policy_config["wordsConfig"] = [
                        {"text": word} for word in word_to_block
                    ]
                guardrail_params["wordPolicyConfig"] = word_policy_config

                # Add content policy config if present
                if len(content_policy_filter) > 0:
                    check_filters = AWSBedrockGuardrails.all_filters_none(
                        content_policy_filter
                    )
                    logger.debug(f"{check_filters=}")
                    if not check_filters:
                        content_filter_config = [
                            {
                                "inputStrength": filter.get("strength"),
                                "outputStrength": filter.get("strength"),
                                "type": filter.get("type"),
                            }
                            for filter in content_policy_filter
                        ]
                        guardrail_params["contentPolicyConfig"] = {
                            "filtersConfig": content_filter_config
                        }

                logger.debug(f"{guardrail_params=}")

                response = bedrock_agent_runtime_client.update_guardrail(
                    **guardrail_params
                )
                logger.debug(f"{response=}")
                return response, guardrail_params
            else:
                logger.error("Error deleting guardrail")
                return None

        except Exception as e:
            logger.error(f"{e=}")

            raise e

    def aws_grs_name_check(name: str) -> bool:
        """
        Validates if a string matches AWS naming pattern [0-9a-zA-Z-_]+

        Args:
            name (str): String to validate

        Returns:
            bool: True if valid, False otherwise
        """
        try:
            pattern = r"^[0-9a-zA-Z-_]+$"
            return bool(re.match(pattern, name))
        except Exception as e:
            logger.error(f"Error validating AWS name: {e}")
            return False

    def get_guardrail_scanners_by_id(guardrail_id: str):
        try:
            if CONFIG.LOCAL_TESTING:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                    aws_access_key_id=CONFIG.AWS_ACCESS_KEY,
                    aws_secret_access_key=CONFIG.AWS_SECRET_KEY,
                )
            else:
                bedrock_agent_runtime_client = boto3.client(
                    "bedrock",
                    region_name=CONFIG.AWS_REGION,
                )
            response = bedrock_agent_runtime_client.get_guardrail(
                guardrailIdentifier=guardrail_id,
            )
            return response
        except Exception as e:
            logger.error(f"{e=}")
            raise e
