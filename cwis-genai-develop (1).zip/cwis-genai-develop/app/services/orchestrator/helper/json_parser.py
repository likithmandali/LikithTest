import re


def convert_quotes(input_string):
    # Regular expression pattern to match JSON-like objects
    json_pattern = r"{.*?}"

    def process_match(match):
        json_string = match.group(0)
        # Replace double quotes with single quotes
        return json_string.replace('"', "'")

    # Use re.sub to find and replace JSON-like objects
    replaced_string = re.sub(json_pattern, process_match, input_string)

    # Replace any remaining double quotes outside JSON objects
    final_replaced_string = replaced_string.replace('"', "'")

    return final_replaced_string


def flatten_dict(d, parent_key="", sep="_"):
    """
    Flatten a nested dictionary.

    Parameters:
    - d: The input dictionary.
    - parent_key: The key of the parent dictionary (used for recursion).
    - sep: Separator to use between keys.

    Returns:
    - A flattened dictionary.
    """
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)
