import asyncio
import re
from enum import Enum
from typing import Union, Dict, Any
from pydantic import BaseModel
import tiktoken
from settings.loguru import logger
from settings.config import CONFIG
from api.schemas.aws.submit import AWSBedrockModel
from api.controllers.aws.aws_bedrock_controller import (
    BedrockRuntimeInvoker,
    # BulkBedrockRuntimeInvoker,
)


class RoleEnum(str, Enum):
    User = "user"
    Assistant = "assistant"
    System = "system"


class TokenLimit(Enum):
    CLAUDE_V2_100K: int = 100000
    CLAUDE_V2_1_200K: int = 200000
    TITAN_V1_TEXT_EMBED_8K: int = 8000
    TITAN_TEXT_G1_PREMIER: int = 32000
    TITAN_TEXT_G1_EXPRESS: int = 8000
    TITAN_TEXT_LITE: int = 4000

    TITAN_MULTIMODAL_EMBED_V1: int = 8000
    AWS_JAMBA_15_MINI: int = 256000
    AWS_JAMBA_15_LARGE: int = 256000
    AWS_CLAUDE_V35_SONNET: int = 200000
    AWS_CLAUDE_V37_SONNET: int = 128000
    AWS_CLAUDE_V4_SONNET: int = 128000
    AWS_LLAMA_32_1B_INSTRUCT: int = 128000
    AWS_LLAMA_32_3B_INSTRUCT: int = 128000
    AWS_LLAMA_32_11B_VISION_INSTRUCT: int = 128000  # Supports images
    AWS_LLAMA_32_90B_VISION_INSTRUCT: int = 128000  # Supports images
    AWS_MIXTRAL_7B_INSTRUCT: int = 32000
    AWS_MIXTRAL_8x_7B_INSTRUCT: int = 32000
    AWS_MIXTRAL_LARGE_2402: int = 32000
    AWS_MIXTRAL_SMALL_2402: int = 32000


class Message(BaseModel):
    role: RoleEnum
    content: str


def tokenizer(input_str: str, model: str = "amazon.titan-text-express-v1"):
    """
    Tokenize input string for AWS Bedrock models.
    Note: Different models may have different tokenization schemes.
    Using cl100k_base encoding as a reasonable approximation for most models.
    """
    # Use cl100k_base encoding which is more suitable for modern models
    # than text-davinci-003 encoding
    try:
        encoding = tiktoken.get_encoding("cl100k_base")
    except Exception as e:
        logger.warning(f"Failed to load tiktoken encoding, falling back to character-based approximation: {e}")
        # Fallback: Use simple character-based approximation (roughly 4 chars per token)
        return len(input_str) // 4
    
    encoded = encoding.encode(input_str)
    return len(encoded)


class AWSBedrockCaller:
    @staticmethod
    def check_token_limit(
        messages: Union[list[Message], list[Dict[str, Any]]],
        model: str = "amazon.titan-text-express-v1",
    ):
        # Extract content from messages, handling multiple formats and counting both text and image tokens
        total_token_count = 0
        text_tokens = 0
        image_tokens = 0
        image_count = 0
        
        for msg in messages:
            if isinstance(msg, dict):
                # Handle dictionary format
                content = msg.get('content', '')
                
                # Check if content is a list (Claude message format with content parts)
                if isinstance(content, list):
                    # Process each content part separately
                    for part in content:
                        if isinstance(part, dict):
                            part_type = part.get('type', '')
                            
                            if part_type == 'text':
                                # Count tokens for text content
                                text_content = part.get('text', '')
                                part_tokens = tokenizer(text_content, model)
                                text_tokens += part_tokens
                                total_token_count += part_tokens
                            
                            elif part_type == 'image':
                                # Estimate tokens for image content
                                part_image_tokens = AWSBedrockCaller._estimate_image_tokens(part, model)
                                image_tokens += part_image_tokens
                                total_token_count += part_image_tokens
                                image_count += 1
                else:
                    # Handle simple string content
                    part_tokens = tokenizer(str(content), model)
                    text_tokens += part_tokens
                    total_token_count += part_tokens
            else:
                # Handle Pydantic Message object format
                part_tokens = tokenizer(msg.content, model)
                text_tokens += part_tokens
                total_token_count += part_tokens
        
        # Log token breakdown for debugging
        logger.debug(f"Token count breakdown - Text: {text_tokens}, Images: {image_tokens} ({image_count} images), Total: {total_token_count}")
        
        match model:
            case "anthropic.claude-v2":
                token_limit = TokenLimit.CLAUDE_V2_100K.value
            case "anthropic.claude-v2:1":
                token_limit = TokenLimit.CLAUDE_V2_1_200K.value
            case "amazon.titan-embed-text-v1":
                token_limit = TokenLimit.TITAN_V1_TEXT_EMBED_8K.value
            case "amazon.titan-text-express-v1" | "amazon.titan-text-express-v1:0":
                token_limit = TokenLimit.TITAN_TEXT_G1_EXPRESS.value
            case "amazon.titan-text-premier-v1:0":
                token_limit = TokenLimit.TITAN_TEXT_G1_PREMIER.value
            case "amazon.titan-text-lite-v1" | "amazon.titan-text-lite-v1:0":
                token_limit = TokenLimit.TITAN_TEXT_LITE.value
            case "amazon.titan-embed-image-v1":
                token_limit = TokenLimit.TITAN_MULTIMODAL_EMBED_V1.value
            case "ai21.jamba-1-5-mini-v1:0":
                token_limit = TokenLimit.AWS_JAMBA_15_MINI.value
            case "ai21.jamba-1-5-large-v1:0":
                token_limit = TokenLimit.AWS_JAMBA_15_LARGE.value
            case "us.anthropic.claude-3-5-sonnet-20240620-v1:0":
                token_limit = TokenLimit.AWS_CLAUDE_V35_SONNET.value
            case "us.anthropic.claude-3-5-sonnet-20241022-v2:0":
                token_limit = TokenLimit.AWS_CLAUDE_V35_SONNET.value
            case "us.anthropic.claude-3-7-sonnet-20250219-v1:0":
                token_limit = TokenLimit.AWS_CLAUDE_V37_SONNET.value
            case "us.anthropic.claude-sonnet-4-20250514-v1:0":
                token_limit = TokenLimit.AWS_CLAUDE_V4_SONNET.value
            case _ if model == f"arn:aws:bedrock:{CONFIG.AWS_REGION}:{CONFIG.AWS_ACCOUNT_ID}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0":
                token_limit = TokenLimit.AWS_CLAUDE_V4_SONNET.value
            case "us.meta.llama3-2-1b-instruct-v1:0":
                token_limit = TokenLimit.AWS_LLAMA_32_1B_INSTRUCT.value
            case "us.meta.llama3-2-3b-instruct-v1:0":
                token_limit = TokenLimit.AWS_LLAMA_32_3B_INSTRUCT.value
            case "us.meta.llama3-2-11b-instruct-v1:0":
                token_limit = TokenLimit.AWS_LLAMA_32_11B_VISION_INSTRUCT.value
            case "us.meta.llama3-2-90b-instruct-v1:0":
                token_limit = TokenLimit.AWS_LLAMA_32_90B_VISION_INSTRUCT.value
            case "mistral.mistral-7b-instruct-v0:2":
                token_limit = TokenLimit.AWS_MIXTRAL_7B_INSTRUCT.value
            case "mistral.mixtral-8x7b-instruct-v0:1":
                token_limit = TokenLimit.AWS_MIXTRAL_8x_7B_INSTRUCT.value
            case "mistral.mistral-large-2402-v1:0":
                token_limit = TokenLimit.AWS_MIXTRAL_LARGE_2402.value
            case "mistral.mistral-small-2402-v1:0":
                token_limit = TokenLimit.AWS_MIXTRAL_SMALL_2402.value
            case _:
                raise AttributeError("Invalid model provided!")
        
        return total_token_count <= token_limit

    @staticmethod
    def regular(
        messages: list[Message],
        model_id: str,
        temperature: float = 0.5,
        system_prompt: str | None = None,
    ):
        try:
            completion = BedrockRuntimeInvoker.messages_api_invoke(
                message=messages,
                temperature=temperature,
                model_id=model_id,
                system_prompt=system_prompt,
            )

            return completion

        except Exception as err:
            logger.error(err.__str__(), exc_info=True)
            raise err



    @staticmethod
    async def message_stream(
        message: list[Message],
        temperature: float,
        model_id: str,
        system_prompt: str | None = None,
    ):
        try:
            async for chunks in BedrockRuntimeInvoker.messages_api_invoke_stream(
                message=message,
                temperature=temperature,
                model_id=model_id,
                system_prompt=system_prompt,
            ):
                await asyncio.sleep(0.01)
                yield chunks

        except Exception as err:
            raise err

    @staticmethod
    def enhance_model_template(promp_template: str):
        try:
            matches = re.finditer(r"{{(.*?)}}", promp_template)
            for match in matches:
                logger.debug(f"matching groups - {match.groups()}")

                if match.groups()[0] == "input_text":
                    text_user_query = (
                        "<question>{{" + match.groups()[0] + "}}</question>"
                    )
                    promp_template = promp_template.replace(
                        "{{" + match.groups()[0] + "}}", text_user_query
                    )

                elif "knowledgeid" in match.groups()[0]:
                    text_knowledge_query = (
                        "<context>{{" + match.groups()[0] + "}}</context>"
                    )
                    promp_template = promp_template.replace(
                        "{{" + match.groups()[0] + "}}", text_knowledge_query
                    )

            return promp_template

        except Exception as err:
            raise err

    @staticmethod
    def TokenPricing(
        input_messages: str = None,
        output_messages: str = None,
        total_pricing: bool = False,
        model: str = "amazon.titan-text-express-v1",
    ):
        match model:
            case "anthropic.claude-v2":
                input_token_pricing = CONFIG.CLAUDE_V2_100K_INPUT_COST
                output_token_pricing = CONFIG.CLAUDE_V2_100K_OUTPUT_COST
            case "anthropic.claude-v2:1":
                input_token_pricing = CONFIG.CLAUDE_V2_1_200K_INPUT_COST
                output_token_pricing = CONFIG.CLAUDE_V2_1_200K_OUTPUT_COST
            case "amazon.titan-embed-text-v1":
                input_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_INPUT_COST
                output_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_OUTPUT_COST
            case "amazon.titan-text-express-v1":
                input_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_INPUT_COST
                output_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_OUTPUT_COST
            case "amazon.titan-text-premier-v1:0":
                input_token_pricing = CONFIG.TITAN_TEXT_G1_PREMIER_INPUT_COST
                output_token_pricing = CONFIG.TITAN_TEXT_G1_PREMIER_OUTPUT_COST
            case "amazon.titan-text-express-v1:0":
                input_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_INPUT_COST
                output_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_OUTPUT_COST
            case "amazon.titan-text-lite-v1":
                input_token_pricing = CONFIG.TITAN_TEXT_LITE_INPUT_COST
                output_token_pricing = CONFIG.TITAN_TEXT_LITE_OUTPUT_COST
            case "amazon.titan-embed-image-v1":
                # For embeddings, we typically don't have separate input/output costs
                # Use the same cost structure as text embeddings
                input_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_INPUT_COST
                output_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_OUTPUT_COST
            case "ai21.jamba-1-5-mini-v1:0":
                input_token_pricing = CONFIG.AWS_JAMBA_15_MINI_INPUT_COST
                output_token_pricing = CONFIG.AWS_JAMBA_15_MINI_OUTPUT_COST
            case "ai21.jamba-1-5-large-v1:0":
                input_token_pricing = CONFIG.AWS_JAMBA_15_LARGE_INPUT_COST
                output_token_pricing = CONFIG.AWS_JAMBA_15_LARGE_OUTPUT_COST
            case "us.anthropic.claude-3-5-sonnet-20240620-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_OUTPUT_COST
            case "us.anthropic.claude-3-5-sonnet-20241022-v2:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_OUTPUT_COST
            case "us.anthropic.claude-3-7-sonnet-20250219-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V37_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V37_SONNET_OUTPUT_COST
            case "us.anthropic.claude-sonnet-4-20250514-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_OUTPUT_COST
            case _ if model == f"arn:aws:bedrock:{CONFIG.AWS_REGION}:{CONFIG.AWS_ACCOUNT_ID}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_OUTPUT_COST
            case "us.meta.llama3-2-1b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_1B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_LLAMA_32_1B_INSTRUCT_OUTPUT_COST
            case "us.meta.llama3-2-3b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_3B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_LLAMA_32_3B_INSTRUCT_OUTPUT_COST
            case "us.meta.llama3-2-11b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_11B_VISION_INSTRUCT_INPUT_COST
                output_token_pricing = (
                    CONFIG.AWS_LLAMA_32_11B_VISION_INSTRUCT_OUTPUT_COST
                )
            case "us.meta.llama3-2-90b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_90B_VISION_INSTRUCT_INPUT_COST
                output_token_pricing = (
                    CONFIG.AWS_LLAMA_32_90B_VISION_INSTRUCT_OUTPUT_COST
                )
            case "mistral.mistral-7b-instruct-v0:2":
                input_token_pricing = CONFIG.AWS_MISTRAL_7B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_MISTRAL_7B_INSTRUCT_OUTPUT_COST
            case "mistral.mixtral-8x7b-instruct-v0:1":
                input_token_pricing = CONFIG.AWS_MIXTRAL_8x_7B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_MIXTRAL_8x_7B_INSTRUCT_OUTPUT_COST
            case "mistral.mistral-large-2402-v1:0":
                input_token_pricing = CONFIG.AWS_MISTRAL_LARGE_2402_INPUT_COST
                output_token_pricing = CONFIG.AWS_MISTRAL_LARGE_2402_OUTPUT_COST
            case "mistral.mistral-small-2402-v1:0":
                input_token_pricing = CONFIG.AWS_MISTRAL_SMALL_2402_INPUT_COST
                output_token_pricing = CONFIG.AWS_MISTRAL_SMALL_2402_OUTPUT_COST
            case _:
                raise AttributeError("Invalid model provided!")
        final_response = {
            "usage": {},
            "price": {},
        }
        token_in_pricing = 0.0
        token_out_pricing = 0.0
        
        if input_messages:
            input_text = f"{input_messages}"
            token_count_in = tokenizer(input_text, model)
            token_in_pricing = token_count_in * input_token_pricing
            final_response["usage"]["input_token_count"] = token_count_in
            final_response["price"]["input_token_price"] = float(
                "{:.5f}".format(token_in_pricing)
            )
        if output_messages:
            token_count_out = tokenizer(output_messages, model)
            token_out_pricing = token_count_out * output_token_pricing
            final_response["usage"]["output_token_count"] = token_count_out
            final_response["price"]["output_token_price"] = float(
                "{:.5f}".format(token_out_pricing)
            )
        if total_pricing:
            final_pricing = token_in_pricing + token_out_pricing
            final_response["total_pricing"] = float("{:.5f}".format(final_pricing))
        return final_response

    @staticmethod
    def TokenPricingWithTokensCount(
        input_tokens: int = None,
        output_tokens: int = None,
        total_pricing: bool = False,
        model: str = "amazon.titan-text-express-v1",
    ):
        match model:
            case "anthropic.claude-v2":
                input_token_pricing = CONFIG.CLAUDE_V2_100K_INPUT_COST
                output_token_pricing = CONFIG.CLAUDE_V2_100K_OUTPUT_COST
            case "anthropic.claude-v2:1":
                input_token_pricing = CONFIG.CLAUDE_V2_1_200K_INPUT_COST
                output_token_pricing = CONFIG.CLAUDE_V2_1_200K_OUTPUT_COST
            case "amazon.titan-embed-text-v1":
                input_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_INPUT_COST
                output_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_OUTPUT_COST
            case "amazon.titan-text-express-v1":
                input_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_INPUT_COST
                output_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_OUTPUT_COST
            case "amazon.titan-embed-image-v1":
                # For embeddings, we typically don't have separate input/output costs
                # Use the same cost structure as text embeddings
                input_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_INPUT_COST
                output_token_pricing = CONFIG.TITAN_V1_TEXT_EMBED_8K_OUTPUT_COST
            case "ai21.jamba-1-5-mini-v1:0":
                input_token_pricing = CONFIG.AWS_JAMBA_15_MINI_INPUT_COST
                output_token_pricing = CONFIG.AWS_JAMBA_15_MINI_OUTPUT_COST
            case "ai21.jamba-1-5-large-v1:0":
                input_token_pricing = CONFIG.AWS_JAMBA_15_LARGE_INPUT_COST
                output_token_pricing = CONFIG.AWS_JAMBA_15_LARGE_OUTPUT_COST
            case "us.anthropic.claude-3-5-sonnet-20240620-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_OUTPUT_COST
            case "us.anthropic.claude-3-5-sonnet-20241022-v2:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_OUTPUT_COST
            case "us.anthropic.claude-3-7-sonnet-20250219-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V37_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V37_SONNET_OUTPUT_COST
            case "us.anthropic.claude-sonnet-4-20250514-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_OUTPUT_COST
            case _ if model == f"arn:aws:bedrock:{CONFIG.AWS_REGION}:{CONFIG.AWS_ACCOUNT_ID}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_OUTPUT_COST
            case "us.meta.llama3-2-1b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_1B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_LLAMA_32_1B_INSTRUCT_OUTPUT_COST
            case "us.meta.llama3-2-3b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_3B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_LLAMA_32_3B_INSTRUCT_OUTPUT_COST
            case "us.meta.llama3-2-11b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_11B_VISION_INSTRUCT_INPUT_COST
                output_token_pricing = (
                    CONFIG.AWS_LLAMA_32_11B_VISION_INSTRUCT_OUTPUT_COST
                )
            case "us.meta.llama3-2-90b-instruct-v1:0":
                input_token_pricing = CONFIG.AWS_LLAMA_32_90B_VISION_INSTRUCT_INPUT_COST
                output_token_pricing = (
                    CONFIG.AWS_LLAMA_32_90B_VISION_INSTRUCT_OUTPUT_COST
                )
            case "mistral.mistral-7b-instruct-v0:2":
                input_token_pricing = CONFIG.AWS_MISTRAL_7B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_MISTRAL_7B_INSTRUCT_OUTPUT_COST
            case "mistral.mixtral-8x7b-instruct-v0:1":
                input_token_pricing = CONFIG.AWS_MIXTRAL_8x_7B_INSTRUCT_INPUT_COST
                output_token_pricing = CONFIG.AWS_MIXTRAL_8x_7B_INSTRUCT_OUTPUT_COST
            case "mistral.mistral-large-2402-v1:0":
                input_token_pricing = CONFIG.AWS_MISTRAL_LARGE_2402_INPUT_COST
                output_token_pricing = CONFIG.AWS_MISTRAL_LARGE_2402_OUTPUT_COST
            case "mistral.mistral-small-2402-v1:0":
                input_token_pricing = CONFIG.AWS_MISTRAL_SMALL_2402_INPUT_COST
                output_token_pricing = CONFIG.AWS_MISTRAL_SMALL_2402_OUTPUT_COST
            case _:
                raise AttributeError("Invalid model provided!")
        final_response = {
            "usage": {},
            "price": {},
        }
        token_in_pricing = 0.0
        token_out_pricing = 0.0
        
        if input_tokens:
            token_in_pricing = input_tokens * input_token_pricing
            final_response["usage"]["input_token_count"] = input_tokens
            final_response["price"]["input_token_price"] = float(
                "{:.5f}".format(token_in_pricing)
            )
        if output_tokens:
            token_out_pricing = output_tokens * output_token_pricing
            final_response["usage"]["output_token_count"] = output_tokens
            final_response["price"]["output_token_price"] = float(
                "{:.5f}".format(token_out_pricing)
            )
        if total_pricing:
            final_pricing = token_in_pricing + token_out_pricing
            final_response["total_pricing"] = float("{:.5f}".format(final_pricing))
        return final_response

    @staticmethod
    def TokenPricingForMessages(
        input_messages: Union[list[Message], list[Dict[str, Any]]] = None,
        output_messages: str = None,
        total_pricing: bool = False,
        model: str = "amazon.titan-text-express-v1",
    ):
        """
        Calculate pricing for message objects (handles both text and image content).
        
        Args:
            input_messages: List of message objects (can contain images)
            output_messages: Output text string
            total_pricing: Whether to calculate total pricing
            model: Model ID
            
        Returns:
            dict: Pricing breakdown including token counts and costs
        """
        # Get pricing rates for the model
        match model:
            case "anthropic.claude-v2":
                input_token_pricing = CONFIG.CLAUDE_V2_100K_INPUT_COST
                output_token_pricing = CONFIG.CLAUDE_V2_100K_OUTPUT_COST
            case "anthropic.claude-v2:1":
                input_token_pricing = CONFIG.CLAUDE_V2_1_200K_INPUT_COST
                output_token_pricing = CONFIG.CLAUDE_V2_1_200K_OUTPUT_COST
            case "us.anthropic.claude-3-5-sonnet-20240620-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_OUTPUT_COST
            case "us.anthropic.claude-3-5-sonnet-20241022-v2:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V35_SONNET_OUTPUT_COST
            case "us.anthropic.claude-3-7-sonnet-20250219-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V37_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V37_SONNET_OUTPUT_COST
            case "us.anthropic.claude-sonnet-4-20250514-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_OUTPUT_COST
            case _ if model == f"arn:aws:bedrock:{CONFIG.AWS_REGION}:{CONFIG.AWS_ACCOUNT_ID}:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0":
                input_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_INPUT_COST
                output_token_pricing = CONFIG.AWS_CLAUDE_V4_SONNET_OUTPUT_COST
            case _:
                # Default to Titan Express for unsupported models
                input_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_INPUT_COST
                output_token_pricing = CONFIG.TITAN_TEXT_G1_EXPRESS_OUTPUT_COST
        
        final_response = {
            "usage": {},
            "price": {},
        }
        token_in_pricing = 0.0
        token_out_pricing = 0.0
        
        if input_messages:
            # Use the same logic as check_token_limit to count tokens accurately
            total_token_count = 0
            text_tokens = 0
            image_tokens = 0
            image_count = 0
            
            for msg in input_messages:
                if isinstance(msg, dict):
                    content = msg.get('content', '')
                    
                    if isinstance(content, list):
                        for part in content:
                            if isinstance(part, dict):
                                part_type = part.get('type', '')
                                
                                if part_type == 'text':
                                    text_content = part.get('text', '')
                                    part_tokens = tokenizer(text_content, model)
                                    text_tokens += part_tokens
                                    total_token_count += part_tokens
                                
                                elif part_type == 'image':
                                    part_image_tokens = AWSBedrockCaller._estimate_image_tokens(part, model)
                                    image_tokens += part_image_tokens
                                    total_token_count += part_image_tokens
                                    image_count += 1
                    else:
                        part_tokens = tokenizer(str(content), model)
                        text_tokens += part_tokens
                        total_token_count += part_tokens
                else:
                    part_tokens = tokenizer(msg.content, model)
                    text_tokens += part_tokens
                    total_token_count += part_tokens
            
            token_in_pricing = total_token_count * input_token_pricing
            final_response["usage"]["input_token_count"] = total_token_count
            final_response["usage"]["input_text_tokens"] = text_tokens
            final_response["usage"]["input_image_tokens"] = image_tokens
            final_response["usage"]["input_image_count"] = image_count
            final_response["price"]["input_token_price"] = float(
                "{:.5f}".format(token_in_pricing)
            )
        
        if output_messages:
            token_count_out = tokenizer(output_messages, model)
            token_out_pricing = token_count_out * output_token_pricing
            final_response["usage"]["output_token_count"] = token_count_out
            final_response["price"]["output_token_price"] = float(
                "{:.5f}".format(token_out_pricing)
            )
        
        if total_pricing:
            final_pricing = token_in_pricing + token_out_pricing
            final_response["total_pricing"] = float("{:.5f}".format(final_pricing))
        
        return final_response

    @staticmethod
    def _estimate_image_tokens(image_part: Dict[str, Any], model: str) -> int:
        """
        Estimate token count for image content based on model specifications.
        
        Args:
            image_part: Image content part from Claude message format
            model: Model ID to determine token calculation method
            
        Returns:
            int: Estimated token count for the image
        """
        # Base image token costs for different model families
        # These are approximations based on AWS documentation
        
        if model.startswith("us.anthropic.claude"):
            # Claude 3.x models: ~1600 tokens per image (base cost)
            # This can vary based on image size and complexity
            return 1600
        
        elif model.startswith("us.meta.llama3-2") and "vision" in model:
            # Llama 3.2 Vision models: estimate based on image size
            # Base cost around 560 tokens for standard images
            return 560
        
        elif model.startswith("amazon.titan") and "embed-image" in model:
            # Titan multimodal embedding models
            return 400
        
        else:
            # For text-only models, images shouldn't be counted, but if they are present
            # we'll use a conservative estimate
            return 0
