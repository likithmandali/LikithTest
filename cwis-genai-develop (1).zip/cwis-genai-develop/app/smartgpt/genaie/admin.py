from django.contrib import admin
from . import models


class MyModelAdmin(admin.ModelAdmin):
    list_display = ("api_type", "overall_status", "response_status_code")


# Register your models here.
admin.site.register(models.Activity)
admin.site.register(models.Application)
admin.site.register(models.LLM)
admin.site.register(models.Project)
admin.site.register(models.Guardrails)
admin.site.register(models.Instance)
admin.site.register(models.SystemTemplate)
admin.site.register(models.ScheduledTask)
admin.site.register(models.ApiLog, MyModelAdmin)
