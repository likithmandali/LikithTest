from django.apps import AppConfig


class GenaieConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "genaie"
