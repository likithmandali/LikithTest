from django.db import models
from .base import BaseModel


class ScheduledTask(BaseModel):
    task_name = models.CharField(max_length=255)
    interval = models.PositiveIntegerField()
    last_run = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=False)

    def __str__(self):
        return f"ID: {self.id} | {self.task_name}"
