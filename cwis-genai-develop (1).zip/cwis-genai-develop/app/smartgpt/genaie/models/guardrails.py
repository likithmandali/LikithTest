import uuid
from django.db import models


class Guardrails(models.Model):
    CLOUD_CHOICES = [
        ("aws", "aws"),
        ("azure", "azure"),
    ]

    # Primary key field (no auto-increment)
    guardrails_id = models.CharField(max_length=250, primary_key=True)
    scanner_configs = models.JSONField(blank=True, null=True)
    cloud_provider = models.CharField(max_length=64, choices=CLOUD_CHOICES)
    is_public = models.BooleanField(default=False)

    # Include created_at and updated_at from BaseModel if needed
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Guardrails"
        verbose_name_plural = "Guardrails"

    def __str__(self):
        return f"ID: {self.guardrails_id} | {self.cloud_provider}"