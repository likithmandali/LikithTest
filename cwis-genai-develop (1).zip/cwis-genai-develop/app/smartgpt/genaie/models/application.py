from django.db import models
from .base import BaseModel
from .project import Project


class Application(BaseModel):
    APPLICATION_GROUP_CHOICES = [
        ("Client-Facing Accelerators", "Client-Facing Accelerators"),
    ]

    name = models.CharField(max_length=255, unique=True)
    type = models.CharField(max_length=64)
    project = models.ManyToManyField(Project)
    description = models.TextField(blank=True, null=True)
    application_group = models.CharField(
        max_length=64, choices=APPLICATION_GROUP_CHOICES
    )

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
