from django.db import models
from .base import BaseModel
from .project import Project


class LLM(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    endpoint = models.TextField(blank=True, null=True)
    project = models.ManyToManyField(Project)

    class Meta:
        verbose_name = "LLM"
        verbose_name_plural = "LLMs"

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
