from django.db import models
from django.contrib.auth.models import User
from .base import BaseModel
from genaie.models.application import Application
from genaie.models.project import Project
from genaie.models.guardrails import Guardrails


class Instance(BaseModel):
    CLOUD_CHOICES = [
        ("aws", "aws"),
    ]
    VECTOR_DB_CHOICES = [
        ("opensearch_serverless", "opensearch_serverless"),
    ]
    EMBEDDING_CHOICE = [
        ("amazon.titan-embed-text-v2:0", "amazon.titan-embed-text-v2:0"),
    ]

    name = models.CharField(max_length=255, unique=True)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    flow = models.IntegerField(blank=True, null=True)
    chunking_strategy = models.CharField(max_length=128, blank=True, null=True)
    k_near_chunks = models.IntegerField(blank=True, null=True)
    chunk_size = models.IntegerField(blank=True, null=True)
    chunking_params = models.JSONField(
        blank=True, null=True
    )  # For storing overlapPercent, bufferSize, and breakpointChunking
    is_active = models.BooleanField(default=True)
    deleted_at = models.DateTimeField(blank=True, null=True)
    users = models.ManyToManyField(User)
    cloud_environment = models.CharField(
        max_length=64, choices=CLOUD_CHOICES, default="aws"
    )
    render_markdown = models.BooleanField(default=False)
    llm_guard = models.BooleanField(default=False)
    llm_guard_value = models.CharField(max_length=250, blank=True, null=True)
    aws_guardrail_id = models.CharField(max_length=250, blank=True, null=True)
    scanner_configs = models.JSONField(blank=True, null=True)
    llm_model = models.CharField(max_length=128, blank=True, null=True)
    query_expansion = models.BooleanField(default=False)
    vector_db = models.CharField(
        max_length=30, choices=VECTOR_DB_CHOICES, default="opensearch_serverless"
    )
    embedding_choice = models.CharField(
        max_length=100, choices=EMBEDDING_CHOICE, default="amazon.titan-embed-text-v2:0"
    )
    last_updated = models.DateTimeField(blank=True, null=True)
    is_updated_model = models.BooleanField(default=False)
    guardrails_id = models.ForeignKey(
        Guardrails,
        to_field="guardrails_id",  # Explicitly reference the guardrails_id field
        db_column="guardrails_id",  # This will be the column name in the database
        on_delete=models.SET_NULL,
        null=True,
        related_name="instances",  # This creates a reverse relation from Guardrails to Instance
    )

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
