from django.db import models
from django.contrib.auth.models import User, Group
from .base import BaseModel
from .instance import Instance
from .project import Project
from .application import Application


class Activity(BaseModel):
    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("Complete", "Complete"),
        ("Failed", "Failed"),
    ]
    _type = models.CharField(max_length=128, verbose_name="type")
    input_text = models.TextField(blank=True, null=True)
    messages = models.JSONField(blank=True, null=True)
    semantic_search_context = models.JSONField(blank=True, null=True)
    output_text = models.TextField(blank=True, null=True)
    template = models.TextField(blank=True, null=True)
    feedback = models.JSONField(blank=True, null=True, default=dict)
    k_near_chunks = models.IntegerField(blank=True, null=True)
    project = models.ForeignKey(Project, blank=True, null=True, on_delete=models.SET_NULL)
    application = models.ForeignKey(Application, blank=True, null=True, on_delete=models.SET_NULL)
    instance = models.ForeignKey(Instance, blank=True, null=True, on_delete=models.SET_NULL)
    task_id = models.CharField(max_length=512, null=True, blank=True)
    meta_data = models.JSONField(blank=True, null=True)
    status = models.TextField(choices=STATUS_CHOICES, blank=True, null=True)
    users = models.ManyToManyField(User)
    group = models.ManyToManyField(Group)
    token_usage = models.JSONField(blank=True, null=True)
    input_token_count = models.IntegerField(blank=True, null=True)
    output_token_count = models.IntegerField(blank=True, null=True)
    input_token_cost = models.FloatField(blank=True, null=True)
    output_token_cost = models.FloatField(blank=True, null=True)
    total_cost = models.FloatField(blank=True, null=True)
    llm_model = models.CharField(max_length=128, blank=True, null=True)
    request_id = models.CharField(max_length=128, blank=True, null=True)
    guardrails_id = models.CharField(max_length=128, blank=True, null=True)
    class Meta:
        verbose_name = "Activity"
        verbose_name_plural = "Activities"

    def __str__(self):
        return f"ID: {self.id}-{self._type}"
