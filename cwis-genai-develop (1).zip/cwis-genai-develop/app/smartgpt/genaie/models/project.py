from django.db import models
from django.contrib.auth.models import Group, User
from .base import BaseModel


class Project(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    group = models.ManyToManyField(Group)
    users = models.ManyToManyField(User)
    is_demo = models.BooleanField(default=False)
    last_updated = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
