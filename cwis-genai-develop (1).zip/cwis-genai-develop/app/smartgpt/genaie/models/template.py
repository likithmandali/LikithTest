from django.db import models
from .base import BaseModel
from .project import Project


class SystemTemplate(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    template = models.TextField()
    project = models.ManyToManyField(Project)

    class Meta:
        verbose_name = "System Template"
        verbose_name_plural = "System Templates"

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
