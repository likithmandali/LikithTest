from django.db import models
import uuid
from django.utils import timezone


class ApiLog(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    api_type = models.CharField(max_length=500)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(blank=True, null=True)
    request_body = models.JSONField(blank=True, null=True)
    response_body = models.JSONField(blank=True, null=True)
    response_status_code = models.IntegerField(blank=True, null=True)
    overall_status = models.CharField(max_length=255)

    def __str__(self):
        return f"API Type: {self.api_type} | Status: {self.overall_status}"
