from django.db import models
from .base import BaseModel


class DocTemplateFile(BaseModel):
    TYPE_CHOICES = [
        ("pptx", "MS PowerPoint Presentation"),
        ("docx", "MS Word Document"),
    ]
    name = models.TextField()
    upload_file_path = models.TextField()
    file_type = models.CharField(max_length=255, choices=TYPE_CHOICES)

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
