from django.db import models
from genaie.models.base import BaseModel


class Knowledge(BaseModel):
    name = models.CharField(max_length=255)
    knowledge_base_id = models.CharField(max_length=255, null=True, default=None)
    data_source_id = models.CharField(max_length=255, null=True, default=None)
    s3_uri = models.CharField(max_length=750, null=True, default=None)
    knowledge_ingestion_job_id = models.CharField(max_length=255, null=True, default=None)

    class Meta:
        verbose_name = "Knowledge"
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
