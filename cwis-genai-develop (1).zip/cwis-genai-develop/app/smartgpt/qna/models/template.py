from django.db import models
from genaie.models.base import BaseModel
from django.contrib.postgres.fields import ArrayField


class Template(BaseModel):
    name = models.CharField(max_length=255)
    prompt_template = models.TextField()
    output_columns = ArrayField(models.CharField(max_length=255), blank=True, null=True)

    mode = models.BooleanField(default=True)
    metadata = models.JSONField(blank=True, null=True)

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
