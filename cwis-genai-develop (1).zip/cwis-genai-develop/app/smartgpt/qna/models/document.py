from django.db import models
from .base import BaseModel
from .knowledge import Knowledge


class Document(BaseModel):
    STATUS_CHOICES = [
        ("In Progress", "In Progress"),
        ("Completed", "Completed"),
        ("Failed", "Failed"),
    ]

    name = models.TextField()
    upload_file_path = models.TextField()
    status = models.TextField(choices=STATUS_CHOICES, default="In Progress", blank=True, null=True)
    knowledge = models.ForeignKey(Knowledge, on_delete=models.CASCADE, blank=True, null=True)
    request_id = models.CharField(max_length=128, blank=True, null=True)

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
