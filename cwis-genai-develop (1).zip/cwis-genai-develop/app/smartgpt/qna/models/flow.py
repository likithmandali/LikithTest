from django.db import models
from genaie.models.base import BaseModel
from .knowledge import Knowledge
from .template import Template
from .doc_template_file import DocTemplateFile


class Flow(BaseModel):
    name = models.CharField(max_length=512)
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    knowledge = models.ManyToManyField(Knowledge, blank=True)
    template = models.ForeignKey(
        Template, on_delete=models.CASCADE, blank=True, null=True
    )
    temperature = models.FloatField(default=0.5)
    doc_template_files = models.ManyToManyField(DocTemplateFile, blank=True)

    def __str__(self):
        return f"ID: {self.id} | {self.name}"
