from django.contrib import admin
from . import models

# Register your models here.
admin.site.register(models.Document)
admin.site.register(models.Flow)
admin.site.register(models.Knowledge)
admin.site.register(models.Template)
admin.site.register(models.DocTemplateFile)
