from decouple import config


class CONFIG:
    SHARED_VOLUME = config("SHARED_VOLUME", default="/app/shared_volume")
