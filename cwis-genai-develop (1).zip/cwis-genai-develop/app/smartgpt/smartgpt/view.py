from django.http import HttpRequest, JsonResponse


def ping(_: HttpRequest) -> JsonResponse:
    return JsonResponse({"response": "Health Check Success!"})
