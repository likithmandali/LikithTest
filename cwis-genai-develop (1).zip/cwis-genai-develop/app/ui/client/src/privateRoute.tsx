/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from 'react';
import {
  authenticateUser,
  isTokenExpired,
  removeAuthToken,
  setAuthToken,
} from './auth';
import { useNavigate } from 'react-router-dom';

export const PrivateRoute = ({ children }: any) => {
  const [authenticated, setAuthenticated] = useState(
    !!sessionStorage.getItem('jwtToken')
  );
  const navigate = useNavigate();

  useEffect(() => {
    const token = sessionStorage.getItem('jwtToken') ? true : false;
    if (!token) {
      const urlParams = new URLSearchParams(window.location.search);
      const token = urlParams.get('token');
      if (!token) {
        // Redirect to login page instead of SSO
        navigate('/login');
      } else {
        setAuthToken(token);
        setAuthenticated(true);
        navigate('/dashboard');
      }
    } else {
      if (isTokenExpired()) {
        removeAuthToken();
        navigate('/login');
      } else {
        setAuthenticated(true);
      }
    }
  }, []);

  return authenticated ? <>{children}</> : null;
};
