export interface Instance {
  id: number;
  name: string;
  flow: number;
  isActive: boolean;
  isDeleted: boolean;
  projectId: number;
  applicationId: number;
  cloudEnvironment: string;
  chunkSize?: number;
  kNearChunks?: number;
  temperature?: number;
  chunkParams?: ChunkingParams;
  parsingStrategy?: string;
}

export interface Appl {
  type: string;
  id: string;
  name: string;
  url: string;
}

export interface Chat {
  role: string;
  content: any;
  images?: Image[];
  feedback?: boolean;
  copyText?:boolean;
}

export interface Image {
  url: string;
  img_name: string;
}

export interface ChatboxInterface {
  initiateChatWarningModal: Function;
}

export interface Project {
  id: number;
  name: string;
}

export interface App {
  description: string;
  id: number;
  name: string;
  url: string;
  type: string;
  applicationGroup: string;
}

export interface IconMap {
  [key: string]: string;
}

export interface IAdvancedSettings {
  mode: 'Normal' | 'hybrid' | 'autocut';
  autocut: 1 | 2 | 3;
  query_param: string | undefined;
  fusion_type: string | undefined;
  enableChatRegeneration: boolean;
  debugMode: boolean;
}

export interface ProcessApiPayload {
  model?: string;
  instance_id: number;
  filepath: string;
  model_params: {
    top_p: number;
    frequency_penalty: number;
    presence_penalty: number;
  };
  include_references: boolean;
  target_column: string;
  target_format: string;
  generator_type: string;
  query_expansion?: boolean;
  // output_columns?: string[];
  advance_search_params?: IAdvancedSettings;
}

export interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export interface FunctionItem {
  name: string;
  description: string;
  active: boolean;
  [key: string]: string | boolean;
}

export interface InstanceParams {
  copilotInstanceName: string;
  description: string;
  Id: string;
  functions: FunctionItem[];
}

export interface copilotInstances {
  name: string;
  description: string;
  id: string;
}

export interface copilotFunctions {
  id: string;
  name: string;
  description: string;
  active: boolean;
  copilot_instance_id: string;
  type: string;
  type_id: string;
}

export interface copilotPrompt {
  id: string;
  name: string;
  prompt: string;
  functionname: string;
  active: boolean;
  copilot_instance_id: string;
}

export interface copilotSubActions {
  id: string;
  sub_type: string;
  type: string;
  genaie_application_name: string;
  genaie_instance_id: string;
  genaie_service_name: string;
  copilot_action_id: string;
  system_prompt: string;
  objectMetaDeta: dataDic[];
}

interface dataDic {
  ObjectName: string;
  ObjDescription: string;
  dataDic: any[];
}

export interface copilotAction {
  copilot_action_id: string;
  name: string;
  description: string;
  active: boolean;
  functionname: string;
}

export interface message {
  role: string;
  content: string;
}

export interface messages {
  role: string;
  content: string;
  type: string;
  index: number;
  entity: string;
}

export interface Knowledge {
  char?: string;
  name: string;
  id: number;
}

interface Method {
  value: string;
  text: string;
}

interface LanguageOption {
  name: string;
  methods: Method[];
  acceptedFiles: string;
  displayFiles: string;
}

export interface CodeToDesignObject {
  [key: string]: LanguageOption;
}
export interface OutputColumn {
  value: string;
}

export interface ErrorMessageTypes {
  message: string;
  id: string;
}

export interface Option {
  id: string;
  option: string;
  label: string;
}

export interface DataProps {
  instanceData?: any;
  nextStep: any;
  prevStep: any;
  setShowNewInstanceModal: any;
  instanceDetails?: any;
}

export interface ChunkingParams {
  overlapPercent?: number;
  bufferSize?: number;
  breakpointChunking?: number;
  childMaxTokens?: number;
}
