export type ApplicationDetails = {
  pageComponent: (() => JSX.Element) | null;
};

export type Llm_models =
  | 'gpt-4-turbo'
  | 'gpt-4o'
  | 'gpt4-32k'
  | 'gpt4-8k'
  | 'gpt35-16k'
  | 'gpt35-4k'
  | 'gemini-pro'
  | 'gemini-1.5-pro-preview-0409'
  | 'text-bison-32k'
  | 'text-bison@001'
  | 'mistral:7b-instruct'
  | 'llama2:7b-chat'
  | 'llama2:7b-chat-ft-medicaid-fed-20240201'
  | 'anthropic.claude-v2:1'
  | 'amazon.titan-text-express-v1'
  | 'us.anthropic.claude-3-5-sonnet-20240620-v1:0'
  | 'us.anthropic.claude-3-5-sonnet-20241022-v2:0'
  | 'us.anthropic.claude-3-7-sonnet-20250219-v1:0'
  | 'us.anthropic.claude-sonnet-4-20250514-v1:0';

export type SetStateFunction<T> = React.Dispatch<React.SetStateAction<T>>;

export type AdvanceSettingProps = {
  chatbox: any;
  overlayContainerRef: any;
  vectorDb?: string;
};

export type VectorDb = 'weaviate' | 'pgvector' | 'opensearch_serverless';

export type RegexPatterns = {
  name: string;
  expressions: string[];
  context: string[];
};

export type Params = {
  allowed_names?: string[];
  hidden_names?: string[];
  entity_types?: string[];
  preamble?: string;
  threshold?: number;
  use_faker?: boolean;
  regex_patterns?: RegexPatterns[];
  language?: string;
  competitors?: string[];
  redact?: boolean;
  substrings?: string[];
  match_type?: string;
  case_sensitive?: boolean;
  contains_all?: boolean;
  topics?: string[];
  languages?: string[];
  is_blocked?: boolean;
  valid_languages?: string[];
  patterns?: string[];
  redact_mode?: string;
  limit?: number;
};

export type Scanner = {
  type: string;
  params: Params;
};

export type ContentFilters = {
  type: string;
  strength: string;
};
export type AwsBedrockPayload = {
  instance_id?: string;
  grs_name?: string;
  pii_types?: string[];
  action_taken?: string;
  words_to_block?: string[];
  content_filter?: ContentFilters[];
  content_safety?: ContentFilters[];
};

export type ToggleStates = {
  [key: string]: boolean;
};

export type AccordionStates = {
  [key: string]: string | null;
};

// document editor
export type CustomText = {
  text: string;
  bold?: boolean;
  fontSize?: string | null;
  paddingTop?: string | null;
  paddingBottom?: string | null;
  backgroundColor?: string | null;
  margin?: string | null;
};

export type CustomElement = {
  type: 'paragraph';
  children: CustomText[];
};
