import React from 'react';
import { CODE_QNA, Failed_Connection_Error } from './constants';

interface Chat {
  role: string;
  content: string;
}

const decodeBase64ToUtf8 = (base64String: string) => {
  // Decode base64 to binary string
  const binaryString = atob(base64String);
  // Convert binary string to array of bytes
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  // Decode bytes to UTF-8 string
  const decoder = new TextDecoder('utf-8');
  return decoder.decode(bytes);
};

type SetStateFunction<T> = React.Dispatch<React.SetStateAction<T>>;
const llmGuardStream = async ({
  requestBody,
  setShowToast,
  setIsLoading,
  setErrorMessage,
  llmCloud,
  setActivityId,
  setSanitizedPrompt,
  signal,
  streamCallback,
  doneCallback,
  setErr,
  currentApp,
}: {
  requestBody: any;
  setShowToast: any;
  setIsLoading: SetStateFunction<boolean>;
  setErrorMessage: any;
  llmCloud?: string;
  setActivityId?: any;
  setSanitizedPrompt?: any;
  signal?: AbortSignal;
  streamCallback: (chunk: string) => void;
  doneCallback?: () => void;
  setErr?: SetStateFunction<string>;
  currentApp?: any;
}) => {
  const token = sessionStorage.getItem('jwtToken');
  let streamingUrl = '';
  setActivityId('');
  setSanitizedPrompt('');
  if (llmCloud === 'aws') {
    // if (requestBody?.messages?.length) {
    //   streamingUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/submit/prompt/messages/streaming/guardrails`;
    // } else {
      streamingUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/submit/prompt/streaming/guardrails`;
   // }
  } else if (llmCloud === 'azure') {
    if (requestBody?.messages?.length) {
      streamingUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/submit/prompt/messages/streaming/guardrails`;
    } else {
      streamingUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/submit/prompt/streaming/guardrails`;
    }
  }

  if (requestBody?.messages?.length) {
    requestBody.messages = requestBody.messages.filter(
      (message: Chat, index: number) =>
        index === 0 || requestBody.messages.length - index < 4
    );
  }

  const isFormData = requestBody instanceof FormData;
  const headers: Record<string, string> = {
    Accept: 'application/json',
    Authorization: `Bearer ${token}`,
  };

  if (!isFormData) {
    headers['Content-Type'] = 'application/json';
  }

  fetch(streamingUrl, {
    method: 'POST',
    headers: headers,
    body:
      isFormData || currentApp === CODE_QNA
        ? requestBody
        : JSON.stringify(requestBody),
    signal: signal,
  })
    .then((response) => {
      if (response.ok) {
        const reader = response?.body?.getReader();
        setActivityId((response?.headers as any)?.get('x-activityid'));
        const encodedSanitizedPrompt = (response?.headers as any)?.get(
          'x-sanitized-prompt'
        );
        const responseSanitizedPrompt = decodeBase64ToUtf8(
          encodedSanitizedPrompt
        );
        if (setSanitizedPrompt && responseSanitizedPrompt) {
          setSanitizedPrompt(responseSanitizedPrompt);
        }
        const read = () => {
          reader
            ?.read()
            .then(({ done, value }) => {
              if (done) {
                if (doneCallback) {
                  doneCallback();
                }
                return;
              }

              const decoder = new TextDecoder();
              streamCallback(decoder.decode(value));
              read();
            })
            .catch((error) => {
              if (error.name === 'AbortError') {
                console.error('Fetch aborted');
              } else {
                console.error('Fetch error:', error);
              }
            });
        };

        read();
      } else {
        const errID = response?.headers.get('x-api-request-id');
        response.json().then((errorResponse) => {
          const errorMessage =
            errorResponse?.error?.errorMessage ||
            'There is an internal server error. Please try again.';
          setErrorMessage &&
            setErrorMessage({ message: errorMessage, id: errID });
        });
        setShowToast(true);
        setIsLoading(false);
      }
    })
    .catch((err) => {
      const errText = err.toString();
      //  Netwrok error:  Adding specific condition for network or VPN disconnect
      if (errText.includes('TypeError: Failed to fetch')) {
        setErrorMessage({
          message: Failed_Connection_Error,
        });
      }
      setShowToast(true);
      setIsLoading(false);
    });
};

export default llmGuardStream;
