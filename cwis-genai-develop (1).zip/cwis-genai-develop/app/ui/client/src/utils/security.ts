import DOMPurify from 'dompurify';

/**
 * Sanitizes HTML content to prevent XSS attacks
 * @param dirty - The HTML string to sanitize
 * @returns Sanitized HTML string safe for rendering
 */
export const sanitizeHtml = (dirty: string): string => {
  return DOMPurify.sanitize(dirty);
};





/**
 * Validates URL to prevent open redirect attacks
 * @param url - The URL to validate
 * @param allowedDomains - Array of allowed domains (optional, defaults to current origin)
 * @returns true if URL is safe, false otherwise
 */
export const isValidRedirectUrl = (url: string, allowedDomains?: string[]): boolean => {
  if (!url) return false;
  
  try {
    // Prevent javascript:, data:, and other potentially dangerous protocols
    if (url.match(/^(javascript|data|vbscript|file|about):/i)) {
      return false;
    }
    
    const urlObj = new URL(url);
    
    // Only allow http and https protocols
    if (urlObj.protocol !== 'http:' && urlObj.protocol !== 'https:') {
      return false;
    }
    
    // Check if it's a relative URL (safer)
    if (url.startsWith('/') && !url.startsWith('//')) {
      return true;
    }
    
    // If absolute URL, check if domain is allowed
    const allowedDomainList = allowedDomains || [window.location.origin];
    const urlOrigin = urlObj.origin;
    
    return allowedDomainList.some(domain => {
      try {
        const domainObj = new URL(domain);
        return domainObj.origin === urlOrigin;
      } catch {
        return false;
      }
    });
  } catch {
    // Invalid URL
    return false;
  }
};

/**
 * Validates download URL to prevent XSS while allowing legitimate file downloads
 * @param url - The download URL to validate
 * @param trustedDomains - Array of trusted domains for downloads (optional)
 * @returns true if URL is safe for downloads, false otherwise
 */
export const isValidDownloadUrl = (url: string, trustedDomains?: string[]): boolean => {
  if (!url) return false;
  
  try {
    // Prevent javascript:, data:, vbscript:, file:, about: protocols
    if (url.match(/^(javascript|data|vbscript|file|about):/i)) {
      return false;
    }
    
    const urlObj = new URL(url);
    
    // Only allow http and https protocols
    if (urlObj.protocol !== 'http:' && urlObj.protocol !== 'https:') {
      return false;
    }
    
    // Check if it's a relative URL (safer)
    if (url.startsWith('/') && !url.startsWith('//')) {
      return true;
    }
    
    // For absolute URLs, check against trusted domains
    const defaultTrustedDomains = [
      window.location.origin,
      // Add common trusted file hosting domains
      'amazonaws.com',
      'aws.amazon.com',
      's3.amazonaws.com',
    ];
    
    const allowedDomains = trustedDomains || defaultTrustedDomains;
    const urlHostname = urlObj.hostname.toLowerCase();
    
    // Check if the URL hostname matches or is a subdomain of trusted domains
    return allowedDomains.some(domain => {
      try {
        if (domain.startsWith('http')) {
          const domainObj = new URL(domain);
          return urlHostname === domainObj.hostname.toLowerCase() || 
                 urlHostname.endsWith('.' + domainObj.hostname.toLowerCase());
        } else {
          // Handle domain strings without protocol
          return urlHostname === domain.toLowerCase() || 
                 urlHostname.endsWith('.' + domain.toLowerCase());
        }
      } catch {
        return false;
      }
    });
  } catch {
    // Invalid URL
    return false;
  }
};

/**
 * Validates base64 data URL for images
 * @param dataUrl - The data URL to validate
 * @returns true if data URL is a valid image, false otherwise
 */
export const isValidImageDataUrl = (dataUrl: string): boolean => {
  if (!dataUrl) return false;
  
  // Check if it's a proper data URL format
  const dataUrlPattern = /^data:image\/(png|jpeg|jpg|gif|webp);base64,([A-Za-z0-9+/]+={0,2})$/;
  
  if (!dataUrlPattern.test(dataUrl)) {
    return false;
  }
  
  try {
    // Extract the base64 part
    const base64Part = dataUrl.split(',')[1];
    if (!base64Part) return false;
    
    // Validate base64 encoding
    const decoded = atob(base64Part);
    
    // Check for reasonable size limits (e.g., 10MB)
    if (decoded.length > 10 * 1024 * 1024) {
      return false;
    }
    
    return true;
  } catch {
    return false;
  }
};

/**
 * Validates image URL to prevent XSS through malicious image sources
 * @param url - The image URL to validate
 * @returns true if URL is safe for use as image src, false otherwise
 */
export const isValidImageUrl = (url: string): boolean => {
  if (!url) return false;
  
  // Handle data URLs specifically for base64 images
  if (url.startsWith('data:')) {
    return isValidImageDataUrl(url);
  }
  
  // Prevent javascript:, vbscript:, file:, about: protocols
  if (url.match(/^(javascript|vbscript|file|about):/i)) {
    return false;
  }
  
  // Allow relative URLs starting with /
  if (url.startsWith('/') && !url.startsWith('//')) {
    // Check for valid image extensions
    return /\.(jpg|jpeg|png|gif|svg|webp)$/i.test(url);
  }
  
  // For absolute URLs, validate the protocol and domain
  try {
    const urlObj = new URL(url);
    
    // Only allow http/https protocols
    if (urlObj.protocol !== 'http:' && urlObj.protocol !== 'https:') {
      return false;
    }
    
    // Check for valid image extensions
    if (!/\.(jpg|jpeg|png|gif|svg|webp)$/i.test(urlObj.pathname)) {
      return false;
    }
    
    // Additional validation - ensure it's from trusted domains
    const allowedDomains = [window.location.origin];
    return allowedDomains.some(domain => {
      try {
        const domainObj = new URL(domain);
        return domainObj.origin === urlObj.origin;
      } catch {
        return false;
      }
    });
  } catch {
    return false;
  }
};