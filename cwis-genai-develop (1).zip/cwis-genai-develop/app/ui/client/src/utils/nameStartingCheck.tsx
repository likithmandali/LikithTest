export const nameStartingCheck = (firstLetter: string) => {
  var format = /^[^\w]*$/;
  if (firstLetter.match(format)) {
    return true;
  } else {
    return false;
  }
};
