import { Option } from '../interfaces';

export const anonymize_options: Option[] = [
  { id: '1', option: 'CREDIT_CARD', label: 'CREDIT_CARD' },
  { id: '2', option: 'PERSON', label: 'PERSON' },
  { id: '3', option: 'PHONE_NUMBER', label: 'PHONE_NUMBER' },
  { id: '4', option: 'URL', label: 'URL' },
  { id: '5', option: 'EMAIL_ADDRESS', label: 'EMAIL_ADDRESS' },
  { id: '6', option: 'IP_ADDRESS', label: 'IP_ADDRESS' },
  { id: '7', option: 'UUID', label: 'UUID' },
  { id: '8', option: 'US_SSN', label: 'US_SSN' },
  { id: '9', option: 'CRYPTO', label: 'CRYPTO' },
  { id: '10', option: 'IBAN_CODE', label: 'IBAN_CODE' },
  { id: '11', option: 'PASSPORT_NUMBER', label: 'PASSPORT_NUMBER' },
  { id: '12', option: 'HOME_ADDRESS', label: 'HOME_ADDRESS' },
  { id: '13', option: 'IMSI_NUMBER', label: 'IMSI_NUMBER' },
  { id: '14', option: 'VISA_PERMIT_NUMBER', label: 'VISA_PERMIT_NUMBER' },
  {
    id: '15',
    option: `DRIVER'S_LICENCE_NUMBER`,
    label: `DRIVER'S_LICENCE_NUMBER`,
  },
  {
    id: '16',
    option: 'VEHICLE_REGISTRATION_PLATE_NUMBER',
    label: 'VEHICLE_REGISTRATION_PLATE_NUMBER',
  },
  { id: '17', option: 'PLACE_OF_BIRTH', label: 'PLACE_OF_BIRTH' },
  { id: '18', option: 'MAC_ADDRESS', label: 'MAC_ADDRESS' },
  { id: '19', option: 'UUID', label: 'UUID' },
  { id: '20', option: 'DATE', label: 'DATE' },
];

export const advance_anonymize_options: Option[] = [
  { id: '1', option: 'AGE', label: 'AGE' },
  { id: '2', option: 'USERNAME', label: 'USERNAME' },
  { id: '3', option: 'PASSWORD', label: 'PASSWORD' },
  { id: '4', option: 'GUID', label: 'GUID' },
  { id: '5', option: 'WORK', label: 'WORK' },
  { id: '6', option: 'BOOK', label: 'BOOK' },
  { id: '7', option: 'COMPANY', label: 'COMPANY' },
  { id: '8', option: 'ACTOR', label: 'ACTOR' },
  { id: '9', option: 'CVV', label: 'CVV' },
  { id: '10', option: 'EXPIRY_DATE', label: 'EXPIRY_DATE' },
  { id: '11', option: 'HEALTH_SERVICE_NUMBER', label: 'HEALTH_SERVICE_NUMBER' },
  { id: '12', option: 'SECRET_KEY', label: 'SECRET_KEY' },
  { id: '13', option: 'ACCESS_KEY', label: 'ACCESS_KEY' },
  { id: '14', option: 'ATM_PIN', label: 'ATM_PIN' },
  { id: '15', option: 'BANK_ACCOUNT_NUMBER', label: 'BANK_ACCOUNT_NUMBER' },
  { id: '16', option: 'SWIFT_CODE', label: 'SWIFT_CODE' },
];

export const regex_pattern_options: Option[] = [
  { id: '1', option: 'PASSPORT_NUMBER', label: 'PASSPORT_NUMBER' },
  { id: '2', option: 'HOME_ADDRESS', label: 'HOME_ADDRESS' },
  { id: '3', option: 'IMSI_NUMBER', label: 'IMSI_NUMBER' },
  { id: '4', option: 'VISA_PERMIT_NUMBER', label: 'VISA_PERMIT_NUMBER' },
  {
    id: '5',
    option: 'DRIVERS_LICENCE_NUMBER',
    label: `DRIVER'S_LICENCE_NUMBER`,
  },
  {
    id: '6',
    option: 'VEHICLE_REGISTRATION_PLATE_NUMBER',
    label: 'VEHICLE_REGISTRATION_PLATE_NUMBER',
  },
  { id: '7', option: 'PLACE_OF_BIRTH', label: 'PLACE_OF_BIRTH' },
  { id: '8', option: 'MAC_ADDRESS', label: 'MAC_ADDRESS' },
  { id: '9', option: 'UUID', label: 'UUID' },
  { id: '10', option: 'DATE', label: 'DATE' },
];

export const programming_lang: Option[] = [
  { id: '1', option: 'ARM Assembly', label: 'ARM Assembly' },
  { id: '2', option: 'AppleScript', label: 'AppleScript' },
  { id: '3', option: 'C', label: 'C' },
  { id: '4', option: 'C#', label: 'C#' },
  { id: '5', option: 'C++', label: 'C++' },
  { id: '6', option: 'COBOL', label: 'COBOL' },
  { id: '7', option: 'Erlang', label: 'Erlang' },
  { id: '8', option: 'Fortran', label: 'Fortran' },
  { id: '9', option: 'Go', label: 'Go' },
  { id: '10', option: 'Java', label: 'Java' },
  { id: '11', option: 'JavaScript', label: 'JavaScript' },
  { id: '12', option: 'Kotlin', label: 'Kotlin' },
  { id: '13', option: 'Lua', label: 'Lua' },
  {
    id: '14',
    option: 'Mathematica/Wolfram Language',
    label: 'Mathematica/Wolfram Language',
  },
  { id: '15', option: 'PHP', label: 'PHP' },
  { id: '16', option: 'Pascal', label: 'Pascal' },
  { id: '17', option: 'Perl', label: 'Perl' },
  { id: '18', option: 'PowerShell', label: 'PowerShell' },
  { id: '19', option: 'Python', label: 'Python' },
  { id: '20', option: 'R', label: 'R' },
  { id: '21', option: 'Ruby', label: 'Ruby' },
  { id: '22', option: 'Rust', label: 'Rust' },
  { id: '23', option: 'Scala', label: 'Scala' },
  { id: '24', option: 'Swift', label: 'Swift' },
  { id: '25', option: 'Visual Basic .NET', label: 'Visual Basic .NET' },
  { id: '26', option: 'jq', label: 'jq' },
];

export const language_options: Option[] = [
  { id: '1', option: 'ar', label: 'arabic (ar)' },
  { id: '2', option: 'bg', label: 'bulgarian (bg)' },
  { id: '3', option: 'de', label: 'german (de)' },
  { id: '4', option: 'el', label: 'modern greek (el)' },
  { id: '5', option: 'en', label: 'english (en)' },
  { id: '6', option: 'es', label: 'spanish (es)' },
  { id: '7', option: 'fr', label: 'french (fr)' },
  { id: '8', option: 'hi', label: 'hindi (hi)' },
  { id: '9', option: 'it', label: 'italian (it)' },
  { id: '10', option: 'ja', label: 'japanese (ja)' },
  { id: '11', option: 'nl', label: 'dutch (nl)' },
  { id: '12', option: 'pl', label: 'polish (pl)' },
  { id: '13', option: 'pt', label: 'portuguese (pt)' },
  { id: '14', option: 'ru', label: 'russian (ru)' },
  { id: '15', option: 'sw', label: 'swahili (sw)' },
  { id: '16', option: 'th', label: 'thai (th)' },
  { id: '17', option: 'tr', label: 'turkish (tr)' },
  { id: '18', option: 'ur', label: 'urdu (ur)' },
  { id: '19', option: 'vi', label: 'vietnamese (vi)' },
  { id: '20', option: 'zh', label: 'chinese (zh)' },
];

export const regexPatternDetails = {
  HOME_ADDRESS: {
    expressions: [
      '(?i)[0-9]{1,5}\\s[A-Za-z0-9\\s\\-]+(?:\\s[A-Za-z]{2,})?\\s(?:Street|St|Rd|Road|Avenue|Ave|Drive|Dr|Blvd|Boulevard|Lane|Ln|Court|Ct|Place|Pl|Square|Sq|Terrace|Terr|Circle|Cir|Highway|Hwy|Parkway|Pkwy|Esplanade|Esp|Trail|Tr|Alley|Aly|Boulevard|Blvd|Crescent|Cres|Drive|Dr|Esplanade|Esp|Gardens|Gdns|Grove|Grv|Heights|Hts|Highway|Hwy|Island|Isl|Junction|Jct|Knolls|Knls|Lane|Ln|Mews|Mews|Parkway|Pkwy|Road|Rd|Square|Sq|Street|St|Terrace|Terr|Trail|Tr|Way|Wy)\\.?\\s(?:[A-Za-z]{2,}\\s)?[A-Za-z]{2,}\\s[A-Za-z]{2}\\s[0-9]{5}',
    ],
    context: ['house address', 'residence', 'stay'],
  },
  PASSPORT_NUMBER: {
    expressions: ['[A-Za-z]{1}\\d{8}', '[0-9]{9}'],
    context: ['passport', 'passport num', 'PN', 'Passport Number', 'PP Number'],
  },
  IMSI_NUMBER: {
    expressions: ['([0-9]{3}[0-9]{3}[0-9]{9})?'],
    context: ['imsi number', 'imsi'],
  },
  VISA_PERMIT_NUMBER: {
    expressions: ['[A-Za-z]{1}\\d{7}'],
    context: [],
  },
  DRIVERS_LICENCE_NUMBER: {
    expressions: [
      '(?i)([A-Za-z]{5}|[A-Za-z]{1,4}9{1,3})\\d{6}([A-Za-z]{2}|[A-Za-z]{1,2}9{1,2})9{1}[A-Za-z]{2}',
      '(?i)[A-Za-z]{2}\\d{2}\\s\\d{11}',
    ],
    context: [],
  },
  VEHICLE_REGISTRATION_PLATE_NUMBER: {
    expressions: [
      '[A-Z]{2}[\\ -]{0,1}[0-9]{2}[\\ -]{0,1}[A-Z]{1,2}[\\ -]{0,1}[0-9]{4}',
      '[0-9]{3,4}[A-Za-z]{2,3}([0-9]{3,4})',
      '[A-Za-z]{2}\\d{2}[A-Za-z]{3}',
      '\\d{2}\\s?[Bb][Hh]\\s?\\d{4}[A-Za-z]{1,2}',
    ],
    context: [],
  },
  PLACE_OF_BIRTH: {
    expressions: [
      '(?i)(?:born in|place of birth is|birthplace is|native city is|native town is|pob is|birth place is):?\\s*(?:((\\w+\\s*){1,3},?\\s*)?(?:(City|State|Province|Territory|Country):\\s*(\\w{2}))?\\s*|([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*))',
    ],
    context: [],
  },
  MAC_ADDRESS: {
    expressions: ['([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})'],
    context: [],
  },
  UUID: {
    expressions: ['[{]?[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}[}]?'],
    context: [],
  },
  DATE: {
    expressions: [
      '(?i)(?:(?<!\\:)(?<!\\:\\d)[0-3]?\\d(?:st|nd|rd|th)?\\s+(?:of\\s+)?(?:jan\\.?|january|feb\\.?|february|mar\\.?|march|apr\\.?|april|may|jun\\.?|june|jul\\.?|july|aug\\.?|august|sep\\.?|september|oct\\.?|october|nov\\.?|november|dec\\.?|december)|(?:jan\\.?|january|feb\\.?|february|mar\\.?|march|apr\\.?|april|may|jun\\.?|june|jul\\.?|july|aug\\.?|august|sep\\.?|september|oct\\.?|october|nov\\.?|november|dec\\.?|december)\\s+(?<!\\:)(?<!\\:\\d)[0-3]?\\d(?:st|nd|rd|th)?)(?:\\,)?\\s*(?:\\d{4})?|[0-3]?\\d[-\\./][0-3]?\\d[-\\./]\\d{2,4}',
    ],
    context: [],
  },
};

// AWS Bedrock GRS Options:
export const pii_entity_options: Option[] = [
  { id: '1', option: 'ADDRESS', label: 'ADDRESS' },
  { id: '2', option: 'AGE', label: 'AGE' },
  { id: '3', option: 'AWS_ACCESS_KEY', label: 'AWS_ACCESS_KEY' },
  { id: '4', option: 'AWS_SECRET_KEY', label: 'AWS_SECRET_KEY' },
  { id: '5', option: 'CA_HEALTH_NUMBER', label: 'CA_HEALTH_NUMBER' },
  {
    id: '6',
    option: 'CA_SOCIAL_INSURANCE_NUMBER',
    label: 'CA_SOCIAL_INSURANCE_NUMBER',
  },
  { id: '7', option: 'CREDIT_DEBIT_CARD_CVV', label: 'CREDIT_DEBIT_CARD_CVV' },
  {
    id: '8',
    option: 'CREDIT_DEBIT_CARD_EXPIRY',
    label: 'CREDIT_DEBIT_CARD_EXPIRY',
  },
  {
    id: '9',
    option: 'CREDIT_DEBIT_CARD_NUMBER',
    label: 'CREDIT_DEBIT_CARD_NUMBER',
  },
  { id: '10', option: 'DRIVER_ID', label: 'DRIVER_ID' },
  { id: '11', option: 'EMAIL', label: 'EMAIL' },
  {
    id: '12',
    option: 'INTERNATIONAL_BANK_ACCOUNT_NUMBER',
    label: 'INTERNATIONAL_BANK_ACCOUNT_NUMBER',
  },
  { id: '13', option: 'IP_ADDRESS', label: 'IP_ADDRESS' },
  { id: '14', option: 'LICENSE_PLATE', label: 'LICENSE_PLATE' },
  { id: '15', option: 'MAC_ADDRESS', label: 'MAC_ADDRESS' },
  { id: '16', option: 'NAME', label: 'NAME' },
  { id: '17', option: 'PASSWORD', label: 'PASSWORD' },
  { id: '18', option: 'PHONE', label: 'PHONE' },
  { id: '19', option: 'PIN', label: 'PIN' },
  { id: '20', option: 'SWIFT_CODE', label: 'SWIFT_CODE' },
  {
    id: '21',
    option: 'UK_NATIONAL_HEALTH_SERVICE_NUMBER',
    label: 'UK_NATIONAL_HEALTH_SERVICE_NUMBER',
  },
  {
    id: '22',
    option: 'UK_NATIONAL_INSURANCE_NUMBER',
    label: 'UK_NATIONAL_INSURANCE_NUMBER',
  },
  {
    id: '23',
    option: 'UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER',
    label: 'UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER',
  },
  { id: '24', option: 'URL', label: 'URL' },
  { id: '25', option: 'USERNAME', label: 'USERNAME' },
  {
    id: '26',
    option: 'US_BANK_ACCOUNT_NUMBER',
    label: 'US_BANK_ACCOUNT_NUMBER',
  },
  {
    id: '27',
    option: 'US_BANK_ROUTING_NUMBER',
    label: 'US_BANK_ROUTING_NUMBER',
  },
  {
    id: '28',
    option: 'US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER',
    label: 'US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER',
  },
  { id: '29', option: 'US_PASSPORT_NUMBER', label: 'US_PASSPORT_NUMBER' },
  {
    id: '30',
    option: 'US_SOCIAL_SECURITY_NUMBER',
    label: 'US_SOCIAL_SECURITY_NUMBER',
  },
  {
    id: '31',
    option: 'VEHICLE_IDENTIFICATION_NUMBER',
    label: 'VEHICLE_IDENTIFICATION_NUMBER',
  },
];

// Azure GRS Options:
export const azure_pii_entity_options: Option[] = [
  { id: '1', option: 'PERSON', label: 'Person' },
  { id: '2', option: 'PERSON_TYPE', label: 'PersonType' },
  { id: '3', option: 'PHONE_NUMBER', label: 'PhoneNumber' },
  { id: '4', option: 'ORGANIZATION', label: 'Organization' },
  { id: '5', option: 'ADDRESS', label: 'Address' },
  { id: '6', option: 'EMAIL', label: 'Email' },
  { id: '7', option: 'URL', label: 'URL' },
  { id: '8', option: 'IPADDRESS', label: 'IPAddress' },
  { id: '9', option: 'DATE', label: 'Date' },
  { id: '10', option: 'AGE', label: 'Age' },
  {
    id: '11',
    option: 'AZURE_DOCUMENT_DB_AUTH_KEY',
    label: 'AzureDocumentDBAuthKey',
  },
  {
    id: '12',
    option: 'AZURE_IAAS_DATABASE_CONNECTTION_AND_SQL_STRING',
    label: 'AzureIAASDatabaseConnectionAndSQLString',
  },
  {
    id: '13',
    option: 'AZURE_IOT_CONNECTION_STRING',
    label: 'AzureIoTConnectionString',
  },
  {
    id: '14',
    option: 'AZURE_PUBLISH_SETTING_PASSWORD',
    label: 'AzurePublishSettingPassword',
  },
  {
    id: '15',
    option: 'AZURE_REDIS_CACHE_STRING',
    label: 'AzureRedisCacheString',
  },
  { id: '16', option: 'AZURE_SAS', label: 'AzureSAS' },
  {
    id: '17',
    option: 'AZURE_SERVICE_BUS_STRING',
    label: 'AzureServiceBusString',
  },
  {
    id: '18',
    option: 'AZURE_STORAGE_ACCOUNT_KEY',
    label: 'AzureStorageAccountKey',
  },
  {
    id: '19',
    option: 'AZURE_STORAGE_ACCOUNT_GENERIC',
    label: 'AzureStorageAccountGeneric',
  },
  {
    id: '20',
    option: 'SQL_SERVER_CONNECTION_STRING',
    label: 'SQLServerConnectionString',
  },
  { id: '21', option: 'ABA_ROUTING_NUMBER', label: 'ABARoutingNumber' },
  { id: '22', option: 'SWIFT_CODE', label: 'SWIFTCode' },
  { id: '23', option: 'CREDIT_CARD_NUMBER', label: 'CreditCardNumber' },
  {
    id: '24',
    option: 'IBAN_NUMBER',
    label: 'InternationalBankingAccountNumber',
  },
  {
    id: '25',
    option: 'US_SOCIAL_SECURITY_NUMBER',
    label: 'USSocialSecurityNumber',
  },
  {
    id: '26',
    option: 'US_DRIVER_LICENSE_NUMBER',
    label: 'USDriversLicenseNumber',
  },
  { id: '27', option: 'US_UK_PASSPORT_NUMBER', label: 'USUKPassportNumber' },
  {
    id: '28',
    option: 'US_INDIVIDUAL_TAX_PAYER_ID',
    label: 'USIndividualTaxpayerIdentification',
  },
  {
    id: '29',
    option: 'US_DRUG_ENFORCEMENT_AGENCY_NUMBER',
    label: 'DrugEnforcementAgencyNumber',
  },
  { id: '30', option: 'US_BANK_ACC_NUMBER', label: 'USBankAccountNumber' },
];
