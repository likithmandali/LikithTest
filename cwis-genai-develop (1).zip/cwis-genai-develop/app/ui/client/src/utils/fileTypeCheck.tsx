export const isAcceptedFileFormat = (
  file: File,
  acceptedFormats: string[]
): boolean => {
  return acceptedFormats.some((ext) => file.name.endsWith(ext));
};
