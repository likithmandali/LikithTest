import React from 'react';
import axios from 'axios';
import { ErrorMessageTypes } from '../interfaces';

interface Chat {
  role: string;
  content: string;
}

type SetStateFunction<T> = React.Dispatch<React.SetStateAction<T>>;
const llmGuardSubmit = async ({
  requestBody,
  setShowToast,
  setIsLoading,
  setErrorMessage,
  llmCloud,
  setActivityId,
  setSanitizedPrompt,
}: {
  requestBody: any;
  setShowToast: any;
  setIsLoading: any;
  setErrorMessage: SetStateFunction<ErrorMessageTypes>;
  llmCloud?: string;
  setActivityId?: any;
  setSanitizedPrompt?: any;
}) => {
  // const token = sessionStorage.getItem('jwtToken');
  let apiUrl = '';
  setActivityId('');

  if (llmCloud === 'gcp') {
    if (requestBody?.advance_search_params) {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/gcp/submit/prompt/advance/cached`;
    } else if (requestBody?.messages?.length) {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/gcp/submit/prompt/messages`;
    } else {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/gcp/submit/prompt`;
    }
  } else if (llmCloud === 'aws') {
    if (requestBody?.advance_search_params) {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/submit/prompt/advance/cached`;
    } else if (requestBody?.messages?.length) {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/submit/prompt/messages`;
    } else {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/submit/prompt`;
    }
  } else if (llmCloud === 'azure') {
    if (requestBody?.advance_search_params) {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/submit/prompt/advance/cached`;
    } else if (requestBody?.messages?.length) {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/submit/prompt/messages`;
    } else {
      apiUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/submit/prompt`;
    }
  }

  if (requestBody?.messages?.length) {
    requestBody.messages = requestBody?.messages?.filter(
      (message: Chat, index: number) =>
        index === 0 || requestBody.messages.length - index < 4
    );
  }

  try {
    setIsLoading(true);
    const response = await axios.post(apiUrl, requestBody);
    setIsLoading(false);
    setActivityId((response?.headers as any)?.get('x-activityid'));
    setSanitizedPrompt(response.data?.sanitized_prompt);
    return response.data.response;
  } catch (error: any) {
    console.error('axios error:', error);
    const err = error?.response?.data?.error;
    const errID = error?.response?.data?.errorId;
    setErrorMessage?.({
      message: err?.errorMessage,
      id: errID,
    });
    setShowToast?.(true);
    setIsLoading(false);
    return null;
  }
};
export default llmGuardSubmit;
