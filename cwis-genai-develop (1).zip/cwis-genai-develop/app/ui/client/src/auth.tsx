import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { isValidRedirectUrl, sanitizeHtml } from './utils/security';

export const authenticateUser = async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/authentication/sso-login`
    );
    const redirect_url = response.data?.redirect_url;

    if (redirect_url && isValidRedirectUrl(redirect_url)) {
      // Additional validation to ensure it's not a javascript: or data: URL
      if (redirect_url.startsWith('javascript:') || redirect_url.startsWith('data:')) {
        // console.error('Malicious redirect URL detected:', redirect_url);
        return false;
      }
      // Ensure redirect is to same origin to prevent open redirect attacks
      if (!redirect_url.startsWith('/') && !redirect_url.startsWith(window.location.origin)) {
        return false;
      }
      window.location.href = new URL(redirect_url).href;
      return true;
    } else {
      // console.error('Invalid or untrusted redirect URL:', redirect_url);
      return false;
    }
  } catch (error) {
    return false;
  }
};

export const setAuthToken = (token: any) => {
  sessionStorage.setItem('jwtToken', token);
  const decoded: { sub?: string; exp?: number; role?: string } =
    jwtDecode(token);
  
  // Sanitize the values before storing to prevent XSS
  const userName = decoded?.sub ? sanitizeHtml(decoded.sub) : '';
  const exp = decoded?.exp;
  const role = decoded?.role ? sanitizeHtml(decoded.role) : '';
  
  sessionStorage.setItem('role', JSON.stringify(role));
  sessionStorage.setItem('user', JSON.stringify(userName));
  sessionStorage.setItem('expiry', JSON.stringify(exp));
};

export const getAuthToken = () => {
  return sessionStorage.getItem('jwtToken');
};

export const removeAuthToken = () => {
  sessionStorage.removeItem('jwtToken');
  sessionStorage.removeItem('user');
  sessionStorage.removeItem('expiry');
};

export const isTokenExpired = () => {
  const expiry = sessionStorage.getItem('expiry');
  const currentTime = Date.now();
  const expiredTime = expiry ? parseInt(expiry, 10) * 1000 : 0;

  return currentTime > expiredTime;
};

export const updateAuthToken = async () => {
  try {
    const payload = {
      access_token: sessionStorage.getItem('jwtToken'),
    };
    const response = await axios.post(
      `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/authentication/token-refresh`,
      payload,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );
    const token = response.data?.access_token;
    setAuthToken(token);
  } catch (error) {
    return false;
  }
};
