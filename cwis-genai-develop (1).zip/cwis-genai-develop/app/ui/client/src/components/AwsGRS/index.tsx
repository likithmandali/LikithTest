import React, { useContext, useEffect, useState } from 'react';
import {
  Accordion,
  Col,
  Row,
  Container,
  Form,
  Button,
  OverlayTrigger,
  Tooltip,
} from 'react-bootstrap';
import MultiSelectDropdown from '../TrustworthyLlm/DropdownBadge';
import InputBadgeCreator from '../TrustworthyLlm/inputbadge';
import { FaInfoCircle } from 'react-icons/fa';
import UserContext from '../../context/UserContext';
import {
  azure_pii_entity_options,
  pii_entity_options,
} from '../../utils/llmGuardOptions';
import { AccordionStates, AwsBedrockPayload, ToggleStates } from '../../types';
import {
  ADMIN,
  PII_TYPES,
  CONTENT_FILTERS,
  SUPERADMIN,
  WORD_FILTERS,
  AWS_CLOUD,
  AZURE_CLOUD,
  CONTENT_SAFETY,
} from '../../utils/constants';
import axios from 'axios';
import SliderComponent from './SliderComponent';

interface AwsGRSProps {
  instanceId: any;
  nextStep: any;
  prevStep: any;
  setShowNewInstanceModal: any;
  instanceDetails?: any;
  isBedrockDisabled?: boolean;
  cloudProvider: string;
}

const AwsGuardRails: React.FC<AwsGRSProps> = ({
  instanceId,
  nextStep,
  prevStep,
  setShowNewInstanceModal,
  instanceDetails,
  isBedrockDisabled = false,
  cloudProvider,
}) => {
  const [toggles, setToggles] = React.useState<ToggleStates>({
    PII_TYPES: true,
    CONTENT_FILTERS: false,
    CONTENT_SAFETY: false,
    WORD_FILTERS: false,
  });
  const [activeKeys, setActiveKeys] = useState<AccordionStates>({});
  const userRole = JSON.parse(sessionStorage.getItem('role') || '{}');
  const [sexualSliderValue, setSexualSliderValue] = useState<string>('HIGH');
  const [insultSliderValue, setInsultSliderValue] = useState<string>('HIGH');
  const [hateSliderValue, setHateSliderValue] = useState<string>('HIGH');
  const [violenceSliderValue, setViolenceSliderValue] =
    useState<string>('HIGH');
  const [misconductSliderValue, setMisconductSliderValue] =
    useState<string>('HIGH');
  const [selfHarmSliderValue, setSelfHarmSliderValue] =
    useState<string>('HIGH');
  const [llmGuard, setLlmGuard] = useState<AwsBedrockPayload>({
    instance_id: instanceId,
    pii_types:
      cloudProvider === AWS_CLOUD
        ? [
            'PHONE',
            'EMAIL',
            'CREDIT_DEBIT_CARD_NUMBER',
            'US_PASSPORT_NUMBER',
            'CREDIT_DEBIT_CARD_CVV',
            'CREDIT_DEBIT_CARD_EXPIRY',
            'US_SOCIAL_SECURITY_NUMBER',
            'INTERNATIONAL_BANK_ACCOUNT_NUMBER',
          ]
        : [
            'PHONE_NUMBER',
            'EMAIL',
            'CREDIT_CARD_NUMBER',
            'IBAN_NUMBER',
            'US_SOCIAL_SECURITY_NUMBER',
            'US_UK_PASSPORT_NUMBER',
          ],
    ...(cloudProvider === AWS_CLOUD
      ? {
          words_to_block: [],
          content_filter: [
            { type: 'SEXUAL', strength: sexualSliderValue },
            { type: 'VIOLENCE', strength: violenceSliderValue },
            { type: 'HATE', strength: hateSliderValue },
            { type: 'INSULTS', strength: insultSliderValue },
            { type: 'MISCONDUCT', strength: misconductSliderValue },
          ],
        }
      : {
          content_safety: [
            { type: 'SEXUAL', strength: sexualSliderValue },
            { type: 'VIOLENCE', strength: violenceSliderValue },
            { type: 'HATE', strength: hateSliderValue },
            { type: 'SELF_HARM', strength: selfHarmSliderValue },
          ],
        }),
  });

  const userContext = useContext(UserContext) || {
    setShowToast: () => {},
    setShowErrMsg: () => {},
    setErrorMessage: () => {},
  };
  const { setShowToast, setShowErrMsg, setErrorMessage } = userContext;

  const handleToggleChange = (id: string, value: boolean) => {
    setToggles((prevToggles) => ({
      ...prevToggles,
      [id]: value,
    }));
    if (!value) {
      setActiveKeys((prevActiveKeys) => ({
        ...prevActiveKeys,
        [id]: null,
      }));
    }
  };

  const handleAccordionToggle = (id: string, eventKey: string) => {
    if (toggles[id]) {
      setActiveKeys((prevActiveKeys) => ({
        ...prevActiveKeys,
        [id]: prevActiveKeys[id] === eventKey ? null : eventKey,
      }));
    }
  };

  const updateAnonymizeParams = (key: any, value: any, type: any) => {
    setLlmGuard((prevState) => ({
      ...prevState,
      [key]: value,
    }));
  };

  //   const isLlmGuardEmpty = () => {
  //     for (let scanner of llmGuard.content_filter) {
  //       if (toggles[scanner.type]) {
  //         switch (scanner.type) {
  //           //   case BanCompetitors:
  //           //     if (scanner.params.competitors?.length === 0) return true;
  //           //     break;
  //           //   case BanSubstrings:
  //           //     if (scanner.params.substrings?.length === 0) return true;
  //           //     break;
  //           //   case BanTopics:
  //           //     if (scanner.params.topics?.length === 0) return true;
  //           //     break;
  //           //   case Regex:
  //           //     if (scanner.params.patterns?.length === 0) return true;
  //           //     break;
  //           default:
  //             break;
  //         }
  //       }
  //     }
  //     return false;
  //   };

  const handlePiiTypesDropDown = (value: any) => {
    const selectedValue = value;
    updateAnonymizeParams('pii_types', selectedValue, PII_TYPES);
  };

  const setHiddenNames = (newNames: any) => {
    updateAnonymizeParams('words_to_block', newNames, WORD_FILTERS);
  };

  useEffect(() => {
    setLlmGuard((prevState) => ({
      ...prevState,
      content_filter: [
        { strength: sexualSliderValue, type: 'SEXUAL' },
        { strength: violenceSliderValue, type: 'VIOLENCE' },
        { strength: hateSliderValue, type: 'HATE' },
        { strength: insultSliderValue, type: 'INSULTS' },
        { strength: misconductSliderValue, type: 'MISCONDUCT' },
      ],
      content_safety: [
        { type: 'SEXUAL', strength: sexualSliderValue },
        { type: 'VIOLENCE', strength: violenceSliderValue },
        { type: 'HATE', strength: hateSliderValue },
        { type: 'SELF_HARM', strength: selfHarmSliderValue },
      ],
    }));
  }, [
    sexualSliderValue,
    violenceSliderValue,
    hateSliderValue,
    insultSliderValue,
    misconductSliderValue,
    selfHarmSliderValue,
  ]);

  useEffect(() => {
    if (
      isBedrockDisabled &&
      instanceDetails &&
      instanceDetails.scannerConfigs
    ) {
      const { scannerConfigs } = instanceDetails;
      setLlmGuard({
        instance_id: instanceId,
        pii_types:
          scannerConfigs?.pii_types?.length > 0
            ? scannerConfigs?.pii_types
            : [],
        words_to_block: scannerConfigs?.words_to_block || [],
        content_filter: scannerConfigs?.content_filter || [],
        content_safety: scannerConfigs?.content_safety || [],
      });

      setSexualSliderValue(
        (
          scannerConfigs?.content_filter || scannerConfigs?.content_safety
        )?.find((filter: any) => filter.type === 'SEXUAL')?.strength || 'NONE'
      );
      setViolenceSliderValue(
        (
          scannerConfigs?.content_filter || scannerConfigs?.content_safety
        )?.find((filter: any) => filter.type === 'VIOLENCE')?.strength || 'NONE'
      );
      setHateSliderValue(
        (
          scannerConfigs?.content_filter || scannerConfigs?.content_safety
        )?.find((filter: any) => filter.type === 'HATE')?.strength || 'NONE'
      );
      setInsultSliderValue(
        scannerConfigs?.content_filter?.find(
          (filter: any) => filter.type === 'INSULTS'
        )?.strength || 'NONE'
      );
      setMisconductSliderValue(
        scannerConfigs?.content_filter?.find(
          (filter: any) => filter.type === 'MISCONDUCT'
        )?.strength || 'NONE'
      );
      setSelfHarmSliderValue(
        scannerConfigs?.content_safety?.find(
          (filter: any) => filter.type === 'SELF_HARM'
        )?.strength || 'NONE'
      );
      setToggles((prevState) => {
        const newState = { ...prevState };
        newState[PII_TYPES] = scannerConfigs?.pii_types?.length > 0;
        newState[CONTENT_FILTERS] = scannerConfigs?.content_filter?.length > 0;
        newState[WORD_FILTERS] = scannerConfigs?.words_to_block?.length > 0;
        newState[CONTENT_SAFETY] = scannerConfigs?.content_safety?.length > 0;
        return newState;
      });
    } else {
      setLlmGuard({
        instance_id: instanceId,
        pii_types: llmGuard.pii_types,
        words_to_block: llmGuard.words_to_block,
        content_filter: llmGuard.content_filter,
        content_safety: llmGuard.content_safety,
      });
      setSexualSliderValue('HIGH');
      setViolenceSliderValue('HIGH');
      setHateSliderValue('HIGH');
      setInsultSliderValue('HIGH');
      setMisconductSliderValue('HIGH');
      setSelfHarmSliderValue('HIGH');
      setToggles({
        PII_TYPES: true,
        CONTENT_FILTERS: false,
        CONTENT_SAFETY: false,
        WORD_FILTERS: false,
      });
      setToggles((prevState) => {
        const newState = { ...prevState };
        newState[PII_TYPES] = true;
        newState[CONTENT_FILTERS] = false;
        newState[CONTENT_SAFETY] = false;
        newState[WORD_FILTERS] = false;
        return newState;
      });
    }
  }, [instanceDetails, isBedrockDisabled]);

  const finalAPiCall = async (payload: any) => {
    try {
      const createGRSApi = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/bedrock/guardrails-create`;
      const updateGRSApi = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/bedrock/update/guardrails`;
      const azureGRSApi = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/guardrails/create-update`;
      let url;
      if (cloudProvider === AWS_CLOUD) {
        url = isBedrockDisabled ? updateGRSApi : createGRSApi;
      } else url = azureGRSApi;
      const response = await axios.post(url, payload, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const responseData = response.data;
      if (response.status === 200) {
        nextStep();
        setShowToast(false);
        return responseData;
      } else {
        const error = responseData?.error;
        setShowToast(true);
        setShowErrMsg(error?.errorMessage);
        // console.error('response error', error);
        return;
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      console.error('Error:', error);
      return err;
    }
  };

  const handleFinalClick = () => {
    const basePayload = {
      instance_id: instanceId,
      pii_types: toggles[PII_TYPES] ? llmGuard.pii_types : [],
    };
    if (cloudProvider === AWS_CLOUD) {
      const filteredContentFilter = llmGuard.content_filter?.filter(
        (filter) => {
          if (filter.type === 'SEXUAL' && toggles[CONTENT_FILTERS]) return true;
          if (filter.type === 'VIOLENCE' && toggles[CONTENT_FILTERS])
            return true;
          if (filter.type === 'HATE' && toggles[CONTENT_FILTERS]) return true;
          if (filter.type === 'INSULTS' && toggles[CONTENT_FILTERS])
            return true;
          if (filter.type === 'MISCONDUCT' && toggles[CONTENT_FILTERS])
            return true;
          return false;
        }
      );
      const payload: AwsBedrockPayload = {
        ...basePayload,
        words_to_block: toggles[WORD_FILTERS] ? llmGuard.words_to_block : [],
        content_filter: toggles[CONTENT_FILTERS] ? filteredContentFilter : [],
      };

      if (
        !toggles[PII_TYPES] &&
        !toggles[WORD_FILTERS] &&
        !toggles[CONTENT_FILTERS]
      ) {
        delete payload.pii_types;
        delete payload.words_to_block;
        delete payload.content_filter;
      }
      finalAPiCall(payload);
    } else {
      // Azure payload
      const filteredContentSafety = llmGuard.content_safety?.filter(
        (filter) => {
          if (filter.type === 'SEXUAL' && toggles[CONTENT_SAFETY]) return true;
          if (filter.type === 'VIOLENCE' && toggles[CONTENT_SAFETY])
            return true;
          if (filter.type === 'HATE' && toggles[CONTENT_SAFETY]) return true;
          if (filter.type === 'SELF_HARM' && toggles[CONTENT_SAFETY])
            return true;
          return false;
        }
      );

      const payload = {
        ...basePayload,
        content_safety: toggles[CONTENT_SAFETY] ? filteredContentSafety : [],
      };

      if (!toggles[PII_TYPES] && !toggles[CONTENT_SAFETY]) {
        delete payload.pii_types;
        delete payload.content_safety;
      }
      finalAPiCall(payload);
    }
  };

  return (
    <div>
      <Container style={{ maxHeight: '400px', overflow: 'scroll' }}>
        <Row className="justify-content-md-center">
          <div className="mb-2">
            <b>Privacy</b>
          </div>
          <Row>
            <Col xs md="2">
              <Form.Check
                type="switch"
                id="pii-switch"
                checked={toggles[PII_TYPES]}
                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                  handleToggleChange(PII_TYPES, event.target.checked);
                }}
              />
            </Col>
            <Col xs md="8">
              <Accordion
                activeKey={toggles[PII_TYPES] ? activeKeys[PII_TYPES] : null}
                onSelect={(eventKey) =>
                  handleAccordionToggle(PII_TYPES, eventKey as string)
                }
              >
                <Accordion.Item eventKey="0">
                  <Accordion.Header>{PII_TYPES}</Accordion.Header>
                  <Accordion.Body className="accordion-body-container">
                    <MultiSelectDropdown
                      options={
                        cloudProvider === AWS_CLOUD
                          ? pii_entity_options
                          : azure_pii_entity_options
                      }
                      label="Select PII types to Anonymize"
                      setSelectedOption={handlePiiTypesDropDown}
                      isdisabled={!toggles[PII_TYPES]}
                      selectedEntity={
                        isBedrockDisabled
                          ? instanceDetails?.scannerConfigs?.pii_types
                          : llmGuard?.pii_types
                      }
                    />
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </Col>
            <Col xs md="2">
              <OverlayTrigger
                placement="right"
                delay={{ show: 250, hide: 400 }}
                overlay={
                  <Tooltip>
                    Specify the types of PII to be filtered and masked.
                  </Tooltip>
                }
              >
                <div style={{ width: 'fit-content' }}>
                  <FaInfoCircle />
                </div>
              </OverlayTrigger>
            </Col>
          </Row>
          <Row>
            <Col xs md="2">
              <Form.Check
                type="switch"
                id="content-filter-switch"
                checked={
                  cloudProvider === AWS_CLOUD
                    ? toggles[CONTENT_FILTERS]
                    : toggles[CONTENT_SAFETY]
                }
                onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                  handleToggleChange(
                    cloudProvider === AWS_CLOUD
                      ? CONTENT_FILTERS
                      : CONTENT_SAFETY,
                    event.target.checked
                  );
                }}
              />
            </Col>
            <Col xs md="8">
              <Accordion
                activeKey={
                  cloudProvider === AWS_CLOUD
                    ? toggles[CONTENT_FILTERS]
                      ? activeKeys[CONTENT_FILTERS]
                      : null
                    : toggles[CONTENT_SAFETY]
                      ? activeKeys[CONTENT_SAFETY]
                      : null
                }
                onSelect={(eventKey) =>
                  handleAccordionToggle(
                    cloudProvider === AWS_CLOUD
                      ? CONTENT_FILTERS
                      : CONTENT_SAFETY,
                    eventKey as string
                  )
                }
              >
                <Accordion.Item eventKey="0">
                  <Accordion.Header>
                    {cloudProvider === AWS_CLOUD
                      ? CONTENT_FILTERS
                      : CONTENT_SAFETY}
                  </Accordion.Header>
                  <Accordion.Body className="accordion-body-container">
                    <SliderComponent
                      mainLabel="Hate"
                      sliderValue={hateSliderValue}
                      setSliderValue={setHateSliderValue}
                      // isBedrockDisabled={isBedrockDisabled}
                    />
                    <SliderComponent
                      mainLabel="Sexual"
                      sliderValue={sexualSliderValue}
                      setSliderValue={setSexualSliderValue}
                    />
                    <SliderComponent
                      mainLabel="Violence"
                      sliderValue={violenceSliderValue}
                      setSliderValue={setViolenceSliderValue}
                    />
                    {cloudProvider === AWS_CLOUD && (
                      <>
                        <SliderComponent
                          mainLabel="Insults"
                          sliderValue={insultSliderValue}
                          setSliderValue={setInsultSliderValue}
                        />
                        <SliderComponent
                          mainLabel="Misconduct"
                          sliderValue={misconductSliderValue}
                          setSliderValue={setMisconductSliderValue}
                        />
                      </>
                    )}
                    {cloudProvider === AZURE_CLOUD && (
                      <SliderComponent
                        mainLabel="Self Harm"
                        sliderValue={selfHarmSliderValue}
                        setSliderValue={setSelfHarmSliderValue}
                      />
                    )}
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </Col>
            <Col xs md="2">
              <OverlayTrigger
                placement="right"
                delay={{ show: 250, hide: 400 }}
                overlay={
                  <Tooltip>
                    Content {cloudProvider === AWS_CLOUD ? 'filter' : 'safety'}{' '}
                    can detect and filter harmful inputs
                    {cloudProvider === AWS_CLOUD
                      ? ' and model responses.'
                      : '.'}{' '}
                    You can configure thresholds to adjust the degree of
                    filtering across based on your use cases and block content
                    that violates your usage policies.
                  </Tooltip>
                }
              >
                <div style={{ width: 'fit-content' }}>
                  <FaInfoCircle />
                </div>
              </OverlayTrigger>
            </Col>
          </Row>
          {cloudProvider === AWS_CLOUD && (
            <Row>
              <Col xs md="2">
                <Form.Check
                  type="switch"
                  id="word-filter-switch"
                  checked={toggles[WORD_FILTERS]}
                  onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                    handleToggleChange(WORD_FILTERS, event.target.checked);
                  }}
                />
              </Col>
              <Col xs md="8">
                <Accordion
                  activeKey={
                    toggles[WORD_FILTERS] ? activeKeys[WORD_FILTERS] : null
                  }
                  onSelect={(eventKey) =>
                    handleAccordionToggle(WORD_FILTERS, eventKey as string)
                  }
                >
                  <Accordion.Item eventKey="0">
                    <Accordion.Header>{WORD_FILTERS}</Accordion.Header>
                    <Accordion.Body className="accordion-body-container">
                      <Form.Label> Add custom words to hide</Form.Label>
                      <InputBadgeCreator
                        label="Hidden Names"
                        keywordBadges={
                          instanceDetails?.scannerConfigs?.words_to_block
                        }
                        setKeywordBadge={setHiddenNames}
                        isdisabled={!toggles[WORD_FILTERS]}
                      />
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </Col>
              <Col xs md="2">
                <OverlayTrigger
                  placement="right"
                  delay={{ show: 250, hide: 400 }}
                  overlay={
                    <Tooltip>
                      Use these filters to mask certain words and phrases in
                      user inputs and model responses.
                    </Tooltip>
                  }
                >
                  <div style={{ width: 'fit-content' }}>
                    <FaInfoCircle />
                  </div>
                </OverlayTrigger>
              </Col>
            </Row>
          )}
        </Row>
      </Container>
      <div className="two-button-container">
        <Button
          variant="primary"
          onClick={() => prevStep()}
          className="secondary-btn-style modal-button"
        >
          Back
        </Button>
        {userRole && (userRole === ADMIN || userRole === SUPERADMIN) && (
          <Button
            variant="primary"
            onClick={() => handleFinalClick()}
            className="modal-button"
            // disabled={isLlmGuardEmpty()}
          >
            Next
          </Button>
        )}
      </div>
    </div>
  );
};

export default AwsGuardRails;
