import React from 'react';
import { Form } from 'react-bootstrap';
import './AwsGRS.css';

interface SliderProps {
  mainLabel: string;
  sliderValue: string;
  setSliderValue: React.Dispatch<React.SetStateAction<string>>;
  isBedrockDisabled?: boolean;
}

const SliderComponent: React.FC<SliderProps> = ({
  mainLabel,
  sliderValue,
  setSliderValue,
  isBedrockDisabled = false,
}) => {
  const handleSliderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(event.target.value);
    const sliderValues = ['NONE', 'LOW', 'MEDIUM', 'HIGH'];
    setSliderValue(sliderValues[value]);
  };

  const sliderLabels = ['None', 'Low', 'Medium', 'High'];
  const sliderValues = ['NONE', 'LOW', 'MEDIUM', 'HIGH'];

  return (
    <div className="slider-container">
      <Form.Label className="label-text bottom-margin">{mainLabel}</Form.Label>
      <div className="custom-width">
        <Form.Range
          min={0}
          max={3}
          step={1}
          value={sliderValues.indexOf(sliderValue)}
          onChange={handleSliderChange}
          disabled={isBedrockDisabled}
        />
        <div className="d-flex justify-content-between labels-font">
          {sliderLabels.map((label, index) => (
            <span key={index}>{label}</span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SliderComponent;
