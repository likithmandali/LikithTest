import React, { useContext, useEffect } from 'react';
import { Accordion, Button, Card, Col, Form, Row } from 'react-bootstrap';
import CustomReactTextareaAutocomplete from '../../utils/CustomReactTextareaAutocomplete.js';
import { ItemComponentProps } from '@webscopeio/react-textarea-autocomplete';
import { Knowledge } from '../../interfaces.js';
import { title } from 'process';
import { TCG_BASIC_MODE } from '../../utils/defaultTemplatePrompts';
import { brotliDecompress } from 'zlib';
import './TCGBasicTemplateMode.css';
import { FaTimes } from 'react-icons/fa';
import UserContext from '../../context/UserContext';
import { string } from 'prop-types';
import { WidthType } from 'docx';
import { TCGTemplatePromptPoints } from '../../utils/constants';

interface BasicModeTemplatePromptProps {
  instanceDetails: any;
  knowledgeId: any;
  templatePrompt: any;
  handleTemplatePromptChange: any;
  handleLayoutChange: any;
  editMode?: boolean;
  selectedLayoutKey?: string;
  selectedTemplateHeadings?: any[];
}
const BasicModeTemplatePrompt: React.FC<BasicModeTemplatePromptProps> = ({
  instanceDetails,
  knowledgeId,
  templatePrompt,
  handleTemplatePromptChange,
  handleLayoutChange,
  editMode,
  selectedLayoutKey,
  selectedTemplateHeadings,
}) => {
  const [addedPoints, setAddedPoints] = React.useState<string[]>([]);
  const [newPoint, setNewPoint] = React.useState<string>('');
  const [selectedLayout, setSelectedLayout] = React.useState<string>('');
  const [imageEnlarge, setImageEnlarge] = React.useState<boolean>(false);
  const userContext = useContext(UserContext) || {
    selectedPoints: [] as string[],
    setSelectedPoints: (points: string[]) => {},
  };
  const { selectedPoints, setSelectedPoints } = userContext;

 const templatePromptPoints = TCGTemplatePromptPoints
  const filteredPoints = selectedPoints?.filter((point) => {
    return !templatePromptPoints
      .map((point) => point.points)
      .flat()
      .includes(point);

  });
 
  const handleSelectedLayout = (layout: string) => {
    handleLayoutChange(layout);
  };
  return (
    <>
      <div style={{ display: 'block', overflowY: 'auto', width: '100%' }}>
        {templatePromptPoints.map((point, index) => {
          return (
            <div key={index}>
              {/* <Form.Label className="label-text">{point.title === 'Added Points'?point.points.length>0&&point.title:point.title}</Form.Label>
            {point.points.map((point, index) => { 
                
                return(
              <div key={index} style={{ display: 'block' }}>
                <Form.Check
                  type="checkbox"
                  label={point}
                  checked={selectedPoints.includes(point)}
                  onChange={()=>{
                    if(selectedPoints.includes(point)){

                      setSelectedPoints(selectedPoints.filter((item) => item !== point));

                    }else{
                        setSelectedPoints([...selectedPoints, point]);
                    }
                  }}
                />
              </div>
            )})} */}
              <Accordion>
                <Accordion.Item eventKey="0">
                  <Accordion.Header>{point.title}</Accordion.Header>
                  <Accordion.Body>
                    {point.points.map((point, index) => {
                      return (
                        <div key={index} style={{ display: 'block' }}>
                          <Form.Check
                            type="checkbox"
                            label={point}
                            checked={
                              selectedPoints && selectedPoints?.includes(point)
                            }
                            onChange={() => {
                              if (selectedPoints?.includes(point)) {
                                setSelectedPoints(
                                  selectedPoints.filter(
                                    (item) => item !== point
                                  )
                                );
                              } else {
                                setSelectedPoints([...selectedPoints, point]);
                              }
                            }}
                          />
                        </div>
                      );
                    })}
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </div>
          );
        })}
        {addedPoints?.length > 0 && (
          <>
          <Accordion>
            <Accordion.Item eventKey="1">
              <Accordion.Header>Added Points</Accordion.Header>
              <Accordion.Body>
                {addedPoints.map((point, index) => (
                  <div key={index}>
                    <Form.Check
                      type="checkbox"
                      label={point}
                      checked={selectedPoints?.includes(point)}
                      onChange={() => {
                        if (selectedPoints.includes(point)) {
                          setSelectedPoints(
                            selectedPoints.filter((item) => item !== point)
                          );
                        } else {
                          setSelectedPoints([...selectedPoints, point]);
                        }
                      }}
                    />
                  </div>
                ))}
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
          </>
        )}
        <div style={{justifyContent:'center',marginTop:'32px'}}>
          <div>
          <Form.Label className="label-text">Add New Point</Form.Label>
          <Row style={{width:'100%'}}>
            <Col sm={9}>
          <Form.Control
            type="text"
            value={newPoint}
            onChange={(e) => setNewPoint(e.target.value)}
          />
          </Col>
          <Col sm={3}>
          <Button
           style={{background:'green'}}
            onClick={() => {
              selectedPoints.push(newPoint);
              setAddedPoints([...addedPoints, newPoint]);
              setNewPoint('');
            }}
          >
            Add Point
          </Button>
          </Col>
          </Row>
          </div>
        </div>

      
      </div>
    </>
  );
};

export default BasicModeTemplatePrompt;
