import Spinner from 'react-bootstrap/Spinner';

import './Loader.css';

function ContentLoader() {
  return (
    <div className="loader-container">
      <Spinner animation="grow" role="status" size="sm">
        <span className="visually-hidden">Loading...</span>
      </Spinner>
    </div>
  );
}

export default ContentLoader;
