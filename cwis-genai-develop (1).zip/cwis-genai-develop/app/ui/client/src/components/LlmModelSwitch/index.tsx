import React, { useEffect, useContext } from 'react';
import { Form } from 'react-bootstrap';
import UserContext, { UserContextType } from '../../context/UserContext';
import { Appl } from '../../interfaces';
import { useParams } from 'react-router-dom';

interface LlmModelSwitchProps {}

const LlmModelSwitch: React.FC<LlmModelSwitchProps> = () => {
  const { appUrl } = useParams();
  const apps = JSON.parse(sessionStorage.getItem('apps') as string) as Appl[];
  const currentApp = apps.find((app) => app.url === appUrl);

  const userContext = useContext(UserContext) || {
    localSelectedModel: '',
    setLocalSelectedModel: () => {},
  };
  const { localSelectedModel, setLocalSelectedModel } =
    userContext as UserContextType;

  useEffect(() => {
    localStorage.setItem('selectedModel', localSelectedModel);
  }, [localSelectedModel]);

  const handleDropdownChange = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setLocalSelectedModel(event.target.value);
  };

  return (
    <Form.Group className="user-input" controlId="llmModelSwitch">
      {currentApp?.name === 'Scan to Summify Engine' ? (
        <Form.Select
          defaultValue="Azure"
          value={localSelectedModel}
          onChange={handleDropdownChange}
        >
          <option value="Azure">Azure</option>
          <option value="GCP">GCP</option>
        </Form.Select>
      ) : (
        <Form.Select
          defaultValue="Azure"
          value={localSelectedModel}
          onChange={handleDropdownChange}
        >
          <option value="Azure">Azure</option>
          <option value="GCP">GCP</option>
          <option value="PrivateLLM">Private LLM</option>
        </Form.Select>
      )}
    </Form.Group>
  );
};

export default LlmModelSwitch;
