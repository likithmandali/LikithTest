import React, { useEffect, useState, useRef, useContext } from 'react';
import {
  Col,
  Container,
  Form,
  Row,
  Button,
  Badge,
  Spinner,
  Tab,
  Tabs,
  Accordion,
  Modal,
} from 'react-bootstrap';
import axios from 'axios';
import { fixNewlineChars } from '../../utils/stringProcessing';
import { isValidImageUrl } from '../../utils/security';
import './InstanceGenerator.css';
import UserContext from '../../context/UserContext';
import { Appl, ChunkingParams } from '../../interfaces';
import { useParams } from 'react-router-dom';
import { Knowledge } from '../../interfaces';
import { ItemComponentProps } from '@webscopeio/react-textarea-autocomplete';
import CustomReactTextareaAutocomplete from '../../utils/CustomReactTextareaAutocomplete.js';
import ProgressBar from 'react-bootstrap/ProgressBar';
import { getEncoding } from 'js-tiktoken';
import {
  CALL_CENTER_PROMPT_AWS,
  CALL_CENTER_PROMPT_AZURE,
  CALL_CENTER_PROMPT_GCP,
  DEFAULT_TEMPLATE_PROMPT,
  DEVELOPER_HELP_PROMPT_AWS,
  DEVELOPER_HELP_PROMPT_AZURE,
  DEVELOPER_HELP_PROMPT_GCP,
  DOC_INSIGHTS_PROMPT_AWS,
  DOC_INSIGHTS_PROMPT_AZURE,
  DOC_INSIGHTS_PROMPT_GCP,
  HELP_DESK_PROMPT_AWS,
  HELP_DESK_PROMPT_AZURE,
  HELP_DESK_PROMPT_GCP,
  HELP_ENGINE_PROMPT_AWS,
  HELP_ENGINE_PROMPT_AZURE,
  HELP_ENGINE_PROMPT_GCP,
  MEETING_SUMMARIZER_PROMPT_AWS,
  MEETING_SUMMARIZER_PROMPT_AZURE,
  MEETING_SUMMARIZER_PROMPT_GCP,
  NOTICE_ENGINE_PROMPT_AWS,
  NOTICE_ENGINE_PROMPT_AZURE,
  NOTICE_ENGINE_PROMPT_GCP,
  POLICY_ENGINE_PROMPT_AWS,
  POLICY_ENGINE_PROMPT_AZURE,
  POLICY_ENGINE_PROMPT_GCP,
  SALES_ENGINE_PROMPT_AWS,
  SALES_ENGINE_PROMPT_AZURE,
  SALES_ENGINE_PROMPT_GCP,
  SCAN_TO_SUMMIFY_PROMPT_AWS,
  SCAN_TO_SUMMIFY_PROMPT_AZURE,
  SCAN_TO_SUMMIFY_PROMPT_GCP,
  STATUS_REPORT_PROMPT_AWS,
  STATUS_REPORT_PROMPT_AZURE,
  STATUS_REPORT_PROMPT_GCP,
  TEST_SCRIPT_PROMPT_AWS,
  TEST_SCRIPT_PROMPT_AZURE,
  TEST_SCRIPT_PROMPT_GCP,
  USER_STORY_PROMPT_AWS,
  USER_STORY_PROMPT_AZURE,
  USER_STORY_PROMPT_GCP,
  TCG_BASIC_MODE,
} from '../../utils/defaultTemplatePrompts';

import KnowledgeTable from '../KnowledgeIdTable';
import {
  KNOWLEDGE_IDS,
  USER_STORY_GENERATOR,
  SALES_ENGINE,
  MEETING_SUMMARIZER,
  STATUS_REPORT_GENERATOR,
  TEST_SCRIPT_GENERATOR,
  SCAN_TO_SUMMIFY,
  HELP_DESK_ENGINE,
  NOTICE_ENGINE,
  CALL_CENTER,
  DOC_INSIGHT,
  DEVELOPER_HELP_ENGINE,
  POLICY_ENGINE,
  HELP_ENGINE,
  NOTICE_ANALYSIS_ENGINE,
  CHANGE_COMMUNICATOR,
  WEAVIATE,
  PGVECTOR,
  ADMIN,
  SUPERADMIN,
  fileUploadKnowledegenote1,
  fileUploadKnowledegenote2,
  customOutputColumnNote1,
  customOutputColumnNote3,
  customOutputColumnNote2,
  PDF,
  DOCX,
  TXT,
  XLSXFile,
  CSV,
  PPTX,
  PPT,
  KnowledgeNameError,
  TokenLimitError1,
  TokenLimitError2,
  AZURE_CLOUD,
  GCP_CLOUD,
  AWS_CLOUD,
  CFG_AI_CLOUD,
  OPENSEARCH_SERVERLESS,
  // model_recommended,
  GPT_4O,
  azure_recommended_model,
  gcp_recommended_model,
  aws_recommended_model,
  TCGTemplatePromptPoints,
} from '../../utils/constants';
import Stepper from '../Stepper';
// import TrusthWorthyLlmForm from '../TrustworthyLlm';
import TrusthWorthyLlmForm from '../TrustworthyLlm';
import { VectorDb } from '../../types';
import { nameStartingCheck } from '../../utils/nameStartingCheck';
import ToastMessage from '../ErrorMessage/ToastMessage';
import AwsGuardRails from '../AwsGRS';
import BasicModeTemplatePrompt from '../TCGBasicTemplatePromot';
import { FaTimes } from 'react-icons/fa';
import { FaTriangleExclamation } from 'react-icons/fa6';

type InstanceGeneratorProps = {
  currentStep: number;
  projectId: any;
  currentAppId: any;
  nextStep: any;
  setShowNewInstanceModal: any;
  step1?: boolean;
  step2?: boolean;
  step3?: boolean;
  step4?: boolean;
  isUploadtemplate?: boolean;
  isEditMode?: any;
  instanceDetails?: any;
  selectedInstance?: any;
  prevStep: any;
  isBackClicked?: boolean;
  getInstanceData?: any;
};

interface KeyValue {
  key: string;
  value: string;
}

type EmbeddingModel = {
  modelName: string;
  modelValue: string;
};
const AmazonTitanv2 = 'amazon.titan-embed-text-v2:0';
const initialEmbeddingModels = [
  { modelName: 'Azure OAI', modelValue: 'native_cloud' },
  { modelName: 'Ollama Mixedbread', modelValue: 'mxbai-embed-large' },
];

const commonEmbeddingModel = {
  modelName: 'Ollama Mixedbread',
  modelValue: 'mxbai-embed-large',
};

const getEmbeddingOptions = (cloudProvider: string): EmbeddingModel[] => {
  switch (cloudProvider) {
    case AZURE_CLOUD:
    case CFG_AI_CLOUD:
      return [
        { modelName: 'Azure OAI', modelValue: 'native_cloud' },
        commonEmbeddingModel,
      ];
    case GCP_CLOUD:
      return [
        { modelName: 'GCP Palm', modelValue: 'native_cloud' },
        commonEmbeddingModel,
      ];
    case AWS_CLOUD:
      return [
        { modelName: 'AWS Bedrock', modelValue: 'native_cloud' },
        commonEmbeddingModel,
      ];
    default:
      return [];
  }
};

const InstanceGenerator: React.FC<InstanceGeneratorProps> = ({
  currentStep,
  projectId,
  currentAppId,
  nextStep,
  prevStep,
  setShowNewInstanceModal,
  step1 = true,
  step2 = true,
  step3 = true,
  step4 = true,
  isUploadtemplate = false,
  isEditMode,
  instanceDetails,
  selectedInstance,
  isBackClicked,
  getInstanceData,
}) => {
  const { appUrl } = useParams();
  const apps = JSON.parse(sessionStorage.getItem('apps') as string) as Appl[];
  const currentApp = apps.find((app) => app.url === appUrl);
  const [knowledgeIDs, setKnowledgeIDs] = useState<any[]>([]);
  const [currentKnowledgeID, setCurrentKnowledgeID] = useState<any[]>([]);
  const [newKnowledgeID, setNewKnowledgeID] = useState<string>('');
  const [newTemplateName, setNewTemplateName] = useState<string>('');
  const [sliderValue, setSliderValue] = useState<number>(0.0);
  const [chunkSizeValue, setChunkSizeValue] = useState<number>(2000);
  const [kNearChunksValue, setKNearChunksValue] = useState<number>(6);
  const [overLapPercent, setOverLapPercent] = useState<number>(15);
  // Parsing Strategy State
  const [parsingStrategy, setParsingStrategy] = useState<string>('DEFAULT');
  const [childMaxTokens, setchildMaxTokens] = useState<number>(500);
  const [bufferSize, setBufferSize] = useState<number>(1);
  const [breakPointPercent, setBreakPointPercent] = useState<number>(95);
  const [instanceName, setInstanceName] = useState<string>('');
  const [flowId, setFlowid] = useState<string>('');
  const [count, setCount] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [templatePrompt, setTemplatePrompt] = useState<string>('');
  const [totalSteps, setTotalSteps] = useState<number>();
  const [fileId, setFileId] = useState<any[]>([]);
  const [showFileUploadSuccessMsg, setShowFileUploadSuccessMsg] =
    useState<Boolean>(false);
  const filesSelectedForUploadRef = useRef<HTMLInputElement>(null);
  const knowledgeFileUpload = useRef<HTMLInputElement>(null);
  const [chunkingStrategy, setChunkingStrategy] = useState('FIXED_SIZE');
  const [grsType, setGrsType] = useState('aws_bedrock');
  const [keyValues, setKeyValues] = useState<KeyValue[]>([
    { key: '', value: '' },
  ]);
  const [instanceData, setInstanceData] = useState<any>(null);
  const [isUploadLoading, setIsUploadLoading] = useState<boolean>(false);
  const [isUploadSuccess, setIsUploadSuccess] = useState<boolean>(false);
  const [selectedOption, setSelectedOption] = useState('Automatic');
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set());
  const [isScannedDoc, setIsScannedDoc] = useState(false);
  const [renderMarkdown, setRenderMarkdown] = useState('No');
  // const [llmGuardOption, setLlmGuardOption] = useState('No');
  const [cloudProviderOptions, setCloudProviderOptions] = useState<any>([]);
  const [selectedModel, setSelectedModel] = useState<any>('');
  const [tokencount, setTokencount] = useState<number>(0);
  const [filetokencount, setFiletokencount] = useState<number>(0);
  const [knowledgeidAdded, setKnowlwdgeidAdded] = useState<boolean>(false);
  const [tokelimit, settokenlimit] = useState<any>();
  const [documentContents, setDocumentContents] = useState<string | null>(null);
  const dragOutputColumns = useRef<number>(0);
  const dragggedOutputColumns = useRef<number>(0);
  const [vectorDb, setVectorDb] = useState<VectorDb>();
  const userRole = JSON.parse(sessionStorage.getItem('role') || '{}');
  const [nameErrorCheck, setNameErrorCheck] = useState<boolean>(false);
  const [embeddingModels, setEmbeddingModels] = useState<EmbeddingModel[]>(
    initialEmbeddingModels
  );
  const [selectedTemplateHeadings, setSelectedTemplateHeadings] = useState<
    String[]
  >([]);
  const [embeddingModel, setEmbeddingModel] = useState(
    initialEmbeddingModels[0].modelValue
  );
  const [isBedrockDisabled, setIsBedrockDisabled] = useState<boolean>(false);
  const [knowledgeNameCheck, setKnowledgeNameCheck] = useState<boolean>(false);
  const [modelRecommendationMsg, setModelRecommendationMsg] =
    useState<string>('');
  const [basicTemplatePrompt, setBasicTemplatePrompt] = useState<string>('');
  const [templateInstructions, setTemplateInstructions] =
    useState<string>('Advanced');
  const [basicModeDescription, setBasicModeDescription] = useState<any>([]);
  const [descriptionError, setDescriptionError] = useState<boolean>(false);
  const [selectedLayout, setSelectedLayout] = useState<string>('');
  const [selectedPersona, setSelectedPersona] = useState<string>('');
  const [viewDefaultGuidelines, setViewDefaultGuidelines] =
    useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('');
  const [imageEnlarge, setImageEnlarge] = React.useState<boolean>(false);
  const [selectedKnowledgeIds, setSelectedKnowledgeIds] = useState<any>([]);
  const [selectedKnowledgeIdError, setSelectedKnowledgeIdError] =
    useState<boolean>(false);
  const [knowledgeUploadCheck, setKnowledgeUploadCheck] =
    useState<boolean>(false);
  const knowledgeUploadWarningRef = useRef<any>(null);
  const containerRef = useRef<any>(null);
  const [isKnowledgeUploadDisabled, setIsKnowledgeUploadDisabled] =
    useState<boolean>(false);
  const [hasVisitedKnowledgePage, setHasVisitedKnowledgePage] =
    useState<boolean>(isEditMode);
  const [models, setModels] = useState([
    {
      name: AZURE_CLOUD,
      models: [
        // {
        //   modelName: 'Latest (GPT-4o 128K)',
        //   modelValue: model_recommended,
        //   tokenSize: 126000,
        // },
        { modelName: 'GPT-4o 128K', modelValue: 'gpt-4o', tokenSize: 126000 },
        {
          modelName: 'GPT-4 Turbo 128K',
          modelValue: 'gpt-4-turbo',
          tokenSize: 126000,
        },
      ],
    },
    {
      name: GCP_CLOUD,
      models: [
        // {
        //   modelName: 'Latest (GEMINI 1.5 PRO)',
        //   modelValue: model_recommended,
        //   tokenSize: 1000000,
        // },
        {
          modelName: 'Gemini 2.0 Flash',
          modelValue: 'gemini-2.0-flash-001',
          tokenSize: 1048576,
        },
        {
          modelName: 'Gemini 2.0 Flash Lite',
          modelValue: 'gemini-2.0-flash-lite-preview-02-05',
          tokenSize: 1048576,
        },
        {
          modelName: 'Gemini 2.5 PRO',
          modelValue: 'gemini-2.5-pro-exp-03-25',
          tokenSize: 1048576,
        },
        // {
        //   modelName: 'GEMINI 1.5 PRO',
        //   modelValue: 'gemini-1.5-pro-preview-0409',
        //   tokenSize: 1000000,
        // },
        // {
        //   modelName: 'Gemini 1.0 Pro',
        //   modelValue: 'gemini-pro',
        //   tokenSize: 30760,
        // },
      ],
    },
    {
      name: AWS_CLOUD,
      models: [
        // {
        //   modelName: 'Latest (Claude V3.5 Sonnet)',
        //   modelValue: model_recommended,
        //   tokenSize: 200000,
        // },
        // {
        //   modelName: 'Claude V3.5 Sonnet_v2',
        //   modelValue: 'us.anthropic.claude-3-5-sonnet-20241022-v2:0',
        //   tokenSize: 200000,
        // },
        // {
        //   modelName: 'Claude V3.7 Sonnet',
        //   modelValue: 'us.anthropic.claude-3-7-sonnet-20250219-v1:0',
        //   tokenSize: 128000,
        // },
        {
          modelName: 'Claude V4 Sonnet',
          modelValue: 'us.anthropic.claude-sonnet-4-20250514-v1:0',
          tokenSize: 128000,
        },
        // {
        //   modelName: 'Claude V2-1',
        //   modelValue: 'anthropic.claude-v2:1',
        //   tokenSize: 198000,
        // },
        // {
        //   modelName: 'Jamba 1.5 Mini',
        //   modelValue: 'ai21.jamba-1-5-mini-v1:0',
        //   tokenSize: 256000,
        // },
        // {
        //   modelName: 'Jamba 1.5 Large',
        //   modelValue: 'ai21.jamba-1-5-large-v1:0',
        //   tokenSize: 256000,
        // },
        {
          modelName: 'Titan Text G1 - Premier',
          modelValue: 'amazon.titan-text-premier-v1:0',
          tokenSize: 32000,
        },
        {
          modelName: 'Titan Text G1 - Express',
          modelValue: 'amazon.titan-text-express-v1',
          tokenSize: 8000,
        },
        // {
        //   modelName: 'Titan Text G1 - Lite',
        //   modelValue: 'amazon.titan-text-lite-v1',
        //   tokenSize: 4000,
        // },
        // {
        //   modelName: 'Llama 3.2 1B',
        //   modelValue: 'us.meta.llama3-2-1b-instruct-v1:0',
        //   tokenSize: 131000,
        // },
        // {
        //   modelName: 'Llama 3.2 3B',
        //   modelValue: 'us.meta.llama3-2-3b-instruct-v1:0',
        //   tokenSize: 131000,
        // },
        // {
        //   modelName: 'Llama 3.2 11B',
        //   modelValue: 'us.meta.llama3-2-11b-instruct-v1:0',
        //   tokenSize: 128000,
        // },
        // {
        //   modelName: 'Mistral 7B Instruct',
        //   modelValue: 'mistral.mistral-7b-instruct-v0:2',
        //   tokenSize: 32000,
        // },
        // {
        //   modelName: 'Mixtral 8x7B Instruct',
        //   modelValue: 'mistral.mixtral-8x7b-instruct-v0:1',
        //   tokenSize: 32000,
        // },
        // {
        //   modelName: 'Mistral Large 24.02',
        //   modelValue: 'mistral.mistral-large-2402-v1:0',
        //   tokenSize: 32000,
        // },
        // {
        //   modelName: 'Mistral Small 24.02',
        //   modelValue: 'mistral.mistral-small-2402-v1:0',
        //   tokenSize: 32000,
        // },
      ],
    },
    {
      name: CFG_AI_CLOUD,
      models: [
        {
          modelName: 'Llama3-70B-Instruct',
          modelValue: 'Llama3-70B-Instruct',
          tokenSize: 198000,
        },
        {
          modelName: 'Mixtral-8x7B',
          modelValue: 'Mixtral-8x7B',
          tokenSize: 6192,
        },
        {
          modelName: 'Mistral-Orca',
          modelValue: 'Mistral-Orca',
          tokenSize: 6192,
        },
      ],
    },
  ]);
  const templatePromptPoints = TCGTemplatePromptPoints;
  const [uploadError, setUploadError] = useState(false);
  const userContext = useContext(UserContext) || {
    showToast: false,
    setShowToast: () => {},
    showErrMsg: '',
    setShowErrMsg: () => {},
    cloudProvider: AZURE_CLOUD,
    setCloudProvider: () => {},
    setSelectedInstance: () => {},
    llmGuardOption: '',
    setLlmGuardOption: () => {},
    queryExpansion: false,
    setQueryExpansion: () => {},
    outputColumns: [{ value: '' }],
    setOutputcolumns: () => {},
    setErrorMessage: () => {},
    selectedPoints: [],
    setSelectedPoints: () => {},
  };

  const {
    setShowToast,
    setShowErrMsg,
    cloudProvider,
    setCloudProvider,
    setSelectedInstance,
    llmGuardOption,
    setLlmGuardOption,
    queryExpansion,
    setQueryExpansion,
    outputColumns,
    setOutputcolumns,
    setErrorMessage,
    selectedPoints,
    setSelectedPoints,
  } = userContext;
  const Item: React.FC<ItemComponentProps<Knowledge>> = ({
    entity: { id, name },
  }) => <div>{`${id}: ${name}`}</div>;
  const Loading: any = ({}) => <div>Loading..</div>;
  useEffect(() => {
    setKnowledgeIDs(instanceDetails?.knowledgeIds);
    if (isEditMode) {
      const basicDescription = instanceDetails?.knowledgeIds?.map(
        (item: any) => {
          const matchedItem = instanceDetails?.metadata?.description?.find(
            (desc: any) => desc.id === item.id
          );
          return {
            id: item.id,
            description: matchedItem ? matchedItem.description : '',
          };
        }
      );
      setBasicModeDescription(basicDescription);
      // setTemplateInstructions(
      //   instanceDetails?.mode === true ? 'Basic' : 'Advanced'
      // );
      setSelectedPoints(instanceDetails?.metadata?.selectedPoints);
      // Validate the image URL from instanceDetails before setting it
      const layoutKey = instanceDetails?.metadata?.key;
      if (isValidImageUrl(layoutKey) || layoutKey === '') {
        setSelectedLayout(layoutKey);
      } else {
        console.warn('Invalid image URL from instanceDetails:', layoutKey);
        setSelectedLayout('');
      }
    }
    if (!isEditMode && knowledgeIDs?.length > 0) {
      setBasicModeDescription(
        knowledgeIDs.map((item: any, index: number) => {
          return { id: item.id, description: '' };
        })
      );
    }
  }, [instanceDetails]);
  const addKnowledgeID = async (id: string) => {
    setKnowledgeIDs([]);
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/knowledge/flow/${isEditMode ? instanceDetails.flow : id}`
      );

      if (response.status === 200) {
        setShowToast(false);
        const responseData = response.data;
        setKnowledgeIDs(responseData?.response);
        setBasicModeDescription(
          responseData?.response.map((item: any, index: number) => {
            return { id: item.id, description: '' };
          })
        );
        getInstanceData(isEditMode ? selectedInstance : instanceData?.id);
        setIsUploadLoading(false);
        setIsUploadSuccess(true);
        return responseData;
      } else {
        console.error('Get request failed');
        setIsUploadLoading(false);
        return;
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setShowErrMsg(err.errorMessage);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      console.error('Error:', error);
      setIsUploadLoading(false);
      return;
    }
  };
  const handleTemplateNameChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setNewTemplateName(event.target.value);
  };

  const handleSliderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseFloat(event.target.value);
    setSliderValue(newValue);
  };

  const handleChunkSizeChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newValue = parseFloat(event.target.value);
    setChunkSizeValue(newValue);
  };

  // Handler for overlapPercent
  const handleOverlapPercentChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newValue = parseFloat(event.target.value);
    setOverLapPercent(newValue);
  };

  // Handler for bufferSize
  const handleBufferSizeChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newValue = parseFloat(event.target.value);
    setBufferSize(newValue);
  };

  // Handler for breakPointPercent (breakpointChunking)
  const handleBreakPointPercentChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newValue = parseFloat(event.target.value);
    setBreakPointPercent(newValue);
  };

  // Handler for childMaxTokens
  const handleChildMaxTokensChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const newValue = parseFloat(event.target.value);
    setchildMaxTokens(newValue);
  };
  // Handler for parsingStrategy
  const handleParsingStrategyChange = (
    event: React.ChangeEvent<HTMLSelectElement>
  ) => {
    setParsingStrategy(event.target.value);
  };

  useEffect(() => {
    if (isEditMode || isBackClicked) {
      if (instanceDetails?.cloudEnvironment === 'aws') {
        if (instanceDetails?.llm_guard_value === 'aws_bedrock') {
          setIsBedrockDisabled(true);
        } else {
          setIsBedrockDisabled(false);
        }
      } else {
        setIsBedrockDisabled(false);
      }
    }
  }, [isEditMode, isBackClicked, instanceDetails]);

  const handleAddDecriptin = (
    event: React.ChangeEvent<HTMLInputElement>,
    id: any
  ) => {
    setDescriptionError(false);
    setShowToast(false);
    if (basicModeDescription.filter((item: any) => item.id === id).length > 0) {
      basicModeDescription.map((item: any) => {
        if (item.id === id) {
          item.description = event;
        }
      });
    } else {
      setBasicModeDescription([
        ...basicModeDescription,
        { id: id, description: event },
      ]);
    }
  };

  const handleInstanceCreation = async (payload: any) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/instance/create-instance`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      const responseData = response.data;
      if (response.status === 200) {
        setShowToast(false);
        setShowErrMsg('');
        const instanceData = responseData?.response;
        setSelectedInstance(instanceData?.id);
        setInstanceData(instanceData);
        setFlowid(instanceData?.flow);
        nextStep();
        setNewTemplateName(instanceName);
        getInstanceData(instanceData?.id);
        if (currentApp?.name === CHANGE_COMMUNICATOR) {
          setShowNewInstanceModal(false);
        }
        addDefaultPrompt();
        return responseData;
      } else {
        const error = responseData?.error;
        setShowToast(true);
        setShowErrMsg(error?.errorMessage);
        // console.error('response error', error);
        return;
      }
    } catch (error: any) {
      console.error(
        'Error fetching projects:',
        error.response?.data ?? error.message
      );
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setShowErrMsg(err.errorMessage);
      if (err && err.errorMessage) {
        setShowErrMsg(err.errorMessage);
        setErrorMessage({
          message: err.errorMessage,
          id: errID,
        });
      } else {
        console.error('Error message not available');
      }
    }
  };

  const createInstance = () => {
    outputColumnAdd();
    const chunkParams = {
      overlapPercent: overLapPercent || null,
      bufferSize: bufferSize || null,
      breakpointChunking: breakPointPercent || null,
      childMaxTokens: childMaxTokens || null,
      parsingStrategy: parsingStrategy || null,
    };
    const payload = {
      llm_model: selectedModel,
      llm_guard_value: grsType,
      name: instanceName,
      projectId: projectId,
      temperature: sliderValue,
      applicationId: currentAppId,
      chunkSize: chunkSizeValue,
      parsingStrategy: parsingStrategy,
      chunkingStrategy: step3 ? chunkingStrategy : undefined,
      kNearChunks:
        vectorDb !== OPENSEARCH_SERVERLESS ? kNearChunksValue : undefined,
      chunkParams: chunkParams,
      cloud_environment: cloudProvider ? cloudProvider : AZURE_CLOUD,
      render_markdown: renderMarkdown === 'Yes' ? true : false,
      llm_guard: llmGuardOption === 'Yes' ? true : false,
      query_expansion: vectorDb === WEAVIATE ? queryExpansion : undefined,
      vector_db: vectorDb,
      embedding_choice:
        vectorDb === OPENSEARCH_SERVERLESS ? AmazonTitanv2 : embeddingModel,
    };
    setHasVisitedKnowledgePage(true);

    if (llmGuardOption !== 'Yes') {
      setLlmGuardOption('No');
    }
    const resData = handleInstanceCreation(payload);
    if (Object.keys(resData)?.length) {
    }
  };

  const fetchInstance = () => {
    nextStep();
    // if (!step4) {
    setShowNewInstanceModal(false);
    // }
  };

  const handleInstanceNameChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    let instanceName = event?.target?.value;
    if (instanceName?.length === 0) {
      setNameErrorCheck(false);
    }
    if (instanceName?.length > 0) {
      const check = nameStartingCheck(instanceName[0]);
      if (check) {
        setNameErrorCheck(true);
      } else {
        setNameErrorCheck(false);
      }
    }
    setInstanceName(instanceName);
  };
  const [uploadcount, setUploadCount] = useState<number>(0);
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setIsKnowledgeUploadDisabled(false);
    setIsUploadLoading(false);
    setIsUploadSuccess(false);
    setShowFileUploadSuccessMsg(false);
    const files = event.target.files;
    if (files) {
      const uploadedFiles = Array.from(files).filter((file) => {
        // Check for CSV extension (case-insensitive)
        const extension = file.name.split('.').pop()?.toLowerCase();
        return extension === 'csv';
      });
      if (newKnowledgeID.length === 0) {
        setUploadError(true);
        setUploadCount(1);
      }
      setUploadedFiles(Array.from(files));
    }
  };

  const editModeusedTokenCount = () => {
    const enc = getEncoding('gpt2');

    let newValue = templatePrompt
      ?.replace(/\{[\s\{]*\{/g, '{{')
      .replace(/\}[\s\}]*\}/g, '}}');
    // AutoComplete Bug solution- Jira ticket no. 500
    newValue = newValue.replace(/}}([^{]+}}?)/g, '}}');
    let newValue1 = enc.encode(newValue); // Encode the text using gpt2 encoding
    setTokencount(newValue1.length);
    let count = 0;
    if (isEditMode) {
      if (instanceDetails.knowledgeIds?.length) {
        for (let i = 0; i < instanceDetails.knowledgeIds?.length; i++) {
          count =
            count +
            templatePrompt.split(instanceDetails.knowledgeIds[i].id).length -
            1;
        }
      }

      if (knowledgeIDs.length > 0) {
        for (let i = 0; i < knowledgeIDs.length; i++) {
          count = count + templatePrompt.split(knowledgeIDs[i].id).length - 1;
        }
        // count=count-1;
      }
      count = count;
      const knowledgetoken =
        (count / 2) * instanceDetails.chunkSize * instanceDetails.kNearChunks;

      setFiletokencount(knowledgetoken);
    }
  };

  const handleSelectKnowledgeID = (knowledge: any) => {
    setSelectedKnowledgeIdError(false);
    setSelectedKnowledgeIds(
      selectedKnowledgeIds?.includes(knowledge.id)
        ? selectedKnowledgeIds.filter((item: any) => item !== knowledge.id)
        : [...selectedKnowledgeIds, knowledge.id]
    );
  };

  const loadKnowledge = async () => {
    setIsKnowledgeUploadDisabled(true);
    setCount(0);
    setIsUploadLoading(true);
    setIsUploadSuccess(false);
    const formData = new FormData();
    uploadedFiles.forEach((file) => {
      formData.append('files', file);
    });
    try {
      const queryParams = {
        knowledge_name: newKnowledgeID ? newKnowledgeID : instanceDetails.name,
        flow_id: isEditMode ? instanceDetails.flow : flowId,
        chunking_strategy: step3
          ? isEditMode
            ? instanceDetails.chunking_strategy
            : chunkingStrategy
          : undefined,
      };
      let url = '';
      const aws_opensearch_serverless_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/knowledge/bedrock/load`;
      const azure_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/knowledge/load`;
      const azure_ocr_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/knowledge/load-with-ocr`;
      // const azure_image_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/knowledge/load-images-with-ocr`;
      const gcp_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/gcp/knowledge/load`;
      const gcp_ocr_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/gcp/knowledge/load-with-ocr`;
      const aws_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/knowledge/load`;
      const aws_ocr_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/knowledge/load-with-ocr`;
      if (isEditMode) {
        if (instanceDetails.cloudEnvironment === AWS_CLOUD) {
          if (instanceDetails.vectorDb === OPENSEARCH_SERVERLESS) {
            url = aws_opensearch_serverless_api;
          } else {
            if (isScannedDoc) {
              url = aws_ocr_api;
            } else {
              url = aws_api;
            }
          }
        } else if (instanceDetails.cloudEnvironment === GCP_CLOUD) {
          if (isScannedDoc) {
            url = gcp_ocr_api;
          } else {
            url = gcp_api;
          }
        } else if (instanceDetails.cloudEnvironment === AZURE_CLOUD) {
          if (documentContents === 'tables-or-images') {
            url = azure_ocr_api;
          } else {
            url = azure_api;
          }
        }
      } else {
        if (cloudProvider === AWS_CLOUD) {
          if (vectorDb === OPENSEARCH_SERVERLESS) {
            url = aws_opensearch_serverless_api;
          } else {
            url = aws_api;
          }
        } else if (cloudProvider === GCP_CLOUD) {
          if (isScannedDoc) {
            url = gcp_ocr_api;
          } else {
            url = gcp_api;
          }
        } else if (cloudProvider === AZURE_CLOUD) {
          if (documentContents === 'tables-or-images') {
            url = azure_ocr_api;
          } else {
            url = azure_api;
          }
        }
      }
      const response = await axios.post(url, formData, {
        params: queryParams,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.status === 200) {
        setShowToast(false);
        setShowErrMsg('');
        setUploadedFiles([]);
        setUploadCount(0);
        setUploadError(false);
        setNewKnowledgeID('');
        setKnowlwdgeidAdded(true);
        setDocumentContents(null);
        setIsScannedDoc(false);
        if (knowledgeFileUpload && knowledgeFileUpload?.current) {
          knowledgeFileUpload.current.value = '';
        }
        const responseData = response.data;
        const knowledgeArray = [responseData.knowledge];
        const transformedKnowledge: Knowledge[] =
          knowledgeArray.map((item: Knowledge) => ({
            id: item.id,
            name: item.name,
          })) || [];
        setCurrentKnowledgeID((prevKnowledge) => [
          ...prevKnowledge,
          ...transformedKnowledge,
        ]);
        addKnowledgeID(flowId);
      } else {
        setIsUploadLoading(false);
        setIsUploadSuccess(false);
        setShowToast(true);
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setShowErrMsg(err.errorMessage);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      setDocumentContents(null);
      setIsScannedDoc(false);
      setIsUploadLoading(false);
      setIsUploadSuccess(false);
      console.error('Error:', error);
    }
  };

  const handleCreateTemplate = async (payload: any) => {
    try {
      let templateApi = '';
      let response;
      if (isEditMode) {
        templateApi = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/template/flow`;
        response = await axios.put(templateApi, payload, {
          headers: {
            'Content-Type': 'application/json',
          },
        });
      } else {
        templateApi = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/template`;
        response = await axios.post(templateApi, payload, {
          headers: {
            'Content-Type': 'application/json',
          },
        });
      }
      const responseData = response.data;
      if (response.status === 200) {
        setShowToast(false);
        setShowErrMsg('');
        getInstanceData(selectedInstance);
        nextStep();
        setShowNewInstanceModal(false);
        setCurrentKnowledgeID([]);
        return responseData;
      } else {
        setShowToast(true);
        return;
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setShowErrMsg(err.errorMessage);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      console.error('Error:', error);
      return;
    }
  };

  const createTemplate = () => {
    const matches = templatePrompt?.match(/{{knowledgeid_(\w+)}}/g);
    const knowledgeIdsInPrompt = matches?.map((match) =>
      match.substring(14, match.length - 2)
    );

    const duplicateKnowledgeIds = matches?.filter(
      (item, index, array) => array.indexOf(item) !== index
    );
    if (
      selectedKnowledgeIds?.length === 0 &&
      currentApp?.name === TEST_SCRIPT_GENERATOR &&
      templateInstructions === 'Basic'
    ) {
      setSelectedKnowledgeIdError(true);
      return;
    }
    if (
      duplicateKnowledgeIds &&
      duplicateKnowledgeIds?.length > 0 &&
      templateInstructions !== 'Basic'
    ) {
      // Keeping only single duplicate Ids to show in error message
      const uniqueDuplicates = [
        ...new Set(
          duplicateKnowledgeIds?.map((match) =>
            match.substring(14, match.length - 2)
          )
        ),
      ];

      setErrorMessage({
        message: `Knowledge ID(s) - ${uniqueDuplicates.join(', ')} are referenced in the system template more than once. Please correct and refer them only once.`,
        id: '',
      });
      setShowToast(true);
      return;
    }
    const allKnowledgeIds = [
      ...(knowledgeIDs?.map((item) => item.id) ?? []),
      ...(newKnowledgeIds?.map((item) => item.id) ?? []),
      ...(instanceDetails.knowledgeIds?.map((item: any) => item.id) ?? []),
    ];
    const missingIds = knowledgeIdsInPrompt
      ? knowledgeIdsInPrompt.filter(
          (id) => !allKnowledgeIds.includes(parseInt(id))
        )
      : [];

    const docInsightKnowledgeIds = allKnowledgeIds?.[0];
    if (currentApp?.name === DOC_INSIGHT) {
      if (
        allKnowledgeIds.length === 0 &&
        !templatePrompt.includes('{{knowledgeid_xxx}}') &&
        templateInstructions !== 'Basic'
      ) {
        setErrorMessage({
          message:
            'Please add {{knowledgeid_xxx}} to the template to proceed further.',
          id: '',
        });
        setShowToast(true);
        return;
      } else if (
        allKnowledgeIds?.length > 0 &&
        (missingIds?.length > 0 || !knowledgeIdsInPrompt)
      ) {
        setErrorMessage({
          message: `The Knowledge ID ${missingIds?.length > 0 ? `- ${missingIds}` : `- ${docInsightKnowledgeIds}`} referenced in the system template are either incorrect or deleted. Please correct to proceed further.`,
          id: '',
        });
        setShowToast(true);
        return;
      }
    } else {
      if (
        allKnowledgeIds.length > 0 &&
        (missingIds?.length > 0 ||
          (missingIds?.length === 0 && !knowledgeIdsInPrompt)) &&
        templateInstructions !== 'Basic'
      ) {
        setErrorMessage({
          message: `The Knowledge ID(s) ${missingIds?.length > 0 ? `- ${missingIds}` : ''} referenced in the system template are either incorrect or deleted. Please correct to proceed further.`,
          id: '',
        });
        setShowToast(true);
        return;
      }
    }
    let payload;
    // outputColumns.push(...extraOutputColumns);
    let outputColumnValues: any = [];
    outputColumnValues = outputColumns.map(
      (output_columns) => output_columns.value
    );
    let columnOptions: any = [];
    columnOptions.push(
      outputColumnValues.filter((output_columns: any) => output_columns !== '')
    );
    const outputColumnsPayload = columnOptions?.[0]?.[0]
      ? columnOptions?.[0]
      : undefined;
    if (isEditMode) {
      if (currentApp?.name === TEST_SCRIPT_GENERATOR) {
        payload = {
          flow_id: instanceDetails.flow,
          template_id: instanceDetails.templateId,
          output_columns: outputColumnsPayload,
          prompt_template: templatePrompt
            ? templatePrompt
            : instanceDetails.template,
          temperature: sliderValue,
        };
      } else {
        payload = {
          flow_id: instanceDetails.flow,
          template_id: instanceDetails.templateId,
          output_columns: outputColumnsPayload,
          prompt_template: templatePrompt
            ? templatePrompt
            : instanceDetails?.template,
          temperature: sliderValue,
        };
      }
    } else {
      if (currentApp?.name === TEST_SCRIPT_GENERATOR) {
        payload = {
          name: newTemplateName
            ? newTemplateName
            : instanceDetails.templateName,
          flow: flowId,
          output_columns: outputColumnsPayload,
          promptTemplate: fixNewlineChars(templatePrompt),

          doc_template_ids: fileId,
        };
      } else {
        payload = {
          name: newTemplateName
            ? newTemplateName
            : instanceDetails.templateName,
          flow: flowId,
          output_columns: outputColumnsPayload,
          promptTemplate: fixNewlineChars(templatePrompt),
          doc_template_ids: fileId,
        };
      }
    }
    handleCreateTemplate(payload);
  };

  const result =
    templateInstructions === 'Basic'
      ? templatePrompt
      : templatePrompt
        ? instanceDetails?.template
        : '';

  useEffect(() => {
    //code for llm guard
    if (step1 && step2 && step3 && step4) {
      setTotalSteps(4);
    } else if (step1 && step2 && step4) {
      setTotalSteps(3);
    } else if (step1 && step3 && step4) {
      setTotalSteps(3);
    } else if (step1 && step2 && step3) {
      setTotalSteps(3);
    } else if (step1 && (step3 || step4)) {
      setTotalSteps(2);
    } else {
      setTotalSteps(1);
    }
  }, [step1, step2, step3, step4]);

  useEffect(() => {
    if (chunkingStrategy === 'SEMANTIC') {
      setChunkSizeValue(1000);
      setBreakPointPercent(95);
      setBufferSize(1);
    } else if (chunkingStrategy === 'HIERARCHICAL') {
      setChunkSizeValue(2000);
      setchildMaxTokens(500);
      setOverLapPercent(15);
    } else if (chunkingStrategy === 'FIXED_SIZE') {
      setChunkSizeValue(2000);
      setOverLapPercent(15);
    }
  }, [chunkingStrategy]);

  useEffect(() => {
    const removeSuccessMessage = setTimeout(() => {
      setIsUploadSuccess(false);
    }, 2000);

    return () => clearTimeout(removeSuccessMessage);
  }, [isUploadSuccess]);

  useEffect(() => {
    if (isEditMode) {
      setChunkSizeValue(instanceDetails.chunkSize);
      setKNearChunksValue(instanceDetails.kNearChunks);
      setSliderValue(instanceDetails.temperature);
      if (instanceDetails?.metadata?.funtional != undefined)
        setSelectedTemplateHeadings(instanceDetails?.metadata?.funtional);
      setSelectedPoints(instanceDetails?.metadata?.selectedPoints);
      setSelectedKnowledgeIds(instanceDetails?.metadata?.selectedKnowledgeIds);
    }
  }, [isEditMode, instanceDetails]);

  useEffect(() => {
    let count = 0;
    if (isEditMode) {
      if (instanceDetails && instanceDetails?.knowledgeIds?.length) {
        for (let i = 0; i < instanceDetails?.knowledgeIds?.length; i++) {
          count =
            count +
            templatePrompt.split(instanceDetails.knowledgeIds[i].id).length -
            1;
        }
      }

      if (knowledgeIDs.length > 0) {
        for (let i = 0; i < knowledgeIDs.length; i++) {
          count = count + templatePrompt.split(knowledgeIDs[i].id).length - 1;
        }
        // count=count-1;
      }
      count = count;
      const knowledgetoken =
        (count / 2) * instanceDetails.chunkSize * instanceDetails.kNearChunks;

      setFiletokencount(knowledgetoken);
    }

    if (!isEditMode) {
      if (knowledgeIDs) {
        for (let i = 0; i < knowledgeIDs.length; i++) {
          count = count + templatePrompt.split(knowledgeIDs[i].id).length - 1;
        }
      }
      const knowledgetoken = count * chunkSizeValue * kNearChunksValue;
      setFiletokencount(knowledgetoken);
    }
  }, [selectedModel]);

  useEffect(() => {
    if (isEditMode) {
      instanceDetails.llmGuard
        ? setLlmGuardOption('Yes')
        : setLlmGuardOption('No');
      instanceDetails.renderMarkdown
        ? setRenderMarkdown('Yes')
        : setRenderMarkdown('No');
    }
  }, [isEditMode, instanceDetails.llmGuard, instanceDetails.renderMarkdown]);

  const handleUploadInstanceDoc = async () => {
    setIsUploadLoading(true);
    setShowFileUploadSuccessMsg(false);
    const formData = new FormData();
    uploadedFiles.forEach((file) => {
      formData.append('files', file);
    });

    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/template/document/submit`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      if (response.status === 200) {
        setShowToast(false);
        setUploadedFiles([]);
        setIsUploadLoading(false);
        const responseData = response.data;
        const data: Array<string> = [];
        const res = responseData.response;
        res.forEach((item: any) => {
          data.push(item.id);
          setFileId(data);
        });
        setShowFileUploadSuccessMsg(true);
        if (filesSelectedForUploadRef?.current) {
          filesSelectedForUploadRef.current.value = '';
        }
      } else {
        setShowToast(true);
        setIsUploadLoading(false);
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setShowErrMsg(err.errorMessage);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      setIsUploadLoading(false);
      setIsUploadSuccess(false);
    }
  };

  const handleAddKeyValue = () => {
    setKeyValues([...keyValues, { key: '', value: '' }]);
  };

  const handleRemoveKeyValue = (index: number) => {
    const updatedKeyValues = [...keyValues];
    updatedKeyValues.splice(index, 1);
    setKeyValues(updatedKeyValues);
  };

  const handleKeyValueInputChange = (
    index: number,
    field: 'key' | 'value',
    value: string
  ) => {
    const updatedKeyValues = [...keyValues];
    updatedKeyValues[index][field] = value;
    setKeyValues(updatedKeyValues);
  };

  const handleKeyValueSubmit = () => {
    const nonEmptyPairs = keyValues.filter(
      ({ key, value }) => key !== '' && value !== ''
    );
    const keyValueJson = Object.fromEntries(
      nonEmptyPairs.map(({ key, value }) => [key, value])
    );
    const keyValueJsonString = JSON.stringify(keyValueJson);
    uploadSampleDocument(keyValueJsonString);
  };

  const uploadSampleDocument = async (keyValueJsonString: any) => {
    setIsUploadLoading(true);
    setIsUploadSuccess(false);
    const formData = new FormData();
    uploadedFiles.forEach((file) => {
      formData.append('pdf_file', file);
    });

    try {
      const queryParams = {
        metadata: keyValueJsonString,
        instance_id: instanceData?.id,
      };
      const response = await axios.post(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/one-shot-chain/notice-analysis/upload-sample-notice`,
        formData,
        {
          params: queryParams,
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      if (response.status === 200) {
        setIsUploadLoading(false);
        setIsUploadSuccess(true);
        setShowToast(false);
        setShowErrMsg('');
        setUploadedFiles([]);
        setKeyValues([{ key: '', value: '' }]);
        if (filesSelectedForUploadRef?.current) {
          filesSelectedForUploadRef.current.value = '';
        }
        const responseData = response.data;
      } else {
        setShowToast(true);
        setIsUploadLoading(false);
        console.error('Failed to upload files');
      }
    } catch (error: any) {
      setIsUploadLoading(false);
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setShowErrMsg(err.errorMessage);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
    }
  };

  const handleKnowledgeName = (event: React.ChangeEvent<HTMLInputElement>) => {
    let knowledgeName = event?.target?.value;
    if (knowledgeName?.length === 0) {
      setKnowledgeNameCheck(false);
    }

    if (knowledgeName?.length > 0) {
      setUploadError(false);
      const check = nameStartingCheck(knowledgeName[0]);
      if (check) {
        setKnowledgeNameCheck(true);
      } else {
        setKnowledgeNameCheck(false);
      }
    }
    if (knowledgeName?.length === 0 && uploadcount == 1) {
      setUploadError(true);
    }
    setNewKnowledgeID(knowledgeName);
  };
  useEffect(() => {
    setUploadError(false);
  }, [currentStep]);

  useEffect(() => {
    if (isEditMode && instanceDetails && instanceDetails.template) {
      setTemplatePrompt(instanceDetails.template.replace(/\\n/g, '\n'));
    }
  }, [instanceDetails, isEditMode]);

  const addDefaultPrompt = () => {
    if (!isEditMode && currentApp && cloudProvider && !templatePrompt.length) {
      switch (currentApp?.name) {
        case USER_STORY_GENERATOR:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(USER_STORY_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(USER_STORY_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(USER_STORY_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(USER_STORY_PROMPT_AZURE);
              break;
          }
          break;
        case SALES_ENGINE:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(SALES_ENGINE_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(SALES_ENGINE_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(SALES_ENGINE_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(SALES_ENGINE_PROMPT_AZURE);
              break;
          }
          break;
        case MEETING_SUMMARIZER:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(MEETING_SUMMARIZER_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(MEETING_SUMMARIZER_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(MEETING_SUMMARIZER_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(MEETING_SUMMARIZER_PROMPT_AZURE);
              break;
          }
          break;
        case STATUS_REPORT_GENERATOR:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(STATUS_REPORT_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(STATUS_REPORT_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(STATUS_REPORT_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(STATUS_REPORT_PROMPT_AZURE);
              break;
          }
          break;
        case TEST_SCRIPT_GENERATOR:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setBasicTemplatePrompt(TCG_BASIC_MODE);
              setTemplatePrompt(TEST_SCRIPT_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(TEST_SCRIPT_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(TEST_SCRIPT_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(TEST_SCRIPT_PROMPT_AZURE);
              break;
          }
          break;
        case SCAN_TO_SUMMIFY:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(SCAN_TO_SUMMIFY_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(SCAN_TO_SUMMIFY_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(SCAN_TO_SUMMIFY_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(SCAN_TO_SUMMIFY_PROMPT_AZURE);
              break;
          }
          break;
        case HELP_DESK_ENGINE:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(HELP_DESK_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(HELP_DESK_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(HELP_DESK_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(HELP_DESK_PROMPT_AZURE);
              break;
          }
          break;
        case NOTICE_ENGINE:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(NOTICE_ENGINE_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(NOTICE_ENGINE_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(NOTICE_ENGINE_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(NOTICE_ENGINE_PROMPT_AZURE);
              break;
          }
          break;
        case CALL_CENTER:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(CALL_CENTER_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(CALL_CENTER_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(CALL_CENTER_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(CALL_CENTER_PROMPT_AZURE);
              break;
          }
          break;
        case DOC_INSIGHT:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(DOC_INSIGHTS_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(DOC_INSIGHTS_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(DOC_INSIGHTS_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(DOC_INSIGHTS_PROMPT_AZURE);
              break;
          }
          break;
        case DEVELOPER_HELP_ENGINE:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(DEVELOPER_HELP_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(DEVELOPER_HELP_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(DEVELOPER_HELP_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(DEVELOPER_HELP_PROMPT_AZURE);
              break;
          }
          break;
        case POLICY_ENGINE:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(POLICY_ENGINE_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(POLICY_ENGINE_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(POLICY_ENGINE_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(POLICY_ENGINE_PROMPT_AZURE);
              break;
          }
          break;
        case HELP_ENGINE:
          switch (cloudProvider) {
            case AZURE_CLOUD:
              setTemplatePrompt(HELP_ENGINE_PROMPT_AZURE);
              break;
            case GCP_CLOUD:
              setTemplatePrompt(HELP_ENGINE_PROMPT_GCP);
              break;
            case AWS_CLOUD:
              setTemplatePrompt(HELP_ENGINE_PROMPT_AWS);
              break;
            default:
              setTemplatePrompt(HELP_ENGINE_PROMPT_AZURE);
              break;
          }
          break;
        default:
          setTemplatePrompt(DEFAULT_TEMPLATE_PROMPT);
          break;
      }
    }
  };

  useEffect(() => {
    setBasicTemplatePrompt(TCG_BASIC_MODE);
  }, []);

  useEffect(() => {
    if (isEditMode && instanceDetails) {
      const selectedCp = models.filter((cp) => {
        if (cp.name === instanceDetails.cloudEnvironment) return cp;
      });
      const cpOptions = selectedCp[0].models;
      setCloudProviderOptions(cpOptions);
      setSelectedModel(cpOptions[0].modelValue);
      if (instanceDetails.llmModel) {
        setSelectedModel(instanceDetails.llmModel);
      }
    }
  }, [instanceDetails]);

  useEffect(() => {
    if (isEditMode && instanceDetails) {
      const selectedCp = models.filter((cp) => {
        if (cp.name === instanceDetails.cloudEnvironment) return cp;
      });
      const cpOptions = selectedCp[0].models;
      setCloudProviderOptions(cpOptions);
      setSelectedModel(cpOptions[0].modelValue);
      if (instanceDetails.llmModel) {
        setSelectedModel(instanceDetails.llmModel);
      }
    } else {
      const selectedCp = models.filter((cp) => {
        if (cp.name === cloudProvider) return cp;
      });
      const cpOptions = selectedCp[0]?.models;
      setCloudProviderOptions(cpOptions);
      settokenlimit(cpOptions[0]);
      // setSelectedModel("GPT-3.5 Turbo");
      if (cloudProvider === AWS_CLOUD) {
        setVectorDb(OPENSEARCH_SERVERLESS);
      } else {
        setVectorDb(WEAVIATE);
      }
    }
  }, [cloudProvider]);

  useEffect(() => {
    if (!isEditMode && selectedModel === '') {
      setSelectedModel('gpt-4o');
    }
    if (!isEditMode && !(selectedModel === '')) {
      const selectedCp = cloudProviderOptions.filter((cp: any) => {
        if (cp.modelName === selectedModel || cp.modelValue === selectedModel)
          return cp?.tokenSize;
      });
      setSelectedModel(selectedCp[0].modelValue);
      settokenlimit(selectedCp[0]);
    }
  }, [instanceName]);

  useEffect(() => {
    if (!isEditMode) {
      const enc = getEncoding('gpt2');

      let newValue = templatePrompt
        ?.replace(/\{[\s\{]*\{/g, '{{')
        .replace(/\}[\s\}]*\}/g, '}}');
      // AutoComplete Bug solution- Jira ticket no. 500
      newValue = newValue.replace(/}}([^{]+}}?)/g, '}}');
      let newValue1 = enc.encode(newValue); // Encode the text using gpt2 encoding
      setTokencount(newValue1.length);
    }
  }, [instanceName]);

  useEffect(() => {
    cloudProvidrModelChange();
  }, [selectedModel, cloudProviderOptions, currentStep]);

  useEffect(() => {
    let outputColumn = document.getElementById('output-column');
    if (outputColumn != null) {
      outputColumn.scrollTop = outputColumn.scrollHeight;
    }
  }, [outputColumns]);

  const cloudProvidrModelChange = () => {
    const selectedCp = cloudProviderOptions.filter((cp: any) => {
      if (cp.modelName === selectedModel || cp.modelValue === selectedModel)
        return cp?.tokenSize;
    });
    settokenlimit(selectedCp[0]);
  };

  const toggleRowExpansion = (rowIndex: number) => {
    setExpandedRows((prevExpandedRows) => {
      const newExpandedRows = new Set(prevExpandedRows);
      if (newExpandedRows.has(rowIndex)) {
        newExpandedRows.delete(rowIndex);
      } else {
        newExpandedRows.add(rowIndex);
      }
      return newExpandedRows;
    });
  };

  const newKnowledgeIds =
    knowledgeIDs &&
    knowledgeIDs.filter(
      (knowledgeID) =>
        !instanceDetails.knowledgeIds?.some(
          (instanceDetail: any) => instanceDetail.id === knowledgeID.id
        )
    );
  const outputColumnAdd = () => {
    setOutputcolumns([
      { value: 'Title' },
      { value: 'Test Steps' },
      { value: 'Expected Outcome' },
      { value: '' },
    ]);
  };

  const editTemperature = async () => {
    editModeusedTokenCount();
    const payload = {
      llm_model: selectedModel,
      temperature: sliderValue,
      llm_guard: llmGuardOption === 'Yes' ? true : false,
      render_markdown: renderMarkdown === 'Yes' ? true : false,
      query_expansion: queryExpansion,
      chunking_params: {
        overlapPercent: overLapPercent,
        bufferSize: bufferSize,
        breakpointChunking: breakPointPercent,
        childMaxTokens: childMaxTokens,
        parsing_strategy: parsingStrategy,
      },
    };
    try {
      const response = await axios.put(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/instance/update/temperature-markdown-llmguard/${selectedInstance}`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      const responseData = response.data;
      if (response.status === 200) {
        setShowToast(false);
        setShowErrMsg('');
        if (currentApp?.name === CHANGE_COMMUNICATOR) {
          setShowNewInstanceModal(false);
          getInstanceData(selectedInstance);
        } else {
          nextStep();
        }
      } else {
        const error = responseData?.error;
        setShowToast(true);
        setShowErrMsg(error?.errorMessage);
        // console.error('response error', error);
        return;
      }
    } catch (error: any) {
      console.error(
        'Error Editing instance',
        error.response?.data ?? error.message
      );
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setShowErrMsg(err.errorMessage);
      if (err && err.errorMessage) {
        setShowErrMsg(err.errorMessage);
        setErrorMessage({
          message: err.errorMessage,
          id: errID,
        });
      } else {
        console.error('Error message not available');
      }
    }
  };

  const handleoautomaticmanualptionchange = (event: any) => {
    setSelectedOption(event.target.checked ? 'Manual' : 'Automatic');
    if (!isEditMode) {
      setRenderMarkdown('No');
      setLlmGuardOption('No');
      setSliderValue(0.0);
      if (chunkingStrategy === 'FIXED_SIZE') {
        setChunkSizeValue(2000);
        setOverLapPercent(15);
      } else if (chunkingStrategy === 'HIERARCHICAL') {
        setChunkSizeValue(2000);
        setchildMaxTokens(500);
        setOverLapPercent(15);
      } else if (chunkingStrategy === 'SEMANTIC') {
        setChunkSizeValue(1000);
        setBreakPointPercent(95);
        setBufferSize(1);
      }
    }
  };

  const handlemodelselectchange = (event: any) => {
    const model_selected = event.target.value;
    const recommendedModels = [
      // model_recommended,
      azure_recommended_model,
      gcp_recommended_model,
      aws_recommended_model,
    ];

    setModelRecommendationMsg(
      recommendedModels.includes(model_selected)
        ? ''
        : 'Available but not recommended. It may not provide optimal results.'
    );

    const selectedCp = cloudProviderOptions.filter((cp: any) => {
      if (cp.modelName === model_selected || cp.modelValue === model_selected)
        return cp?.tokenSize;
    });
    setSelectedModel(model_selected);
    settokenlimit(selectedCp[0]);
  };

  const getColor = (percentage: any) => {
    if (percentage <= 75) {
      return 'success'; // Green
    } else if (percentage < 100) {
      return 'warning'; // Yellow
    } else {
      return 'danger'; // Red
    }
  };

  function handleTemplatePromptChange(
    event: React.ChangeEvent<HTMLTextAreaElement>
  ) {
    let count = 0;
    if (isEditMode) {
      if (instanceDetails?.knowledgeIds?.length) {
        for (let i = 0; i < instanceDetails?.knowledgeIds?.length; i++) {
          count =
            count +
            event.target.value.split(instanceDetails.knowledgeIds[i].id)
              .length -
            1;
        }
      }

      if (knowledgeIDs.length > 0) {
        for (let i = 0; i < knowledgeIDs.length; i++) {
          count =
            count + event.target.value.split(knowledgeIDs[i].id).length - 1;
        }
        // count=count-1;
      }
      count = count;
      const knowledgetoken =
        (count / 2) * instanceDetails.chunkSize * instanceDetails.kNearChunks;

      setFiletokencount(knowledgetoken);
    }

    if (!isEditMode) {
      if (knowledgeIDs) {
        for (let i = 0; i < knowledgeIDs.length; i++) {
          count =
            count + event.target.value.split(knowledgeIDs[i].id).length - 1;
        }
      }
      const knowledgetoken = count * chunkSizeValue * kNearChunksValue;
      setFiletokencount(knowledgetoken);
    }

    // Replace '{ {' with '{{' and '} }' with '}}'
    const enc = getEncoding('gpt2');

    let newValue = event.target.value
      ?.replace(/\{[\s\{]*\{/g, '{{')
      .replace(/\}[\s\}]*\}/g, '}}');
    // AutoComplete Bug solution- Jira ticket no. 500
    newValue = newValue.replace(/}}([^{]+}}?)/g, '}}');
    let newValue1 = enc.encode(newValue); // Encode the text using gpt2 encoding
    setTokencount(newValue1.length);
    let newValue2 = enc.decode(newValue1);
    setTemplatePrompt(newValue);
  }

  useEffect(() => {
    if (isEditMode || isBackClicked) {
      setCloudProvider(instanceDetails.cloudEnvironment);
      setEmbeddingModel(instanceDetails.embeddingChoice);
      setEmbeddingModels(getEmbeddingOptions(instanceDetails.cloudEnvironment));
      // Initialize chunking parameters from API response
      if (instanceDetails?.chunkingParams) {
        setChunkSizeValue(instanceDetails.chunkSize);
        setOverLapPercent(instanceDetails.chunkingParams.overlapPercent || 15);
        setBufferSize(instanceDetails.chunkingParams.bufferSize || 1);
        setBreakPointPercent(
          instanceDetails.chunkingParams.breakpointChunking || 95
        );
        setchildMaxTokens(instanceDetails.chunkingParams.childMaxTokens || 500);
        setParsingStrategy(
          instanceDetails.chunkingParams.parsing_strategy || 'DEFAULT'
        );
      }
    }
  }, [isEditMode, isBackClicked, instanceDetails]);

  const cloudProviderSelectChange = (event: any) => {
    setCloudProvider(event.target.value);
    if (event.target.value === AWS_CLOUD) {
      setVectorDb(OPENSEARCH_SERVERLESS);
    } else {
      setVectorDb(WEAVIATE);
    }
    const selectedCp = models.filter((cp) => {
      if (cp.name === event.target.value) return cp;
    });
    const cpOptions = selectedCp[0].models;
    setSelectedModel(cpOptions[0].modelValue);
    setModelRecommendationMsg('');
    setEmbeddingModels(getEmbeddingOptions(event.target.value));
    setEmbeddingModel(
      getEmbeddingOptions(event.target.value)[0]?.modelValue || ''
    );
  };

  const handleDocumentContentsChange = (count: any) => {
    if (count % 2 == 0) {
      setDocumentContents('tables-or-images');
    } else {
      setDocumentContents('');
    }
    setCount(count + 1);
  };
  const handleQueryExpansion = (event: any) => {
    setQueryExpansion(event.target.checked);
  };

  useEffect(() => {
    if (currentApp?.name === NOTICE_ANALYSIS_ENGINE) {
      setCloudProvider(AWS_CLOUD);
    }
  }, [currentApp]);
  useEffect(() => {
    // Set cloud provider to AWS on component initialization
    if (!isEditMode) {
      setCloudProvider(AWS_CLOUD);
      // Update vector DB to match AWS default
      setVectorDb(OPENSEARCH_SERVERLESS);

      // Update models for AWS
      const selectedCp = models.filter((cp) => cp.name === AWS_CLOUD);
      if (selectedCp.length > 0) {
        const cpOptions = selectedCp[0].models;
        setCloudProviderOptions(cpOptions);
        setSelectedModel(cpOptions[0].modelValue);
        setEmbeddingModels(getEmbeddingOptions(AWS_CLOUD));
        setEmbeddingModel(getEmbeddingOptions(AWS_CLOUD)[0]?.modelValue || '');

        setGrsType('aws_bedrock');
      }
    }
  }, []);
  const handleLayoutChange = (value: string) => {
    // Validate the image URL before setting it
    if (isValidImageUrl(value) || value === '') {
      setSelectedLayout(value);
    } else {
      console.warn('Invalid image URL provided:', value);
      setSelectedLayout('');
    }
  };
  const handleTCGTemplatePointChange = (event: any) => {
    setSelectedTemplateHeadings(
      selectedTemplateHeadings?.includes(event.target.value)
        ? selectedTemplateHeadings?.filter(
            (item) => item !== event.target.value
          )
        : [...selectedTemplateHeadings, event.target.value]
    );

    const newPoints = templatePromptPoints
      .filter((point) => point.title === event.target.value)
      .map((point) => point.points)
      .flat();
    setSelectedPoints((prevSelectedPoints: any) => {
      if (prevSelectedPoints) {
        const pointsAreSelected = newPoints.every((point) =>
          prevSelectedPoints?.includes(point)
        );
        if (pointsAreSelected) {
          // If all new points are already selected, filter them out
          return prevSelectedPoints.filter(
            (point: any) => !newPoints.includes(point)
          );
        } else {
          // Otherwise, add new points to selectedPoints
          return [...prevSelectedPoints, ...newPoints];
        }
      } else {
        return [...newPoints];
      }
    });
  };

  return (
    <div>
      {currentApp?.name !== CHANGE_COMMUNICATOR && (
        <Stepper currentStep={currentStep} totalSteps={totalSteps} />
      )}
      {currentStep === 1 && step1 ? (
        <>
          <Form.Group
            className="instance-name"
            controlId="exampleForm.instanceName"
          >
            <div className="modal-header-container">
              <h2 className="modal-header-title">Basic Details</h2>
            </div>
            <div className="basic-details-container">
              <div className="basic-details-wrapper">
                <Form.Label className="label-text">Instance Name</Form.Label>
                <Form.Control
                  as="input"
                  type="text"
                  value={isEditMode ? instanceDetails.name : instanceName}
                  onChange={handleInstanceNameChange}
                  placeholder="Enter Instance Name"
                  className="text-input"
                  disabled={isEditMode || isBackClicked}
                />
                <div>
                  {nameErrorCheck && (
                    <div className="upload-error new-name-check">
                      Instance Name should not start with special character!!
                    </div>
                  )}
                </div>
              </div>
            </div>
            {/* Parsing Strategy Dropdown will only appear with chunking-related fields below */}
            <div className="basic-details-container">
              <div className="cloudprovider-model-selector">
                {currentApp?.name !== NOTICE_ANALYSIS_ENGINE && (
                  <div className="basic-details-wrapper cloudprovider-model-selector-width">
                    <Form.Label className="label-text">
                      Cloud Provider
                    </Form.Label>
                    <div className="cloudprovider-options">
                      <Form.Select
                        aria-label="Select Cloud Provider"
                        onChange={(evt) => cloudProviderSelectChange(evt)}
                        value={
                          isEditMode
                            ? instanceDetails.cloudEnvironment
                            : cloudProvider
                        }
                        disabled={true}
                        className="model-selector"
                      >
                        <option value={AZURE_CLOUD}>Azure</option>
                        {currentApp?.name !== SCAN_TO_SUMMIFY &&
                          currentApp?.name !== NOTICE_ENGINE && (
                            <option value={GCP_CLOUD}>GCP</option>
                          )}
                        {currentApp?.name !== MEETING_SUMMARIZER &&
                          currentApp?.name !== NOTICE_ENGINE && (
                            <option value={AWS_CLOUD}>AWS</option>
                          )}
                      </Form.Select>
                    </div>
                  </div>
                )}{' '}
                <div
                  className={`basic-details-wrapper cloudprovider-model-selector-width gap ${
                    currentApp?.name === NOTICE_ANALYSIS_ENGINE
                      ? 'notice-analysis-engine'
                      : ''
                  }`}
                >
                  <Form.Label className="label-text">Model</Form.Label>
                  <Form.Select
                    className={`model-selector ${
                      currentApp?.name === NOTICE_ANALYSIS_ENGINE
                        ? 'model-selector-nae'
                        : ''
                    }`}
                    value={selectedModel}
                    onChange={(event) => handlemodelselectchange(event)}
                  >
                    {cloudProviderOptions.map((models: any) => (
                      <option value={models.modelValue}>
                        {models.modelName}
                      </option>
                    ))}
                  </Form.Select>
                  {modelRecommendationMsg && (
                    <div className="model-recommendation-msg">
                      {modelRecommendationMsg}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {currentApp?.name !== NOTICE_ANALYSIS_ENGINE && (
              <div className="basic-details-container">
                <div style={{ fontWeight: 'bold' }} className="option-labels">
                  <span
                    className={
                      selectedOption === 'Manual' ? 'disable-text' : ''
                    }
                  >
                    Automatic
                  </span>
                  <Form.Check
                    type="switch"
                    id="custom-switch"
                    checked={selectedOption === 'Manual'}
                    onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
                      handleoautomaticmanualptionchange(event)
                    }
                  />
                  <span
                    className={
                      selectedOption === 'Manual' ? '' : 'disable-text'
                    }
                  >
                    Manual
                  </span>
                </div>
              </div>
            )}
            {selectedOption === 'Manual' && (
              <div className="basic-details-container">
                <div className="basic-details-wrapper">
                  <Form.Group controlId="formSlider">
                    {' '}
                    <div className="custom-slider-wrapper">
                      <span className="precise-label">Precise</span>
                      <span className="creative-label">Creative</span>
                    </div>
                    <Form.Range
                      value={sliderValue}
                      min={0.0}
                      max={1.0}
                      step={0.1}
                      onChange={handleSliderChange}
                      className="custom-slider"
                    />
                  </Form.Group>
                </div>
                {currentApp?.name !== CHANGE_COMMUNICATOR && (
                  <>
                    {(step3 || currentApp?.name === DOC_INSIGHT) && (
                      <div className="basic-details-wrapper">
                        <Form.Label className="label-text">
                          Vector Database
                        </Form.Label>
                        <Form.Select
                          aria-label="Select Vector Database"
                          onChange={(evt) => {
                            const value = evt.target.value as VectorDb;
                            setVectorDb(value);
                          }}
                          value={
                            isEditMode ? instanceDetails.vectorDb : vectorDb
                          }
                          disabled={true}
                        >
                          {/* <option value={WEAVIATE}>Weaviate</option>
                            <option value={PGVECTOR}>PG Vector</option> */}
                          {cloudProvider === AWS_CLOUD && (
                            <option value={OPENSEARCH_SERVERLESS}>
                              Opensearch Serverless
                            </option>
                          )}
                        </Form.Select>
                      </div>
                    )}
                    <div className="basic-details-wrapper">
                      <Form.Label className="label-text">
                        Markdown Format Response
                      </Form.Label>
                      <div
                        style={{ fontWeight: 'bold' }}
                        className="markdown-option-labels"
                      >
                        <span
                          className={
                            renderMarkdown === 'Yes' ? 'disable-text' : ''
                          }
                        >
                          No
                        </span>
                        <Form.Check
                          type="switch"
                          id="custom-switch"
                          checked={renderMarkdown === 'Yes'}
                          onChange={(
                            event: React.ChangeEvent<HTMLInputElement>
                          ) => {
                            setRenderMarkdown(
                              event.target.checked ? 'Yes' : 'No'
                            );
                          }}
                        />
                        <span
                          className={
                            renderMarkdown === 'Yes' ? '' : 'disable-text'
                          }
                        >
                          Yes
                        </span>
                      </div>
                    </div>
                    {cloudProvider !== CFG_AI_CLOUD && (
                      <>
                        <div className="basic-details-wrapper">
                          <Form.Label className="label-text label-container">
                            LLM Guard{' '}
                          </Form.Label>

                          <div
                            style={{ fontWeight: 'bold' }}
                            className="markdown-option-labels"
                          >
                            <span
                              className={
                                llmGuardOption === 'Yes' ? 'disable-text' : ''
                              }
                            >
                              No
                            </span>
                            <Form.Check
                              type="switch"
                              id="custom-switch"
                              checked={llmGuardOption === 'Yes'}
                              onChange={(
                                event: React.ChangeEvent<HTMLInputElement>
                              ) => {
                                setLlmGuardOption(
                                  event.target.checked ? 'Yes' : 'No'
                                );
                              }}
                              disabled={isBedrockDisabled || isEditMode}
                            />
                            <span
                              className={
                                llmGuardOption === 'Yes' ? '' : 'disable-text'
                              }
                            >
                              Yes
                            </span>
                          </div>
                        </div>
                        {llmGuardOption === 'Yes' &&
                          cloudProvider !== GCP_CLOUD && (
                            <div className="basic-details-wrapper">
                              <Form.Label className="label-text">
                                Guard Rail
                              </Form.Label>
                              <Form.Select
                                aria-label="Select Guard Rail Type"
                                onChange={(evt) => setGrsType(evt.target.value)}
                                value={
                                  isEditMode
                                    ? instanceDetails.llm_guard_value
                                    : grsType
                                }
                                disabled={true}
                              >
                                <option value="deloitte_grs">
                                  Deloitte GRS
                                </option>
                                {cloudProvider === AWS_CLOUD && (
                                  <option value="aws_bedrock">
                                    AWS Bedrock GRS
                                  </option>
                                )}
                                {cloudProvider === AZURE_CLOUD && (
                                  <option value="azure_guardrails">
                                    Azure GRS
                                  </option>
                                )}
                              </Form.Select>
                            </div>
                          )}
                      </>
                    )}
                    {(step3 || currentApp?.name === DOC_INSIGHT) &&
                      (isEditMode ? instanceDetails.vectorDb : vectorDb) ===
                        WEAVIATE && (
                        <>
                          <div className="basic-details-wrapper">
                            <Form.Label className="label-text">
                              Embedding Model
                            </Form.Label>
                            <Form.Select
                              aria-label="Select Embedding Model"
                              onChange={(evt) =>
                                setEmbeddingModel(evt.target.value)
                              }
                              value={
                                isEditMode
                                  ? instanceDetails.embeddingChoice
                                  : embeddingModel
                              }
                              disabled={isEditMode || isBackClicked}
                            >
                              {embeddingModels.map((model) => (
                                <option value={model.modelValue}>
                                  {model.modelName}
                                </option>
                              ))}
                            </Form.Select>
                          </div>
                          <div className="basic-details-wrapper">
                            <Form.Label className="label-text">
                              Enhanced Document Search
                              <span style={{ fontWeight: 'normal' }}>
                                {' '}
                                (Slower but more accurate)
                              </span>
                            </Form.Label>
                            <div
                              style={{ fontWeight: 'bold' }}
                              className="markdown-option-labels"
                            >
                              <span
                                className={queryExpansion ? 'disable-text' : ''}
                              >
                                No
                              </span>
                              <Form.Check
                                type="switch"
                                id="query-expansion-switch"
                                onChange={handleQueryExpansion}
                                checked={queryExpansion}
                              />
                              <span
                                className={queryExpansion ? '' : 'disable-text'}
                              >
                                Yes
                              </span>
                            </div>
                          </div>
                        </>
                      )}
                  </>
                )}
              </div>
            )}
            {selectedOption === 'Manual' &&
              (step3 || currentApp?.name === DOC_INSIGHT) &&
              currentApp?.name !== NOTICE_ANALYSIS_ENGINE && (
                <>
                  <div className="basic-details-container">
                    <div className="basic-details-wrapper">
                      <Form.Label className="label-text">
                        Chunking Strategy
                      </Form.Label>
                      <Form.Select
                        aria-label="Select Chunking strategy"
                        onChange={(evt) => {
                          setChunkingStrategy(evt.target.value);
                        }}
                        value={
                          isEditMode
                            ? instanceDetails.chunking_strategy
                            : chunkingStrategy
                        }
                        disabled={isEditMode || isBackClicked}
                      >
                        <option value="FIXED_SIZE">Fixed Size</option>
                        <option value="HIERARCHICAL">Hierarchical</option>
                        <option value="SEMANTIC">Semantic</option>
                      </Form.Select>
                    </div>
                    {/* Parsing Strategy Dropdown - grouped with chunking fields */}
                    <div className="basic-details-wrapper">
                      <Form.Label className="label-text">
                        Parsing Strategy
                      </Form.Label>
                      <Form.Select
                        aria-label="Select Parsing Strategy"
                        value={parsingStrategy}
                        onChange={handleParsingStrategyChange}
                        disabled={isEditMode || isBackClicked}
                      >
                        <option value="DEFAULT">Default</option>
                        <option value="BEDROCK_DATA_AUTOMATION">
                          Bedrock Data Automation
                        </option>
                        <option value="BEDROCK_FOUNDATION_MODEL">
                          Bedrock Foundation Model
                        </option>
                      </Form.Select>
                    </div>
                    {(isEditMode
                      ? instanceDetails.chunking_strategy
                      : chunkingStrategy) === 'FIXED_SIZE' && (
                      <>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSlider">
                            <Form.Label className="label-text">
                              {'Max Tokens: '}
                              {chunkSizeValue && (
                                <Form.Text className="label-text">
                                  {chunkSizeValue}
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={chunkSizeValue}
                              min={100}
                              max={8191}
                              step={1}
                              onChange={handleChunkSizeChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSlider">
                            <Form.Label className="label-text">
                              {'Overlap Percentage: '}
                              {overLapPercent && (
                                <Form.Text className="label-text">
                                  {overLapPercent} %
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={overLapPercent}
                              min={0}
                              max={50}
                              step={1}
                              onChange={handleOverlapPercentChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                      </>
                    )}
                    {(isEditMode
                      ? instanceDetails.chunking_strategy
                      : chunkingStrategy) === 'HIERARCHICAL' && (
                      <>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSlider">
                            <Form.Label className="label-text">
                              {'Max Tokens Parent: '}
                              {chunkSizeValue && (
                                <Form.Text className="label-text">
                                  {chunkSizeValue}
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={chunkSizeValue}
                              min={500}
                              max={4000}
                              step={10}
                              onChange={handleChunkSizeChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSlider">
                            <Form.Label className="label-text">
                              {'Max Tokens Child: '}
                              {childMaxTokens && (
                                <Form.Text className="label-text">
                                  {childMaxTokens}
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={childMaxTokens}
                              min={500}
                              max={4000}
                              step={10}
                              onChange={handleChildMaxTokensChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSlider">
                            <Form.Label className="label-text">
                              {'Overlap Tokens: '}
                              {overLapPercent && (
                                <Form.Text className="label-text">
                                  {overLapPercent}
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={overLapPercent}
                              min={0}
                              max={200}
                              step={5}
                              onChange={handleOverlapPercentChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                      </>
                    )}
                    {(isEditMode
                      ? instanceDetails.chunking_strategy
                      : chunkingStrategy) === 'SEMANTIC' && (
                      <>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSlider">
                            <Form.Label className="label-text">
                              {'Max Tokens: '}
                              {chunkSizeValue && (
                                <Form.Text className="label-text">
                                  {chunkSizeValue}
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={chunkSizeValue}
                              min={100}
                              max={1000}
                              step={10}
                              onChange={handleChunkSizeChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSliderBreakpoint">
                            <Form.Label className="label-text">
                              {'Breakpoint Percentile Threshold: '}
                              {breakPointPercent && (
                                <Form.Text className="label-text">
                                  {breakPointPercent}
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={breakPointPercent}
                              min={80}
                              max={100}
                              step={1}
                              onChange={handleBreakPointPercentChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                        <div className="basic-details-wrapper">
                          <Form.Group controlId="formSliderBuffer">
                            <Form.Label className="label-text">
                              {'Buffer Size: '}
                              {bufferSize && (
                                <Form.Text className="label-text">
                                  {bufferSize}
                                </Form.Text>
                              )}
                            </Form.Label>
                            <Form.Range
                              value={bufferSize}
                              defaultValue={1}
                              min={1}
                              max={10}
                              step={1}
                              onChange={handleBufferSizeChange}
                              className="custom-slider"
                              disabled={isEditMode || isBackClicked}
                            />
                          </Form.Group>
                        </div>
                      </>
                    )}
                  </div>
                </>
              )}

            <div className="button-container">
              {currentApp?.name !== CHANGE_COMMUNICATOR && (
                <>
                  {userRole &&
                    (userRole === ADMIN || userRole === SUPERADMIN) && (
                      <Button
                        variant="primary"
                        onClick={() =>
                          isEditMode || isBackClicked
                            ? editTemperature()
                            : createInstance()
                        }
                        className="primary-btn-style modal-button"
                        disabled={nameErrorCheck}
                      >
                        Next
                      </Button>
                    )}
                </>
              )}
              {currentApp?.name === CHANGE_COMMUNICATOR && (
                <>
                  {userRole &&
                    (userRole === ADMIN || userRole === SUPERADMIN) && (
                      <Button
                        variant="primary"
                        onClick={() =>
                          isEditMode || isBackClicked
                            ? editTemperature()
                            : createInstance()
                        }
                        className="primary-btn-style modal-button"
                      >
                        Finish
                      </Button>
                    )}
                </>
              )}
            </div>
          </Form.Group>
        </>
      ) : currentStep === 2 && step2 ? (
        <>
          {(isEditMode ? instanceDetails.llm_guard_value : grsType) ===
            'aws_bedrock' ||
          (isEditMode ? instanceDetails.llm_guard_value : grsType) ===
            'azure_guardrails' ? (
            <AwsGuardRails
              instanceId={isEditMode ? selectedInstance : instanceData?.id}
              nextStep={nextStep}
              prevStep={prevStep}
              setShowNewInstanceModal={setShowNewInstanceModal}
              instanceDetails={instanceDetails}
              isBedrockDisabled={
                isEditMode || isBackClicked || isBedrockDisabled
              }
              cloudProvider={
                isEditMode ? instanceDetails.cloudEnvironment : cloudProvider
              }
            />
          ) : (
            <TrusthWorthyLlmForm
              instanceData={isEditMode ? selectedInstance : instanceData?.id}
              nextStep={nextStep}
              prevStep={prevStep}
              setShowNewInstanceModal={setShowNewInstanceModal}
              instanceDetails={instanceDetails}
            />
          )}
        </>
      ) : (!step2 && currentStep === 2 && step3) ||
        (step2 && currentStep === 3 && step3) ? (
        !knowledgeUploadCheck ? (
          <Container ref={containerRef}>
            <div className="modal-header-container">
              <h2 className="modal-header-title">Knowledge Details</h2>
            </div>
            <div className="basic-details-container-step2">
              <div className="basic-details-knowledge-wrapper">
                <Form.Group
                  className="knowledge-name"
                  controlId="exampleForm.knowledgeName"
                >
                  <Form.Label className="label-text">Knowledge Name</Form.Label>
                  <Form.Control
                    as="input"
                    // value={isEditMode ? instanceDetails.name : newKnowledgeID}
                    value={newKnowledgeID}
                    className="text-input"
                    onChange={handleKnowledgeName}
                    // disabled={isEditMode}
                  />
                  {knowledgeNameCheck && (
                    <div className="upload-error new-name-check">
                      Knowledge Name should not start with special character!!
                    </div>
                  )}
                </Form.Group>
              </div>
              <div className="basic-details-knowledge-wrapper">
                <Form.Group
                  className="file-input"
                  controlId="exampleForm.fileInput"
                >
                  <Form.Label className="label-text">
                    Upload Document
                  </Form.Label>
                  <Form.Control
                    type="file"
                    multiple
                    accept={`${PDF}, ${DOCX}, ${TXT}, ${XLSXFile}, ${CSV}`}
                    onChange={handleFileChange}
                    ref={knowledgeFileUpload}
                  />
                  {isUploadLoading && (
                    <div className="upload-spinner">
                      <Spinner animation="border" size="sm" /> Uploading
                    </div>
                  )}
                  {uploadedFiles && isUploadSuccess && (
                    <div className="upload-msg">
                      <Badge bg="success">Upload Successful</Badge>
                    </div>
                  )}
                  <div className="basic-details-container-checkbox">
                    {(isEditMode
                      ? instanceDetails.cloudEnvironment
                      : cloudProvider) === AZURE_CLOUD && (
                      <Form.Group>
                        <Form.Label>
                          The document being uploaded contains :{' '}
                        </Form.Label>
                        <Form.Check
                          type="checkbox"
                          name="documentContents"
                          label="Tables"
                          value="tables-or-images"
                          checked={documentContents === 'tables-or-images'}
                          defaultChecked={false}
                          onChange={() => handleDocumentContentsChange(count)}
                        />
                      </Form.Group>
                    )}
                  </div>
                  <div className="choose-file-note">
                    {fileUploadKnowledegenote1}
                  </div>
                  {((!isEditMode && cloudProvider === AZURE_CLOUD) ||
                    (isEditMode &&
                      instanceDetails.cloudEnvironment === AZURE_CLOUD)) && (
                    <div className="choose-file-note">
                      {fileUploadKnowledegenote2}
                    </div>
                  )}
                </Form.Group>
              </div>
            </div>
            <div className="basic-details-container">
              <Button
                variant="secondary"
                onClick={loadKnowledge}
                className="secondary-btn-style modal-button"
                disabled={
                  newKnowledgeID.length <= 0 ||
                  uploadedFiles.length === 0 ||
                  isKnowledgeUploadDisabled
                }
              >
                Upload
              </Button>
            </div>
            {uploadError && newKnowledgeID.length <= 0 && (
              <ToastMessage
                setShowToast={setUploadError}
                isInsideModal={true}
                errorMessage={KnowledgeNameError}
              />
            )}
            <Form.Label className="label-text">{KNOWLEDGE_IDS}</Form.Label>
            <div className="basic-details-container">
              <KnowledgeTable
                vectorDb={isEditMode ? instanceDetails.vectorDb : vectorDb}
                data={
                  instanceDetails ? instanceDetails.knowledgeIds : knowledgeIDs
                }
                expandedRows={expandedRows}
                toggleRowExpansion={toggleRowExpansion}
                getInstanceData={getInstanceData}
                showDelete={true}
                cloudProvider={
                  instanceDetails
                    ? instanceDetails.cloudEnvironment
                    : cloudProvider
                }
                selectedInstance={
                  instanceDetails ? selectedInstance : instanceData?.id
                }
                templateInstructionMode={'Advanced'}
                basicModeDescription={basicModeDescription}
                handleAddDescription={handleAddDecriptin}
                isEditMode={isEditMode}
                descriptionError={descriptionError}
              />
            </div>

            <div className="two-button-container">
              <Button
                variant="primary"
                onClick={() => {
                  setCount(0);
                  setDocumentContents('');
                  prevStep();
                  setKnowledgeUploadCheck(false);
                }}
                className="secondary-btn-style modal-button"
              >
                Back
              </Button>

              <Button
                variant="primary"
                onClick={() => {
                  if (knowledgeIDs?.length === 0) {
                    setKnowledgeUploadCheck(true);
                    // setShowToast(true);
                  } else {
                    setCount(0);
                    setDocumentContents('');
                    nextStep();
                  }
                }}
                disabled={knowledgeNameCheck}
                className="primary-btn-style modal-button"
                // disabled={uploadError}
              >
                Next
              </Button>
            </div>
          </Container>
        ) : (
          <>
            <Modal
              show={knowledgeUploadCheck}
              onHide={() => setKnowledgeUploadCheck(false)}
              className="mb-0"
              size="lg"
            >
              <Modal.Header closeButton>
                <Modal.Title>
                  <div className="d-flex">
                    <div className="p-2 d-flex align-items-center border-1">
                      <FaTriangleExclamation
                        size={30}
                        className="text-warning"
                      />
                    </div>
                    <div className="p-2 d-flex align-items-center ">
                      <p className="m-0">Warning</p>
                    </div>
                  </div>
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <p>
                  No project-specific documents have been uploaded. Without this
                  data, responses will be generic. Do you want to continue?
                </p>
              </Modal.Body>
              <Modal.Footer>
                <Button
                  variant="primary"
                  onClick={() => setKnowledgeUploadCheck(false)}
                >
                  Stay And Upload Knowledge
                </Button>
                <Button
                  variant="secondary"
                  className="modal-secondary-btn"
                  onClick={() => {
                    setCount(0);
                    setDocumentContents('');
                    nextStep();
                  }}
                >
                  Continue To Next Step
                </Button>
              </Modal.Footer>
            </Modal>
          </>
        )
      ) : (
        ((!step2 && currentStep === 3 && step4) ||
          (!step3 && currentStep === 3 && step4) ||
          (currentStep === 4 && step4) ||
          (!step3 && currentStep === 2 && step4)) && (
          <Container>
            <div className="modal-header-container">
              <h2 className="modal-header-title">Template Details</h2>
            </div>
            <Form.Group
              className="template-container"
              controlId="exampleForm.createTemplate"
            >
              <div className="template-field-wrapper">
                <Form.Label className="label-text">Template Name</Form.Label>
                <Form.Control
                  as="input"
                  type="text"
                  value={
                    isEditMode ? instanceDetails.templateName : newTemplateName
                  }
                  onChange={handleTemplateNameChange}
                  className="text-input"
                  disabled={isEditMode || isBackClicked}
                />
              </div>
              {currentApp?.name === TEST_SCRIPT_GENERATOR ? (
                <>
                  <Form.Label className="label-text">
                    Template Instructions
                  </Form.Label>
                  {templateInstructions === 'Advanced' ? (
                    <div>
                      <CustomReactTextareaAutocomplete
                        className="form-control rta__textarea"
                        rows={3}
                        value={templatePrompt}
                        minChar={0}
                        onChange={handleTemplatePromptChange}
                        loadingComponent={Loading}
                        trigger={{
                          '{': {
                            dataProvider: () => {
                              // for DOC_INSIGHT app only, return only the last knowledge id - temporary fix to be removed later
                              if (currentApp?.name === DOC_INSIGHT) {
                                if (
                                  instanceDetails &&
                                  instanceDetails?.knowledgeIds &&
                                  instanceDetails?.knowledgeIds?.length > 0
                                ) {
                                  return [
                                    instanceDetails?.knowledgeIds[
                                      instanceDetails?.knowledgeIds?.length - 1
                                    ],
                                  ];
                                } else {
                                  return knowledgeIDs && knowledgeIDs.length > 0
                                    ? [knowledgeIDs[knowledgeIDs.length - 1]]
                                    : [];
                                }
                              } else {
                                if (instanceDetails) {
                                  return [...instanceDetails.knowledgeIds];
                                } else {
                                  return knowledgeIDs || [];
                                }
                              }
                            },
                            component: Item,
                            output: (item: Knowledge, trigger: string) =>
                              `{{knowledgeid_${item.id}}}`,
                          },
                        }}
                      />

                      {isEditMode &&
                        instanceDetails.chunking_strategy !==
                          'TOKEN_LIMIT_CHUNK' && (
                          <div className="tokens-div">
                            Progress bar is only visible when Chunking Stratergy
                            is Token Chunking
                          </div>
                        )}

                      {!isEditMode &&
                        chunkingStrategy !== 'TOKEN_LIMIT_CHUNK' && (
                          <div className="tokens-div">
                            Progress bar is only visible when Chunking Stratergy
                            is Token Chunking
                          </div>
                        )}
                      {isEditMode &&
                        instanceDetails.chunking_strategy ===
                          'TOKEN_LIMIT_CHUNK' && (
                          <div className="tokens-div">
                            {((filetokencount + tokencount) /
                              tokelimit?.tokenSize) *
                              100 >=
                              100 && (
                              <ToastMessage
                                errorMessage={
                                  `${TokenLimitError1}` +
                                  `${selectedModel}` +
                                  `${TokenLimitError2}`
                                }
                                isInsideModal={true}
                              />
                            )}

                            <div className="token-counter-bar-wrapper">
                              <div className="token-display">
                                Tokens Used {filetokencount + tokencount}/
                                {tokelimit?.tokenSize}
                              </div>
                              <ProgressBar
                                className="token-count-progress"
                                now={
                                  ((filetokencount + tokencount) /
                                    tokelimit?.tokenSize) *
                                  100
                                }
                                variant={getColor(
                                  ((filetokencount + tokencount) /
                                    tokelimit?.tokenSize) *
                                    100
                                )}
                              />
                            </div>
                          </div>
                        )}
                      {!isEditMode &&
                        chunkingStrategy === 'TOKEN_LIMIT_CHUNK' &&
                        !step3 && (
                          <div className="tokens-div">
                            Progress bar is only visible when Chunking Stratergy
                            is Token Chunking
                          </div>
                        )}
                      {!isEditMode &&
                        chunkingStrategy === 'TOKEN_LIMIT_CHUNK' &&
                        step3 && (
                          <div className="tokens-div">
                            {((filetokencount + tokencount) /
                              tokelimit?.tokenSize) *
                              100 >=
                              100 && (
                              <ToastMessage
                                errorMessage={
                                  `${TokenLimitError1}` +
                                  `${selectedModel}` +
                                  `${TokenLimitError2}`
                                }
                                isInsideModal={true}
                              />
                            )}
                            <div className="token-counter-bar-wrapper">
                              <div className="token-display">
                                Tokens Used {filetokencount + tokencount}/
                                {tokelimit?.tokenSize}
                              </div>
                              <ProgressBar
                                className="token-count-progress"
                                now={
                                  ((filetokencount + tokencount) /
                                    tokelimit?.tokenSize) *
                                  100
                                }
                                variant={getColor(
                                  ((filetokencount + tokencount) /
                                    tokelimit?.tokenSize) *
                                    100
                                )}
                              />
                            </div>
                          </div>
                        )}
                      {currentApp?.name === TEST_SCRIPT_GENERATOR && (
                        <div className="margin-top margin-bottom">
                          <div className="choose-file-note">Note:</div>
                          <div className="choose-file-note">
                            {customOutputColumnNote1}
                          </div>
                          <div className="choose-file-note">
                            {customOutputColumnNote2}
                          </div>
                          <div className="choose-file-note">
                            {customOutputColumnNote3}
                          </div>
                        </div>
                      )}
                      {currentApp?.name === TEST_SCRIPT_GENERATOR && (
                        <div className="output-column-parent-container">
                          <div className="fixed-output-columns">
                            <Form.Control
                              type="text"
                              placeholder="Title"
                              className="mb-2"
                              draggable={false}
                              disabled={true}
                            />
                            <Form.Control
                              type="text"
                              placeholder="Test Steps"
                              className="mb-2"
                              draggable={false}
                              disabled={true}
                            />
                            <Form.Control
                              type="text"
                              placeholder="Expected Outcome"
                              className="mb-2"
                              draggable={false}
                              disabled={true}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <>
                      <div className="basic-mode-template-wrapper">
                        <Form.Group style={{ display: 'flex', width: '60%' }}>
                          <Form.Label className="label-text margin-top">
                            View/Edit default guidelines
                          </Form.Label>
                          <div
                            className="option-labels margin-top"
                            style={{ marginLeft: '10px' }}
                          >
                            <Form.Check
                              type="switch"
                              id="custom-switch"
                              checked={viewDefaultGuidelines === true}
                              style={{ justifyContent: 'flex-start' }}
                              onChange={(
                                event: React.ChangeEvent<HTMLInputElement>
                              ) => {
                                setViewDefaultGuidelines(
                                  !viewDefaultGuidelines
                                );
                              }}
                            />
                          </div>
                        </Form.Group>
                        {viewDefaultGuidelines && (
                          <BasicModeTemplatePrompt
                            instanceDetails={instanceDetails}
                            templatePrompt={basicTemplatePrompt}
                            knowledgeId={knowledgeIDs}
                            handleTemplatePromptChange={
                              handleTemplatePromptChange
                            }
                            handleLayoutChange={handleLayoutChange}
                            selectedLayoutKey={selectedLayout}
                            editMode={isEditMode}
                            selectedTemplateHeadings={selectedTemplateHeadings}
                          />
                        )}

                        <Accordion style={{ width: '50%' }}>
                          <Accordion.Item eventKey="0">
                            <Accordion.Header>Test Scope</Accordion.Header>
                            <Accordion.Body>
                              {isEditMode ? (
                                <>
                                  {instanceDetails?.knowledgeIds?.map(
                                    (knowledgeId: Knowledge) => (
                                      <>
                                        <div style={{ display: 'flex' }}>
                                          <input
                                            type="checkbox"
                                            onChange={() => {
                                              handleSelectKnowledgeID(
                                                knowledgeId
                                              );
                                            }}
                                            checked={selectedKnowledgeIds?.includes(
                                              knowledgeId.id
                                            )}
                                          />
                                          <option
                                            value={knowledgeId.id}
                                            style={{ marginLeft: '5px' }}
                                          >
                                            {`${knowledgeId.name} - ${knowledgeId.id}`}
                                          </option>
                                        </div>
                                      </>
                                    )
                                  )}
                                </>
                              ) : (
                                <>
                                  {knowledgeIDs?.map(
                                    (knowledgeId: Knowledge) => (
                                      <div style={{ display: 'flex' }}>
                                        <input
                                          type="checkbox"
                                          onChange={() => {
                                            handleSelectKnowledgeID(
                                              knowledgeId
                                            );
                                          }}
                                        />
                                        <option
                                          value={knowledgeId.id}
                                          style={{ marginLeft: '5px' }}
                                        >
                                          {`${knowledgeId.name} - ${knowledgeId.id}`}
                                        </option>
                                      </div>
                                    )
                                  )}
                                </>
                              )}
                            </Accordion.Body>
                          </Accordion.Item>
                        </Accordion>

                        <div className="margin-top checkPoints-container">
                          <Tabs
                            defaultActiveKey="Functional"
                            id="justify-tab-example"
                            className="mb-3"
                            justify
                            onSelect={(key: string | null) => {
                              if (key !== null) {
                                setActiveTab(key);
                              }
                            }}
                          >
                            <Tab title="Functional" eventKey={'Functional'}>
                              <div className="checkPoints-tabContent">
                                <div>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Pre-requisite"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Pre-requisite'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Pre Requisites
                                    </Form.Label>
                                  </Form.Group>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Negative Steps"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Negative Steps'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Negative Steps
                                    </Form.Label>
                                  </Form.Group>
                                </div>
                                <div>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="End To End Testing"
                                      checked={selectedTemplateHeadings?.includes(
                                        'End To End Testing'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      End To End Testing
                                    </Form.Label>
                                  </Form.Group>
                                </div>
                              </div>
                            </Tab>

                            <Tab title="Data" eventKey={'Data'}>
                              <div className="checkPoints-tabContent">
                                <div>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Format Validations"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Format Validations'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Format Validations
                                    </Form.Label>
                                  </Form.Group>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="UI Validations"
                                      checked={selectedTemplateHeadings?.includes(
                                        'UI Validations'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      UI Validations
                                    </Form.Label>
                                  </Form.Group>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Boundary Testing"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Boundary Testing'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Boundary Testing
                                    </Form.Label>
                                  </Form.Group>
                                </div>
                                <div>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Field Length Validations"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Field Length Validations'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Field Length Validations
                                    </Form.Label>
                                  </Form.Group>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Data Type Validations"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Data Type Validations'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Data Type Validations
                                    </Form.Label>
                                  </Form.Group>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Mandatory Field Validations"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Mandatory Field Validations'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Mandatory Field Validations
                                    </Form.Label>
                                  </Form.Group>
                                </div>
                              </div>
                            </Tab>
                            <Tab title="Validation" eventKey={'Validation'}>
                              <div className="checkPoints-tabContent">
                                <div>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Accessibility Testing"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Accessibility Testing'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Accessibility Testing
                                    </Form.Label>
                                  </Form.Group>
                                </div>
                                <div>
                                  <Form.Group style={{ display: 'flex' }}>
                                    <input
                                      type="checkbox"
                                      id="vehicle1"
                                      name="vehicle1"
                                      value="Cross-Browser Testing"
                                      checked={selectedTemplateHeadings?.includes(
                                        'Cross-Browser Testing'
                                      )}
                                      onChange={(e) =>
                                        handleTCGTemplatePointChange(e)
                                      }
                                    />
                                    <Form.Label
                                      className="label-text"
                                      style={{
                                        marginLeft: '10px',
                                        marginTop: '10px',
                                      }}
                                    >
                                      Cross-Browser Testing
                                    </Form.Label>
                                  </Form.Group>
                                </div>
                              </div>
                            </Tab>
                          </Tabs>
                        </div>
                        <Form.Label className="label-text selected-layout-label">
                          Select one Layout
                        </Form.Label>
                        <div>
                          {!imageEnlarge ? (
                            <div className="select-layout-image-container">
                              <div className="individual-layout-image-container">
                                <Form.Check
                                  type={'radio'}
                                  name="selected-layout"
                                  onChange={() => handleLayoutChange('first')}
                                  checked={selectedLayout === 'first'}
                                />
                                <img
                                  src="/TSGLayout1.png"
                                  alt="layout3"
                                  className={
                                    imageEnlarge
                                      ? 'enlarge-layout'
                                      : 'layout-image'
                                  }
                                  onClick={() => {
                                    setImageEnlarge(!imageEnlarge);
                                    setSelectedLayout('/TSGLayout1.png');
                                  }}
                                />
                              </div>
                              <div className="individual-layout-image-container">
                                <Form.Check
                                  type={'radio'}
                                  name="selected-layout"
                                  onChange={() => handleLayoutChange('second')}
                                  checked={selectedLayout === 'second'}
                                />
                                <img
                                  src="/TSGLayout2.png"
                                  alt="layout3"
                                  className={
                                    imageEnlarge
                                      ? 'enlarge-layout'
                                      : 'layout-image'
                                  }
                                  onClick={() => {
                                    setImageEnlarge(!imageEnlarge);
                                    setSelectedLayout('/TSGLayout2.png');
                                  }}
                                />
                              </div>
                              <div className="individual-layout-image-container">
                                <Form.Check
                                  type={'radio'}
                                  name="selected-layout"
                                  onChange={() => handleLayoutChange('third')}
                                  checked={selectedLayout === 'third'}
                                />
                                <img
                                  src="/TSGLayout3.png"
                                  alt="layout3"
                                  className={
                                    imageEnlarge
                                      ? 'enlarge-layout'
                                      : 'layout-image'
                                  }
                                  onClick={() => {
                                    setImageEnlarge(!imageEnlarge);
                                    setSelectedLayout('/TSGLayout3.png');
                                  }}
                                />
                              </div>
                            </div>
                          ) : (
                            <div className="enlarged-image-container">
                              <img
                                src={isValidImageUrl(selectedLayout) ? selectedLayout : '/default-image.png'}
                                alt="layout3"
                                className="image-enlarge"
                                onClick={() => {
                                  setImageEnlarge(!imageEnlarge);
                                  setSelectedLayout('');
                                }}
                              />
                              <Button
                                onClick={() => {
                                  setImageEnlarge(!imageEnlarge);
                                  setSelectedLayout('');
                                }}
                                variant="danger"
                                className="d-flex justify-content-center align-items-center cross-btn enlarged-image-close-button"
                              >
                                <FaTimes />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                </>
              ) : (
                <div className="template-field-wrapper">
                  <Form.Label className="label-text">
                    Template Instructions
                  </Form.Label>
                  <CustomReactTextareaAutocomplete
                    className="form-control rta__textarea"
                    rows={3}
                    value={templatePrompt}
                    minChar={0}
                    onChange={handleTemplatePromptChange}
                    loadingComponent={Loading}
                    trigger={{
                      '{': {
                        dataProvider: () => {
                          // for DOC_INSIGHT app only, return only the last knowledge id - temporary fix to be removed later
                          if (currentApp?.name === DOC_INSIGHT) {
                            if (
                              instanceDetails &&
                              instanceDetails?.knowledgeIds &&
                              instanceDetails?.knowledgeIds?.length > 0
                            ) {
                              return [
                                instanceDetails?.knowledgeIds[
                                  instanceDetails?.knowledgeIds?.length - 1
                                ],
                              ];
                            } else {
                              return knowledgeIDs && knowledgeIDs.length > 0
                                ? [knowledgeIDs[knowledgeIDs.length - 1]]
                                : [];
                            }
                          } else {
                            if (instanceDetails) {
                              return [...instanceDetails.knowledgeIds];
                            } else {
                              return knowledgeIDs || [];
                            }
                          }
                        },
                        component: Item,
                        output: (item: Knowledge, trigger: string) =>
                          `{{knowledgeid_${item.id}}}`,
                      },
                    }}
                  />

                  {isEditMode &&
                    instanceDetails.chunking_strategy !==
                      'TOKEN_LIMIT_CHUNK' && (
                      <div className="tokens-div">
                        Progress bar is only visible when Chunking Stratergy is
                        Token Chunking
                      </div>
                    )}

                  {!isEditMode && chunkingStrategy !== 'TOKEN_LIMIT_CHUNK' && (
                    <div className="tokens-div">
                      Progress bar is only visible when Chunking Stratergy is
                      Token Chunking
                    </div>
                  )}
                  {isEditMode &&
                    instanceDetails.chunking_strategy ===
                      'TOKEN_LIMIT_CHUNK' && (
                      <div className="tokens-div">
                        {((filetokencount + tokencount) /
                          tokelimit?.tokenSize) *
                          100 >=
                          100 && (
                          <ToastMessage
                            errorMessage={
                              `${TokenLimitError1}` +
                              `${selectedModel}` +
                              `${TokenLimitError2}`
                            }
                            isInsideModal={true}
                          />
                        )}
                        <div className="token-counter-bar-wrapper">
                          <div className="token-display">
                            Tokens Used {filetokencount + tokencount}/
                            {tokelimit?.tokenSize}
                          </div>
                          <ProgressBar
                            className="token-count-progress"
                            now={
                              ((filetokencount + tokencount) /
                                tokelimit?.tokenSize) *
                              100
                            }
                            variant={getColor(
                              ((filetokencount + tokencount) /
                                tokelimit?.tokenSize) *
                                100
                            )}
                          />
                        </div>
                      </div>
                    )}
                  {!isEditMode &&
                    chunkingStrategy === 'TOKEN_LIMIT_CHUNK' &&
                    !step3 && (
                      <div className="tokens-div">
                        Progress bar is only visible when Chunking Stratergy is
                        Token Chunking
                      </div>
                    )}
                  {!isEditMode &&
                    chunkingStrategy === 'TOKEN_LIMIT_CHUNK' &&
                    step3 && (
                      <div className="tokens-div">
                        {((filetokencount + tokencount) /
                          tokelimit?.tokenSize) *
                          100 >=
                          100 && (
                          <ToastMessage
                            errorMessage={
                              `${TokenLimitError1}` +
                              `${selectedModel}` +
                              `${TokenLimitError2}`
                            }
                            isInsideModal={true}
                          />
                        )}
                        <div className="token-counter-bar-wrapper">
                          <div className="token-display">
                            Tokens Used {filetokencount + tokencount}/
                            {tokelimit?.tokenSize}
                          </div>
                          <ProgressBar
                            className="token-count-progress"
                            now={
                              ((filetokencount + tokencount) /
                                tokelimit?.tokenSize) *
                              100
                            }
                            variant={getColor(
                              ((filetokencount + tokencount) /
                                tokelimit?.tokenSize) *
                                100
                            )}
                          />
                        </div>
                      </div>
                    )}
                  {currentApp?.name === TEST_SCRIPT_GENERATOR && (
                    <div className="margin-top margin-bottom">
                      <div className="choose-file-note">Note:</div>
                      <div className="choose-file-note">
                        {customOutputColumnNote1}
                      </div>
                      <div className="choose-file-note">
                        {customOutputColumnNote2}
                      </div>
                      <div className="choose-file-note">
                        {customOutputColumnNote3}
                      </div>
                      {/* <div className="choose-file-note">
                          {userNoteOutputColum2}
                        </div>
                        <div className="choose-file-note">
                          {userNoteOutputColum3}
                        </div> */}
                    </div>
                  )}
                  {currentApp?.name === TEST_SCRIPT_GENERATOR && (
                    <div className="output-column-parent-container">
                      {/* <div
                          className="keyValue-container output-column-container"
                          id="output-column"
                        > */}
                      <div className="fixed-output-columns">
                        <Form.Control
                          type="text"
                          placeholder="Title"
                          className="mb-2"
                          draggable={false}
                          disabled={true}
                        />
                        <Form.Control
                          type="text"
                          placeholder="Test Steps"
                          className="mb-2"
                          draggable={false}
                          disabled={true}
                        />
                        <Form.Control
                          type="text"
                          placeholder="Expected Outcome"
                          className="mb-2"
                          draggable={false}
                          disabled={true}
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {isUploadtemplate && (
                <Col>
                  <Row>
                    <Form.Group
                      className="file-input"
                      controlId="exampleForm.fileInput"
                    >
                      <Form.Label>Upload document(s)</Form.Label>
                      <Form.Control
                        type="file"
                        multiple
                        accept={
                          currentApp?.name === STATUS_REPORT_GENERATOR
                            ? `${PPT}, ${PPTX},${DOCX}`
                            : `${CSV}, ${XLSXFile}, ${PDF}, ${DOCX}, ${TXT}`
                        }
                        onChange={handleFileChange}
                        ref={filesSelectedForUploadRef}
                        disabled={isEditMode || isBackClicked}
                      />
                    </Form.Group>
                    {isUploadLoading && (
                      <div className="upload-spinner">
                        <Spinner animation="border" size="sm" /> Uploading
                      </div>
                    )}
                    {showFileUploadSuccessMsg && (
                      <div className="upload-msg">
                        <Badge bg="success">Upload Successful</Badge>
                      </div>
                    )}
                    <div>
                      <Form.Text>Formats supported: docx & ppt</Form.Text>
                    </div>
                    <div style={{ marginBottom: '10px' }}>
                      <Form.Text>
                        Note: If no templates are added then default templates
                        will be added from backend.
                      </Form.Text>
                    </div>
                  </Row>
                  <Row>
                    <Col>
                      {userRole &&
                        (userRole === ADMIN || userRole === SUPERADMIN) && (
                          <Button
                            variant="secondary"
                            onClick={() => handleUploadInstanceDoc()}
                            className="secondary-btn-style upload-secondary"
                            disabled={
                              isEditMode ||
                              isBackClicked ||
                              uploadedFiles.length === 0
                            }
                          >
                            Upload File
                          </Button>
                        )}
                    </Col>
                  </Row>
                </Col>
              )}
              {step3 && (
                <div className="template-field-wrapper ">
                  <Form.Label className="label-text">
                    {KNOWLEDGE_IDS}
                  </Form.Label>
                  <div className="knowledgeId-list-wraper">
                    {instanceDetails ? (
                      <KnowledgeTable
                        data={instanceDetails.knowledgeIds}
                        expandedRows={expandedRows}
                        toggleRowExpansion={toggleRowExpansion}
                        showDelete={false}
                      />
                    ) : (
                      <KnowledgeTable
                        data={knowledgeIDs}
                        expandedRows={expandedRows}
                        toggleRowExpansion={toggleRowExpansion}
                        showDelete={false}
                      />
                    )}
                  </div>
                </div>
              )}
            </Form.Group>
            {selectedKnowledgeIdError &&
              currentApp?.name === TEST_SCRIPT_GENERATOR &&
              templateInstructions === 'Basic' && (
                <div className="upload-error">
                  Please select atleast one knowledge id
                </div>
              )}

            <div className="two-button-container">
              <Button
                variant="primary"
                onClick={() => {
                  prevStep();
                  setKnowledgeUploadCheck(false);
                }}
                className="secondary-btn-style modal-button"
              >
                Back
              </Button>
              {userRole && (userRole === ADMIN || userRole === SUPERADMIN) && (
                <Button
                  variant="primary"
                  onClick={createTemplate}
                  className="modal-button"
                  disabled={filetokencount + tokencount > tokelimit?.tokenSize}
                >
                  Finish
                </Button>
              )}
            </div>
          </Container>
        )
      )}
    </div>
  );
};

export default InstanceGenerator;
