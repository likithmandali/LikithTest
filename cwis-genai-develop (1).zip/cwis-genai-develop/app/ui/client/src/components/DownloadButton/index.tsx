import React, { useContext } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import axios from 'axios';

import './DownloadButton.css';
import UserContext from '../../context/UserContext';
import { isValidRedirectUrl, isValidDownloadUrl } from '../../utils/security';
type downloadButtonProps = {
  instanceId?: any;
  outputData?: any;
  title?: string;
  activeActivityId?: any;
  activityType?: string;
};

const DownloadButton: React.FC<downloadButtonProps> = ({
  instanceId,
  outputData,
  title,
  activeActivityId,
  activityType,
}) => {
  const userContext = useContext(UserContext) || {
    setShowToast: () => {},
    setErrorMessage: () => {},
  };

  const { setShowToast, setErrorMessage } = userContext;
  const handleDownLoad = async (e: any) => {
    const fileType = e;
    let formData;
    if (activityType === 'Status Report Generator') {
      const instance_id = instanceId.toString();
      formData = {
        input_text: outputData,
        report_file_type: fileType,
        instance_id: instance_id,
      };
    } else {
      formData = {
        activity_id: activeActivityId,
        report_type: fileType,
      };
    }
    let response;
    try {
      if (activityType === 'Status Report Generator') {
        response = await axios.post(
          `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/report/download`,
          formData,
          {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        );
      } else {
        response = await axios.post(
          `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/one-shot-chain/notice-analysis/downloads-report-by-activity-id`,
          null,
          {
            params: formData,
            headers: {
              'Content-Type': 'application/json',
            },
          }
        );
      }
      if (response && response.status === 200) {
        const fileResponse = response.data.response;
        if (fileResponse) {
          const fileUrl = fileResponse.download_link;
          
          // Validate the file URL from API response first
          if (!fileUrl || typeof fileUrl !== 'string') {
            // console.error('Invalid file URL received from API:', fileUrl);
            return;
          }
          
          let downloadURL = '';
          if (activityType === 'Status Report Generator') {
            // Validate and construct URL safely
            const backendDomain = process.env.REACT_APP_BACKEND_DOMAIN;
            if (!backendDomain) {
              console.error('Backend domain not configured');
              return;
            }
            
            try {
              // Use URL constructor for safe URL building
              const baseUrl = new URL(backendDomain);
              const fullUrl = new URL(fileUrl, baseUrl);
              downloadURL = fullUrl.href;
            } catch (error) {
              console.error('Failed to construct download URL:', error);
              return;
            }
          } else {
            downloadURL = fileUrl;
          }
          
          // Validate the final download URL using the specialized download validation
          if (isValidDownloadUrl(downloadURL)) {
            try {
              // Additional security: Reconstruct URL to ensure it's properly formatted
              const validatedUrl = new URL(downloadURL);
              const clickLink = document.createElement('a');
              clickLink.href = validatedUrl.href;
              clickLink.download = ''; // Ensure download attribute is set
              clickLink.click();
            } catch (error) {
              console.error('Failed to create valid download URL:', error);
            }
          } else {
            console.error('Invalid download URL detected, potential XSS attempt blocked:');
          }
        }
      } else {
        console.error('Failed to get response');
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      console.error('Error:', error);
    }
  };

  const renderDropdownItems = () => {
    if (activityType === 'Status Report Generator') {
      return (
        <>
          <Dropdown.Item
            eventKey="pptx"
            onSelect={() => handleDownLoad('pptx')}
          >
            PPT
          </Dropdown.Item>
          <Dropdown.Item
            eventKey="docx"
            onSelect={() => handleDownLoad('docx')}
          >
            Word file
          </Dropdown.Item>
        </>
      );
    } else if (activityType === 'Notice Analysis Engine') {
      return (
        <>
          <Dropdown.Item
            eventKey="xlsx"
            onSelect={() => handleDownLoad('xlsx')}
          >
            Excel File
          </Dropdown.Item>
          <Dropdown.Item eventKey="csv" onSelect={() => handleDownLoad('csv')}>
            CSV
          </Dropdown.Item>
        </>
      );
    }
    return null;
  };

  return (
    <DropdownButton
      id="dropdown-download-button"
      variant="success"
      title={title}
      onSelect={handleDownLoad}
    >
      {renderDropdownItems()}
    </DropdownButton>
  );
};

export default DownloadButton;
