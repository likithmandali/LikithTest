import React, { useContext, useEffect, useState } from 'react';
import { Appl, Instance } from '../../interfaces';
import { Button, Form, Modal } from 'react-bootstrap';
import UserContext from '../../context/UserContext';
import axios from 'axios';
import { FaEdit } from 'react-icons/fa';

import { FaTrashAlt } from 'react-icons/fa';
import InstanceSteps from './InstanceSteps';
import { SUPERADMIN } from '../../utils/constants';
import ErrorMessage from '../ErrorMessage';

type SetStateFunction<T> = React.Dispatch<React.SetStateAction<T>>;

type SelectInstanceProps = {
  projectId: string;
  currentApp: Appl | undefined;
  chatbox?: any;
  outputData?: string;
  setOutputData?: SetStateFunction<string>;
  setUserInput?: SetStateFunction<string>;
  setShowDownload?: SetStateFunction<boolean>;
  instanceDetails?: any;
  setInstanceDetails?: any;
};

const CreateInstance: React.FC<SelectInstanceProps> = ({
  projectId,
  currentApp,
  chatbox,
  outputData,
  setOutputData,
  setUserInput,
  setShowDownload,
  instanceDetails,
  setInstanceDetails,
}) => {
  const [instances, setInstances] = useState<Instance[]>([]);
  const [showNewInstanceModal, setShowNewInstanceModal] = useState(false);
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isEditMode, setIsEditMode] = useState(false);
  // const [instanceDetails, setInstanceDetails] = useState<string>('');
  const [showClearChatWarning, setShowClearChatWarning] =
    useState<boolean>(false);
  const [newSelectedInstance, setNewSelectedInstance] = useState<any>(null);
  const [isBackClicked, setIsBackClicked] = useState(false);
  const [showDeletePopup, setShowDeletePopup] = useState(false);
  const userRole = JSON.parse(sessionStorage.getItem('role') || '{}');
  const userContext = useContext(UserContext) || {
    selectedInstance: '',
    setSelectedInstance: () => {},
    showToast: false,
    setShowToast: () => {},
    showErrMsg: '',
    chatContents: [],
    filesSelectedForUploadRef: null,
    errorMessage: {},
    setErrorMessage: () => {},
  };

  const {
    selectedInstance,
    setSelectedInstance,
    showToast,
    setShowToast,
    chatContents,
    filesSelectedForUploadRef,
    errorMessage,
    setErrorMessage,
  } = userContext;

  const fetchInstances = () => {
    axios
      .get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/instance/project/${projectId}/application/${currentApp?.id}`
      )
      .then((response) => {
        const data = response.data;
        const sorteddata = data.response.sort((a: any, b: any) => {
          if (Number(a.id) > Number(b.id)) {
            return 1;
          }
          if (Number(a.id) < Number(b.id)) {
            return -1;
          }
          return 0;
        });
        setInstances(sorteddata);
      })
      .catch((err) => {
        console.error('Error:', err);
      });
  };

  useEffect(() => {
    fetchInstances();
    if (selectedInstance) {
      getInstanceData(selectedInstance);
    }
  }, []);

  const handleInstanceChange = (value: string, forceClear: boolean = false) => {
    if (!forceClear && chatContents && chatContents.length !== 0) {
      chatbox?.current?.initiateChatWarningModal({
        callback: handleInstanceChange,
        prop: value,
      });
    } else if (outputData && outputData?.length !== 0) {
      setNewSelectedInstance(value);
      setShowClearChatWarning(true);
    } else {
      setSelectedInstance(value);
      if (value) {
        getInstanceData(value);
      }
      if (setOutputData) {
        setOutputData('');
      }
      setShowToast(false);
    }
    if (filesSelectedForUploadRef && filesSelectedForUploadRef.current) {
      filesSelectedForUploadRef.current.value = '';
    }
  };

  const handleClearChat = () => {
    if (setOutputData) {
      setOutputData('');
    }
    if (setUserInput) {
      setUserInput('');
    }
    if (setShowDownload) {
      setShowDownload(false);
    }
    setSelectedInstance(newSelectedInstance);
    setShowClearChatWarning(false);
    getInstanceData(newSelectedInstance);
  };
  const handleCancelClearChat = () => {
    setShowClearChatWarning(false);
  };

  const nextStep = () => {
    if (currentStep === 1) {
      setCurrentStep(currentStep + 1);
      setIsBackClicked(false);
    }
    if (currentStep === 2) {
      fetchInstances();
      setIsBackClicked(false);
      if (selectedInstance) {
        getInstanceData(selectedInstance);
      }
      setShowNewInstanceModal(false);
    }
  };

  const prevStep = () => {
    if (currentStep === 2) {
      setCurrentStep(currentStep - 1);
      getInstanceData(selectedInstance);
      fetchInstances();
      setIsBackClicked(true);
    }
  };

  const openNewInstanceModal = (event: React.MouseEvent<HTMLAnchorElement>) => {
    event?.preventDefault();
    if (chatContents && chatContents.length !== 0) {
      chatbox?.current?.initiateChatWarningModal({
        callback: openNewInstanceModal,
      });
    } else if (outputData && outputData?.length !== 0) {
      setShowClearChatWarning(true);
    } else {
      setCurrentStep(1);
      setShowNewInstanceModal(true);
      setIsEditMode(false);
      setInstanceDetails('');
      setShowToast(false);
    }
  };

  const getInstanceData = (instanceId: any) => {
    axios
      .get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/instance/${instanceId}`
      )
      .then((response) => {
        const data = response.data;
        setInstanceDetails(data.response);
      })
      .catch((err) => {
        console.error('Error:', err);
      });
  };

  const handleDelete = async () => {
    try {
      const response = await axios.delete(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/instance/delete-instance/${selectedInstance}`
      );
      if (response.status === 200) {
        fetchInstances();
        setSelectedInstance('');
        setInstanceDetails('');
        setShowDeletePopup(false);
      } else {
        console.error('Failed to delete instance');
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
    }
  };
  const canceldeletePopup = () => {
    setShowDeletePopup(false);
  };

  const deleteModal = () => {
    return (
      <div className="clear-chat-warning-container">
        <Modal
          show={showDeletePopup}
          onHide={canceldeletePopup}
          backdrop="static"
        >
          <Modal.Header closeButton>
            <Modal.Title>Delete Instance</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="delete-warning">
              <p>
                This action will delete the selected Instance:{' '}
                {instanceDetails.name}. Are you sure you want to delete it?
              </p>
            </div>
          </Modal.Body>

          <Modal.Footer>
            {userRole && userRole === SUPERADMIN && (
              <Button variant="danger" onClick={handleDelete}>
                Delete
              </Button>
            )}
            <Button variant="secondary" onClick={canceldeletePopup}>
              Cancel
            </Button>
          </Modal.Footer>
          {showToast && (
            <ErrorMessage
              errorMessage={errorMessage}
              setShowToast={setShowToast}
              isInsideModal={true}
            />
          )}
        </Modal>
      </div>
    );
  };

  return (
    <>
      <Form.Group className="user-input" controlId="exampleForm.instancePicker">
        <Form.Label>Select an Instance</Form.Label>
        <div className="icon-dropdown-wrapper">
          <Form.Select
            aria-label="Select an instance"
            className="instance-picker"
            value={selectedInstance}
            onChange={(evt) => {
              handleInstanceChange(evt?.target?.value);
            }}
          >
            <option value="">Select an instance</option>
            {instances.map((instance) => (
              <option key={instance.id} value={instance.id}>
                {`${instance?.name} | ${instance.cloudEnvironment.toUpperCase()}`}
              </option>
            ))}
          </Form.Select>
          <Button
            className="knowledge-delete-button"
            style={{ cursor: 'pointer' }}
            onClick={() => setShowDeletePopup(true)}
            disabled={!selectedInstance}
          >
            <FaTrashAlt className="knowledge-icon-delete" />
          </Button>
        </div>
        <Form.Label className="create-new-instance-link">
          <a href="javascript:void(0);" onClick={openNewInstanceModal}>
            Create New Instance
          </a>
        </Form.Label>
      </Form.Group>

      {showNewInstanceModal ? (
        <Modal
          show={showNewInstanceModal}
          onHide={() => {
            setShowNewInstanceModal(false);
            getInstanceData(selectedInstance);
            setIsBackClicked(false);
            setShowToast(false);
          }}
          backdrop="static"
        >
          <Modal.Header closeButton>
            {isEditMode ? 'Edit Instance' : 'Create New Instance'}
          </Modal.Header>
          <Modal.Body>
            <InstanceSteps
              currentStep={currentStep}
              projectId={projectId}
              currentAppId={currentApp?.id}
              nextStep={nextStep}
              prevStep={prevStep}
              isBackClicked={isBackClicked}
              setShowNewInstanceModal={setShowNewInstanceModal}
              step2={true}
              isEditMode={isEditMode}
              instanceDetails={instanceDetails}
              selectedInstance={selectedInstance}
              getInstanceData={getInstanceData}
            />
          </Modal.Body>
          {showToast && (
            <ErrorMessage
              errorMessage={errorMessage}
              setShowToast={setShowToast}
              isInsideModal={true}
            />
          )}
        </Modal>
      ) : null}
      {showClearChatWarning && (
        <div className="clear-chat-warning-container">
          <Modal
            show={showClearChatWarning}
            onHide={handleCancelClearChat}
            backdrop="static"
            keyboard={true}
          >
            <Modal.Header closeButton>
              <Modal.Title>Clear Chat?</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <p>
                This action will clear the chat history and create a new
                session. Are you sure you want to clear the chat?
              </p>
            </Modal.Body>

            <Modal.Footer>
              <Button variant="danger" onClick={handleClearChat}>
                Clear
              </Button>
              <Button variant="secondary" onClick={handleCancelClearChat}>
                Cancel
              </Button>
            </Modal.Footer>
          </Modal>
        </div>
      )}
      {showDeletePopup && deleteModal()}
    </>
  );
};

export default CreateInstance;
