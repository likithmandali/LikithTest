import React, { useContext, useEffect, useRef, useState } from 'react';
import {
  Button,
  Table,
  Badge,
  Spinner,
  Modal,
  FormControl,
  OverlayTrigger,
  Tooltip,
} from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import './KnowledgeIdTable.css';
import { FaTrashAlt } from 'react-icons/fa';
import { FaRegTrashAlt } from 'react-icons/fa';
import axios from 'axios';
import { Appl } from '../../interfaces';
import {
  ADMIN,
  AWS_CLOUD,
  AZURE_CLOUD,
  CSV,
  DOCX,
  FILE_TYPE_ERROR,
  fileUploadKnowledegenote1,
  fileUploadKnowledegenote2,
  GCP_CLOUD,
  OPENSEARCH_SERVERLESS,
  PDF,
  PGVECTOR,
  SUPERADMIN,
  TEST_SCRIPT_GENERATOR,
  TXT,
  XLSXFile,
} from '../../utils/constants';
import UserContext from '../../context/UserContext';
import ErrorMessage from '../ErrorMessage';
import { Form } from 'react-bootstrap';
import { FaFileUpload } from 'react-icons/fa';
import { isAcceptedFileFormat } from '../../utils/fileTypeCheck';

interface KnowledgeTableProps {
  data: any[];
  expandedRows: Set<number>;
  toggleRowExpansion: (rowIndex: number) => void;
  selectedInstance?: string;
  getInstanceData?: any;
  showDelete?: boolean;
  cloudProvider?: any;
  vectorDb?: string;
  templateInstructionMode?: string;
  basicModeDescription?: any;
  handleAddDescription?: any;
  descriptionError?: boolean;
  isEditMode?: boolean;
}

const KnowledgeTable: React.FC<KnowledgeTableProps> = ({
  data,
  expandedRows,
  toggleRowExpansion,
  selectedInstance,
  getInstanceData,
  showDelete,
  cloudProvider,
  vectorDb,
  templateInstructionMode,
  basicModeDescription,
  handleAddDescription,
  descriptionError,
  isEditMode,
}) => {
  const { appUrl } = useParams();
  const apps = JSON.parse(sessionStorage.getItem('apps') as string) as Appl[];
  const currentApp = apps.find((app) => app.url === appUrl);
  const [isDeleteResponse, setIsDeleteResponse] = useState<boolean>(false);
  const [isDeleteLoading, setIsDeleteLoading] = useState<boolean>(false);
  const [showDeletePopup, setShowDeletePopup] = useState(false);
  const [knowledgePaylaod, setknowledgePaylaod] = useState<any>({});
  const [knowledgeQueryParams, setknowledgeQueryParams] = useState<any>({});
  const [docName, setDocName] = useState<string>('');
  const userRole = JSON.parse(sessionStorage.getItem('role') || '{}');
  const [basicModeDescriptionKnowledgeTable, setBasicModeDescription] =
    useState<any>([]);
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [isUploadLoading, setIsUploadLoading] = useState<boolean>(false);
  const [isUploadSuccess, setIsUploadSuccess] = useState<boolean>(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const knowledgeFileUpload = useRef<HTMLInputElement>(null);
  const [uploadKId, setUploadKId] = useState<number>();
  const [knowledgeName, setKnowledgeName] = useState<string>('');
  const acceptedFiles = [PDF, DOCX, TXT, XLSXFile, CSV];
  const [isScannedDoc, setIsScannedDoc] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');
  // Bulk-select state for Bedrock batch deletion
  const [selectedDocIds, setSelectedDocIds] = useState<number[]>([]);
  const [selectedDocMeta, setSelectedDocMeta] = useState<
    { documentId: number; knowledgeId: number; name: string }[]
  >([]);
  const [showBulkDeletePopup, setShowBulkDeletePopup] = useState(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);

  const userContext = useContext(UserContext) || {
    showToast: false,
    setShowToast: () => {},
    errorMessage: {},
    setErrorMessage: () => {},
  };

  const { showToast, setShowToast, errorMessage, setErrorMessage } =
    userContext;

  const handleKnowledgeDelete = async (queryParams: any, payload: any) => {
    setIsDeleteLoading(true);
    const weaviateUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/api/v2/ui/weaviate/delete-knowledge`;
    const pgvectorUrl = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/pgvector/delete-knowledge`;
    try {
      let response;
      if (vectorDb === PGVECTOR) {
        response = await axios.delete(pgvectorUrl, {
          data: payload,
          headers: {
            'Content-Type': 'application/json',
          },
        });
      } else {
        response = await axios.delete(weaviateUrl, {
          params: queryParams,
          headers: {
            'Content-Type': 'application/json',
          },
        });
      }
      if (response.status === 200) {
        setIsDeleteLoading(false);
        setIsDeleteResponse(true);
        setShowDeletePopup(false);
        getInstanceData(selectedInstance);
      } else {
        console.error('Failed to delete file');
        setIsDeleteLoading(false);
      }
    } catch (error: any) {
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      console.error('Error:', error);
      setIsDeleteLoading(false);
    }
  };
  useEffect(() => {
    const removeSuccessMessage = setTimeout(() => {
      setIsDeleteResponse(false);
    }, 2000);

    return () => clearTimeout(removeSuccessMessage);
  }, [isDeleteResponse]);

  // const handleAddDecriptin = (
  //   event: React.ChangeEvent<HTMLInputElement>,
  //   id: any
  // ) => {
  //   if (
  //     basicModeDescriptionKnowledgeTable.filter((item: any) => item.id === id)
  //       .length > 0
  //   ) {
  //     basicModeDescriptionKnowledgeTable.map((item: any) => {
  //       if (item.id === id) {
  //         item.description = event;
  //       }
  //     });
  //   } else {
  //     setBasicModeDescription([
  //       ...basicModeDescriptionKnowledgeTable,
  //       { id: id, description: event },
  //     ]);
  //   }
  // };

  const handleDelete = async (
    KnowledgeId: string,
    docId: string,
    documentName: string
  ) => {
    setIsDeleteResponse(false);
    let queryParams = {};
    let payload = {};
    if (vectorDb === PGVECTOR) {
      payload = {
        instance_id: selectedInstance,
        knowledge_id: KnowledgeId,
        collection_name:
          cloudProvider === 'azure'
            ? 'AzureDocument'
            : cloudProvider === 'gcp'
              ? 'GCPDocument'
              : cloudProvider === 'aws'
                ? 'AWSDocument'
                : '',
        document_name: documentName,
      };
    } else {
      queryParams = {
        document_id: docId,
      };
    }
    // handleKnowledgeDelete(payload);
    setknowledgeQueryParams(queryParams);
    setknowledgePaylaod(payload);
    setDocName(documentName);
    setShowDeletePopup(true);
  };

  // Toggle single checkbox selection
  const toggleSelectDoc = (knowledgeId: number, documentId: number, name: string) => {
    setSelectedDocIds((prev) => {
      if (prev.includes(documentId)) {
        setSelectedDocMeta((m) => m.filter((d) => d.documentId !== documentId));
        return prev.filter((id) => id !== documentId);
      }
      setSelectedDocMeta((m) => [...m, { documentId, knowledgeId, name }]);
      return [...prev, documentId];
    });
  };

  // Select/Deselect all docs on current table
  const toggleSelectAll = () => {
    // Flatten all docs
    const allDocs = data
      ?.flatMap((k: any) =>
        (k?.documentDetails || []).map((d: any) => ({
          documentId: Number(d.documentId),
          knowledgeId: Number(k.id),
          name: d.documentName,
        }))
      )
      .filter(Boolean);
    if (!allDocs?.length) return;
    if (selectedDocIds.length === allDocs.length) {
      setSelectedDocIds([]);
      setSelectedDocMeta([]);
    } else {
      setSelectedDocIds(allDocs.map((d) => d.documentId));
      setSelectedDocMeta(allDocs as any);
    }
  };

  // Helpers for knowledge-scoped selection
  const getSelectedForKnowledge = (knowledgeId: number) =>
    selectedDocMeta.filter((d) => d.knowledgeId === knowledgeId);

  const openBulkDeleteConfirmForKnowledge = (_knowledgeId: number) => {
    // New behavior: delete across all selected docs (possibly multiple knowledge IDs)
    if (selectedDocIds.length === 0) {
      setShowToast(true);
      setErrorMessage({
        message: 'Select one or more documents to delete.',
        id: '',
      });
      return;
    }
    setShowBulkDeletePopup(true);
  };

  // Validate selection belongs to the same knowledge ID (as required by API)
  const validateSameKnowledge = (): { ok: boolean; knowledgeId?: number } => {
    const uniqueKnowledge = Array.from(new Set(selectedDocMeta.map((d) => d.knowledgeId)));
    if (uniqueKnowledge.length <= 1) {
      return { ok: true, knowledgeId: uniqueKnowledge[0] } as any;
    }
    setShowToast(true);
    setErrorMessage({
      message: 'Please select documents from the same Knowledge ID to delete in bulk.',
      id: '',
    });
    return { ok: false };
  };

  const openBulkDeleteConfirm = () => {
    const { ok } = validateSameKnowledge();
    if (!ok) return;
    setShowBulkDeletePopup(true);
  };

  const closeBulkDeleteConfirm = () => setShowBulkDeletePopup(false);

  const handleBedrockBulkDelete = async () => {
    // New behavior: group selected documents by knowledgeId and call API per group
    if (selectedDocIds.length === 0) return;
    setIsBulkDeleting(true);
    try {
      const groups: Record<number, number[]> = {};
      selectedDocMeta.forEach((d) => {
        if (!groups[d.knowledgeId]) groups[d.knowledgeId] = [];
        if (!groups[d.knowledgeId].includes(d.documentId)) {
          groups[d.knowledgeId].push(d.documentId);
        }
      });

      const url = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/knowledge/bedrock/documents/delete`;
      // Execute sequentially to simplify error handling
      for (const kId of Object.keys(groups)) {
        const payload = { document_ids: groups[Number(kId)] };
        const response = await axios.post(url, payload, {
          headers: { 'Content-Type': 'application/json' },
        });
        if (response.status !== 200) {
          throw new Error('Delete failed');
        }
      }

      setSelectedDocIds([]);
      setSelectedDocMeta([]);
      setIsBulkDeleting(false);
      setShowBulkDeletePopup(false);
      getInstanceData && getInstanceData(selectedInstance);
    } catch (error: any) {
      setIsBulkDeleting(false);
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setErrorMessage({
        message: err?.errorMessage || 'Failed to delete some selected documents',
        id: errID || '',
      });
    }
  };
  const canceldeletePopup = () => {
    setShowDeletePopup(false);
  };
  const handleAddDescriptionValue = (e: any, id: any) => {
    setBasicModeDescription(
      basicModeDescriptionKnowledgeTable.map((item: any) => {
        if (item?.id === id) {
          item.description = e.target.value;
        }
      })
    );
    handleAddDescription(e.target.value, id);
  };

  useEffect(() => {
    if (isEditMode) {
      setBasicModeDescription(basicModeDescription);
    }
  }, []);

  const deleteModal = () => {
    return (
      <div className="clear-chat-warning-container">
        <Modal
          show={showDeletePopup}
          onHide={canceldeletePopup}
          backdrop={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>Delete Knowledge Document(s)?</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="delete-warning">
              <p>
                This action will delete the knowledge document {docName}. Are
                you sure you want to delete it?
              </p>
            </div>
          </Modal.Body>

          <Modal.Footer>
            {userRole && (userRole === ADMIN || userRole === SUPERADMIN) && (
              <Button
                variant="danger"
                onClick={() =>
                  handleKnowledgeDelete(knowledgeQueryParams, knowledgePaylaod)
                }
              >
                Delete
              </Button>
            )}
            <Button variant="secondary" onClick={canceldeletePopup}>
              Cancel
            </Button>
          </Modal.Footer>
          {showToast && (
            <ErrorMessage
              errorMessage={errorMessage}
              setShowToast={setShowToast}
              isInsideModal={true}
            />
          )}
        </Modal>
      </div>
    );
  };

  const bulkDeleteModal = () => {
    // Ensure we display each selected document only once even if metadata array
    // accidentally contains duplicates (e.g., due to rapid re-renders or prior
    // inconsistent state updates). We key uniqueness by documentId.
    const uniqueMetaMap = new Map<number, { documentId: number; knowledgeId: number; name: string }>();
    selectedDocMeta.forEach((d) => {
      if (!uniqueMetaMap.has(d.documentId)) uniqueMetaMap.set(d.documentId, d);
    });
    const names = Array.from(uniqueMetaMap.values()).map((d) => d.name);
    return (
      <div className="clear-chat-warning-container">
        <Modal show={showBulkDeletePopup} onHide={closeBulkDeleteConfirm} backdrop={false}>
          <Modal.Header closeButton>
            <Modal.Title>Delete Selected Document(s)?</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {isBulkDeleting ? (
              <div className="modal-progress" style={{ display: 'flex', justifyContent: 'center', padding: '12px' }}>
                <Spinner animation="border" className="text-danger" />
              </div>
            ) : (
              <div className="delete-warning">
                <p>
                  This will permanently delete {names.length} selected document(s)
                  from the knowledge base. Are you sure you want to proceed?
                </p>
                {names.length > 0 && (
                  <div style={{ maxHeight: 150, overflow: 'auto', fontSize: '0.9rem' }}>
                    <ul>
                      {names.map((n, i) => (
                        <li key={`${n}-${i}`}>{n}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </Modal.Body>
          <Modal.Footer>
            {userRole && (userRole === ADMIN || userRole === SUPERADMIN) && !isBulkDeleting && (
              <Button variant="danger" onClick={handleBedrockBulkDelete}>
                Delete
              </Button>
            )}
          </Modal.Footer>
          {showToast && (
            <ErrorMessage
              errorMessage={errorMessage}
              setShowToast={setShowToast}
              isInsideModal={true}
            />
          )}
        </Modal>
      </div>
    );
  };

  const handleUploadModalOpen = (id: number, name: string) => {
    setIsScannedDoc(false);
    setIsUploadLoading(false);
    setIsUploadSuccess(false);
    setShowNotification(false);
    setNotificationMessage('');
    setUploadKId(id);
    setKnowledgeName(name);
    setShowUploadModal(true);
  };

  const handleUploadModalClose = () => {
    setShowUploadModal(false);
    setUploadedFiles([]);
    setShowNotification(false);
    setNotificationMessage('');
    if (knowledgeFileUpload && knowledgeFileUpload?.current) {
      knowledgeFileUpload.current.value = '';
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setIsUploadLoading(false);
    setIsUploadSuccess(false);
    setShowNotification(false);
    const files = event.target.files;
    if (files && files.length > 0) {
      const isValidFormat = isAcceptedFileFormat(files[0], acceptedFiles);
      if (isValidFormat) {
        const selectedFiles = Array.from(files);
        const existingDocumentNames = data
          .find((knowledge: any) => knowledge.id === uploadKId)
          ?.documentDetails.map((doc: any) => doc.documentName.toLowerCase());
        const duplicateFiles = selectedFiles.filter((file) =>
          existingDocumentNames?.includes((file as File).name.toLowerCase())
        );
        
        if (duplicateFiles.length > 0) {
          let message = '';
          if (duplicateFiles.length === 1) {
            const fileName = (duplicateFiles[0] as File).name;
            const truncatedName = fileName.length > 30 ? `${fileName.substring(0, 30)}...` : fileName;
            message = `File "${truncatedName}" already exists and will be replaced.`;
          } else {
            message = 'Some files already exist and will be replaced.';
          }
          setNotificationMessage(message);
          setShowNotification(true);
          setUploadedFiles(selectedFiles);
        } else {
          setShowToast(false);
          setShowNotification(false);
          setUploadedFiles(selectedFiles);
        }
      } else {
        setErrorMessage({
          message: `${FILE_TYPE_ERROR} ${PDF}, ${DOCX}, ${TXT}, ${XLSXFile}, ${CSV}`,
          id: '',
        });
        setShowToast(true);
        setShowNotification(false);
      }
    } else {
      setShowToast(false);
      setShowNotification(false);
    }
  };

  useEffect(() => {
    const removeSuccessMessage = setTimeout(() => {
      setIsUploadSuccess(false);
    }, 2000);

    return () => clearTimeout(removeSuccessMessage);
  }, [isUploadSuccess]);

  const handleUpload = async () => {
    setIsUploadLoading(true);
    setIsUploadSuccess(false);
    setShowNotification(false);
    setNotificationMessage('');
    const formData = new FormData();
    uploadedFiles.forEach((file) => {
      formData.append('files', file);
    });
    try {
      const queryParams = {
        knowledge_id: uploadKId,
      };
      let url = '';
      const azure_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/knowledge/upload`;
      const aws_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/knowledge/upload`;
      const gcp_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/gcp/knowledge/upload`;
      const aws_opensearch_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/aws/knowledge/bedrock/upload`;
      const azure_ocr_api = `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/azure/knowledge/upload-with-ocr`;
      if (vectorDb === OPENSEARCH_SERVERLESS) {
        url = aws_opensearch_api;
      } else if (cloudProvider === AWS_CLOUD) {
        url = aws_api;
      } else if (cloudProvider === GCP_CLOUD) {
        url = gcp_api;
      } else if (cloudProvider === AZURE_CLOUD && isScannedDoc) {
        url = azure_ocr_api;
      } else {
        url = azure_api;
      }
      const response = await axios.post(url, formData, {
        params: queryParams,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      if (response.status === 200) {
        setShowToast(false);
        setIsUploadLoading(false);
        setIsUploadSuccess(true);
        setUploadedFiles([]);
        setIsScannedDoc(false);
        getInstanceData(selectedInstance);
        // handleUploadModalClose();
        if (knowledgeFileUpload && knowledgeFileUpload?.current) {
          knowledgeFileUpload.current.value = '';
        }
      } else {
        setIsUploadLoading(false);
        setIsUploadSuccess(false);
        setShowToast(true);
      }
    } catch (error: any) {
      setUploadedFiles([]);
      if (knowledgeFileUpload && knowledgeFileUpload?.current) {
        knowledgeFileUpload.current.value = '';
      }
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
      setIsUploadLoading(false);
      setIsUploadSuccess(false);
      console.error('Error:', error);
    }
  };

  const uploadModal = () => {
    return (
      <Modal
        className="upload-modal"
        show={showUploadModal}
        onHide={handleUploadModalClose}
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>Upload New Document(s)</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="">
            <p>{`Upload new documents to ${knowledgeName} Knowledge.`}</p>
          </div>
          <Form.Group controlId="formFile" className="mt-3">
            <Form.Control
              type="file"
              multiple
              accept={`${PDF}, ${DOCX}, ${TXT}, ${XLSXFile}, ${CSV}`}
              onChange={handleFileChange}
              ref={knowledgeFileUpload}
            />
              {isUploadLoading && (
                <div className="status-inline">
                  <Spinner animation="border" /> Uploading
                </div>
              )}
            {uploadedFiles && isUploadSuccess && (
              <div className="upload-msg">
                <Badge bg="success">Upload Successful</Badge>
              </div>
            )}
            {showNotification && (
              <div className="upload-msg">
                <OverlayTrigger
                  placement="top"
                  delay={{ show: 250, hide: 400 }}
                  overlay={
                    <Tooltip>
                      {notificationMessage.includes('...') ? 
                        `Full filename: ${uploadedFiles[0]?.name || ''}` : 
                        notificationMessage
                      }
                    </Tooltip>
                  }
                >
                  <Badge bg="warning" className="text-dark" style={{ 
                    whiteSpace: 'normal', 
                    wordWrap: 'break-word', 
                    maxWidth: '100%',
                    display: 'inline-block',
                    cursor: notificationMessage.includes('...') ? 'pointer' : 'default'
                  }}>
                    {notificationMessage}
                  </Badge>
                </OverlayTrigger>
              </div>
            )}
            <div className="basic-details-container-checkbox">
              {cloudProvider === AZURE_CLOUD && (
                <Form.Group>
                  <Form.Label>
                    The document being uploaded contains :{' '}
                  </Form.Label>
                  <Form.Check
                    type="checkbox"
                    name="documentContents"
                    label="Tables"
                    value="tables-or-images"
                    checked={isScannedDoc}
                    onChange={() => setIsScannedDoc(!isScannedDoc)}
                    defaultChecked={false}
                  />
                </Form.Group>
              )}
            </div>
            <div className="choose-file-note">{fileUploadKnowledegenote1}</div>
            {cloudProvider === AZURE_CLOUD && (
              <div className="choose-file-note">
                {fileUploadKnowledegenote2}
              </div>
            )}
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleUploadModalClose}>
            Close
          </Button>
          <Button
            variant="primary"
            onClick={handleUpload}
            disabled={uploadedFiles.length === 0}
          >
            Upload
          </Button>
        </Modal.Footer>
      </Modal>
    );
  };

  return (
    <div className="table-responsive">
      <Table striped bordered hover>
        <thead>
          <tr>
            {/* Header layout differs for Bedrock/OpenSearch vs others */}
            {vectorDb === OPENSEARCH_SERVERLESS ? (
              <>
                <th className="id-column">Knowledge ID</th>
                <th className="select-column" style={{ whiteSpace: 'nowrap' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <Form.Check
                      type="checkbox"
                      checked={
                        data?.flatMap((k: any) => k?.documentDetails || []).length > 0 &&
                        selectedDocIds.length ===
                          data?.flatMap((k: any) => k?.documentDetails || []).length
                      }
                      onChange={toggleSelectAll}
                      title="Select All"
                    />
                  </div>
                </th>
                <th className="documents-column">Document ID</th>
                <th className="documents-column">Document Name</th>
                {showDelete && <th className="action-column">Action</th>}
              </>
            ) : (
              <>
                <th className="id-column">ID</th>
                <th className="name-column">Name</th>
                <th className="documents-column">Document(s) Name</th>
                {templateInstructionMode === 'Basic' &&
                  currentApp?.name === TEST_SCRIPT_GENERATOR && (
                    <th className="documents-column">Description</th>
                  )}
                {showDelete &&
                  userRole &&
                  (userRole === ADMIN || userRole === SUPERADMIN) && (
                    <th className="delete-column">Actions</th>
                  )}
                {showDelete && <th className="upload-column">Upload</th>}
              </>
            )}
          </tr>
        </thead>
        <tbody>
          {data?.map((edge: any, rowIndex: number) => (
            <React.Fragment key={edge.id}>
              {edge.documentDetails?.map((doc: any, docIndex: number) => (
                <tr
                  key={`${edge.id}-${doc.documentId}`}
                  onClick={() => toggleRowExpansion(rowIndex)}
                  style={{ cursor: 'pointer' }}
                >
                  {vectorDb === OPENSEARCH_SERVERLESS ? (
                    // Bedrock/OpenSearch layout
                    <>
                      {docIndex === 0 && (
                        <td rowSpan={edge.documentDetails.length}>{edge.id}</td>
                      )}
                      <td>
                        <Form.Check
                          type="checkbox"
                          checked={selectedDocIds.includes(Number(doc.documentId))}
                          onChange={() =>
                            toggleSelectDoc(Number(edge.id), Number(doc.documentId), doc.documentName)
                          }
                          onClick={(e: any) => e.stopPropagation()}
                        />
                      </td>
                      <td>{doc.documentId}</td>
                      <td>{doc.documentName}</td>
                      {showDelete && docIndex === 0 && (
                        <td rowSpan={edge.documentDetails.length}>
                          <div style={{ display: 'flex', gap: 8 }}>
                            <OverlayTrigger
                              placement="top"
                              delay={{ show: 250, hide: 400 }}
                              overlay={<Tooltip>Upload New Document(s)</Tooltip>}
                            >
                              <span>
                                <Button
                                  className="knowledge-action-btn"
                                  onClick={(e: any) => {
                                    e.stopPropagation();
                                    handleUploadModalOpen(edge.id, edge.name);
                                  }}
                                  variant="outline-primary"
                                  size="sm"
                                >
                                  <FaFileUpload /> Upload
                                </Button>
                              </span>
                            </OverlayTrigger>
                            <OverlayTrigger
                              placement="top"
                              delay={{ show: 250, hide: 400 }}
                              overlay={<Tooltip>Delete selected document(s)</Tooltip>}
                            >
                              <span>
                                <Button
                                  className="knowledge-action-btn"
                                  size="sm"
                                  variant="outline-danger"
                                  disabled={selectedDocIds.length === 0}
                                  onClick={(e: any) => {
                                    e.stopPropagation();
                                    openBulkDeleteConfirmForKnowledge(Number(edge.id));
                                  }}
                                >
                                  <FaRegTrashAlt /> Delete
                                </Button>
                              </span>
                            </OverlayTrigger>
                          </div>
                        </td>
                      )}
                    </>
                  ) : (
                    // Default layout (non-OpenSearch)
                    <>
                      {docIndex === 0 && (
                        <>
                          <td rowSpan={edge.documentDetails.length}>{edge.id}</td>
                          <td rowSpan={edge.documentDetails.length}>{edge.name}</td>
                        </>
                      )}
                      <td>{doc.documentName}</td>
                    </>
                  )}
                  {templateInstructionMode === 'Basic' &&
                    docIndex === 0 &&
                    currentApp?.name === TEST_SCRIPT_GENERATOR && (
                      <td rowSpan={edge.documentDetails.length}>
                        <FormControl
                          as="textarea"
                          placeholder={
                            rowIndex % 3 === 0
                              ? 'Navigation flow document'
                              : rowIndex % 3 === 1
                                ? 'Functional document'
                                : rowIndex % 3 === 2
                                  ? 'Client requirement document'
                                  : ''
                          }
                          className={
                            descriptionError &&
                            basicModeDescription.filter(
                              (item: any) => item.id === edge.id
                            )[0]?.description === ''
                              ? 'description-error'
                              : ''
                          }
                          rows={2}
                          value={
                            basicModeDescriptionKnowledgeTable?.filter(
                              (item: any) => item?.id === edge?.id
                            )[0]?.description
                          }
                          onChange={(e) =>
                            handleAddDescriptionValue(e, edge.id)
                          }
                        />
                      </td>
                    )}
                  {showDelete &&
                    userRole &&
                    vectorDb !== OPENSEARCH_SERVERLESS &&
                    (userRole === ADMIN || userRole === SUPERADMIN) && (
                      <td>
                        <Button
                          className="knowledge-delete-button"
                          style={{ cursor: 'pointer' }}
                          onClick={() =>
                            handleDelete(
                              edge.id,
                              doc.documentId,
                              doc.documentName
                            )
                          }
                        >
                          <FaTrashAlt className="knowledge-icon-delete" />
                        </Button>
                      </td>
                    )}
                  {showDelete && vectorDb !== OPENSEARCH_SERVERLESS && docIndex === 0 && (
                    <td rowSpan={edge.documentDetails.length}>
                      <OverlayTrigger
                        placement="right"
                        delay={{ show: 250, hide: 400 }}
                        overlay={<Tooltip>Upload New Document(s) to existing Knowledge Id</Tooltip>}
                      >
                        <div className="upload-icon-container">
                          <Button
                            className="knowledge-action-btn"
                            variant="outline-primary"
                            size="sm"
                            onClick={() => handleUploadModalOpen(edge.id, edge.name)}
                          >
                            <FaFileUpload className="knowledge-icon-upload" /> Upload
                          </Button>
                        </div>
                      </OverlayTrigger>
                    </td>
                  )}
                </tr>
              ))}
            </React.Fragment>
          ))}
        </tbody>
      </Table>
      {showDeletePopup && deleteModal()}
      {showBulkDeletePopup && bulkDeleteModal()}
      {showUploadModal && uploadModal()}
      {isDeleteLoading && (
        <div className="status-inline">
          <Spinner animation="border" className="text-danger" />
        </div>
      )}
      {isDeleteResponse && (
        <div className="upload-msg">
          <Badge bg="danger">Delete Successful</Badge>
        </div>
      )}
    </div>
  );
};

export default KnowledgeTable;
