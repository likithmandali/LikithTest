import React, { useState } from 'react';
import './DynamicTabsAndForms.css'; // Import your CSS file

interface JsonData {
  [key: string]: {
    [key: string]: string;
  }[];
}

interface DynamicTabsAndFormsProps {
  jsonData?: JsonData;
  content: string; // Define the content prop here
  savedHtml: string;
}

const DynamicTabsAndForms: React.FC<DynamicTabsAndFormsProps> = ({
  jsonData,
}) => {
  const initialTab = jsonData ? Object.keys(jsonData)[0] : '';
  const initialCollapsedTabs: Record<string, boolean> = {};

  // Initialize collapsedTabs with boolean values for each tab
  if (jsonData) {
    Object.keys(jsonData).forEach((key) => {
      initialCollapsedTabs[key] = key !== initialTab;
    });
  }

  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const [activeSubTab, setActiveSubTab] = useState<number>(0);
  const [collapsedTabs, setCollapsedTabs] =
    useState<Record<string, boolean>>(initialCollapsedTabs);

  const handleTabClick = (tabName: string) => {
    setActiveTab(tabName);
    setActiveSubTab(0); // Reset sub-tab when switching tabs

    // Toggle the collapse state for the clicked tab
    const updatedCollapsedTabs: Record<string, boolean> = {};
    if (jsonData) {
      Object.keys(collapsedTabs).forEach((key) => {
        updatedCollapsedTabs[key] =
          key === tabName ? !collapsedTabs[key] : true;
      });
      setCollapsedTabs(updatedCollapsedTabs);
    }
  };

  const handleSubTabClick = (index: number) => {
    setActiveSubTab(index);
  };

  return (
    <>
      <div className="accordion-container">
        <div className="scrollbars-container">
          <div className="accordion " id="accordionExample">
            {jsonData &&
              Object.keys(jsonData).map((tabName, tabIndex) => (
                <div key={tabName} className="accordion-item">
                  <h2 className="accordion-header" id={`heading${tabIndex}`}>
                    <button
                      className={`accordion-button ${activeTab === tabName && !collapsedTabs[tabName] ? '' : 'collapsed'}`}
                      type="button"
                      onClick={() => handleTabClick(tabName)}
                      aria-expanded={!collapsedTabs[tabName]}
                      aria-controls={`collapse${tabIndex}`}
                    >
                      {tabName}
                    </button>
                  </h2>
                  <div
                    id={`collapse${tabIndex}`}
                    className={`accordion-collapse collapse ${!collapsedTabs[tabName] ? 'show' : ''}`}
                    aria-labelledby={`heading${tabIndex}`}
                    data-bs-parent="#accordionExample"
                  >
                    <div className="accordion-body">
                      {jsonData[tabName].length > 1 && (
                        <div className="sub-tabs-row">
                          {jsonData[tabName].map((data, subTabIndex) => (
                            <div
                              key={subTabIndex}
                              onClick={() => handleSubTabClick(subTabIndex)}
                              className={`subtab-margin subtab-text ${activeSubTab === subTabIndex ? 'active' : ''}`}
                            >
                              {Object.values(data)[0]}
                            </div>
                          ))}
                        </div>
                      )}
                      {jsonData[tabName].length > 1 && (
                        <hr className="subtab-line" />
                      )}
                      {activeSubTab !== null &&
                        jsonData[tabName][activeSubTab] && (
                          <div className="sub-tab-content">
                            <form>
                              {Object.entries(
                                jsonData[tabName][activeSubTab]
                              ).map(([key, value]) => (
                                <div key={key} className="form-field">
                                  <label>{key}:</label>
                                  <input
                                    type="text"
                                    value={value}
                                    readOnly
                                    className="form-control"
                                  />
                                </div>
                              ))}
                            </form>
                          </div>
                        )}
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default DynamicTabsAndForms;
