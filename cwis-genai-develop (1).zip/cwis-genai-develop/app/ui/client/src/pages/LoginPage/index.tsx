import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Toast } from 'react-bootstrap';
import axios from 'axios';
import { setAuthToken } from '../../auth';
import { useNavigate } from 'react-router-dom';
import './LoginPage.css';
import ContentLoader from '../../components/Loader/contentLoader';
import { ADMIN, SUPERADMIN } from '../../utils/constants';

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showLogoutToast, setShowLogoutToast] = useState<boolean>(false);
  const userRole = JSON.parse(sessionStorage.getItem('role') || '{}');

  useEffect(() => {
    const logoutSuccess = sessionStorage.getItem('logoutSuccess');
    if (logoutSuccess === 'true') {
      setShowLogoutToast(true);
      sessionStorage.removeItem('logoutSuccess');
    }

    const isLoggedIn = sessionStorage.getItem('isLoggedIn');
    if (isLoggedIn === 'true') {
      if (userRole && (userRole === ADMIN || userRole === SUPERADMIN)) {
        navigate('/dashboard');
      } else {
        navigate('/dashboard/project/3');
      }
    }
  }, []);

  const handleLogin = async () => {
    setError('');
    
    if (!username.trim()) {
      setError('Username is required');
      return;
    }
    
    if (!password.trim()) {
      setError('Password is required');
      return;
    }

    setIsLoading(true);
    try {
      const formData = new URLSearchParams();
      formData.append('grant_type', 'password');
      formData.append('username', username.trim());
      formData.append('password', password);

      const response = await axios.post(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/authentication/token`,
        formData,
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          skipAutoRedirect: true, // Prevent auto-redirect on 401/403
        } as any
      );

      setAuthToken(response?.data?.access_token);
      sessionStorage.setItem('isLoggedIn', 'true');
      
      const currentUserRole = JSON.parse(sessionStorage.getItem('role') || '{}');
      
      if (currentUserRole && (currentUserRole === ADMIN || currentUserRole === SUPERADMIN)) {
        navigate('/dashboard');
      } else {
        navigate('/dashboard/project/3');
      }
      setIsLoading(false);
    } catch (error: any) {
      setIsLoading(false);
      if (error.response?.data?.error?.errorMessage) {
        setError(error.response.data.error.errorMessage);
      } else if (error.response?.status === 401) {
        setError('Invalid username or password');
      } else if (error.response?.status === 422) {
        setError('Invalid request format. Please try again.');
      } else {
        setError('Login failed. Please try again.');
      }
      console.error('Login error:', error);
    }
  };

  const handleSubmit = (e: any) => {
    if (e.key === 'Enter' && !e.shiftKey && username.trim() && password.trim()) {
      e.preventDefault();
      handleLogin();
    }
  };

  const handlePassword = (e: any) => {
    setPassword(e.target.value);
  };

  return (
    <div className="error-page-container">
     {showLogoutToast && (
  <div className="toast-container">
    <Toast
      onClose={() => setShowLogoutToast(false)}
      show={showLogoutToast}
      delay={5000}
      autohide
      className="bg-success text-white regular-toast custom-toast-width"
    >
      <Toast.Body className="d-flex justify-content-between align-items-center">
        You have successfully logged out of Path NC.
        <Button 
          variant="close" 
          className="btn-close btn-close-white" 
          onClick={() => setShowLogoutToast(false)}
        />
      </Toast.Body>
    </Toast>
  </div>
)}

      <div className="error-text-container">
        <Container>
          <div className="login-container">
            <h2>Login</h2>
            <Row className="justify-content-md-center">
              <Form.Group className="login-page-row" controlId="formBasicEmail">
                <Col md="3">
                  <Form.Label className="login-label-text">Username</Form.Label>
                </Col>
                <Col md="8">
                  <Form.Control
                    type="text"
                    placeholder="Enter Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </Col>
              </Form.Group>
            </Row>
            <Row className="justify-content-md-center">
              <Form.Group
                className="login-page-row"
                controlId="formBasicPassword"
              >
                <Col md="3">
                  <Form.Label className="login-label-text">Password</Form.Label>
                </Col>
                <Col md="8">
                  <Form.Control
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => handlePassword(e)}
                    onKeyDown={(e) => {
                      handleSubmit(e);
                    }}
                  />
                </Col>
              </Form.Group>
            </Row>
            {isLoading ? (
              <Button disabled={true}>
                <ContentLoader />
              </Button>
            ) : (
              <Button
                className="mt-4"
                variant="primary"
                type="button"
                onClick={handleLogin}
                disabled={!username.trim() || !password.trim()}
              >
                Login
              </Button>
            )}
            {error && <p className="text-danger mt-2">{error}</p>}
          </div>
        </Container>
      </div>
    </div>
  );
};

export default LoginPage;
