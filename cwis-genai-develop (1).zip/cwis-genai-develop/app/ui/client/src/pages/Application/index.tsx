/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Appl } from '../../interfaces';
import { ApplicationDetails } from '../../types';
import { useNavigate } from 'react-router-dom';
import './Application.css';
import '../../components/Tabs/Tabs.css';
import PolicyEngine from '../PolicyEngine';
import CaseCopilotGenerator from '../CaseCopilotGenerator';
const Application = () => {
  const { projectId, appUrl } = useParams();
  const apps = JSON.parse(sessionStorage.getItem('apps') as string) as Appl[];
  const currentApp = apps.find((app) => app.url === appUrl);
  const navigate = useNavigate();

  useEffect(() => {
    if (!currentApp) {
      navigate('/403');
    }
  }, []);

  const applicationList: Record<string, ApplicationDetails> = {
    'Policy Engine': {
      pageComponent: PolicyEngine,
    },
    'Sales Engine': {
      pageComponent: PolicyEngine,
    },
    'Help Engine': {
      pageComponent: PolicyEngine,
    },
    'Case Copilot Generator': {
      pageComponent: CaseCopilotGenerator,
    },
  };

  const getApplicationJsx = (type: string) => {
    const component = applicationList[type]?.pageComponent;
    if (component) {
      return React.createElement(component, {
        currentApp: currentApp,
        projectId: projectId,
      });
    }
  };
  return (
    <div className="application-page-container">
      {currentApp?.type && getApplicationJsx(currentApp?.type)}
    </div>
  );
};

export default Application;
