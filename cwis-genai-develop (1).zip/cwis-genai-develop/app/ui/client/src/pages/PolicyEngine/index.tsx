/* eslint-disable react-hooks/exhaustive-deps */
import { useState, useRef, useEffect, useContext } from 'react';
import { Form } from 'react-bootstrap';
import { Link, useParams } from 'react-router-dom';
import './PolicyEngine.css';
import stream from '../../utils/stream';
import llmGuardSubmit from '../../utils/llmGuardSubmit';
import CustomFeedback from '../../components/Feedback';
import Chatbox from '../../components/Chatbox';
import { ReactComponent as BackIcon } from '../../assets/arrows/back-arrow.svg';
import { Appl, Chat, ChatboxInterface } from '../../interfaces';
import { Llm_models } from '../../types';
import SelectInstance from '../../components/SelectInstance';
import AdvancedSettings from '../../components/AdvancedSettings';
import UserContext from '../../context/UserContext';
import {
  CONTRIBUTOR,
  GCP_CLOUD,
  NORMAL,
  PGVECTOR,
  WEAVIATE,
} from '../../utils/constants';
import { fixXMLTags } from '../../utils/stringProcessing';
import DebugBox from '../../components/DebugBox';
import ErrorMessage from '../../components/ErrorMessage';
import AdvSettingsToast from '../../components/ErrorMessage/AdvSettingsToast';
import llmGuardStream from '../../utils/llmGuardStream';

const PolicyEngine = () => {
  const { projectId, appUrl } = useParams();
  const apps = JSON.parse(sessionStorage.getItem('apps') as string) as Appl[];
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [outputData, setOutputData] = useState<string>('');
  const [showFeedbackOptions, setShowFeedBackOptions] =
    useState<boolean>(false);
  const [activityId, setActivityId] = useState<string>('');
  const chatbox = useRef<ChatboxInterface>(null);
  const overlayContainerRef = useRef<HTMLDivElement | null>(null);
  const currentApp = apps.find((app) => app.url === appUrl);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [isDisabled, setIsDisabled] = useState<boolean>(true);
  const [inputText, setInputText] = useState<string>('');
  const [instanceData, setInstanceData] = useState<any>('');
  const [sanitizedPrompt, setSanitizedPrompt] = useState<string>('');
  const userRole = JSON.parse(sessionStorage.getItem('role') || '{}');
  const [showSanitizedPrompt, setShowSanitizedPrompt] =
    useState<boolean>(false);
  const userContext = useContext(UserContext) || {
    selectedInstance: '',
    useAdvancedSettings: false,
    userInput: '',
    setUserInput: () => {},
    isLoading: false,
    setIsLoading: () => {},
    showAdvancedSettings: false,
    setShowAdvancedSettings: () => {},
    showAdvancedSettingsAlert: false,
    setShowAdvancedSettingsAlert: () => {},
    chatContents: [],
    setChatContents: () => [],
    advancedSettings: {
      mode: 'autocut',
      autocut: 1,
      query_param: undefined,
      fusion_type: undefined,
      enableChatRegeneration: false,
      debugMode: false,
    },
    setIsActivityActive: () => {},
    isActivityActive: false,
    showToast: false,
    setShowToast: () => {},
    llmCloud: '',
    llmGuardOption: '',
    knowledgeDocumentStatus: '',
    debugMode: false,
    errorMessage: {},
    setErrorMessage: () => {},
    showActivityError: false,
    setShowActivityError: () => {},
  };

  const {
    selectedInstance,
    useAdvancedSettings,
    advancedSettings,
    userInput,
    setUserInput,
    setShowAdvancedSettingsAlert,
    showAdvancedSettingsAlert,
    setShowAdvancedSettings,
    isLoading,
    setIsLoading,
    chatContents,
    setChatContents,
    showToast,
    setShowToast,
    llmCloud,
    llmGuardOption,
    debugMode,
    errorMessage,
    setErrorMessage,
    showActivityError,
    setShowActivityError,
  } = userContext;

  const [selectedLlmModel, setSelectedLlmModel] = useState<Llm_models>(
    llmCloud === 'gcp'
      ? 'gemini-1.5-pro-preview-0409'
      : llmCloud === 'aws'
        ? 'us.anthropic.claude-sonnet-4-20250514-v1:0'
        : 'gpt-4o'
  );
  const abortControllerRef = useRef<AbortController | null>(null);
  useEffect(() => {
    setSelectedLlmModel(
      llmCloud === 'gcp'
        ? 'gemini-1.5-pro-preview-0409'
        : llmCloud === 'aws'
          ? 'us.anthropic.claude-sonnet-4-20250514-v1:0'
          : 'gpt-4o'
    );
  }, [llmCloud]);

  const handlePromptSubmit = async (payload: any, isRegenerate = false) => {
    setInputText(userInput);
    if (
      useAdvancedSettings &&
      advancedSettings.mode !== NORMAL &&
      instanceData.vectorDb === WEAVIATE &&
      advancedSettings.query_param === ''
    ) {
      setShowAdvancedSettingsAlert(true);
    } else {
      if (!isRegenerate) {
        setChatContents([
          ...chatContents,
          { role: 'user', content: userInput } as Chat,
          { role: 'assistant', content: '' } as Chat,
        ]);
      } else {
        // Remove the last assistant message
        setChatContents((prevContents) => [
          ...prevContents.slice(0, -1),
          { role: 'assistant', content: '' } as Chat,
        ]);
      }
      setUserInput('');
      setOutputData('');
      setIsLoading(true);
      setShowFeedBackOptions(false);
      abortControllerRef.current = new AbortController();
      stream({
        requestBody: payload,
        streamCallback: (value: string) => {
          // setOutputData((prev) => `${prev}${value}`);
          setOutputData((prev) => {
            setChatContents((oldChatContents) =>
              oldChatContents.map((chatContent, index, array) => {
                if (index + 1 === array.length) {
                  return {
                    ...chatContent,
                    content: fixXMLTags(`${prev}${value}`),
                  };
                } else {
                  return chatContent;
                }
              })
            );
            return `${prev}${value}`;
          });
        },
        doneCallback: () => {
          setIsLoading(false);
          setShowFeedBackOptions(true);
          setShowToast(false);
        },
        setShowToast: setShowToast,
        setIsLoading: setIsLoading,
        setErrorMessage: setErrorMessage,
        llmCloud: llmCloud,
        selectedLlmModel: selectedLlmModel,
        activityId: activityId,
        setActivityId: setActivityId,
        signal: abortControllerRef.current.signal,
      });
    }
  };

  const handleLlmGuardStream = async (payload: any, isRegenerate = false) => {
    setInputText(userInput);
    if (
      useAdvancedSettings &&
      advancedSettings.mode !== NORMAL &&
      advancedSettings.query_param === ''
    ) {
      setShowAdvancedSettingsAlert(true);
    } else {
      if (!isRegenerate) {
        setChatContents([
          ...chatContents,
          { role: 'user', content: userInput } as Chat,
          { role: 'assistant', content: '' } as Chat,
        ]);
      } else {
        // Remove the last assistant message
        setChatContents((prevContents) => [
          ...prevContents.slice(0, -1),
          { role: 'assistant', content: '' } as Chat,
        ]);
      }
      setUserInput('');
      setOutputData('');
      setIsLoading(true);
      setShowFeedBackOptions(false);
      abortControllerRef.current = new AbortController();
      llmGuardStream({
        requestBody: payload,
        streamCallback: (value: string) => {
          // setOutputData((prev) => `${prev}${value}`);
          setOutputData((prev) => {
            setChatContents((oldChatContents) =>
              oldChatContents.map((chatContent, index, array) => {
                if (index + 1 === array.length) {
                  return {
                    ...chatContent,
                    content: fixXMLTags(`${prev}${value}`),
                  };
                } else {
                  return chatContent;
                }
              })
            );
            return `${prev}${value}`;
          });
        },
        doneCallback: () => {
          setIsLoading(false);
          setShowFeedBackOptions(true);
          setShowToast(false);
        },
        setShowToast: setShowToast,
        setIsLoading: setIsLoading,
        setErrorMessage: setErrorMessage,
        llmCloud: llmCloud,
        setActivityId: setActivityId,
        signal: abortControllerRef.current.signal,
        setSanitizedPrompt: setSanitizedPrompt,
      });
    }
  };

  const handleAbortStream = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  const handleLlmGuardSubmit = async (payload: any, isRegenerate = false) => {
    setInputText(userInput);
    if (
      useAdvancedSettings &&
      advancedSettings.mode !== NORMAL &&
      instanceData.vectorDb === WEAVIATE &&
      advancedSettings.query_param === ''
    ) {
      setShowAdvancedSettingsAlert(true);
    } else {
      if (!isRegenerate) {
        setChatContents([
          ...chatContents,
          { role: 'user', content: userInput } as Chat,
          { role: 'assistant', content: '' } as Chat,
        ]);
      } else {
        // Remove the last assistant message
        setChatContents((prevContents) => [
          ...prevContents.slice(0, -1),
          { role: 'assistant', content: '' } as Chat,
        ]);
      }
      setUserInput('');
      setOutputData('');
      setIsLoading(true);
      setShowFeedBackOptions(false);
      const response = await llmGuardSubmit({
        requestBody: payload,
        setIsLoading,
        setErrorMessage,
        setActivityId,
        setShowToast,
        llmCloud,
        setSanitizedPrompt,
      });
      if (response) {
        setChatContents((oldChatContents) => [
          ...oldChatContents,
          { role: 'assistant', content: response },
        ]);
        setShowFeedBackOptions(true);
        setShowToast(false);
      }
    }
  };

  const submitPrompt = (event: React.MouseEvent<HTMLButtonElement>) => {
    setShowSanitizedPrompt(false);
    setSanitizedPrompt('');
    setShowToast(false);
    event.preventDefault();
    const { enableChatRegeneration, debugMode, ...filteredAdvancedSettings } =
      advancedSettings;
    let payload: any = {
      instance_id: selectedInstance,
      include_references: true,
      advance_search_params:
        useAdvancedSettings &&
        advancedSettings.mode !== NORMAL &&
        chatContents.length === 0 &&
        instanceData.vectorDb === WEAVIATE &&
        llmGuardOption === 'No'
          ? filteredAdvancedSettings
          : undefined,
    };

    if (instanceData.cloudEnvironment === 'aws') {
      payload.input_text = userInput;
    } else {
      if (chatContents.length === 0) {
        payload.input_text = userInput;
      } else {
        payload.messages = [
          { role: 'system', content: 'You are a helpful assistant' },
          ...chatContents,
          { role: 'user', content: userInput },
        ];
      }
    }

    if (llmGuardOption === 'Yes') {
      if (instanceData.cloudEnvironment === GCP_CLOUD) {
        handleLlmGuardSubmit(payload);
      } else {
        handleLlmGuardStream(payload);
      }
    } else handlePromptSubmit(payload);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | React.MouseEvent) => {
      if (
        overlayContainerRef.current &&
        !overlayContainerRef.current.contains(event.target as Node)
      ) {
        setShowAdvancedSettings(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  const chatClearCallback = () => {
    setShowToast(false);
    setChatContents([]);
    setShowSanitizedPrompt(false);
    setSanitizedPrompt('');
  };

  const handleRegenerate = async (content: string) => {
    setIsLoading(true);
    const { enableChatRegeneration, debugMode, ...filteredAdvancedSettings } =
      advancedSettings;
    const payload = {
      input_text:
        chatContents.length <= 2
          ? chatContents[chatContents.length - 2].content
          : undefined,
      messages:
        chatContents.length > 2
          ? [
              { role: 'system', content: 'You are a helpful assistant' },
              ...chatContents.slice(0, -2),
              {
                role: 'user',
                content: chatContents[chatContents.length - 2].content,
              },
            ]
          : undefined,
      instance_id: selectedInstance,
      include_references: true,
      advance_search_params:
        useAdvancedSettings &&
        advancedSettings.mode !== NORMAL &&
        chatContents.length <= 2 &&
        instanceData.vectorDb !== PGVECTOR
          ? filteredAdvancedSettings
          : undefined,
    };
    if (llmGuardOption === 'Yes') {
      if (instanceData.cloudEnvironment === GCP_CLOUD) {
        await handleLlmGuardSubmit(payload, true);
      } else {
        handleLlmGuardStream(payload, true);
      }
    } else {
      await handlePromptSubmit(payload, true); // Passing additional parameter to indicate regeneration
    }
  };

  return (
    <div className="application-page-container">
      <div className="title">{currentApp?.name}</div>
      <div className="back-button-container">
        <Link to={`/dashboard/project/${projectId}`}>
          <BackIcon /> Back
        </Link>
        {instanceData.cloudEnvironment !== 'cfg_ai' && (
          <div ref={overlayContainerRef}>
            <AdvancedSettings
              chatbox={chatbox}
              overlayContainerRef={overlayContainerRef}
              vectorDb={instanceData.vectorDb}
            />
          </div>
        )}
      </div>
      <div className="single-app-container">
        <SelectInstance
          projectId={projectId}
          currentApp={currentApp}
          chatbox={chatbox}
          setOutputData={setOutputData}
          setInstanceDetails={setInstanceData}
          instanceDetails={instanceData}
          // chatContents={chatContents}
        />

        <Form.Group
          controlId="exampleForm.optionPicker"
          className={
            userRole === CONTRIBUTOR ? 'user-input margin-top' : 'user-input'
          }
        >
          <Chatbox
            submitPrompt={submitPrompt}
            chatClearCallback={chatClearCallback}
            ref={chatbox}
            selectedModel={llmCloud}
            useMarkdownFormat={instanceData.renderMarkdown}
            handleAbortStream={handleAbortStream}
            handleRegenerate={handleRegenerate}
          />
        </Form.Group>
      </div>
      {debugMode && (
        <div className="single-app-container">
          <DebugBox
            activityId={activityId}
            isChatLoading={isLoading}
            chatContents={chatContents}
          />
        </div>
      )}
      {llmGuardOption === 'Yes' &&
        sanitizedPrompt &&
        chatContents?.length > 0 && (
          <Form.Group className="transcript-toggle-container">
            <Form.Check
              type="switch"
              id="transcript-view-switch"
              label=" View Sanitized Prompt"
              onChange={(evt) => setShowSanitizedPrompt(evt.target.checked)}
            />
          </Form.Group>
        )}
      {showSanitizedPrompt && (
        <Form.Group controlId="outputTextArea">
          <Form.Control
            as="textarea"
            rows={10}
            className="output-container"
            value={`Sanitized Prompt:\n${sanitizedPrompt}`}
            disabled
          />
        </Form.Group>
      )}
      {showToast && (
        <ErrorMessage errorMessage={errorMessage} setShowToast={setShowToast} />
      )}
      {showActivityError && (
        <ErrorMessage
          errorMessage={errorMessage}
          setShowToast={setShowActivityError}
        />
      )}
      {chatContents.length > 0 && showFeedbackOptions && (
        <CustomFeedback
          url={`${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/activity/feedback/update`}
          activityId={activityId}
        />
      )}
      {showAdvancedSettingsAlert && (
        <AdvSettingsToast
          setShowAdvancedSettingsAlert={setShowAdvancedSettingsAlert}
        />
      )}
    </div>
  );
};

export default PolicyEngine;
