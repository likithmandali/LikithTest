import { useState } from 'react';
import { authenticateUser } from '../../auth';
import { Button } from 'react-bootstrap';
import ContentLoader from '../../components/Loader/contentLoader';
import './LogoutPage.css';

const LogoutPage = () => {
  const [isLoading, setisLoading] = useState<boolean>(false);
  const handleLogin = () => {
    
    setisLoading(true);
    window.location.href = '/login';
  };
  return (
    <div className="error-page-container">
      <header>
        <h1>
          <img src="/logo.png" alt="GenAIe Logo" className="genaie-logo" />
        </h1>
      </header>
      <div className="error-text-container">
        <h2>You have successfully logged out of GenAIe.</h2>
        <p>Click on the Login button below to log back in!</p>
        <div>
          {isLoading ? (
            <Button disabled={true}>
              <ContentLoader />
            </Button>
          ) : (
            <Button onClick={handleLogin}>Login</Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default LogoutPage;
