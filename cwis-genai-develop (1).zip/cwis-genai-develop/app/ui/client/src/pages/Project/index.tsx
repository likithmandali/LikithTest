/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useContext } from 'react';

import UserStoryIcon from '../../assets/app-icons/1.svg';
import PolicyIcon from '../../assets/app-icons/2.svg';
import SalesEngineIcon from '../../assets/app-icons/3.svg';
import MeetingIcon from '../../assets/app-icons/4.svg';
import HelpEngineIcon from '../../assets/app-icons/5.svg';
import StatusGeneratorIcon from '../../assets/app-icons/6.svg';
import SearchEngineIcon from '../../assets/app-icons/7.svg';
import TestScriptIcon from '../../assets/app-icons/8.svg';
import DocumentOcrIcon from '../../assets/app-icons/9.svg';
import { ReactComponent as BackIcon } from '../../assets/arrows/back-arrow.svg';
import Card from 'react-bootstrap/Card';
import { Link, useParams } from 'react-router-dom';
import { App, IconMap } from '../../interfaces';
import Loader from '../../components/Loader';
import axios from 'axios';
import './Project.css';
import UserContext from '../../context/UserContext';
const ApplicationTitle = 'Applications in Playground';
const ProjectCmp = () => {
  const [apps, setApps] = useState<App[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { projectId } = useParams();
  const userContext = useContext(UserContext) || {
    setChatContents: () => [],
    setSelectedInstance: () => {},
    setUserInput: () => {},
    setOutputData: () => {},
    setShowToast: () => {},
    setErrorMessage: () => {},
  };
  const {
    setChatContents,
    setSelectedInstance,
    setUserInput,
    setOutputData,
    setShowToast,
    setErrorMessage,
  } = userContext;

  const fetchApps = () => {
    axios
      .get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/apps/project/${projectId}`
      )
      .then((response) => {
        const data = response.data;
        data.response = data.response.map((app: App) => ({
          ...app,
          url: app.name.toLowerCase().replace(/\s/g, '-'),
        }));
        setApps(data.response);
        sessionStorage.setItem('apps', JSON.stringify(data.response));
        setIsLoading(false);
      })
      .catch((err) => {
        console.error('Error:', err);
        setIsLoading(false);
      });
  };
  useEffect(() => {
    fetchApps();
  }, []);

  const getIcons: IconMap = {
    'User Story Generator': UserStoryIcon,
    'Policy Engine': PolicyIcon,
    'Sales Engine': SalesEngineIcon,
    'Meeting Summarizer': MeetingIcon,
    'Help Engine': HelpEngineIcon,
    'Status Report Generator': StatusGeneratorIcon,
    'Search Engine': SearchEngineIcon,
    'Test Case Generator': TestScriptIcon,
    'Scan to Summify Engine': DocumentOcrIcon,
    'Help Desk Engine': HelpEngineIcon,
    'Notice Explanation Engine': PolicyIcon,
    'Call Center': PolicyIcon,
    'Document Insight': DocumentOcrIcon,
    'Developer Help Engine': HelpEngineIcon,
    'Co-pilot': PolicyIcon,
    'Change Communicator': StatusGeneratorIcon,
    'Notice Analysis Engine': DocumentOcrIcon,
    'LLM Fine-tune Dataset Generator': StatusGeneratorIcon,
    'Case Copilot Generator': StatusGeneratorIcon,
    'Vision QA engine': StatusGeneratorIcon,
    'Code To Design': DocumentOcrIcon,
    'Made in 24 Hours': HelpEngineIcon,
    'Code Search': DocumentOcrIcon,
    'Code QnA': DocumentOcrIcon,
    'Vision Video Analytics': StatusGeneratorIcon,
    'Test Case Generator 2.0': TestScriptIcon,
    'Test Case Generator 3.0': TestScriptIcon,
  };

  const groupOrder = {
    'Deloitte Users': 1,
    'Client-Facing Accelerators': 2,
  };

  const handleApplicationStateRefresh = () => {
    setChatContents([]);
    setSelectedInstance(null);
    setUserInput('');
    setOutputData('');
    setShowToast(false);
    setErrorMessage({ message: '', id: '' });
  };

  const sortAppsById = (apps: any) => {
    return apps.sort(
      (app1: any, app2: any) => parseInt(app1.id, 10) - parseInt(app2.id, 10)
    );
  };

  const groupedApps = apps.reduce((groups: any, app) => {
    const { applicationGroup, ...rest } = app;
    if (!groups[applicationGroup]) {
      groups[applicationGroup] = [];
    }
    groups[applicationGroup].push(rest);
    return groups;
  }, {});

  Object.keys(groupedApps).forEach((group) => {
    groupedApps[group] = sortAppsById(groupedApps[group]);
  });

  const sortedGroups = Object.keys(groupedApps).sort((a, b) => {
    return (
      (groupOrder[a as keyof typeof groupOrder] || 999) -
      (groupOrder[b as keyof typeof groupOrder] || 999)
    );
  });

  return (
    <>
      <div className="title">{ApplicationTitle}</div>
      <div className="back-button-container applications-back">
        <Link to={`/dashboard`}>
          <BackIcon /> Back
        </Link>
        {apps.length > 0 && (
          <>
            <Link to={`/dashboard/project/${projectId}/activity-history`}>
              <button className="activity-button">Activity History</button>
            </Link>
          </>
        )}
      </div>
      {isLoading ? (
        <Loader />
      ) : apps.length === 0 ? (
        <div style={{ textAlign: 'center', marginTop: '2rem' }}>
          <h1>You do not have access to any of the Applications.</h1>
          <p>
            Please reach out to your application admin for more information
            on gaining access.
          </p>
        </div>
      ) : (
        <div className="card-container">
          {sortedGroups.map((group, index) => (
            <div key={index}>
              <div className="group-title">Engines for {group}</div>
              <div className="card-container">
                {groupedApps[group].map((app: any) => (
                  <Link
                    to={`/dashboard/project/${projectId}/${app.url}`}
                    className="card-link"
                    key={app.id}
                  >
                    <Card
                      className="application-card"
                      onClick={handleApplicationStateRefresh}
                    >
                      <Card.Body>
                        <div className="application-card-content">
                          <img src={getIcons[app.type]} alt={app.name} />
                          <h5 className="title-text">{app.name}</h5>
                          <div className="description-text">
                            {app.description}
                          </div>
                        </div>
                      </Card.Body>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
};

export default ProjectCmp;
