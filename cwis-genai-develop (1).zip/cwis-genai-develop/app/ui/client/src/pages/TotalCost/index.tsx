import React, { useContext, useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import './TotalCost.css';
import '../../components/Tabs/Tabs.css';
import { Form, Button, Table, Tabs, Tab } from 'react-bootstrap';
import 'react-datepicker/dist/react-datepicker.css';
import { ReactComponent as BackIcon } from '../../assets/arrows/back-arrow.svg';
import { Link } from 'react-router-dom';
import ContentLoader from '../../components/Loader/contentLoader';
import { FaChevronUp, FaChevronDown } from 'react-icons/fa';
import TimelinesReport from '../TimelinesReport';
import ChartComponent from '../../components/PieChart';
import UserContext from '../../context/UserContext';
import ErrorMessage from '../../components/ErrorMessage';
import {
  ActivitiesPieChart,
  CostPieChart,
  Engine,
  hexColors,
  julyDate,
  Project,
  Timelines,
  UsageDashboard,
} from '../../utils/constants';
import { CgSortAz, CgSortZa } from 'react-icons/cg';

import Chart from 'react-apexcharts';

const getOneMonthBeforeDate = () => {
  const today = new Date();
  today.setMonth(today.getMonth() - 1);
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const lastMonthDate = getOneMonthBeforeDate();

const TotalCost = () => {
  const [startDate, setStartDate] = useState(lastMonthDate);
  const [endDate, setEndDate] = useState('');
  const [responseData, setResponseData] = useState<any>();
  const [responseAppsData, setResponseAppsData] = useState<any>();
  const [loading, isloading] = useState(false);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [applicationData, setApplicationData] = useState<any>();
  const [legendProjectData, setLegendProjectData] = useState<any>();
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [showDate, setShowDate] = useState({
    startDate: '',
    endDate: '',
  });
  const [validationError, setValidationError] = useState<string | null>(null);
  const [selectedChartType, setSelectedChartType] =
    useState<string>(CostPieChart);
  const [selectedFilterType, setSelectedFilterType] = useState<string>(Engine);
  const [selectedChartTypeForProject, setSelectedChartTypeForProject] =
    useState<string>(ActivitiesPieChart);
  const [isLegendClicked, setIsLegenClicked] = useState<boolean>(false);
  const [seriesName, setSeriesName] = useState<string>('');
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: 'asc' | 'desc';
  } | null>(null);
  const userContext = useContext(UserContext) || {
    showToast: false,
    setShowToast: () => {},
    errorMessage: {},
    setErrorMessage: () => {},
  };

  const { showToast, setShowToast, errorMessage, setErrorMessage } =
    userContext;

  const formatDate = (date: string) => {
    const [yyyy, mm, dd] = date.split('-');
    return `${dd.substring(0, 2)}-${mm}-${yyyy}`;
  };
  const maxDate = new Date().toISOString().split('T')[0];
  const currentDate = formatDate(maxDate);
  const initialDate = julyDate;
  const formatedInitialDate = formatDate(initialDate);
  const formaterLastMonthDate = formatDate(lastMonthDate);
  const Initialparams = {
    start_date: formaterLastMonthDate,
    project_id: undefined,
    end_date: currentDate,
  };
  const toggleRowExpansion = (index: number) => {
    if (expandedRow === index) {
      setExpandedRow(null);
    } else {
      setExpandedRow(index);
    }
  };
  const submitValues = async (params: {
    start_date: string;
    project_id: string | undefined;
    end_date: string;
  }) => {
    isloading(true);
    setShowToast(false);
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/activity/dashboard/summary`,
        { params }
      );
      if (response.status === 200 || response.status === 201) {
        isloading(false);
        const data = response.data;
        let filteredResponseData = data?.project_cost?.filter(
          (item: any) => item.projectId !== null
        );
        filteredResponseData =
          selectedChartType === ActivitiesPieChart
            ? filteredResponseData?.sort(
                (a: any, b: any) => b.activity_count - a.activity_count
              )
            : filteredResponseData?.sort(
                (a: any, b: any) => b.totalCost - a.totalCost
              );
        let filteredResponseAppsData = data?.apps_cost?.filter(
          (item: any) => item.applicationId !== null
        );
        filteredResponseAppsData =
          selectedChartType === ActivitiesPieChart
            ? filteredResponseAppsData?.sort(
                (a: any, b: any) => b.activity_count - a.activity_count
              )
            : filteredResponseAppsData?.sort(
                (a: any, b: any) => b.totalCost - a.totalCost
              );
        const sortedfilteredResponseData = filteredResponseData?.sort(
          (a: any, b: any) => {
            const projectA = a?.projectId;
            const projectB = b?.projectId;
            return (projectA || 0) - (projectB || 0);
          }
        );

        setResponseData(sortedfilteredResponseData);
        setResponseAppsData(filteredResponseAppsData);
        setShowDate({
          startDate: params.start_date,
          endDate: params.end_date,
        });
      } else {
        isloading(false);
      }
    } catch (error: any) {
      console.error(
        'Error fetching projects:',
        error?.response?.data ?? error?.message
      );
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      isloading(false);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
    }
  };
  const handleOptionChange = (event: any) => {
    const filteredResponseData =
      event?.target.value === ActivitiesPieChart
        ? responseData?.sort(
            (a: any, b: any) => b.activity_count - a.activity_count
          )
        : responseData?.sort((a: any, b: any) => b.totalCost - a.totalCost);

    const filteredResponseAppsData =
      event?.target.value === ActivitiesPieChart
        ? responseAppsData?.sort(
            (a: any, b: any) => b.activity_count - a.activity_count
          )
        : responseAppsData?.sort((a: any, b: any) => b.totalCost - a.totalCost);

    setSelectedChartType(event?.target.value);
    setResponseData(filteredResponseData);
    setResponseAppsData(filteredResponseAppsData);
  };
  const handleFilterOptionChange = (event: any) => {
    setSelectedFilterType(event?.target.value);
  };
  const handleOptionProjectChange = (event: any, projectId: any) => {
    setSelectedChartTypeForProject(event?.target.value);
  };
  useEffect(() => {
    submitValues(Initialparams);
  }, []);

  const handleClear = () => {
    setValidationError(null);
    setStartDate(lastMonthDate);
    setEndDate('');
    submitValues(Initialparams);
    setExpandedRow(null);
  };
  const handleSubmit = () => {
    setExpandedRow(null);
    let fromDate = undefined;
    let enddate = undefined;
    if (startDate) {
      if (new Date(startDate) > new Date(endDate)) {
        setValidationError('From Date should not be greater than To Date.');
        return;
      } else {
        setValidationError(null);
      }
      isloading(true);
      fromDate = formatDate(startDate);
    }
    if (endDate) {
      enddate = formatDate(endDate);
    } else {
      enddate = currentDate;
    }
    const params = {
      start_date: fromDate ? fromDate : formatedInitialDate,
      project_id: undefined,
      end_date: enddate ? enddate : currentDate,
    };
    submitValues(params);
  };

  useEffect(() => {
    handleSubmit();
  }, [startDate, endDate]);

  const handleRowExpansion = (index: number, projectId: number) => {
    toggleRowExpansion(index);
    getApplicationDetails(projectId, ActivitiesPieChart);
  };
  const getApplicationDetails = async (
    projectId: number,
    selectedChartTypeForProject: string,
    fromLegend: boolean = false
  ) => {
    setIsDataLoading(true);
    setShowToast(false);
    const params = {
      start_date: startDate ? formatDate(startDate) : formatedInitialDate,
      end_date: endDate ? formatDate(endDate) : currentDate,
    };
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/activity/project/app-info/${projectId}`,
        { params }
      );
      if (response.status === 200 || response.status === 201) {
        setIsDataLoading(false);
        const data = response.data;
        const sortedApplicationInformation =
          selectedChartTypeForProject === ActivitiesPieChart
            ? data?.response?.applicationInformation?.sort(
                (a: any, b: any) => b.activities - a.activities
              )
            : data?.response?.applicationInformation?.sort(
                (a: any, b: any) => b.cost - a.cost
              );
        sortedApplicationInformation.activitiesArr =
          data?.response?.applicationInformation?.map(
            (response: any, index: number) => response.activities ?? 0
          );
        sortedApplicationInformation.seriesCostArr =
          data?.response?.applicationInformation?.map(
            (response: any, index: number) =>
              response.cost ? parseFloat(response.cost?.toFixed(2) ?? 0) : 0
          );
        sortedApplicationInformation.labelsNameArr =
          data?.response?.applicationInformation?.map(
            (response: any, index: number) => response.applicationName
          );

        if (fromLegend) {
          setLegendProjectData(sortedApplicationInformation);
          setIsLegenClicked(true);
        } else {
          setApplicationData(sortedApplicationInformation);
        }
      } else {
        setIsDataLoading(false);
      }
    } catch (error: any) {
      console.error(
        'Error fetching application details:',
        error?.response?.data ?? error?.message
      );
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setIsDataLoading(false);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
    }
  };

  const getProjectsForApp = async (
    appName: string,
    selectedChartTypeForProject: string,
    fromLegend: boolean = false
  ) => {
    setIsDataLoading(true);
    setShowToast(false);
    const params = {
      start_date: startDate ? formatDate(startDate) : formatedInitialDate,
      end_date: endDate ? formatDate(endDate) : currentDate,
    };
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/activity/app/cost/per/project?appname=${appName}`,
        { params }
      );
      if (response.status === 200 || response.status === 201) {
        setIsDataLoading(false);
        const data = response.data;
        const sortedProjectInfo =
          selectedChartTypeForProject === ActivitiesPieChart
            ? data?.apps_cost?.sort(
                (a: any, b: any) => b.activities - a.activities
              )
            : data?.apps_cost?.sort(
                (a: any, b: any) => b.totalCost - a.totalCost
              );
        sortedProjectInfo.activitiesArr = data?.apps_cost?.map(
          (response: any, index: number) => response.activities ?? 0
        );
        sortedProjectInfo.seriesCostArr = data?.apps_cost?.map(
          (response: any, index: number) =>
            response.totalCost
              ? parseFloat(response.totalCost?.toFixed(2) ?? 0)
              : 0
        );
        sortedProjectInfo.labelsNameArr = data?.apps_cost?.map(
          (response: any, index: number) => response.projectName
        );
        if (fromLegend) {
          setLegendProjectData(sortedProjectInfo);
          setIsLegenClicked(true);
        }
      } else {
        setIsDataLoading(false);
      }
    } catch (error: any) {
      console.error(
        'Error fetching application details:',
        error?.response?.data ?? error?.message
      );
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      setIsDataLoading(false);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
    }
  };
  const sortedResponseData = responseData?.sort((a: any, b: any) => {
    const projectA = a.projectId;
    const projectB = b.projectId;
    return (projectB?.id || 0) - (projectA?.id || 0);
  });
  const costArr = sortedResponseData?.map((response: any, index: number) =>
    response.totalCost ? parseFloat(response.totalCost?.toFixed(2) ?? 0) : 0
  );
  const projectNameArr = sortedResponseData?.map(
    (response: any, index: number) => response.activity_count ?? 0
  );
  const nameArr = sortedResponseData?.map(
    (response: any, index: number) => response.projectname
  );
  let costAppsArr = responseAppsData?.map((response: any, index: number) =>
    response.totalCost ? parseFloat(response.totalCost?.toFixed(2) ?? 0) : 0
  );
  const projectNameAppsArr = responseAppsData?.map(
    (response: any, index: number) => response.activity_count ?? 0
  );
  const nameAppsArr = responseAppsData?.map(
    (response: any, index: number) => response.applicationName
  );

  const ChartMainOptions = useMemo(() => {
    return {
      options: {
        chart: {
          type: 'pie',
          toolbar: {
            show: true,
          },
          events: {
            dataPointSelection: (
              event: any,
              chartContext: any,
              config: {
                w: { config: { labels: { [x: string]: any } } };
                dataPointIndex: string | number;
              }
            ) => {
              const itemClicked = config.w.config.labels[config.dataPointIndex];
              handleLegendClick(itemClicked);
            },
          },
        },
        labels: nameArr,
        legend: {
          show: true,
          onItemClick: {
            toggleDataSeries: true,
          },
          onItemHover: {
            highlightDataSeries: false,
          },
        },
        colors: hexColors.slice(0, nameArr?.length),
      },
      appsOptions: {
        chart: {
          type: 'pie',
          toolbar: {
            show: true,
          },
          events: {
            dataPointSelection: (
              event: any,
              chartContext: any,
              config: {
                w: { config: { labels: { [x: string]: any } } };
                dataPointIndex: string | number;
              }
            ) => {
              const itemClicked = config.w.config.labels[config.dataPointIndex];
              handleLegendClick(itemClicked);
            },
          },
        },
        labels: nameAppsArr,
        legend: {
          show: true,
          onItemClick: {
            toggleDataSeries: true,
          },
          onItemHover: {
            highlightDataSeries: false,
          },
        },
        colors: hexColors.slice(0, nameAppsArr?.length),
      },
      seriesForCostDonut: costArr ?? [0],
      seriesForActivitiesDonut: projectNameArr ?? [0],
      seriesForCostAppsDonut: costAppsArr ?? [0],
      seriesForActivitiesAppsDonut: projectNameAppsArr ?? [0],
    };
  }, [
    nameArr,
    nameAppsArr,
    costArr,
    projectNameArr,
    costAppsArr,
    projectNameAppsArr,
  ]);

  const ChartNestOptions = useMemo(() => {
    return {
      options: {
        chart: {
          type: 'pie',
          toolbar: {
            show: true,
          },
        },
        labels: applicationData?.labelsNameArr,
        legend: {
          show: true,
          onItemClick: {
            toggleDataSeries: true,
          },
          onItemHover: {
            highlightDataSeries: false,
          },
        },
        colors: hexColors.slice(0, applicationData?.labelsNameArr?.length),
      },
      seriesForCostDonut: applicationData?.seriesCostArr ?? [0],
      seriesForActivitiesDonut: applicationData?.activitiesArr ?? [0],
    };
  }, [applicationData]);

  const ChartLegendProjectOptions = useMemo(() => {
    return {
      options: {
        chart: {
          type: 'pie',
          toolbar: {
            show: true,
          },
        },
        labels: legendProjectData?.labelsNameArr,
        legend: {
          show: true,
          onItemClick: {
            toggleDataSeries: false,
          },
          onItemHover: {
            highlightDataSeries: false,
          },
        },
        colors: hexColors.slice(0, legendProjectData?.labelsNameArr?.length),
      },
      seriesForCost: legendProjectData?.seriesCostArr ?? [0],
      seriesForActivities: legendProjectData?.activitiesArr ?? [0],
    };
  }, [legendProjectData]);

  const chartConfig: {
    [key: string]: {
      [key: string]: {
        title: string;
        options: any;
        series: any;
      };
    };
  } = {
    CostPieChart: {
      Project: {
        title: 'Cost Chart: Project',
        options: ChartMainOptions.options,
        series: ChartMainOptions.seriesForCostDonut,
      },
      Engine: {
        title: 'Cost Chart: Engine',
        options: ChartMainOptions.appsOptions,
        series: ChartMainOptions.seriesForCostAppsDonut,
      },
    },
    ActivitiesPieChart: {
      Project: {
        title: 'Activities Chart: Project',
        options: ChartMainOptions.options,
        series: ChartMainOptions.seriesForActivitiesDonut,
      },
      Engine: {
        title: 'Activities Chart: Engine',
        options: ChartMainOptions.appsOptions,
        series: ChartMainOptions.seriesForActivitiesAppsDonut,
      },
    },
  };

  const chartProps = chartConfig[selectedChartType]?.[selectedFilterType];

  const handleLegendClick = (itemClicked: any) => {
    setSeriesName(itemClicked);
    if (selectedFilterType === Project) {
      const project = sortedResponseData.find(
        (project: any) => project.projectname === itemClicked
      );
      if (project) {
        const projectId = project.projectId;
        getApplicationDetails(projectId, ActivitiesPieChart, true);
      }
    } else {
      getProjectsForApp(itemClicked, ActivitiesPieChart, true);
    }
  };

  const handleDateChange = (e: any) => {
    const event = !e.target.value ? lastMonthDate : e.target.value;
    setStartDate(event);
  };

  const handleDataSorting = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === 'asc'
    ) {
      direction = 'desc';
    }

    const sortedData = [...responseData]?.sort((a: any, b: any) => {
      if (key === 'activity_count') {
        return direction === 'asc'
          ? a.activity_count - b.activity_count
          : b.activity_count - a.activity_count;
      } else if (key === 'totalcost') {
        return direction === 'asc'
          ? a.totalCost - b.totalCost
          : b.totalCost - a.totalCost;
      } else if (key === 'lastUpdated') {
        const dateA = new Date(a.lastUpdated).getTime();
        const dateB = new Date(b.lastUpdated).getTime();
        return direction === 'asc' ? dateA - dateB : dateB - dateA;
      } else if (key === 'projectId') {
        return direction === 'asc'
          ? a.projectId - b.projectId
          : b.projectId - a.projectId;
      } else if (key === 'projectname') {
        return direction === 'asc'
          ? a.projectname.localeCompare(b.projectname)
          : b.projectname.localeCompare(a.projectname);
      }
      return 0;
    });

    setSortConfig({ key, direction });
    setResponseData(sortedData);
  };

  return (
    <>
      <>
        <div className="application-page-container">
          <div className="title">Usage Dashboard</div>
          <div className="back-button-container">
            <Link to={`/`}>
              <BackIcon /> Back
            </Link>
          </div>
          <div className="single-app-container">
            <Tabs
              defaultActiveKey={UsageDashboard}
              id="uncontrolled-tab-example"
              className="application-page-container"
            >
              <Tab eventKey={UsageDashboard} title="Dashboard">
                <div>
                  <Form.Label className="Project-selector">
                    <b>Date Range</b>
                  </Form.Label>
                  <div className="split-screen">
                    <div>
                      <div>From Date</div>
                      <Form.Control
                        type="date"
                        name="datepic"
                        placeholder="Select Date"
                        value={startDate}
                        className="date-picker"
                        onChange={handleDateChange}
                        min={initialDate}
                        max={maxDate}
                      />
                    </div>
                    <div>
                      <div>To Date</div>
                      <Form.Control
                        type="date"
                        name="datepic"
                        placeholder="Select Date"
                        value={endDate ? endDate : maxDate}
                        className="date-picker"
                        // disabled={!startDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        min={startDate}
                        max={maxDate}
                      />
                    </div>
                  </div>
                  {validationError && (
                    <div className="date-error-message">{validationError}</div>
                  )}
                  {responseData && responseData.length > 0 && (
                    <>
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          marginTop: 20,
                          position: 'relative',
                        }}
                      >
                        <div className="filters-container">
                          <div className="filter-show">
                            <Form.Label>Show</Form.Label>
                            <Form.Select
                              value={selectedFilterType}
                              onChange={handleFilterOptionChange}
                            >
                              <option value={Project}>{Project}</option>
                              <option value={Engine}>{Engine}</option>
                            </Form.Select>
                          </div>
                          <div className="filter-groupby">
                            <Form.Label>Group By</Form.Label>
                            <Form.Select
                              value={selectedChartType}
                              onChange={handleOptionChange}
                            >
                              <option value={CostPieChart}>Cost</option>
                              <option value={ActivitiesPieChart}>
                                Activity Count
                              </option>
                            </Form.Select>
                          </div>
                        </div>
                      </div>
                      <div className="margin-top all-record-message">
                        Showing results from {showDate.startDate} to{' '}
                        {showDate.endDate}:
                      </div>
                      {!isLegendClicked ? (
                        <>
                          {chartProps && (
                            <ChartComponent
                              title={chartProps.title}
                              options={chartProps.options}
                              series={chartProps.series}
                              loading={loading}
                            />
                          )}
                        </>
                      ) : (
                        <>
                          <Button
                            onClick={() => {
                              setIsLegenClicked(false);
                            }}
                            className="mt-2 mb-4"
                            variant="outline-primary"
                          >
                            Reset
                          </Button>
                          <p>
                            Selected Data: <b>{seriesName}</b>
                          </p>
                          {legendProjectData &&
                            legendProjectData?.length > 0 && (
                              <Chart
                                options={{
                                  ...ChartLegendProjectOptions?.options,
                                  chart: {
                                    ...ChartLegendProjectOptions?.options.chart,
                                    type: 'pie',
                                  },
                                }}
                                series={
                                  selectedChartType === CostPieChart
                                    ? ChartLegendProjectOptions?.seriesForCost
                                    : ChartLegendProjectOptions?.seriesForActivities
                                }
                                type="pie"
                                width={'100%'}
                                height={300}
                              />
                            )}
                        </>
                      )}
                      <Table className="margin-top" hover>
                        <thead>
                          <tr>
                            <th></th>
                            <th>
                              <div
                                onClick={() => handleDataSorting('projectId')}
                                style={{ cursor: 'pointer' }}
                              >
                                <span>Project ID</span>
                                {sortConfig?.key === 'projectId' &&
                                sortConfig.direction === 'asc' ? (
                                  <CgSortAz />
                                ) : (
                                  <CgSortZa />
                                )}{' '}
                              </div>
                            </th>
                            <th>
                              <div
                                onClick={() => handleDataSorting('projectname')}
                                style={{ cursor: 'pointer' }}
                              >
                                <span>Project Name </span>
                                {sortConfig?.key === 'projectname' &&
                                sortConfig.direction === 'asc' ? (
                                  <CgSortAz />
                                ) : (
                                  <CgSortZa />
                                )}{' '}
                              </div>
                            </th>
                            <th>
                              <div
                                onClick={() =>
                                  handleDataSorting('activity_count')
                                }
                                style={{ cursor: 'pointer' }}
                              >
                                <span>Activity Count </span>{' '}
                                {sortConfig?.key === 'activity_count' &&
                                sortConfig.direction === 'asc' ? (
                                  <CgSortAz />
                                ) : (
                                  <CgSortZa />
                                )}{' '}
                              </div>
                            </th>
                            <th>
                              <div
                                onClick={() => handleDataSorting('totalcost')}
                                style={{ cursor: 'pointer' }}
                              >
                                <span>Total Cost </span>{' '}
                                {sortConfig?.key === 'totalcost' &&
                                sortConfig.direction === 'asc' ? (
                                  <CgSortAz />
                                ) : (
                                  <CgSortZa />
                                )}{' '}
                              </div>
                            </th>
                            <th>
                              <div
                                onClick={() => handleDataSorting('lastUpdated')}
                                style={{ cursor: 'pointer' }}
                              >
                                <span>Last Updated </span>{' '}
                                {sortConfig?.key === 'lastUpdated' &&
                                sortConfig.direction === 'asc' ? (
                                  <CgSortAz />
                                ) : (
                                  <CgSortZa />
                                )}{' '}
                              </div>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {responseData &&
                            responseData.length > 0 &&
                            responseData.map((response: any, index: number) => (
                              <>
                                <tr
                                  onClick={() =>
                                    handleRowExpansion(
                                      index,
                                      response.projectId
                                    )
                                  }
                                  style={{ cursor: 'pointer' }}
                                >
                                  <td>
                                    {expandedRow === index ? (
                                      <FaChevronUp />
                                    ) : (
                                      <FaChevronDown />
                                    )}
                                  </td>
                                  <td>{response.projectId}</td>
                                  <td>{response.projectname}</td>
                                  <td>{response.activity_count}</td>
                                  <td>
                                    {' '}
                                    $
                                    {response.totalCost
                                      ? parseFloat(
                                          response.totalCost?.toFixed(2) ?? '0'
                                        )
                                      : '0'}
                                  </td>
                                  <td>{formatDate(response.lastUpdated)}</td>
                                </tr>
                                {expandedRow === index &&
                                  (isDataLoading ? (
                                    <tr className="expanded-row">
                                      <td colSpan={6} className="expanded-row">
                                        <ContentLoader />
                                      </td>
                                    </tr>
                                  ) : (
                                    <tr className="expanded-row">
                                      <td colSpan={6} className="expanded-row">
                                        <div
                                          style={{
                                            display: 'flex',
                                            flexDirection: 'column',
                                            marginTop: 20,
                                          }}
                                        >
                                          <>
                                            <Form.Label>Group By</Form.Label>
                                            <Form.Select
                                              value={
                                                selectedChartTypeForProject
                                              }
                                              onChange={(event) =>
                                                handleOptionProjectChange(
                                                  event,
                                                  response.projectId
                                                )
                                              }
                                            >
                                              <option value={CostPieChart}>
                                                Cost
                                              </option>
                                              <option
                                                value={ActivitiesPieChart}
                                              >
                                                Activity Count
                                              </option>
                                            </Form.Select>
                                          </>
                                          {selectedChartTypeForProject ===
                                            CostPieChart &&
                                            applicationData && (
                                              <>
                                                <ChartComponent
                                                  options={
                                                    ChartNestOptions.options
                                                  }
                                                  series={
                                                    ChartNestOptions.seriesForCostDonut
                                                  }
                                                  title="Cost"
                                                  loading={loading}
                                                />
                                              </>
                                            )}
                                          {selectedChartTypeForProject ===
                                            ActivitiesPieChart &&
                                            applicationData && (
                                              <>
                                                <ChartComponent
                                                  options={
                                                    ChartNestOptions.options
                                                  }
                                                  series={
                                                    ChartNestOptions.seriesForActivitiesDonut
                                                  }
                                                  title="Activities"
                                                  loading={loading}
                                                />
                                              </>
                                            )}
                                        </div>
                                        <Table
                                          style={{ borderColor: '#ededed' }}
                                          hover
                                          className="applications-table"
                                        >
                                          <thead>
                                            <tr>
                                              <th>Application Name</th>
                                              <th>Application Activites</th>
                                              <th>Cost</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {applicationData &&
                                              applicationData?.length > 0 &&
                                              applicationData.map(
                                                (app: any) => (
                                                  <tr>
                                                    <td>
                                                      {app.applicationName}
                                                    </td>
                                                    <td>{app.activities}</td>
                                                    <td>
                                                      {' '}
                                                      {app.cost
                                                        ? parseFloat(
                                                            app.cost?.toFixed(2)
                                                          ) <= 0.01
                                                          ? 'Less than 1 Cent'
                                                          : '$' +
                                                            parseFloat(
                                                              app.cost?.toFixed(
                                                                2
                                                              )
                                                            )
                                                        : 'Less than 1 Cent'}
                                                    </td>
                                                  </tr>
                                                )
                                              )}
                                          </tbody>
                                        </Table>
                                      </td>
                                    </tr>
                                  ))}
                              </>
                            ))}
                        </tbody>
                      </Table>
                    </>
                  )}
                </div>
              </Tab>
              <Tab eventKey={Timelines} title="Timelines">
                <TimelinesReport
                  setShowToast={setShowToast}
                  setErrorMessage={setErrorMessage}
                  lastMonthDate={lastMonthDate}
                />
              </Tab>
            </Tabs>
          </div>
          {showToast && (
            <ErrorMessage
              errorMessage={errorMessage}
              setShowToast={setShowToast}
            />
          )}
        </div>
      </>
    </>
  );
};
export default TotalCost;
