import React, { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import './TimelinesReport.css';
import { Button, ButtonGroup, Form } from 'react-bootstrap';
import 'react-datepicker/dist/react-datepicker.css';
import ContentLoader from '../../components/Loader/contentLoader';
import Chart from 'react-apexcharts';
import {
  ActivitiesPieChart,
  activity_cost,
  activity_count,
  applicationName,
  CostPieChart,
  Day,
  email,
  Engine,
  hexColors,
  julyDate,
  Month,
  Project,
  projectname,
  User,
  Week,
  Year,
} from '../../utils/constants';

type ChartComponentProps = {
  title: string;
  options: any;
  series: any;
};

type TimelineProps = {
  setShowToast: (showToast: boolean) => void;
  setErrorMessage: ({ message, id }: { message: string; id: string }) => void;
  lastMonthDate: string;
};

const TimelinesReport: React.FC<TimelineProps> = ({
  setShowToast,
  setErrorMessage,
  lastMonthDate,
}) => {
  const [startDate, setStartDate] = useState(lastMonthDate);
  const [endDate, setEndDate] = useState('');
  const [responseTimelinesData, setResponseTimelinesData] = useState<any>();
  const [loading, isloading] = useState(false);
  const [showDate, setShowDate] = useState({
    startDate: '',
    endDate: '',
  });
  const [validationError, setValidationError] = useState<string | null>(null);
  const [selectedChartType, setSelectedChartType] =
    useState<string>(CostPieChart);
  const [selectedFilterType, setSelectedFilterType] = useState<string>(Engine);
  const [selectedSortType, setSelectedSortType] = useState<string>(Week);
  const [visibleSeries, setVisibleSeries] = useState<string | null>(null);

  const formatDate = (date: string) => {
    const [yyyy, mm, dd] = date.split('-');
    return `${dd}-${mm}-${yyyy}`;
  };
  const maxDate = new Date().toISOString().split('T')[0];
  const currentDate = formatDate(maxDate);
  const initialDate = julyDate;
  const formatedInitialDate = formatDate(initialDate);
  const formaterLastMonthDate = formatDate(lastMonthDate);
  const Timelineparams = {
    split_by: selectedFilterType?.toLowerCase(),
    frequency: selectedSortType?.toLowerCase(),
    project_id: undefined,
    activity_details:
      selectedChartType === CostPieChart ? activity_cost : activity_count,
    start_date: formaterLastMonthDate,
    end_date: currentDate,
  };

  const timelinesValues = async (params: {
    split_by: string;
    frequency: string;
    project_id: string | undefined;
    activity_details: string;
    start_date: string;
    end_date: string;
  }) => {
    isloading(true);
    setShowToast(false);
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/activity/dashboard/timeline/specific`,
        { params }
      );
      if (response.status === 200 || response.status === 201) {
        isloading(false);
        const data = response.data;
        let filteredResponseData = data?.response;
        filteredResponseData =
          selectedChartType === ActivitiesPieChart
            ? filteredResponseData?.sort(
                (a: any, b: any) => b.activity_count - a.activity_count
              )
            : filteredResponseData?.sort(
                (a: any, b: any) => b.totalCost - a.totalCost
              );
        setResponseTimelinesData(filteredResponseData);
        setShowDate({
          startDate: params.start_date,
          endDate: params.end_date,
        });
      } else {
        isloading(false);
        setShowToast(true);
      }
    } catch (error: any) {
      console.error(
        'Error fetching projects:',
        error?.response?.data ?? error?.message
      );
      const err = error?.response?.data?.error;
      const errID = error?.response?.data?.errorId;
      setShowToast(true);
      isloading(false);
      setErrorMessage({
        message: err.errorMessage,
        id: errID,
      });
    }
  };
  const handleOptionChange = (event: any) => {
    setSelectedChartType(event?.target.value);
    timelinesValues({
      split_by: selectedFilterType?.toLowerCase(),
      frequency: selectedSortType?.toLowerCase(),
      project_id: undefined,
      activity_details:
        event?.target.value === CostPieChart ? activity_cost : activity_count,
      start_date: startDate ? formatDate(startDate) : formatedInitialDate,
      end_date: endDate ? formatDate(endDate) : currentDate,
    });
  };
  const handleFilterOptionChange = (event: any) => {
    setSelectedFilterType(event?.target.value);
    timelinesValues({
      split_by: event?.target.value?.toLowerCase(),
      frequency: selectedSortType?.toLowerCase(),
      project_id: undefined,
      activity_details:
        selectedChartType === CostPieChart ? activity_cost : activity_count,
      start_date: startDate ? formatDate(startDate) : formatedInitialDate,
      end_date: endDate ? formatDate(endDate) : currentDate,
    });
  };
  const handleSortOrderChange = (event: any) => {
    setSelectedSortType(event?.target.value);
    timelinesValues({
      split_by: selectedFilterType?.toLowerCase(),
      frequency: event?.target.value?.toLowerCase(),
      project_id: undefined,
      activity_details:
        selectedChartType === CostPieChart ? activity_cost : activity_count,
      start_date: startDate ? formatDate(startDate) : formatedInitialDate,
      end_date: endDate ? formatDate(endDate) : currentDate,
    });
  };
  useEffect(() => {
    timelinesValues(Timelineparams);
  }, []);

  const handleSubmit = () => {
    if (startDate && endDate) {
      if (new Date(startDate) > new Date(endDate)) {
        setValidationError('From Date should not be greater than To Date.');
        return;
      } else {
        setValidationError(null);
      }
    }

    timelinesValues({
      split_by: selectedFilterType?.toLowerCase(),
      frequency: selectedSortType?.toLowerCase(),
      project_id: undefined,
      activity_details:
        selectedChartType === CostPieChart ? activity_cost : activity_count,
      start_date: startDate ? formatDate(startDate) : formatedInitialDate,
      end_date: endDate ? formatDate(endDate) : currentDate,
    });
  };

  const transformData = (data: any[], visibleSeries: string | null = null) => {
    const groupedData: { [key: string]: { [key: string]: number } } = {};
    const itemType =
      selectedFilterType === User
        ? email
        : selectedFilterType === Project
          ? projectname
          : applicationName;
    const filteredData = data.filter((item) => item[itemType]);

    filteredData.forEach((item) => {
      const date = new Date(item.timeline).toLocaleDateString();
      if (!groupedData[date]) {
        groupedData[date] = {};
      }
      if (!groupedData[date][item[itemType]]) {
        groupedData[date][item[itemType]] = 0;
      }
      selectedChartType === ActivitiesPieChart
        ? (groupedData[date][item[itemType]] += item.activity_count)
        : (groupedData[date][item[itemType]] += item.totalCost);
    });

    const categories = Object.keys(groupedData).sort((a, b) => {
      const dateA = new Date(a.split('/').reverse().join('-')).getTime();
      const dateB = new Date(b.split('/').reverse().join('-')).getTime();
      return dateA - dateB;
    });

    const seriesNames = Array.from(
      new Set(filteredData.map((item) => item[itemType]).filter((name) => name))
    );

    const series = seriesNames.map((item, index) => ({
      name: item,
      data: categories.map((date) => {
        const value = groupedData[date][item] || 0;
        return selectedChartType === CostPieChart
          ? parseFloat(value.toFixed(2))
          : value;
      }),
      hidden: visibleSeries === null || visibleSeries === item ? false : true,
    }));

    return { categories, series };
  };

  useEffect(() => {
    handleSubmit();
  }, [startDate, endDate]);

  const { categories, series } = useMemo(() => {
    return responseTimelinesData && responseTimelinesData.length > 0
      ? transformData(responseTimelinesData, visibleSeries)
      : { categories: [], series: [] };
  }, [responseTimelinesData, selectedChartType, visibleSeries]);

  const chartOptions = {
    chart: {
      id: 'timeline-chart',
      type: 'bar',
      stacked: true,
      events: {
        legendClick: (chartContext: any, seriesIndex: number) => {
          const seriesName = chartContext.w.config.series[seriesIndex].name;
          setVisibleSeries(seriesName);
        },
      },
    },
    colors: hexColors,
    xaxis: {
      categories,
    },
    yaxis: {
      title: {
        text:
          selectedChartType === CostPieChart ? 'Total Cost' : 'Activity Count',
      },
    },
    legend: {
      position: 'bottom',
    },
    plotOptions: {
      bar: {
        horizontal: false,
        dataLabels: {
          total: {
            enabled: true,
            offsetX: 0,
            style: {
              fontSize: '13px',
              fontWeight: 900,
            },
            formatter: (val: any) =>
              selectedChartType === CostPieChart ? '$' + val.toFixed(2) : val,
          },
        },
      },
    },
  };

  const ChartComponent: React.FC<ChartComponentProps> = ({
    title,
    options,
    series,
  }) => {
    if (!options || !series) {
      console.error('Invalid options or series:', { options, series });
      return null;
    }
    return (
      <>
        {/* <h4 className="margin-top">{title}</h4> */}
        <Chart
          options={options}
          series={series}
          type="bar"
          width={'100%'}
          height={600}
        />
      </>
    );
  };

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    const event = !e.target.value ? lastMonthDate : e.target.value;
    setStartDate(event);
  };
  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    setEndDate(e.target.value);
  };

  const handleShowAll = () => {
    setVisibleSeries(null);
  };

  return (
    <>
      <div>
        <Form.Label className="Project-selector">
          <b>Date Range</b>
        </Form.Label>
        <div className="split-screen">
          <div>
            <div>From Date</div>
            <Form.Control
              type="date"
              name="datepic"
              placeholder="Select Date"
              value={startDate}
              className="date-picker"
              onChange={handleStartDateChange}
              min={initialDate}
              max={maxDate}
            />
          </div>
          <div>
            <div>To Date</div>
            <Form.Control
              type="date"
              name="datepic"
              placeholder="Select Date"
              value={endDate ? endDate : maxDate}
              className="date-picker"
              disabled={!startDate}
              onChange={handleEndDateChange}
              min={startDate}
              max={maxDate}
            />
          </div>
        </div>
        {validationError && (
          <div className="date-error-message">{validationError}</div>
        )}

        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            marginTop: 20,
            position: 'relative',
          }}
        >
          <div className="filters-container">
            <div className="filter-show">
              <Form.Label>Data</Form.Label>
              <Form.Select
                value={selectedFilterType}
                onChange={handleFilterOptionChange}
              >
                <option value={User}>{User}</option>
                <option value={Project}>{Project}</option>
                <option value={Engine}>{Engine}</option>
              </Form.Select>
            </div>
            <div className="filter-groupby">
              <Form.Label>Y-axis</Form.Label>
              <Form.Select
                value={selectedChartType}
                onChange={handleOptionChange}
              >
                <option value={CostPieChart}>Cost</option>
                <option value={ActivitiesPieChart}>Activity Count</option>
              </Form.Select>
            </div>
            <div className="filter-sortby">
              <Form.Label>Group By</Form.Label>
              <Form.Select
                value={selectedSortType}
                onChange={handleSortOrderChange}
              >
                <option value={Day}>{Day}</option>
                <option value={Week}>{Week}</option>
                <option value={Month}>{Month}</option>
                <option value={Year}>{Year}</option>
              </Form.Select>
            </div>
          </div>
        </div>

        {responseTimelinesData && responseTimelinesData.length > 0 && (
          <>
            <div className="margin-top all-record-message">
              Showing results from {showDate.startDate} to {showDate.endDate}:
            </div>
            <>
              {loading ? (
                <div className="loading-container">
                  <ContentLoader />
                  <span>Updating Chart...</span>
                </div>
              ) : (
                <>
                  <ChartComponent
                    title="Cost Chart: Project"
                    options={chartOptions}
                    series={series}
                  />
                  <div className="show-all-button">
                    <ButtonGroup>
                      <Button variant="outline-primary" onClick={handleShowAll}>
                        Show All
                      </Button>
                    </ButtonGroup>
                  </div>
                </>
              )}
            </>
          </>
        )}
      </div>
    </>
  );
};
export default TimelinesReport;
