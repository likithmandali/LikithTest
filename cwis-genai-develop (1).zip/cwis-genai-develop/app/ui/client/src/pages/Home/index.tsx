import Card from 'react-bootstrap/Card';
import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import { ReactComponent as ProjectLogo } from '../../assets/project-logo_1.svg';
import { Project } from '../../interfaces';
import Loader from '../../components/Loader';
import './Home.css';
// import { Alert } from 'react-bootstrap';
import axios from 'axios';
import { SUPERADMIN } from '../../utils/constants';
import UserContext from '../../context/UserContext';
import ErrorMessage from '../../components/ErrorMessage';

const Home = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [showToast, setShowToast] = useState<boolean>(false);
  const [userRoleFromAPi, setUserRoleFromAPi] = useState<string>('');
  const userContext = useContext(UserContext) || {
    setErrorMessage: () => {},
    errorMessage: { message: '', id: '' },
  };

  const { setErrorMessage, errorMessage } = userContext;

  const fetchProjects = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/projects/all`
      );

      const data = response.data;
      setShowToast(false);
      setProjects(data.response);
      sessionStorage.setItem('projects', JSON.stringify(data.response));
      setIsLoading(false);
    } catch (error: any) {
      console.error(
        'Error fetching projects:',
        error?.response?.data ?? error?.message
      );
      const err = error?.response?.data?.error?.errorMessage;
      const errID = error?.response?.data?.errorId;
      setIsLoading(false);
      setShowToast(true);
      setErrorMessage({ message: err, id: errID });
    }
  };

  const fetchUserRole = async () => {
    setUserRoleFromAPi('');
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BACKEND_DOMAIN}/rosa/${process.env.REACT_APP_ENVIRONMENT}/v1/genaie/authentication/users/me/`
      );

      const data = response.data;
      setUserRoleFromAPi(data.user_role);
      setShowToast(false);
      setIsLoading(false);
    } catch (error: any) {
      console.error(
        'Error fetching projects:',
        error?.response?.data ?? error?.message
      );
      const err = error?.response?.data?.error?.errorMessage;
      const errID = error?.response?.data?.errorId;
      setIsLoading(false);
      setShowToast(true);
      setErrorMessage({ message: err, id: errID });
    }
  };

  useEffect(() => {
    fetchProjects();
    fetchUserRole();
  }, []);

  return (
    <div className="home-page-container">
      <div className="title-container">
        <h1 className="title">Your Projects</h1>
      </div>
      {isLoading ? (
        <Loader />
      ) : projects.length === 0 ? (
        <div style={{ textAlign: 'center' }}>
          <h1>You do not have access to any of the projects.</h1>
          <p>
            Please reach out to your application admin for more information
            on gaining access.
          </p>
        </div>
      ) : (
        <>
          {/* Only SuperAdmins can view this Track Usage button */}
          {/* {userRoleFromAPi && userRoleFromAPi === SUPERADMIN && (
            <div className="total-cost-button">
              <Link to={`/dashboard/project/track-usage`}>
                <button className="activity-button">Usage Dashboard</button>
              </Link>
            </div>
          )} */}
          <div className="card-container">
            {projects.length > 0 &&
              projects.map((project) => (
                <Link
                  to={`/dashboard/project/${project.id.toString()}`}
                  className="card-link home-card-link"
                  key={project.id}
                >
                  <Card className="project-card-container">
                    <Card.Body
                      className="project-card-body"
                      title={project.name}
                    >
                      <Card.Title className="project-card-title">
                        <div className="project-logo-container">
                           <ProjectLogo
                          style={{
                            maxWidth: '100%',
                            height: 'auto',
                            width: '30%'
                          }}
                          />
                        </div>
                        <h2
                          className={`card-title-text ${project.name?.length > 40 ? 'long-project-text' : 'project-text'}`}
                        >
                          {project.name}
                        </h2>
                      </Card.Title>
                    </Card.Body>
                  </Card>
                </Link>
              ))}
          </div>
        </>
      )}
      {showToast && (
        <ErrorMessage errorMessage={errorMessage} setShowToast={setShowToast} />
      )}
    </div>
  );
};

export default Home;
