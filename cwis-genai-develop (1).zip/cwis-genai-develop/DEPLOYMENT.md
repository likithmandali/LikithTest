# Deployment and Operations Guide

## Overview

This guide covers deployment strategies, monitoring, and operational procedures for the NC_path Enterprise AI Backend.

## Deployment Architecture

### Current Deployment Stack

- **Container Platform**: Docker + Docker Compose
- **Orchestration**: Kubernetes (ROSA - Red Hat OpenShift on AWS)
- **CI/CD**: GitHub Actions + ArgoCD
- **Infrastructure**: AWS (S3, RDS, Bedrock, ECR)
- **Monitoring**: Flower (Celery), Custom health checks

## Deployment Environments

### 1. Development Environment

```bash
# Quick start
make quick-dev

# Manual steps
make ENV=dev setup-dev
make ENV=dev build
make ENV=dev up
make ENV=dev db-migrate
make ENV=dev db-superuser
```

**Access Points:**

- UI: http://localhost:9003
- SmartGPT API: http://localhost:9000
- Orchestrator API: http://localhost:9001/docs
- Flower (Celery): http://localhost:9005
- Redis: localhost:6379

### 2. Production Environment

```bash
# Quick start
make quick-prod

# Manual steps
make ENV=prod setup-prod
make ENV=prod build
make ENV=prod up
make ENV=prod db-migrate
```

## CI/CD Pipeline

### GitHub Actions Workflow

```yaml
# .github/workflows/deploy.yml
name: Deploy NC_path Enterprise AI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run Tests
        run: |
          make ENV=dev build
          make ENV=dev test
          make ENV=dev lint

  build-and-push:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v3
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: us-east-1

      - name: Login to Amazon ECR
        run: aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin $ECR_REGISTRY

      - name: Build and push images
        run: |
          make ENV=prod build
          docker tag smartgpt:latest $ECR_REGISTRY/nc-path/smartgpt:$GITHUB_SHA
          docker tag orchestrator:latest $ECR_REGISTRY/nc-path/orchestrator:$GITHUB_SHA
          docker push $ECR_REGISTRY/nc-path/smartgpt:$GITHUB_SHA
          docker push $ECR_REGISTRY/nc-path/orchestrator:$GITHUB_SHA

  deploy:
    needs: build-and-push
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to ROSA
        run: |
          # ArgoCD will automatically sync the deployment
          echo "Deployment triggered via ArgoCD"
```

### ArgoCD Configuration

```yaml
# argocd/application.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: nc-path-enterprise-ai
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/NCDHHS-Enterprise/cwis-genai
    targetRevision: main
    path: kubernetes/manifests
  destination:
    server: https://kubernetes.default.svc
    namespace: nc-path-prod
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

## Kubernetes Deployment

### Namespace and Resources

```yaml
# kubernetes/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: nc-path-prod
  labels:
    app: nc-path-enterprise-ai
    environment: production
```

### SmartGPT Deployment

```yaml
# kubernetes/smartgpt-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: smartgpt
  namespace: nc-path-prod
spec:
  replicas: 3
  selector:
    matchLabels:
      app: smartgpt
  template:
    metadata:
      labels:
        app: smartgpt
    spec:
      containers:
        - name: smartgpt
          image: ECR_REGISTRY/nc-path/smartgpt:latest
          ports:
            - containerPort: 8000
          env:
            - name: DATABASE_URL
              valueFrom:
                secretKeyRef:
                  name: nc-path-secrets
                  key: database-url
            - name: SECRET_KEY
              valueFrom:
                secretKeyRef:
                  name: nc-path-secrets
                  key: django-secret-key
          resources:
            requests:
              memory: "512Mi"
              cpu: "250m"
            limits:
              memory: "1Gi"
              cpu: "500m"
          livenessProbe:
            httpGet:
              path: /health/
              port: 8000
            initialDelaySeconds: 30
            periodSeconds: 10
          readinessProbe:
            httpGet:
              path: /ready/
              port: 8000
            initialDelaySeconds: 5
            periodSeconds: 5
```

### Service and Ingress

```yaml
# kubernetes/smartgpt-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: smartgpt-service
  namespace: nc-path-prod
spec:
  selector:
    app: smartgpt
  ports:
    - port: 80
      targetPort: 8000
  type: ClusterIP

---
# kubernetes/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: nc-path-ingress
  namespace: nc-path-prod
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  tls:
    - hosts:
        - api.nc-path.deloitte.com
      secretName: nc-path-tls
  rules:
    - host: api.nc-path.deloitte.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: smartgpt-service
                port:
                  number: 80
```

## Monitoring and Observability

### Health Checks

```python
# smartgpt/health/views.py
from django.http import JsonResponse
from django.db import connection
import redis

def health_check(request):
    """Comprehensive health check endpoint"""
    status = {
        'status': 'healthy',
        'timestamp': timezone.now().isoformat(),
        'services': {}
    }

    # Database check
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        status['services']['database'] = 'healthy'
    except Exception as e:
        status['services']['database'] = f'unhealthy: {str(e)}'
        status['status'] = 'unhealthy'

    # Redis check
    try:
        r = redis.Redis.from_url(settings.REDIS_URL)
        r.ping()
        status['services']['redis'] = 'healthy'
    except Exception as e:
        status['services']['redis'] = f'unhealthy: {str(e)}'
        status['status'] = 'unhealthy'

    # AWS services check
    try:
        # Check S3 connectivity
        import boto3
        s3 = boto3.client('s3')
        s3.head_bucket(Bucket=settings.AWS_S3_BUCKET_NAME)
        status['services']['s3'] = 'healthy'
    except Exception as e:
        status['services']['s3'] = f'unhealthy: {str(e)}'
        status['status'] = 'unhealthy'

    return JsonResponse(status)
```

### Logging Configuration

```python
# smartgpt/settings/logging.py
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'json': {
            'format': '{"timestamp": "%(asctime)s", "level": "%(levelname)s", "logger": "%(name)s", "message": "%(message)s"}',
            'datefmt': '%Y-%m-%d %H:%M:%S'
        },
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'json' if os.getenv('LOG_FORMAT') == 'json' else 'verbose',
        },
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '/app/logs/django.log',
            'maxBytes': 1024*1024*10,  # 10MB
            'backupCount': 5,
            'formatter': 'json',
        },
    },
    'root': {
        'level': os.getenv('LOG_LEVEL', 'INFO'),
        'handlers': ['console', 'file'],
    },
    'loggers': {
        'django': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
            'propagate': False,
        },
        'nc_path': {
            'handlers': ['console', 'file'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
}
```

### Metrics and Monitoring

```python
# monitoring/metrics.py
from prometheus_client import Counter, Histogram, Gauge
import time

# Define metrics
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('http_request_duration_seconds', 'HTTP request duration')
ACTIVE_USERS = Gauge('active_users_total', 'Number of active users')
CELERY_TASKS = Counter('celery_tasks_total', 'Total Celery tasks', ['task_name', 'status'])

class MetricsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start_time = time.time()

        response = self.get_response(request)

        # Record metrics
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=request.path,
            status=response.status_code
        ).inc()

        REQUEST_DURATION.observe(time.time() - start_time)

        return response
```

## Backup and Recovery

### Database Backup Strategy

```bash
#!/bin/bash
# scripts/backup-database.sh

BACKUP_DIR="/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="nc_path_backup_${TIMESTAMP}.sql"

# Create backup
kubectl exec -n nc-path-prod deployment/postgres -- pg_dump -U postgres nc_path > "${BACKUP_DIR}/${BACKUP_FILE}"

# Compress backup
gzip "${BACKUP_DIR}/${BACKUP_FILE}"

# Upload to S3
aws s3 cp "${BACKUP_DIR}/${BACKUP_FILE}.gz" s3://nc-path-backups/database/

# Clean old local backups (keep last 7 days)
find ${BACKUP_DIR} -name "nc_path_backup_*.sql.gz" -mtime +7 -delete

echo "Backup completed: ${BACKUP_FILE}.gz"
```

### Disaster Recovery Plan

1. **Database Recovery**

   ```bash
   # Download latest backup
   aws s3 cp s3://nc-path-backups/database/latest.sql.gz ./
   
   # Restore database
   gunzip latest.sql.gz
   kubectl exec -i -n nc-path-prod deployment/postgres -- psql -U postgres -d nc_path < latest.sql
   ```

2. **Application Recovery**
   ```bash
   # Redeploy from last known good image
   kubectl set image deployment/smartgpt smartgpt=ECR_REGISTRY/nc-path/smartgpt:last-known-good -n nc-path-prod
   kubectl set image deployment/orchestrator orchestrator=ECR_REGISTRY/nc-path/orchestrator:last-known-good -n nc-path-prod
   ```

## Security Considerations

### 1. Network Security

- All inter-service communication encrypted
- Network policies to restrict pod-to-pod communication
- Ingress with TLS termination

### 2. Secret Management

```yaml
# kubernetes/secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: nc-path-secrets
  namespace: nc-path-prod
type: Opaque
data:
  database-url: <base64-encoded-database-url>
  django-secret-key: <base64-encoded-secret-key>
  aws-access-key-id: <base64-encoded-access-key>
  aws-secret-access-key: <base64-encoded-secret-key>
```

### 3. RBAC Configuration

```yaml
# kubernetes/rbac.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: nc-path-prod
  name: nc-path-role
rules:
  - apiGroups: [""]
    resources: ["pods", "services", "configmaps", "secrets"]
    verbs: ["get", "list", "watch"]
```

## Troubleshooting Guide

### Common Issues

1. **Pod Startup Issues**

   ```bash
   kubectl describe pod nc-path-prod < pod-name > -n
   kubectl logs nc-path-prod --previous < pod-name > -n
   ```

2. **Database Connection Issues**

   ```bash
   kubectl exec -it deployment/smartgpt -n nc-path-prod -- python manage.py dbshell
   ```

3. **Service Discovery Issues**
   ```bash
   kubectl get svc -n nc-path-prod
   kubectl get endpoints -n nc-path-prod
   ```

### Performance Tuning

1. **Resource Optimization**
   - Monitor resource usage with `kubectl top`
   - Adjust resource requests/limits based on actual usage
   - Use horizontal pod autoscaling for dynamic scaling

2. **Database Optimization**
   - Monitor slow queries
   - Optimize database indexes
   - Configure connection pooling

3. **Caching Strategy**
   - Implement Redis caching for frequently accessed data
   - Use CDN for static assets
   - Cache API responses where appropriate
