# LLM Judge Tests - Setup Guide

This guide explains how to set up and use the consolidated LLM Judge test suite.

## Directory Structure

All LLM Judge code is consolidated in the `tests/` directory:

```
tests/
├── eval_judge/              # Bedrock judge evaluation module
│   ├── __init__.py
│   └── bedrock_judge.py    # Core judge logic
├── scripts/                 # Utility scripts
│   └── make_sample_excel.py # Creates sample test data
├── data/                    # Test data (Excel files)
│   └── smoke.xlsx          # Sample smoke test data
├── results/                 # Output directory (auto-generated)
├── run_from_excel_bedrock.py  # Main evaluation script
├── healthcheck.py            # Lightweight bot health-check
├── requirements.txt        # Python dependencies
├── README.md              # Quick reference
└── SETUP_GUIDE.md         # This file
```

## Quick Start

### 1. Install Dependencies

```bash
cd tests
pip install -r requirements.txt
```

### 2. Create Sample Data

```bash
python scripts/make_sample_excel.py
```

### 3. Run Smoke Test

```bash
python run_from_excel_bedrock.py \
  --in data/smoke.xlsx \
  --test-type smoke \
  --check-threshold \
  --threshold 0.6 \
  --generate-json
```

## 🔧 GitHub Actions Setup

### Workflow Files

1. **`.github/workflows/smoke.yml`** (Consolidated)
   - Triggers on push/PR to `develop` or `cwis-uat` branches
   - Automatically selects environment based on branch:
     - `develop` branch → uses `develop` environment secrets
     - `cwis-uat` branch → uses `cwis-uat` environment secrets
   - Uses conditional logic to select environment-specific secrets

2. **`.github/workflows/regression.yml`**
   - Triggers on push/PR to `cwis-uat` branch only
   - Uses `cwis-uat` environment
   - Scheduled: Every Sunday at 2 AM UTC
   - Manual: Can be triggered via workflow_dispatch

3. **`.github/workflows/healthcheck.yml`**
   - Lightweight bot health-check (auth + single request)
   - Cron: every 15 minutes (configurable — see [Schedule Cron Reference](#schedule-cron-reference))
   - **Multi-environment**: runs in parallel across all environments listed in `HEALTHCHECK_ENVIRONMENTS` variable
   - Manual: trigger via workflow_dispatch — select a specific environment or leave blank to check all enabled environments
   - On failure, sends an HTML email notification per environment via the **Email Notification API** (AWS Lambda + API Gateway)
   - Requires `EMAIL_API_URL` and `EMAIL_API_KEY` secrets
   - Set `HEALTHCHECK_NOTIFY_EMAILS` (comma-separated) for recipient list
   - Set `HEALTHCHECK_ENVIRONMENTS` to control which environments are monitored (default `develop`)

### GitHub Environments Setup

You need to create two GitHub Environments with environment-specific secrets:

#### 1. Create `develop` Environment

1. Go to: **Settings → Environments**
2. Click **New environment**
3. Name: `develop`
4. Add **secrets** (credentials only):
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `BOT_USERNAME_DEVELOP`
   - `BOT_PASSWORD_DEVELOP`

#### 2. Create `cwis-uat` Environment

1. Go to: **Settings → Environments**
2. Click **New environment**
3. Name: `cwis-uat`
4. Add **secrets** (credentials only):
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `BOT_USERNAME_CWIS_UAT`
   - `BOT_PASSWORD_CWIS_UAT`

### Repository Variables

Go to: **Settings → Secrets and variables → Actions → Variables**

Add these variables (shared across environments):

| Variable                 | Default                                     | Description                |
| ------------------------ | ------------------------------------------- | -------------------------- |
| `AWS_REGION`             | `us-east-1`                                 | AWS region                 |
| `BEDROCK_JUDGE_MODEL_ID` | `anthropic.claude-3-5-sonnet-20240620-v1:0` | Bedrock model ID           |
| `S3_BUCKET_NAME`         | `llm-judge-test-results`                    | S3 bucket name             |
| `S3_KEY_PREFIX_DEVELOP`  | `llm-judge-develop`                         | S3 prefix for develop      |
| `S3_KEY_PREFIX_CWIS_UAT` | `llm-judge-cwis-uat`                        | S3 prefix for cwis-uat     |
| `BOT_AUTH_METHOD`        | `username_password`                         | Bot auth method            |
| `BOT_TOKEN_KEY`          | `access_token`                              | Token key in auth response |
| `BOT_RENDER_MARKDOWN`    | `false`                                     | Render markdown            |
| `BOT_INCLUDE_REFERENCES` | `false`                                     | Include references         |
| `BOT_GUARDRAILS_ID`      | (empty)                                     | Guardrails ID (optional)   |

#### Health-Check Variables

| Variable                    | Default   | Description                                                                     |
| --------------------------- | --------- | ------------------------------------------------------------------------------- |
| `HEALTHCHECK_ENVIRONMENTS`  | `develop` | Comma-separated list of environments to monitor (e.g., `develop,cwis-uat,prod`) |
| `HEALTHCHECK_NOTIFY_EMAILS` | (empty)   | Comma-separated email addresses for failure notifications                       |

**Examples:**

- `HEALTHCHECK_ENVIRONMENTS` = `develop` — only monitor develop (start here)
- `HEALTHCHECK_ENVIRONMENTS` = `develop,cwis-uat` — monitor both in parallel
- `HEALTHCHECK_ENVIRONMENTS` = `develop,cwis-uat,prod` — monitor all three in parallel
- `HEALTHCHECK_NOTIFY_EMAILS` = `akshay.kumar@dhhs.nc.gov,raguram.ramasubbu@dhhs.nc.gov,devops@dhhs.nc.gov`

#### Health-Check Email Notification Secrets

Failure emails are sent via the **Email Notification API** (AWS Lambda + API Gateway). These are shared across all environments — only one Email API is used.

Add these **secrets** (Settings > Secrets and variables > Actions > Secrets):

| Secret          | Description                                                                                    |
| --------------- | ---------------------------------------------------------------------------------------------- |
| `EMAIL_API_URL` | Email Notification API base URL (e.g., `https://<id>.execute-api.<region>.amazonaws.com/prod`) |
| `EMAIL_API_KEY` | API Gateway API key for the Email Notification API                                             |

> **Important:** `EMAIL_API_URL` should be the base URL up to the stage (e.g., `/prod`). Do **not** include a trailing slash or the `/v1/email/send` path — the workflow appends it automatically.

> Email is only sent when `HEALTHCHECK_NOTIFY_EMAILS` is set **and** the health-check fails. A separate email is sent for each failed environment.

#### Health-Check Per-Environment Secrets and Variables

Each environment listed in `HEALTHCHECK_ENVIRONMENTS` requires its own bot credentials and configuration.

**Secrets** (per environment):

| Purpose      | develop                | cwis-uat                | prod                |
| ------------ | ---------------------- | ----------------------- | ------------------- |
| Bot username | `BOT_USERNAME_DEVELOP` | `BOT_USERNAME_CWIS_UAT` | `BOT_USERNAME_PROD` |
| Bot password | `BOT_PASSWORD_DEVELOP` | `BOT_PASSWORD_CWIS_UAT` | `BOT_PASSWORD_PROD` |

**Variables** (per environment):

| Purpose         | develop                   | cwis-uat                   | prod                   |
| --------------- | ------------------------- | -------------------------- | ---------------------- |
| Bot auth URL    | `BOT_AUTH_URL_DEVELOP`    | `BOT_AUTH_URL_CWIS_UAT`    | `BOT_AUTH_URL_PROD`    |
| Bot API URL     | `BOT_URL_DEVELOP`         | `BOT_URL_CWIS_UAT`         | `BOT_URL_PROD`         |
| Bot model ARN   | `BOT_MODEL_ARN_DEVELOP`   | `BOT_MODEL_ARN_CWIS_UAT`   | `BOT_MODEL_ARN_PROD`   |
| Bot instance ID | `BOT_INSTANCE_ID_DEVELOP` | `BOT_INSTANCE_ID_CWIS_UAT` | `BOT_INSTANCE_ID_PROD` |

> **Fallback:** If an environment-specific variable is not set, the workflow falls back to the repository-level variable (e.g., `BOT_AUTH_URL`), then to an empty default.

#### How Environment Selection Works

The workflow has two jobs:

1. **`setup`** — reads `HEALTHCHECK_ENVIRONMENTS` and builds a dynamic matrix
2. **`healthcheck`** — runs in parallel for each environment in the matrix

| Trigger                      | Behavior                                              |
| ---------------------------- | ----------------------------------------------------- |
| **Scheduled** (cron)         | Checks all environments in `HEALTHCHECK_ENVIRONMENTS` |
| **Manual** (blank selection) | Same as scheduled                                     |
| **Manual** (specific env)    | Checks only the selected environment                  |
| **Push** (branch trigger)    | Same as scheduled                                     |

Each environment runs as a separate job with `fail-fast: false`, so one environment failing does **not** cancel the others.

#### Adding a New Environment

To enable health-check monitoring for a new environment (e.g., `prod`):

1. Add the required **secrets**: `BOT_USERNAME_PROD`, `BOT_PASSWORD_PROD`
2. Add the required **variables**: `BOT_AUTH_URL_PROD`, `BOT_URL_PROD`, `BOT_MODEL_ARN_PROD`, `BOT_INSTANCE_ID_PROD`
3. Update `HEALTHCHECK_ENVIRONMENTS` to include it: `develop,cwis-uat,prod`
4. **No workflow code changes needed**

#### Schedule Cron Reference

The health-check schedule is defined by the `cron` expression in `healthcheck.yml` (line 9). To change the interval, edit the cron value and push the change:

| Interval                    | Cron Expression                  |
| --------------------------- | -------------------------------- |
| Every 5 minutes             | `*/5 * * * *`                    |
| Every 15 minutes            | `*/15 * * * *` (current default) |
| Every 30 minutes            | `*/30 * * * *`                   |
| Every hour                  | `0 * * * *`                      |
| Every 6 hours               | `0 */6 * * *`                    |
| Once daily (midnight UTC)   | `0 0 * * *`                      |
| Weekdays only, every 30 min | `*/30 * * * 1-5`                 |

> **Note:** GitHub Actions cron uses UTC time. Scheduled workflows only run on the default branch.

### Environment-Specific Variables

These should be set in the respective GitHub Environments or as repository variables:

**For `develop` environment:**

- `BOT_AUTH_URL_DEVELOP` - Bot authentication endpoint URL
- `BOT_URL_DEVELOP` - Bot API endpoint URL
- `BOT_MODEL_ARN_DEVELOP` - Bot model ARN
- `BOT_INSTANCE_ID_DEVELOP` (default: `1` if not set)

**For `cwis-uat` environment:**

- `BOT_AUTH_URL_CWIS_UAT` - Bot authentication endpoint URL
- `BOT_URL_CWIS_UAT` - Bot API endpoint URL
- `BOT_MODEL_ARN_CWIS_UAT` - Bot model ARN
- `BOT_INSTANCE_ID_CWIS_UAT` (default: `1` if not set)

**Optional repository-level fallbacks:**

- `BOT_AUTH_URL` - Fallback if environment-specific not set
- `BOT_URL` - Fallback if environment-specific not set
- `BOT_MODEL_ARN` - Fallback if environment-specific not set
- `BOT_INSTANCE_ID` - Fallback if environment-specific not set

**Note:** Environment-specific variables take precedence over repository-level variables. If neither is set, defaults are used.

## Secret Naming Convention

**Secrets are only used for credentials (passwords, access keys). All configuration values use variables.**

### Develop Environment Secrets

- `AWS_ACCESS_KEY_ID` - AWS access key
- `AWS_SECRET_ACCESS_KEY` - AWS secret key
- `BOT_USERNAME_DEVELOP` - Bot API username
- `BOT_PASSWORD_DEVELOP` - Bot API password

### CWIS UAT Environment Secrets

- `AWS_ACCESS_KEY_ID` - AWS access key
- `AWS_SECRET_ACCESS_KEY` - AWS secret key
- `BOT_USERNAME_CWIS_UAT` - Bot API username
- `BOT_PASSWORD_CWIS_UAT` - Bot API password

## Workflow Behavior

### Smoke Test (Consolidated)

- **Trigger**: Push/PR to `develop` or `cwis-uat` branches
- **Environment Selection**:
  - `develop` branch → automatically uses `develop` environment
  - `cwis-uat` branch → automatically uses `cwis-uat` environment
- **S3 Prefix**:
  - `develop` branch → `llm-judge-develop`
  - `cwis-uat` branch → `llm-judge-cwis-uat`
- **Purpose**: Test code deployed to respective environment
- **How it works**: Uses `github.ref_name` to determine branch and conditionally selects secrets

### Regression Test

- **Trigger**:
  - Push/PR to `cwis-uat` branch
  - Scheduled: Every Sunday at 2 AM UTC
  - Manual: Via workflow_dispatch
- **Environment**: `cwis-uat` (uses cwis-uat secrets)
- **S3 Prefix**: `llm-judge-cwis-uat-regression`
- **Input File**: `data/regression.xlsx`
- **Purpose**: Weekly comprehensive testing on UAT environment

## Output Files

All results are generated in `tests/results/`:

- `*.xlsx` - Excel report with formatting and summary
- `*.csv` - CSV report
- `*.json` - JSON summary for dashboards

Results are also:

- Uploaded to S3 (if `--upload-s3` is used)
- Uploaded as GitHub Actions artifacts:
  - Smoke tests: 90 days retention
  - Regression tests: 90 days retention
- **Download URLs**: Available in the JSON file (not logged to avoid GitHub Actions credential masking)

## Testing Locally

### Test with Develop Environment

```bash
cd tests
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export BOT_AUTH_URL=https://develop-endpoint.com/auth
export BOT_USERNAME=dev_user
export BOT_PASSWORD=dev_pass
export BOT_URL=https://develop-endpoint.com/stream
export BOT_MODEL_ARN=arn:aws:bedrock:...

python run_from_excel_bedrock.py \
  --in data/smoke.xlsx \
  --test-type smoke \
  --check-threshold \
  --threshold 0.6 \
  --generate-json
```

### Test with CWIS UAT Environment

```bash
cd tests
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export BOT_AUTH_URL=https://uat-endpoint.com/auth
export BOT_USERNAME=uat_user
export BOT_PASSWORD=uat_pass
export BOT_URL=https://uat-endpoint.com/stream
export BOT_MODEL_ARN=arn:aws:bedrock:...

python run_from_excel_bedrock.py \
  --in data/smoke.xlsx \
  --test-type smoke \
  --check-threshold \
  --threshold 0.6 \
  --generate-json
```

## Checklist

### Initial Setup

- [ ] Create `develop` GitHub Environment
- [ ] Create `cwis-uat` GitHub Environment (when ready)
- [ ] Create `prod` GitHub Environment (when ready)
- [ ] Add all required secrets to each environment
- [ ] Add repository variables
- [ ] Set `HEALTHCHECK_ENVIRONMENTS` to `develop` (add more environments as they become ready)
- [ ] Set `HEALTHCHECK_NOTIFY_EMAILS` with recipient list
- [ ] Add `EMAIL_API_URL` and `EMAIL_API_KEY` secrets for email notifications
- [ ] Test workflows manually

### Verification

- [ ] Push to `develop` branch → smoke test runs
- [ ] Push to `cwis-uat` branch → smoke test runs
- [ ] Check results in S3
- [ ] Check artifacts in GitHub Actions
- [ ] Verify exit codes (0 = pass, 1 = fail)

## Troubleshooting

### Workflow fails with "Environment not found"

- Ensure GitHub Environments are created
- Check environment names match workflow files

### "Secret not found" errors

- Verify secrets are added to the correct environment
- Check secret names match workflow files exactly

### S3 upload fails

- Verify AWS credentials are correct
- Check S3 bucket exists and is accessible
- Verify IAM permissions

### Bot API calls fail

- Check endpoint URLs are correct for each environment
- Verify credentials are valid
- Check network connectivity

### Health-check email notification fails

- **HTTP 403 "Missing Authentication Token"**: `EMAIL_API_URL` is wrong — ensure it ends with the stage (e.g., `/prod`) and has no trailing slash or `/v1/email/send` path
- **HTTP 403 "Forbidden"**: `EMAIL_API_KEY` is missing, incorrect, or not linked to the API Gateway usage plan
- **No email sent**: Verify `HEALTHCHECK_NOTIFY_EMAILS` variable is set and not empty

### Health-check not running for all environments

- Verify `HEALTHCHECK_ENVIRONMENTS` variable is set correctly (comma-separated, no spaces required)
- Check that each environment has the required secrets and variables configured
- Review the `setup` job logs to see which matrix was generated

## Related Documentation

- `README.md` - Quick reference
