# LLM Judge Tests Directory

This directory contains all the code and resources needed for LLM Judge evaluation tests.

## Directory Structure

```
tests/
├── eval_judge/          # Bedrock judge evaluation module
│   ├── __init__.py
│   └── bedrock_judge.py
├── scripts/             # Utility scripts
│   └── make_sample_excel.py
├── data/                # Test data (Excel files)
│   └── smoke.xlsx       # Sample smoke test data
├── results/             # Output directory (generated)
├── run_from_excel_bedrock.py  # Main evaluation script
├── healthcheck.py             # Lightweight bot health-check
├── requirements.txt     # Python dependencies
└── README.md           # This file
```

## Setup

1. **Install dependencies**:

   ```bash
   cd tests
   pip install -r requirements.txt
   ```

2. **Create sample data** (if needed):
   ```bash
   python scripts/make_sample_excel.py
   ```

## Usage

### Run Smoke Test Locally

```bash
cd tests
python run_from_excel_bedrock.py \
  --in data/smoke.xlsx \
  --test-type smoke \
  --check-threshold \
  --threshold 0.6 \
  --generate-json \
  --upload-s3
```

### Run Regression Test Locally

```bash
cd tests
python run_from_excel_bedrock.py \
  --in data/regression.xlsx \
  --test-type regression \
  --check-threshold \
  --threshold 0.6 \
  --generate-json \
  --upload-s3
```

## Environment Variables

### Required (Secrets)

- `AWS_ACCESS_KEY_ID` - AWS access key (secret)
- `AWS_SECRET_ACCESS_KEY` - AWS secret key (secret)
- `AWS_REGION` (default: `us-east-1`) - AWS region (variable)
- `BEDROCK_JUDGE_MODEL_ID` (default: `anthropic.claude-3-5-sonnet-20240620-v1:0`) - Bedrock model ID (variable)

### Bot API

**Secrets (credentials):**

- `BOT_USERNAME` - Bot API username (secret)
- `BOT_PASSWORD` - Bot API password (secret)

**Variables (configuration):**

- `BOT_AUTH_URL` - Bot authentication endpoint URL (variable)
- `BOT_URL` - Bot API endpoint URL (variable)
- `BOT_MODEL_ARN` - Bot model ARN (variable)
- `BOT_INSTANCE_ID` (default: `1`) - Bot instance ID (variable, environment-specific)
- `BOT_AUTH_METHOD` (default: `username_password`) - Authentication method (variable)
- `BOT_TOKEN_KEY` (default: `access_token`) - Token key in auth response (variable)
- `BOT_INCLUDE_REFERENCES` (default: `false`) - Include references (variable)
- `BOT_RENDER_MARKDOWN` (default: `false`) - Render markdown (variable)
- `BOT_GUARDRAILS_ID` (optional) - Guardrails ID (variable)

### S3 (Variables)

- `S3_BUCKET_NAME` (default: `llm-judge-test-results`) - S3 bucket name
- `S3_KEY_PREFIX` (default: `llm-judge-test-results`) - S3 key prefix

**Note:** In GitHub Actions, environment-specific variables are used (e.g., `BOT_AUTH_URL_DEVELOP`, `BOT_INSTANCE_ID_DEVELOP` for develop environment).

## GitHub Actions

### Smoke Tests

- **Workflow**: `.github/workflows/smoke.yml` (consolidated)
- **Develop**: Triggers on push/PR to `develop` branch → uses `develop` environment
- **CWIS UAT**: Triggers on push/PR to `cwis-uat` branch → uses `cwis-uat` environment
- **Manual**: Can be triggered via workflow_dispatch

### Regression Tests

- **Workflow**: `.github/workflows/regression.yml`
- **Branches**: Only runs on `cwis-uat` branch
- **Environment**: Uses `cwis-uat` environment
- **Schedule**: Every Sunday at 2 AM UTC
- **Manual**: Can be triggered via workflow_dispatch

### Health-Check

- **Workflow**: `.github/workflows/healthcheck.yml`
- **Script**: `tests/healthcheck.py` — lightweight probe that authenticates and sends a single request to the bot endpoint
- **Schedule**: Cron runs every 15 minutes (configurable — see cron table below)
- **Environments**: Supports `develop`, `cwis-uat`, and `prod` — runs in parallel via matrix strategy
- **Email Notifications**: On failure, sends an HTML email per environment via the Email Notification API (AWS Lambda + API Gateway)
- **Manual**: Can be triggered via workflow_dispatch — select a specific environment or leave blank to check all enabled environments

#### How Environment Selection Works

The workflow uses a **matrix strategy** to run health-checks in parallel across multiple environments. A `setup` job reads the `HEALTHCHECK_ENVIRONMENTS` variable and builds the matrix dynamically.

| Trigger                           | Behavior                                                                 |
| --------------------------------- | ------------------------------------------------------------------------ |
| **Scheduled** (cron)              | Checks all environments listed in `HEALTHCHECK_ENVIRONMENTS` in parallel |
| **Manual** (blank selection)      | Same as scheduled — checks all enabled environments                      |
| **Manual** (specific environment) | Checks only the selected environment                                     |
| **Push** (branch trigger)         | Same as scheduled — checks all enabled environments                      |

Each environment runs as a separate job, so one failing environment does **not** cancel the others.

#### Enabling Environments

Control which environments are monitored by updating a single repository variable — no code changes needed:

| `HEALTHCHECK_ENVIRONMENTS` value | Result                                  |
| -------------------------------- | --------------------------------------- |
| `develop`                        | Only checks develop (default)           |
| `develop,cwis-uat`               | Checks develop and cwis-uat in parallel |
| `develop,cwis-uat,prod`          | Checks all three in parallel            |

#### Per-Environment Secrets and Variables

Each environment requires its own bot credentials and configuration:

**Secrets** (Settings > Secrets and variables > Actions > Secrets):

| Purpose      | develop                | cwis-uat                | prod                |
| ------------ | ---------------------- | ----------------------- | ------------------- |
| Bot username | `BOT_USERNAME_DEVELOP` | `BOT_USERNAME_CWIS_UAT` | `BOT_USERNAME_PROD` |
| Bot password | `BOT_PASSWORD_DEVELOP` | `BOT_PASSWORD_CWIS_UAT` | `BOT_PASSWORD_PROD` |

**Variables** (Settings > Secrets and variables > Actions > Variables):

| Purpose         | develop                   | cwis-uat                   | prod                   |
| --------------- | ------------------------- | -------------------------- | ---------------------- |
| Bot auth URL    | `BOT_AUTH_URL_DEVELOP`    | `BOT_AUTH_URL_CWIS_UAT`    | `BOT_AUTH_URL_PROD`    |
| Bot API URL     | `BOT_URL_DEVELOP`         | `BOT_URL_CWIS_UAT`         | `BOT_URL_PROD`         |
| Bot model ARN   | `BOT_MODEL_ARN_DEVELOP`   | `BOT_MODEL_ARN_CWIS_UAT`   | `BOT_MODEL_ARN_PROD`   |
| Bot instance ID | `BOT_INSTANCE_ID_DEVELOP` | `BOT_INSTANCE_ID_CWIS_UAT` | `BOT_INSTANCE_ID_PROD` |

Fallback: if an environment-specific variable is not set, the workflow falls back to the repository-level variable (e.g., `BOT_AUTH_URL`), then to an empty string.

#### Adding a New Environment

To enable health-check monitoring for a new environment (e.g., `prod`):

1. Add the required secrets: `BOT_USERNAME_PROD`, `BOT_PASSWORD_PROD`
2. Add the required variables: `BOT_AUTH_URL_PROD`, `BOT_URL_PROD`, `BOT_MODEL_ARN_PROD`, `BOT_INSTANCE_ID_PROD`
3. Update `HEALTHCHECK_ENVIRONMENTS` to include it (e.g., `develop,cwis-uat,prod`)
4. No workflow code changes needed

#### Email Notification Secrets (Shared)

These are shared across all environments — only one Email API is used:

| Secret          | Description                                                                                    |
| --------------- | ---------------------------------------------------------------------------------------------- |
| `EMAIL_API_URL` | Email Notification API base URL (e.g., `https://<id>.execute-api.<region>.amazonaws.com/prod`) |
| `EMAIL_API_KEY` | API Gateway API key for the Email Notification API                                             |

> `EMAIL_API_URL` should be the base URL up to the stage (e.g., `/prod`). Do **not** include a trailing slash or `/v1/email/send`.

#### Health-Check Variables (Shared)

| Variable                    | Default   | Description                                                                                                                                   |
| --------------------------- | --------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `HEALTHCHECK_ENVIRONMENTS`  | `develop` | Comma-separated list of environments to monitor (e.g., `develop,cwis-uat,prod`)                                                               |
| `HEALTHCHECK_NOTIFY_EMAILS` | (empty)   | Comma-separated email addresses for failure notifications (e.g., `akshay.kumar@dhhs.nc.gov,raguram.ramasubbu@dhhs.nc.gov,devops@dhhs.nc.gov`) |

#### Schedule Cron Reference

To change the health-check interval, edit the `cron` value in `healthcheck.yml` line 9:

| Interval                    | Cron Expression          |
| --------------------------- | ------------------------ |
| Every 5 minutes             | `*/5 * * * *`            |
| Every 15 minutes            | `*/15 * * * *` (current) |
| Every 30 minutes            | `*/30 * * * *`           |
| Every hour                  | `0 * * * *`              |
| Every 6 hours               | `0 */6 * * *`            |
| Once daily (midnight UTC)   | `0 0 * * *`              |
| Weekdays only, every 30 min | `*/30 * * * 1-5`         |

> GitHub Actions cron uses UTC time. Scheduled workflows only run on the default branch.

## Output Files

Results are generated in `tests/results/`:

- `*.xlsx` - Excel report with formatting
- `*.csv` - CSV report
- `*.json` - JSON summary for dashboards (contains S3 download URLs)

Results are also:

- Uploaded to S3 (if `--upload-s3` is used)
- Uploaded as GitHub Actions artifacts (retention: 90 days for smoke, 90 days for regression)
- Download URLs are stored in the JSON file (not logged to avoid GitHub Actions masking)

## Notes

- All code is self-contained in the `tests/` directory
- Uses environment-specific secrets via GitHub Environments
