import os, sys, time, json, argparse
import subprocess
import pandas as pd
import requests
import boto3
from botocore.config import Config
import logging
from botocore.exceptions import ClientError
from datetime import datetime
from urllib3.exceptions import NewConnectionError
from requests.exceptions import ChunkedEncodingError
from http.client import IncompleteRead




# Ensure tests directory is on sys.path for 'eval_judge' imports when running as a script
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from typing import Optional
from eval_judge.bedrock_judge import judge_pair_bedrock, is_non_retryable_error


def setup_logging(log_level: str = "INFO", log_file: str = None):
    """Setup logging configuration with best practices."""
    
    # Convert string to logging level
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    
    # Create formatter
    formatter = logging.Formatter(
        fmt='%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Get root logger
    logger = logging.getLogger()
    logger.setLevel(numeric_level)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler (if specified)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)  # Always log everything to file
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # Set specific loggers to appropriate levels
    logging.getLogger('boto3').setLevel(logging.WARNING)
    logging.getLogger('botocore').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)
    
    return logger

# Global token cache
_token_cache = {
    "token": None,
    "expires_at": 0
}

"""
Reads Excel with columns:
id | question | gold_answer | candidate (optional)

If --use-existing-candidate is set and 'candidate' exists, uses it.
Otherwise, calls your custom bot REST API to get a candidate answer via SSE stream.

ENV for your bot:
BOT_AUTH_URL (e.g., https://genai-dev-orch.extapps.cwisrosa-dev-1.gc7f.p1.openshiftapps.com/auth)
BOT_AUTH_METHOD (username_password or api_key; default: username_password)
BOT_USERNAME (username for authentication)
BOT_PASSWORD (password for authentication)
BOT_API_KEY (API key if using api_key auth method)
BOT_TOKEN_KEY (key in auth response for token; default "access_token")
BOT_URL (e.g., https://genai-dev-orch.extapps.cwisrosa-dev-1.gc7f.p1.openshiftapps.com/stream)
BOT_INSTANCE_ID (instance ID for API; default "1")
BOT_MODEL_ARN (model ARN for API calls)
BOT_INCLUDE_REFERENCES (include references in response; default "false")
BOT_RENDER_MARKDOWN (render markdown in response; default "false")
BOT_GUARDRAILS_ID (guardrails ID for API calls)

S3 Upload Configuration (optional):
S3_BUCKET_NAME (S3 bucket for storing results; default: llm-judge-test-results)
S3_KEY_PREFIX (S3 key prefix; default: llm-judge-test-results)
AWS_DEFAULT_REGION (AWS region; default us-east-1)

The bot response comes as SSE stream and the complete response is sent to the judge.
The judge is instructed to focus on the main answer content while considering supporting information.
Supports multiple SSE response formats (content, text, message, response, data fields).

Output Excel/CSV includes separate columns for each score and its rationale:
- full_bot_response (complete bot response including reasoning and references)
- candidate (extracted RESPONSE portion for reference - judge evaluates full response)
- accuracy, accuracy_rationale
- relevancy, relevancy_rationale  
- completeness, completeness_rationale
- tone, tone_rationale
- notes (combined notes from judge)

Output files are automatically named based on input filename + timestamp:
- Input: data/eval.xlsx → Output: results/eval_20250115_143022.xlsx
- Input: data/smoke_test_20250926_135027.xlsx → Output: results/smoke_test_20250926_135027.xlsx (no double timestamp)
- Use --out-prefix to override the default naming

Excel formatting includes:
- Professional headers with blue background and white text
- Color-coded verdicts (PASS=Green, REVIEW=Yellow, FAIL=Red, ERROR=Dark Red)
- Score color scales (Red=0, Yellow=0.5, Green=1)
- Optimized column widths for readability
- Text wrapping for long content
- Frozen header row for easy navigation
- Comprehensive summary sheet with:
  * Key performance metrics and pass/fail rates
  * Detailed score analysis with min/max/average/std dev
  * Interactive pie chart for verdict distribution
  * Bar chart for score comparisons
  * Performance insights and recommendations
"""

def get_auth_token() -> str:
    """Get authentication token from the auth endpoint with caching and expiry checking."""
    logger = logging.getLogger(__name__)
    current_time = time.time()
    
    # Check if we have a valid cached token
    if (_token_cache["token"] is not None and 
        current_time < _token_cache["expires_at"]):
        logger.debug("Using cached authentication token")
        return _token_cache["token"]
    
    logger.info("Fetching new authentication token")
    
    # Token expired or doesn't exist, get a new one
    auth_url = os.getenv("BOT_AUTH_URL", "").strip()
    if not auth_url:
        logger.error("BOT_AUTH_URL environment variable is not set")
        raise RuntimeError("BOT_AUTH_URL is not set.")
    
    logger.debug(f"Auth URL: {auth_url}")
    
    # Support multiple auth methods
    auth_method = os.getenv("BOT_AUTH_METHOD", "username_password").lower()
    
    if auth_method == "username_password":
        auth_payload = {
            "username": os.getenv("BOT_USERNAME", ""),
            "password": os.getenv("BOT_PASSWORD", "")
        }
    elif auth_method == "api_key":
        auth_payload = {
            "api_key": os.getenv("BOT_API_KEY", "")
        }
    else:
        raise RuntimeError(f"Unsupported auth method: {auth_method}")
    
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    # Respect global SSL verification toggle for auth request as well
    disable_ssl_verify = os.getenv("DISABLE_SSL_VERIFY", "false").lower() == "true"
    if disable_ssl_verify:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    r = requests.post(
        auth_url,
        headers=headers,
        data=auth_payload,
        timeout=30,
        verify=(not disable_ssl_verify)
    )
    r.raise_for_status()
    data = r.json()
    
    token_key = os.getenv("BOT_TOKEN_KEY", "access_token")
    if token_key not in data:
        raise RuntimeError(f"Auth response missing key '{token_key}': {data}")
    
    token = str(data[token_key]).strip()
    
    # Calculate expiry time
    expires_in = data.get("expires_in", 3600)  # Default to 1 hour if not provided
    expires_at = current_time + expires_in - 60  # Subtract 60 seconds for safety buffer
    
    # Cache the token
    _token_cache["token"] = token
    _token_cache["expires_at"] = expires_at
    
    return token

def clear_token_cache():
    """Clear the cached token (useful for testing or when token is invalidated)."""
    global _token_cache
    _token_cache = {
        "token": None,
        "expires_at": 0
    }

def get_bot_answer_rest(question: str, max_retries: int = 5, retry_delay: float = 1.0) -> str:
    """Get bot answer via authenticated API with retry logic for network failures."""
    logger = logging.getLogger(__name__)
    logger.info(f"Getting bot answer for question: {question[:100]}...")
    
    url = os.getenv("BOT_URL", "").strip()
    if not url:
        logger.error("BOT_URL environment variable is not set")
        raise RuntimeError("BOT_URL is not set.")
    
    logger.debug(f"Bot URL: {url}")
    
    # Get authentication token
    token = get_auth_token()
    
    # Prepare headers with auth token
    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        "Authorization": f"Bearer {token}"
    }
    
    # Build payload to match API schema exactly
    instance_id = os.getenv("BOT_INSTANCE_ID", "1")  # send as string
    model_arn = os.getenv("BOT_MODEL_ARN", "").strip() or os.getenv("BOT_MODEL_NAME", "us.anthropic.claude-sonnet-4-20250514-v1:0")

    payload = {
        "instance_id": instance_id,
        "model": model_arn,
        "input_text": question,
        # Always include as object
        "additional_json_context": {},
        "include_references": os.getenv("BOT_INCLUDE_REFERENCES", "false").lower() == "true",
        "render_markdown": os.getenv("BOT_RENDER_MARKDOWN", "false").lower() == "true",
    }
    # Optional guardrails
    guardrails_id = os.getenv("BOT_GUARDRAILS_ID", "").strip()
    if guardrails_id:
        payload["guardrails_id"] = guardrails_id

    # Create session for connection pooling and better error handling
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'LLM-Judge/1.0',
        'Connection': 'keep-alive',
        'Accept-Encoding': 'gzip, deflate',
        'Cache-Control': 'no-cache'
    })
    
    # Optional: disable SSL verification via env flag (to handle expired/self-signed certs)
    disable_ssl_verify = os.getenv("DISABLE_SSL_VERIFY", "false").lower() == "true"
    if disable_ssl_verify:
        session.verify = False
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    # Configure session for better reliability
    session.mount('http://', requests.adapters.HTTPAdapter(max_retries=0))
    session.mount('https://', requests.adapters.HTTPAdapter(max_retries=0))
    
    # Retry logic for network failures
    last_exception = None
    for attempt in range(max_retries):
        try:
            logger.debug(f"Attempt {attempt + 1}/{max_retries} - Making API request...")
            
            # Make non-streaming request with session for better connection handling
            # Use different timeout strategies for different attempts
            timeout = 60 + (attempt * 30)  # Increase timeout with each attempt
            r = session.post(url, headers=headers, json=payload, timeout=timeout, verify=session.verify)
            
            # Handle token expiry (401 Unauthorized)
            if r.status_code == 401:
                clear_token_cache()  # Clear invalid token
                raise RuntimeError("Authentication failed - token may have expired. Please check credentials.")
            
            r.raise_for_status()
            
            # Parse full response text
            full_response = r.text or ""
            logger.debug(f"API request successful on attempt {attempt + 1}")
            
            # Return the complete response with reasoning and references
            return full_response.strip()
            
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout, 
                NewConnectionError, ChunkedEncodingError, IncompleteRead) as e:
            last_exception = e
            logger.warning(f"Network/streaming error on attempt {attempt + 1}/{max_retries}: {e}")
            
            if attempt < max_retries - 1:
                # More aggressive backoff for IncompleteRead errors
                if isinstance(e, IncompleteRead):
                    retry_delay = 2.0 + (attempt * 1.5)  # Longer delay for connection issues
                else:
                    retry_delay = 1.0 + (attempt * 0.5)  # Standard backoff
                
                logger.info(f"Retrying in {retry_delay:.1f} seconds...")
                time.sleep(retry_delay)
            else:
                logger.error(f"All {max_retries} attempts failed due to network/streaming errors")
                raise RuntimeError(f"Failed to connect to bot API after {max_retries} attempts. Last error: {e}")
        
        except Exception as e:
            logger.error(f"Non-retryable error: {e}")
            raise e
        finally:
            # Reset connection between attempts to prevent connection reuse issues
            if attempt < max_retries - 1:
                session.close()
                # Create new session for next attempt
                session = requests.Session()
                session.headers.update({
                    'User-Agent': 'LLM-Judge/1.0',
                    'Connection': 'keep-alive',
                    'Accept-Encoding': 'gzip, deflate',
                    'Cache-Control': 'no-cache'
                })
                session.mount('http://', requests.adapters.HTTPAdapter(max_retries=0))
                session.mount('https://', requests.adapters.HTTPAdapter(max_retries=0))
                # Re-apply SSL verification preference on new session
                if disable_ssl_verify:
                    session.verify = False
                    import urllib3
                    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            elif attempt == max_retries - 1:
                session.close()
    
    # This should never be reached, but just in case
    raise RuntimeError(f"Unexpected error in retry logic: {last_exception}")



def _format_excel_report(workbook, worksheet, df):
    """Apply comprehensive formatting to the Excel report for better readability."""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.formatting.rule import ColorScaleRule, CellIsRule
    from openpyxl.utils import get_column_letter
    
    # Define styles
    header_font = Font(bold=True, color="FFFFFF", size=12)
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    center_align = Alignment(horizontal="center", vertical="center")
    wrap_align = Alignment(wrap_text=True, vertical="top")
    
    # Format headers
    for col_num in range(1, len(df.columns) + 1):
        cell = worksheet.cell(row=1, column=col_num)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center_align
        cell.border = border
    
    # Set column widths based on content type
    column_widths = {
        'id': 8,
        'question': 30,
        'gold_answer': 60,
        'full_bot_response': 100,  # Significantly increased width to prevent trimming
        'verdict': 12,
        'overall': 10,
        'accuracy': 10,
        'accuracy_rationale': 30,
        'relevancy': 10,
        'relevancy_rationale': 30,
        'completeness': 12,
        'completeness_rationale': 30,
        'tone': 8,
        'tone_rationale': 30,
        'notes': 30
    }
    
    # Apply column widths
    for col_num, column_name in enumerate(df.columns, 1):
        width = column_widths.get(column_name, 15)
        worksheet.column_dimensions[get_column_letter(col_num)].width = width
    
    # Format data cells
    for row_num in range(2, len(df) + 2):
        for col_num in range(1, len(df.columns) + 1):
            cell = worksheet.cell(row=row_num, column=col_num)
            cell.border = border
            cell.alignment = wrap_align
    
    # Apply conditional formatting for scores
    score_columns = ['overall', 'accuracy', 'relevancy', 'completeness', 'tone']
    for col_name in score_columns:
        if col_name in df.columns:
            col_num = df.columns.get_loc(col_name) + 1
            col_letter = get_column_letter(col_num)
            
            # Color scale for 0-5 scores: red (0) to green (5)
            color_scale = ColorScaleRule(
                start_type='num', start_value=0, start_color='FF6B6B',    # Red for 0
                mid_type='num', mid_value=2.5, mid_color='FFD93D',       # Yellow for 2.5
                end_type='num', end_value=5, end_color='6BCF7F'           # Green for 5
            )
            worksheet.conditional_formatting.add(
                f'{col_letter}2:{col_letter}{len(df) + 1}',
                color_scale
            )
            
            # Add specific color rules for each score level
            score_colors = [
                (0, 'FF0000'),  # Red for 0
                (1, 'FF4500'),  # Orange Red for 1
                (2, 'FF8C00'),  # Dark Orange for 2
                (3, 'FFD700'),  # Gold for 3
                (4, '90EE90'),  # Light Green for 4
                (5, '00FF00')   # Green for 5
            ]
            
            for score, color in score_colors:
                score_rule = CellIsRule(
                    operator='equal', 
                    formula=[str(score)], 
                    fill=PatternFill(start_color=color, end_color=color, fill_type="solid")
                )
                worksheet.conditional_formatting.add(
                    f'{col_letter}2:{col_letter}{len(df) + 1}',
                    score_rule
                )
    
    # Format verdict column with color coding
    if 'verdict' in df.columns:
        verdict_col = df.columns.get_loc('verdict') + 1
        verdict_letter = get_column_letter(verdict_col)
        
        # PASS = Green
        pass_rule = CellIsRule(operator='equal', formula=['"PASS"'], 
                              fill=PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid"))
        worksheet.conditional_formatting.add(
            f'{verdict_letter}2:{verdict_letter}{len(df) + 1}',
            pass_rule
        )
        
        # REVIEW = Yellow
        review_rule = CellIsRule(operator='equal', formula=['"REVIEW"'], 
                                fill=PatternFill(start_color="FFFF99", end_color="FFFF99", fill_type="solid"))
        worksheet.conditional_formatting.add(
            f'{verdict_letter}2:{verdict_letter}{len(df) + 1}',
            review_rule
        )
        
        # FAIL = Red
        fail_rule = CellIsRule(operator='equal', formula=['"FAIL"'], 
                              fill=PatternFill(start_color="FFB6C1", end_color="FFB6C1", fill_type="solid"))
        worksheet.conditional_formatting.add(
            f'{verdict_letter}2:{verdict_letter}{len(df) + 1}',
            fail_rule
        )
        
        # ERROR = Dark Red
        error_rule = CellIsRule(operator='equal', formula=['"ERROR"'], 
                               fill=PatternFill(start_color="FF6B6B", end_color="FF6B6B", fill_type="solid"))
        worksheet.conditional_formatting.add(
            f'{verdict_letter}2:{verdict_letter}{len(df) + 1}',
            error_rule
        )
    
    # Freeze panes for better navigation
    worksheet.freeze_panes = 'A2'
    
    # Add summary statistics with error handling
    logger = logging.getLogger(__name__)
    try:
        _add_summary_sheet(workbook, df)
    except Exception as e:
        logger.error(f"Summary sheet generation failed: {e}")
        logger.info("Continuing without summary sheet...")


def _add_summary_sheet(workbook, df):
    """Add a comprehensive summary sheet with statistics and charts."""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.chart import PieChart, BarChart, Reference, Series
    from openpyxl.chart.label import DataLabelList
    import pandas as pd
    import logging
    
    logger = logging.getLogger(__name__)
    
    # Create summary sheet
    summary_ws = workbook.create_sheet("Summary", 0)  # Insert as first sheet
    
    # Define styles
    title_font = Font(bold=True, size=18, color="2F4F4F")
    header_font = Font(bold=True, size=14, color="4682B4")
    subheader_font = Font(bold=True, size=12)
    border = Border(left=Side(style='thin'), right=Side(style='thin'), 
                   top=Side(style='thin'), bottom=Side(style='thin'))
    
    # Add main title
    summary_ws['A1'] = "LLM Judge Evaluation Summary Report"
    summary_ws['A1'].font = title_font
    summary_ws.merge_cells('A1:F1')
    
    # Add timestamp
    from datetime import datetime
    summary_ws['A2'] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    summary_ws['A2'].font = Font(italic=True, size=10)
    
    # SECTION 1: Key Metrics
    row = 4
    summary_ws[f'A{row}'] = "KEY METRICS"
    summary_ws[f'A{row}'].font = header_font
    row += 1
    
    # Basic statistics
    total_evals = len(df)
    summary_ws[f'A{row}'] = "Total Evaluations:"
    summary_ws[f'B{row}'] = total_evals
    summary_ws[f'B{row}'].font = Font(bold=True)
    row += 1
    
    if 'verdict' in df.columns:
        verdict_counts = df['verdict'].value_counts()
        pass_rate = (verdict_counts.get('PASS', 0) / total_evals * 100) if total_evals > 0 else 0
        review_rate = (verdict_counts.get('REVIEW', 0) / total_evals * 100) if total_evals > 0 else 0
        fail_rate = (verdict_counts.get('FAIL', 0) / total_evals * 100) if total_evals > 0 else 0
        
        summary_ws[f'A{row}'] = "Pass Rate:"
        summary_ws[f'B{row}'] = f"{pass_rate:.1f}%"
        summary_ws[f'B{row}'].font = Font(bold=True, color="008000")
        row += 1
        
        summary_ws[f'A{row}'] = "Review Rate:"
        summary_ws[f'B{row}'] = f"{review_rate:.1f}%"
        summary_ws[f'B{row}'].font = Font(bold=True, color="FF8C00")
        row += 1
        
        summary_ws[f'A{row}'] = "Fail Rate:"
        summary_ws[f'B{row}'] = f"{fail_rate:.1f}%"
        summary_ws[f'B{row}'].font = Font(bold=True, color="DC143C")
        row += 2
    
    # SECTION 2: Score Analysis (Left side)
    summary_ws[f'A{row}'] = "📈 SCORE ANALYSIS"
    summary_ws[f'A{row}'].font = header_font
    row += 1
    
    score_columns = ['overall', 'accuracy', 'relevancy', 'completeness', 'tone']
    
    # Create score summary table
    summary_ws[f'A{row}'] = "Metric"
    summary_ws[f'B{row}'] = "Average"
    summary_ws[f'C{row}'] = "Min"
    summary_ws[f'D{row}'] = "Max"
    
    for col in ['A', 'B', 'C', 'D']:
        summary_ws[f'{col}{row}'].font = subheader_font
        summary_ws[f'{col}{row}'].border = border
    row += 1
    
    score_data_start = row
    for col in score_columns:
        if col in df.columns:
            avg_score = df[col].mean()
            min_score = df[col].min()
            max_score = df[col].max()
            
            summary_ws[f'A{row}'] = col.title()
            summary_ws[f'B{row}'] = round(avg_score, 3)
            summary_ws[f'C{row}'] = round(min_score, 3)
            summary_ws[f'D{row}'] = round(max_score, 3)
            
            for cell_col in ['A', 'B', 'C', 'D']:
                summary_ws[f'{cell_col}{row}'].border = border
            row += 1
    
    score_data_end = row - 1
    
    # SECTION 3: Verdict Distribution (Left side, below score analysis)
    row += 2
    summary_ws[f'A{row}'] = "🥧 VERDICT DISTRIBUTION"
    summary_ws[f'A{row}'].font = header_font
    row += 1
    
    verdict_data_start = row
    if 'verdict' in df.columns:
        verdict_counts = df['verdict'].value_counts()
        
        summary_ws[f'A{row}'] = "Verdict"
        summary_ws[f'B{row}'] = "Count"
        summary_ws[f'C{row}'] = "Percentage"
        
        for col in ['A', 'B', 'C']:
            summary_ws[f'{col}{row}'].font = subheader_font
            summary_ws[f'{col}{row}'].border = border
        row += 1
        
        for verdict, count in verdict_counts.items():
            percentage = (count / total_evals * 100) if total_evals > 0 else 0
            summary_ws[f'A{row}'] = verdict
            summary_ws[f'B{row}'] = count
            summary_ws[f'C{row}'] = f"{percentage:.1f}%"
            
            for cell_col in ['A', 'B', 'C']:
                summary_ws[f'{cell_col}{row}'].border = border
            row += 1
    
    verdict_data_end = row - 1
    
    # SECTION 4: Evaluation Criteria (Right side, moved further right)
    criteria_start_row = 4  # Start at same row as key metrics
    summary_ws[f'K{criteria_start_row}'] = "📋 EVALUATION CRITERIA"
    summary_ws[f'K{criteria_start_row}'].font = header_font
    criteria_start_row += 1
    
    # Add evaluation criteria explanation
    criteria_text = [
        "ACCURACY (0-5): Is the provided information correct?",
        "• 5: Entirely accurate information",
        "• 4: Almost all accurate with minimal inaccurate",
        "• 3: Mostly accurate with some inaccurate",
        "• 2: Some accurate and some inaccurate",
        "• 1: Almost entirely inaccurate",
        "• 0: Completely inaccurate",
        "",
        "COMPLETENESS (0-5): Does the response include all necessary information?",
        "• 5: All key pieces of information included",
        "• 4: Most key pieces included",
        "• 3: Some information but missing less pivotal pieces",
        "• 2: Some information but missing key pieces",
        "• 1: Minimal key pieces included",
        "• 0: No information to answer the question",
        "",
        "RELEVANCY (0-5): Is the provided information applicable to the question?",
        "• 5: All information relevant",
        "• 4: Most information relevant",
        "• 3: Some relevant, some not relevant",
        "• 2: Most irrelevant but has connection",
        "• 1: Almost all irrelevant",
        "• 0: All information irrelevant",
        "",
        "TONE (0-5): Is the provided information easy to understand?",
        "• 5: Simple, clear, and easy to read",
        "• 4: Simple language",
        "• 3: Complex but simpler than source",
        "• 2: As complex as source document",
        "• 1: Unprofessional or more complex than source",
        "• 0: Not in English",
        "",
        "VERDICT THRESHOLDS:",
        "• PASS: ≥ 3.0 (3 and above)",
        "• REVIEW: 2.0-2.9 (between 2 to 3)",
        "• FAIL: < 2.0 (below 2)",
        "",
        "QUALITY GATE RULES:",
        "• Any dimension ≤ 1: VERDICT = FAIL (overall score preserved)",
        "• Any dimension = 2: VERDICT = REVIEW (overall score preserved)",
        "• All dimensions ≥ 3: Normal verdict thresholds apply"
    ]
    
    for line in criteria_text:
        if line == "":
            criteria_start_row += 1
            continue
        summary_ws[f'K{criteria_start_row}'] = line
        if line.endswith("?"):
            summary_ws[f'K{criteria_start_row}'].font = Font(bold=True, size=11)
        elif line.startswith("•"):
            summary_ws[f'K{criteria_start_row}'].font = Font(size=10)
        elif line.startswith("VERDICT"):
            summary_ws[f'K{criteria_start_row}'].font = Font(bold=True, size=11, color="2F4F4F")
        else:
            summary_ws[f'K{criteria_start_row}'].font = Font(size=10)
        criteria_start_row += 1
    
    # SECTION 5: Create Pie Chart for Verdict Distribution (Center)
    if 'verdict' in df.columns and len(verdict_counts) > 0:
        pie_chart = PieChart()
        pie_chart.title = "Verdict Distribution"
        pie_chart.height = 10
        pie_chart.width = 15
        
        # Data for pie chart - use proper data references
        data = Reference(summary_ws, min_col=2, min_row=verdict_data_start + 1, 
                        max_row=verdict_data_end, max_col=2)
        labels = Reference(summary_ws, min_col=1, min_row=verdict_data_start + 1, 
                          max_row=verdict_data_end, max_col=1)
        
        # Add data with proper series naming
        pie_chart.add_data(data, titles_from_data=True)
        pie_chart.set_categories(labels)
        
        # Style the pie chart with color coding
        pie_chart.dataLabels = DataLabelList()
        pie_chart.dataLabels.showPercent = True
        pie_chart.dataLabels.showVal = True
        
        # Add color coding for different verdicts
        from openpyxl.drawing.colors import RGBPercent
        try:
            if len(pie_chart.series) > 0:
                series = pie_chart.series[0]
                # Color coding: PASS=Green, REVIEW=Yellow, FAIL=Red
                colors = {
                    'PASS': RGBPercent(0.0, 0.8, 0.0),      # Green
                    'REVIEW': RGBPercent(1.0, 0.8, 0.0),     # Yellow/Orange  
                    'FAIL': RGBPercent(0.8, 0.0, 0.0)       # Red
                }
                
                # Apply colors based on verdict labels (skip if points don't exist)
                if hasattr(series, 'points') and series.points:
                    for i, point in enumerate(series.points):
                        if i < len(verdict_counts):
                            verdict = list(verdict_counts.keys())[i]
                            if verdict in colors:
                                point.graphicalProperties.solidFill = colors[verdict]
        except Exception as e:
            logger.warning(f"Could not apply pie chart colors: {e}")
        
        # Position pie chart further right to avoid overlap with score analysis
        summary_ws.add_chart(pie_chart, "F4")
    
    # SECTION 6: Create Bar Chart for Score Analysis (Center, below pie chart)
    if len([col for col in score_columns if col in df.columns]) > 0:
        try:
            bar_chart = BarChart()
            bar_chart.title = "Average Scores by Metric"
            bar_chart.y_axis.title = "Score (0 - 5)"
            bar_chart.x_axis.title = "Metrics"
            bar_chart.height = 10
            bar_chart.width = 15
            
            # Set Y-axis scale to 0-5 with proper scaling
            bar_chart.y_axis.scaling.min = 0
            bar_chart.y_axis.scaling.max = 5
            bar_chart.y_axis.majorUnit = 1  # 1-unit gaps
            bar_chart.y_axis.minorUnit = 0.5
            
            # Data for bar chart
            data = Reference(summary_ws, min_col=2, min_row=score_data_start, 
                            max_row=score_data_end, max_col=2)
            labels = Reference(summary_ws, min_col=1, min_row=score_data_start, 
                              max_row=score_data_end, max_col=1)
            
            bar_chart.add_data(data, titles_from_data=False)
            bar_chart.set_categories(labels)
            
            # Position bar chart further right, below pie chart, to avoid overlap
            summary_ws.add_chart(bar_chart, "F20")
        except Exception as e:
            logger.warning(f"Could not create bar chart: {e}")
    
    # SECTION 6: Performance Insights
    row = verdict_data_end + 3
    summary_ws[f'A{row}'] = "PERFORMANCE INSIGHTS"
    summary_ws[f'A{row}'].font = header_font
    row += 1
    
    # Generate insights
    if 'overall' in df.columns:
        overall_avg = df['overall'].mean()
        if overall_avg >= 4.0:
            insight = "🟢 Excellent performance - Most responses meet high standards"
        elif overall_avg >= 3.0:
            insight = "🟡 Good performance - Some responses need improvement"
        else:
            insight = "🔴 Performance needs attention - Many responses require revision"
        
        summary_ws[f'A{row}'] = insight
        summary_ws[f'A{row}'].font = Font(size=12)
        row += 2
    
    # Identify top performing areas
    if len([col for col in score_columns if col in df.columns]) > 1:
        score_avgs = {}
        for col in score_columns:
            if col in df.columns:
                score_avgs[col] = df[col].mean()
        
        if score_avgs:
            best_metric = max(score_avgs, key=score_avgs.get)
            worst_metric = min(score_avgs, key=score_avgs.get)
            
            summary_ws[f'A{row}'] = f"Strongest Area: {best_metric.title()} ({score_avgs[best_metric]:.3f})"
            summary_ws[f'A{row}'].font = Font(color="008000")
            row += 1
            
            summary_ws[f'A{row}'] = f"Improvement Needed: {worst_metric.title()} ({score_avgs[worst_metric]:.3f})"
            summary_ws[f'A{row}'].font = Font(color="DC143C")
            row += 1
    
    # Set column widths for new layout
    column_widths = {
        'A': 20,  # Left side - metrics
        'B': 12,  # Left side - values
        'C': 10,  # Left side - min
        'D': 12,  # Left side - max
        'E': 15,  # Center - chart space
        'F': 15,  # Center - chart space (charts start here)
        'G': 15,  # Center - chart space
        'H': 15,  # Center - chart space
        'I': 15,  # Center - chart space
        'J': 15,  # Center - chart space
        'K': 25,  # Right side - evaluation criteria
        'L': 15,  # Right side - criteria details
        'M': 15   # Right side - criteria details
    }
    for col, width in column_widths.items():
        summary_ws.column_dimensions[col].width = width
def upload_to_s3(file_path: str, bucket_name: str = None, key_prefix: str = None):
    """
    Upload file to S3 and return a dict with all available URLs:
      - presigned_url: Presigned URL (if verified successfully, may not work from all networks)
      - https_url: Stable HTTPS URL (requires AWS credentials, always available)
      - s3_path: S3 path for use with AWS CLI (e.g., s3://bucket/key)

    Returns:
        dict: {
            "presigned_url": str or None,
            "https_url": str,
            "s3_path": str
        }
        Returns None if upload fails.

    Notes:
    - Presigned URL is tested once from the runner using a simple GET. If S3 still
      returns InvalidAccessKeyId/AccessDenied for that URL, presigned_url will be None.
    - Stable HTTPS URL is NOT presigned; it still requires appropriate S3 permissions.
    - Use https_url or s3_path if presigned_url doesn't work from your network.
    """
    logger = logging.getLogger(__name__)
    
    logger.info("="*60)
    logger.info("STARTING S3 UPLOAD PROCESS")
    logger.info("="*60)
    
    # Check if file exists
    if not os.path.exists(file_path):
        logger.error(f"File not found: {file_path}")
        return False
    
    file_size = os.path.getsize(file_path)
    logger.info(f"File: {file_path}")
    logger.info(f"Size: {file_size:,} bytes ({file_size/1024:.1f} KB)")
    
    # Get configuration
    if not bucket_name:
        bucket_name = os.getenv("S3_BUCKET_NAME", "llm-judge-test-results")
    if not key_prefix:
        key_prefix = os.getenv("S3_KEY_PREFIX", "llm-judge-test-results")
    
    aws_region = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
    
    logger.info(f"S3 Bucket: {bucket_name}")
    logger.info(f"Key Prefix: {key_prefix}")
    logger.info(f"AWS Region: {aws_region}")
    
    # Create S3 client
    logger.info("Creating S3 client...")
    try:
        # Get credentials explicitly from environment (service account access key/secret)
        aws_access_key = os.getenv("AWS_ACCESS_KEY_ID")
        aws_secret_key = os.getenv("AWS_SECRET_ACCESS_KEY")
        
        
        # Configure S3 client with explicit signing to ensure presigned URLs work correctly
        # Use signature version v4 (s3v4) which is required for presigned URLs
        s3_config = Config(
            signature_version='s3v4'
        )
        
        # Create S3 client with explicit credentials (service account access key/secret)
        # This ensures both upload and presigned URL generation use the same credentials
        if aws_access_key and aws_secret_key:
            # Using long-lived service account credentials
            s3_client = boto3.client(
                's3',
                region_name=aws_region,
                config=s3_config,
                aws_access_key_id=aws_access_key,
                aws_secret_access_key=aws_secret_key,
                aws_session_token=None
            )
            logger.debug("S3 client created with explicit service account credentials")
        else:
            # Fall back to default credential chain
            s3_client = boto3.client('s3', region_name=aws_region, config=s3_config)
        
        # Verify credentials by checking if we can access the bucket
        try:
            s3_client.head_bucket(Bucket=bucket_name)
            logger.info("S3 client created successfully and bucket access verified")
            
        except Exception as verify_err:
            logger.warning(f"Bucket access verification failed: {verify_err}")
            logger.warning("Continuing anyway - upload may fail if credentials are invalid")
    except Exception as e:
        logger.error(f"Failed to create S3 client: {e}")
        logger.error("Check that AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY are set correctly")
        return None
    
    # Generate key (filename with timestamp)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    filename = os.path.basename(file_path)
    key = f"{key_prefix}/{timestamp}_{filename}"
    
    logger.info(f"S3 Key: {key}")
    logger.info("Starting upload...")
    
    try:
        # Upload file
        s3_client.upload_file(file_path, bucket_name, key)
        logger.info("File uploaded successfully!")

        # Generate presigned URL (3 days expiry)
        presigned_url = None
        try:
            logger.info("Generating presigned download URL...")
            presigned_url = s3_client.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket_name, "Key": key},
                ExpiresIn=259200  # 3 days
            )
            logger.info("Presigned URL generated successfully")
        except Exception as e:
            logger.warning(f"Failed to generate presigned URL: {e}")
            presigned_url = None

        # Construct a stable, non-expiring HTTPS URL (not presigned) as fallback / reference
        if aws_region == "us-east-1":
            https_url = f"https://{bucket_name}.s3.amazonaws.com/{key}"
        else:
            https_url = f"https://{bucket_name}.s3.{aws_region}.amazonaws.com/{key}"

        # Display results prominently
        logger.info("="*60)
        logger.info("UPLOAD COMPLETED SUCCESSFULLY!")
        logger.info("="*60)
        logger.info("Download URLs are available in the JSON file (artifact or S3)")
        logger.info("="*60)

        # Return both URLs: presigned (if available) and stable HTTPS (always available)
        # Return as dict to allow caller to choose which to use
        return {
            "presigned_url": presigned_url,
            "https_url": https_url,
            "s3_path": f"s3://{bucket_name}/{key}"
        }
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        logger.error(f"AWS S3 Error: {error_code}")
        if error_code == 'NoSuchBucket':
            logger.error(f"S3 bucket '{bucket_name}' does not exist. Create it first or set S3_BUCKET_NAME")
        elif error_code == 'AccessDenied':
            logger.error(f"Access denied to S3 bucket '{bucket_name}'. Check your AWS permissions.")
        else:
            logger.error(f"S3 upload failed: {e}")
        return False
    except Exception as e:
        logger.error(f"Upload failed: {e}")
        return False


def check_pass_threshold(df, threshold=0.6, logger=None):
    """
    Check if evaluation results pass the threshold.
    
    Args:
        df: DataFrame with evaluation results (must have 'overall' and 'verdict' columns)
        threshold: Pass threshold as decimal (0.6 = 60%). Checks if average overall >= threshold * 5.0
        logger: Optional logger instance
    
    Returns:
        tuple: (passed: bool, metrics: dict)
    """
    if logger is None:
        logger = logging.getLogger(__name__)
    
    # Calculate metrics
    total_evals = len(df)
    avg_overall = df['overall'].mean() if 'overall' in df.columns else 0.0
    
    # Calculate pass rate (PASS verdicts / total)
    if 'verdict' in df.columns:
        pass_count = (df['verdict'] == 'PASS').sum()
        review_count = (df['verdict'] == 'REVIEW').sum()
        fail_count = (df['verdict'] == 'FAIL').sum()
        error_count = (df['verdict'] == 'ERROR').sum()
        pass_rate = (pass_count / total_evals * 100) if total_evals > 0 else 0.0
    else:
        pass_count = review_count = fail_count = error_count = 0
        pass_rate = 0.0
    
    # Threshold: 60% = 3.0/5.0 average overall score
    threshold_score = threshold * 5.0
    passed = avg_overall >= threshold_score
    
    # Calculate score breakdowns
    score_breakdown = {}
    score_columns = ['accuracy', 'relevancy', 'completeness', 'tone']
    for col in score_columns:
        if col in df.columns:
            score_breakdown[col] = {
                "avg": float(df[col].mean()),
                "min": float(df[col].min()),
                "max": float(df[col].max()),
                "std": float(df[col].std()) if len(df) > 1 else 0.0
            }
    
    metrics = {
        "total_evaluations": int(total_evals),
        "average_overall_score": float(avg_overall),
        "threshold_score": float(threshold_score),
        "threshold_percentage": float(threshold * 100),
        "passed": bool(passed),
        "pass_rate_percentage": float(pass_rate),
        "verdict_counts": {
            "PASS": int(pass_count),
            "REVIEW": int(review_count),
            "FAIL": int(fail_count),
            "ERROR": int(error_count)
        },
        "score_breakdown": score_breakdown
    }
    
    return passed, metrics


def generate_json_summary(df, out_prefix, test_type="unknown", threshold=0.6, 
                         excel_s3_url=None, excel_download_url=None,
                         excel_presigned_url=None, excel_https_url=None, logger=None):
    """
    Generate JSON summary file for dashboard/CI/CD.
    
    Args:
        df: DataFrame with evaluation results
        out_prefix: Output file prefix (e.g., "results/smoke_20250115_143022")
        test_type: Type of test ("smoke" or "regression")
        threshold: Pass threshold used
        excel_s3_url: S3 path to Excel file (optional)
        excel_download_url: Primary download URL (presigned or HTTPS, optional)
        excel_presigned_url: Presigned URL (may not work from all networks, optional)
        excel_https_url: Stable HTTPS URL (requires AWS credentials, optional)
        logger: Optional logger instance
    
    Returns:
        str: Path to generated JSON file, or None if failed
    """
    if logger is None:
        logger = logging.getLogger(__name__)
    
    # Check pass/fail
    passed, metrics = check_pass_threshold(df, threshold, logger)
    
    # Get git info - check for external source first, then GitHub Actions
    source_repo = os.getenv("SOURCE_REPO", "")
    source_sha = os.getenv("SOURCE_SHA", "")
    source_branch = os.getenv("SOURCE_BRANCH", "")
    source_ref = os.getenv("SOURCE_REF", "")
    
    if source_repo:
        # External repo triggered this (e.g., GenAI repo)
        git_info = {
            "source_repo": source_repo,
            "sha": source_sha,
            "branch": source_branch,
            "ref": source_ref,
            "triggered_by": "external_repo"
        }
    else:
        # Running in llm-judge repo or locally
        git_sha = os.getenv("GITHUB_SHA", "")
        git_ref = os.getenv("GITHUB_REF", "")
        git_branch = os.getenv("GITHUB_REF_NAME", "")
        if not git_branch and git_ref:
            # Extract branch from ref (e.g., "refs/heads/main" -> "main")
            git_branch = git_ref.replace("refs/heads/", "").replace("refs/tags/", "")
        
        git_info = {
            "sha": git_sha,
            "ref": git_ref,
            "branch": git_branch,
            "triggered_by": "llm_judge_repo"
        }
    
    # Create summary
    summary = {
        "test_type": test_type,
        "timestamp": datetime.now().isoformat() + "Z",
        "git_info": git_info,
        "metrics": metrics,
        "files": {
            "excel": f"{out_prefix}.xlsx",
            "csv": f"{out_prefix}.csv",
            "json": f"{out_prefix}.json"
        },
        "s3": {
            "excel_s3_url": excel_s3_url,
            "excel_download_url": excel_download_url,  # Primary URL (presigned if available, else HTTPS)
            "excel_presigned_url": excel_presigned_url,  # Presigned URL (may fail from some networks)
            "excel_https_url": excel_https_url  # Stable HTTPS URL (requires AWS credentials)
        }
    }
    
    # Write JSON file
    json_path = f"{out_prefix}.json"
    try:
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        logger.info(f"Generated JSON summary: {json_path}")
        return json_path
    except Exception as e:
        logger.error(f"Failed to write JSON summary: {e}")
        return None


def main():
    ap = argparse.ArgumentParser(description="LLM Judge - Evaluate candidate answers against gold answers using Amazon Bedrock")
    ap.add_argument("--in", dest="infile", required=True, help="Excel input (.xlsx) with id,question,gold_answer[,candidate].")
    ap.add_argument("--out-prefix", help="Output prefix (default: auto-generated from input filename + timestamp).")
    ap.add_argument("--sleep", type=float, default=0.0, help="Sleep seconds between rows.")
    ap.add_argument("--max-retries", type=int, default=3, help="Maximum retries for API calls (default: 3).")
    ap.add_argument("--retry-delay", type=float, default=2.0, help="Initial retry delay in seconds (default: 2.0).")
    ap.add_argument("--use-existing-candidate", action="store_true",
                    help="Use 'candidate' column if present instead of calling bot.")
    ap.add_argument("--upload-s3", action="store_true",
                    help="Upload Excel report to S3.")
    ap.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                    help="Set logging level (default: INFO).")
    ap.add_argument("--log-file", help="Log to file in addition to console.")
    ap.add_argument("--check-threshold", action="store_true",
                    help="Enable threshold checking and exit with code 0 (pass) or 1 (fail).")
    ap.add_argument("--threshold", type=float, default=0.6,
                    help="Pass threshold as decimal (default: 0.6 = 60%% = 3.0/5.0 average score).")
    ap.add_argument("--test-type", default="unknown", choices=["smoke", "regression", "unknown"],
                    help="Type of test for JSON summary (default: unknown).")
    ap.add_argument("--generate-json", action="store_true",
                    help="Generate JSON summary file alongside Excel output.")
    # Get default from environment variable if available, otherwise use 3
    default_max_errors = int(os.getenv("MAX_CONSECUTIVE_RETRYABLE_ERRORS", "3"))
    ap.add_argument("--max-consecutive-retryable-errors", type=int, default=default_max_errors,
                    help=f"Maximum consecutive retryable errors before exiting (default: {default_max_errors} from MAX_CONSECUTIVE_RETRYABLE_ERRORS env var or 3). Set to 0 to disable early exit for retryable errors.")
    args = ap.parse_args()
    
    # Generate output prefix if not provided
    if not args.out_prefix:
        # Extract filename without extension from input file
        input_basename = os.path.splitext(os.path.basename(args.infile))[0]
        
        # Check if filename already contains a timestamp pattern (YYYYMMDD_HHMMSS)
        import re
        timestamp_pattern = r'\d{8}_\d{6}'
        if re.search(timestamp_pattern, input_basename):
            # Filename already has a timestamp, use it as-is
            args.out_prefix = f"results/{input_basename}"
        else:
            # No timestamp found, add one
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            args.out_prefix = f"results/{input_basename}_{timestamp}"
    
    # Ensure results directory exists
    os.makedirs(os.path.dirname(args.out_prefix), exist_ok=True)
    
    # Setup logging
    logger = setup_logging(args.log_level, args.log_file)
    logger.info("="*60)
    logger.info("STARTING LLM JUDGE EVALUATION")
    logger.info("="*60)
    logger.info(f"Input file: {args.infile}")
    logger.info(f"Output prefix: {args.out_prefix}")
    logger.info(f"Log level: {args.log_level}")
    logger.info(f"Upload to S3: {args.upload_s3}")
    logger.info(f"Use existing candidates: {args.use_existing_candidate}")
    logger.info(f"Sleep between rows: {args.sleep}s")
    logger.info(f"Max retries for API calls: {args.max_retries}")
    logger.info(f"Retry delay: {args.retry_delay}s")

 

    # Check cache status
    cache_file = os.getenv("JUDGE_CACHE", ".judge_cache.json")
    if os.path.exists(cache_file):
        cache_size = os.path.getsize(cache_file)
        logger.info(f"Judge cache file found: {cache_file} ({cache_size:,} bytes)")
        logger.debug(f"Cache file exists - previous results may be reused")
    else:
        logger.info(f"No judge cache file found: {cache_file}")
        logger.debug(f"All evaluations will be fresh API calls")

    logger.info("Reading input Excel file...")
    df = pd.read_excel(args.infile)
    # Normalize column names: strip whitespace
    df.columns = df.columns.str.strip()
    logger.info(f"Loaded {len(df)} rows from {args.infile}")
    logger.info(f"Input data columns: {list(df.columns)}")
    logger.debug(f"First few rows preview:")
    for i, row in df.head(3).iterrows():
        logger.debug(f"  Row {i+1}: ID={row.get('id', 'N/A')}, Question={str(row.get('question', ''))[:50]}...")

    # Check for required columns (case-insensitive)
    needed = ["id", "gold_answer"]
    found_cols_lower = {col.lower(): col for col in df.columns}
    for col in needed:
        if col.lower() not in found_cols_lower:
            logger.error(f"Missing required column '{col}' in {args.infile}")
            logger.error(f"Available columns: {list(df.columns)}")
            raise ValueError(f"Missing required column '{col}' in {args.infile}. Available: {list(df.columns)}")
    
    # Check for either candidate or question column (case-insensitive)
    has_candidate = any(col.lower() == "candidate" for col in df.columns)
    has_question = any(col.lower() == "question" for col in df.columns)
    if not has_candidate and not has_question:
        logger.error("Excel must include either 'candidate' or 'question' column")
        logger.error(f"Available columns: {list(df.columns)}")
        raise ValueError(f"Excel must include either 'candidate' or 'question' column. Available: {list(df.columns)}")

    use_existing = args.use_existing_candidate and ("candidate" in df.columns)
    logger.info(f"Using existing candidates: {use_existing}")

    # Track consecutive retryable errors
    consecutive_retryable_errors = 0
    max_consecutive_retryable_errors = args.max_consecutive_retryable_errors
    logger.info(f"Max consecutive retryable errors before exit: {max_consecutive_retryable_errors} (0 = disabled)")

    logger.info("Starting evaluation process...")
    rows = []
    for i, (_, row) in enumerate(df.iterrows()):
        qid = str(row["id"])
        gold = str(row["gold_answer"])
        
        logger.info(f"Processing row {i+1}/{len(df)}: {qid}")

        # Priority: Use existing candidate only if --use-existing-candidate flag is set
        # Otherwise, always fetch from bot API using question column
        if use_existing and "candidate" in df.columns:
            candidate_val = row.get("candidate")
            if candidate_val is not None and not pd.isna(candidate_val):
                candidate_str = str(candidate_val).strip()
                if candidate_str:
                    candidate = candidate_str
                    full_bot_response = candidate  # For display purposes
                    logger.info(f"Row {i+1}: Using existing candidate from Excel (length: {len(candidate)})")
                else:
                    use_existing = False  # Fall through to fetch from bot
            else:
                use_existing = False  # Fall through to fetch from bot
        else:
            use_existing = False  # Will fetch from bot
        
        if not use_existing:
            # Try to get question with case-insensitive column matching
            question = None
            question_col = None
            for col in df.columns:
                if col.lower().strip() == "question":
                    question_col = col
                    question = row.get(col)
                    break
            
            if question_col is None:
                logger.error(f"Row {qid}: 'question' column not found in Excel. Available columns: {list(df.columns)}")
                logger.error(f"Row {qid}: To fetch responses from bot API, you must provide a 'question' column with values.")
                raise RuntimeError(f"Row {qid}: 'question' column not found. Available columns: {list(df.columns)}")
            
            # Handle pandas NaN values
            if pd.isna(question):
                question = ""
                logger.warning(f"Row {qid}: question value is NaN/empty in column '{question_col}'")
            else:
                question = str(question).strip()
            
            if not question:
                logger.error(f"Row {qid}: Question column '{question_col}' exists but value is empty.")
                logger.error(f"Row {qid}: To fetch responses from bot API, you must provide a question value.")
                logger.error(f"Row {qid}: Available columns: {list(df.columns)}")
                # Log row data for debugging (excluding very long values)
                row_dict = {}
                for k, v in dict(row).items():
                    if isinstance(v, str) and len(v) > 100:
                        row_dict[k] = v[:100] + "..."
                    else:
                        row_dict[k] = v
                logger.error(f"Row {qid}: Row data (preview): {row_dict}")
                raise RuntimeError(f"Row {qid}: Question column '{question_col}' exists but value is empty. Please fill in the question column to fetch responses from bot API.")
            logger.info(f"Row {i+1}: Fetching candidate from bot API...")
            try:
                full_bot_response = get_bot_answer_rest(question, max_retries=args.max_retries, retry_delay=args.retry_delay)
                logger.info(f"Row {i+1}: Successfully got full bot response (length: {len(full_bot_response)})")
                
                # Log the full response for debugging
                logger.debug(f"Row {i+1}: Full bot response preview: {full_bot_response[:200]}...")
                logger.debug(f"Row {i+1}: Complete bot response:\n{full_bot_response}")
                logger.info(f"Row {i+1}: Using full bot response for evaluation (length: {len(full_bot_response)})")
            except Exception as e:
                logger.error(f"Row {i+1}: Failed to get candidate: {e}")
                
                # Check if this is a non-retryable error after retries
                if is_non_retryable_error(e):
                    logger.error("=" * 60)
                    logger.error("NON-RETRYABLE ERROR DETECTED - EXITING IMMEDIATELY")
                    logger.error("=" * 60)
                    logger.error(f"Bot API error: {e}")
                    logger.error("")
                    logger.error("This appears to be a configuration/permission issue that won't be resolved by retrying.")
                    logger.error("Please check Bot API credentials and configuration.")
                    logger.error("=" * 60)
                    sys.exit(1)
                
                full_bot_response = f"ERROR: {str(e)}"

        # Skip evaluation if full_bot_response is an error
        if full_bot_response.startswith("ERROR:"):
            logger.warning(f"Row {i+1}: Skipping evaluation due to error in bot response")
            
            # Check if this was a non-retryable error
            error_msg = full_bot_response.replace("ERROR: ", "")
            # Create a simple exception-like object for error checking
            class ErrorWrapper:
                def __init__(self, msg):
                    self.msg = msg
                def __str__(self):
                    return self.msg
            
            error_obj = ErrorWrapper(error_msg)
            if is_non_retryable_error(error_obj):
                logger.error("=" * 60)
                logger.error("NON-RETRYABLE ERROR DETECTED - EXITING IMMEDIATELY")
                logger.error("=" * 60)
                logger.error(f"Bot API error: {error_msg}")
                logger.error("")
                logger.error("This appears to be a configuration/permission issue.")
                logger.error("Please check Bot API credentials and configuration.")
                logger.error("=" * 60)
                sys.exit(1)
            else:
                # Retryable error - increment counter
                consecutive_retryable_errors += 1
                logger.warning(f"Retryable error on row {i+1}. Consecutive retryable errors: {consecutive_retryable_errors}")
                
                if max_consecutive_retryable_errors > 0 and consecutive_retryable_errors >= max_consecutive_retryable_errors:
                    logger.error("=" * 60)
                    logger.error("TOO MANY CONSECUTIVE RETRYABLE ERRORS - EXITING")
                    logger.error("=" * 60)
                    logger.error(f"{max_consecutive_retryable_errors} consecutive rows failed with retryable errors.")
                    logger.error("This likely indicates a persistent issue (service outage, network problem).")
                    logger.error(f"Last error: {error_msg}")
                    logger.error("=" * 60)
                    sys.exit(1)
            
            result = {
                "verdict": "ERROR",
                "overall": 0,
                "scores": {"overall": 0, "accuracy": 0, "relevancy": 0, "completeness": 0, "tone": 0},
                "rationales": {"accuracy": "Bot response was an error", "relevancy": "Bot response was an error", "completeness": "Bot response was an error", "tone": "Bot response was an error", "notes": ["Bot response was an error"]}
            }
            scores = result["scores"]
            rats = result.get("rationales", {})
        else:
            # Reset counter on successful bot response
            consecutive_retryable_errors = 0
            logger.info(f"Row {i+1}: Evaluating with Bedrock judge...")
            try:
                # Get question for context (if available)
                question_text = row.get("question", "")
                # Handle pandas NaN values
                if pd.isna(question_text):
                    question_text = ""
                else:
                    question_text = str(question_text).strip()
                # Use full bot response for evaluation (judge will focus on main answer content)
                evaluation_text = full_bot_response
                result = judge_pair_bedrock(gold, evaluation_text, question_text)
                scores = result["scores"]
                rats = result.get("rationales", {})
                logger.info(f"Row {i+1}: Evaluation completed - Verdict: {result.get('verdict', 'UNKNOWN')}")
                
                # Reset counter on successful evaluation
                consecutive_retryable_errors = 0
                
                # Debug logging to check if caching is working
                logger.debug(f"Row {i+1}: Cache status - Check .judge_cache.json file for cached results")
                
                # Debug logging for evaluation details
                logger.debug(f"Row {i+1}: Evaluation inputs:")
                logger.debug(f"  Question: {question_text[:100]}..." if question_text else "  Question: (none)")
                logger.debug(f"  Gold Answer: {gold[:100]}..." if gold else "  Gold Answer: (none)")
                logger.debug(f"  Bot Response: {evaluation_text[:200]}..." if evaluation_text else "  Bot Response: (none)")
                logger.debug(f"Row {i+1}: Evaluation results:")
                logger.debug(f"  Verdict: {result.get('verdict', 'UNKNOWN')}")
                logger.debug(f"  Overall: {result.get('overall', 'N/A')}")
                logger.debug(f"  Scores: {scores}")
                logger.debug(f"  Rationales: {rats}")
            except Exception as e:
                logger.error(f"Row {i+1}: Evaluation failed: {e}")
                
                # Check if this is a non-retryable error after retries
                if is_non_retryable_error(e):
                    logger.error("=" * 60)
                    logger.error("NON-RETRYABLE ERROR DETECTED - EXITING IMMEDIATELY")
                    logger.error("=" * 60)
                    logger.error(f"Error: {e}")
                    logger.error("")
                    logger.error("This appears to be a configuration/permission issue that won't be resolved by retrying.")
                    logger.error("Please check:")
                    logger.error("1. AWS credentials and permissions")
                    logger.error("2. Bedrock model ID and subscription")
                    logger.error("3. Model access in AWS Bedrock Console")
                    logger.error("=" * 60)
                    sys.exit(1)
                
                # Retryable error - increment counter
                consecutive_retryable_errors += 1
                logger.warning(f"Retryable error on row {i+1}. Consecutive retryable errors: {consecutive_retryable_errors}")
                
                if max_consecutive_retryable_errors > 0 and consecutive_retryable_errors >= max_consecutive_retryable_errors:
                    logger.error("=" * 60)
                    logger.error("TOO MANY CONSECUTIVE RETRYABLE ERRORS - EXITING")
                    logger.error("=" * 60)
                    logger.error(f"{max_consecutive_retryable_errors} consecutive rows failed with retryable errors.")
                    logger.error("This likely indicates a persistent issue (service outage, network problem).")
                    logger.error(f"Last error: {e}")
                    logger.error("=" * 60)
                    sys.exit(1)
                
                result = {
                    "verdict": "ERROR",
                    "overall": 0,
                    "scores": {"overall": 0, "accuracy": 0, "relevancy": 0, "completeness": 0, "tone": 0},
                    "rationales": {"accuracy": str(e), "relevancy": str(e), "completeness": str(e), "tone": str(e), "notes": [str(e)]}
                }
                scores = result["scores"]
                rats = result.get("rationales", {})

        # Prepare row data
        row_data = {
            "id": qid,
            "question": str(row.get("question", "")),
            "gold_answer": gold,
            "full_bot_response": full_bot_response,
            "verdict": result["verdict"],
            "overall": result["overall"],
            "accuracy": scores.get("accuracy"),
            "accuracy_rationale": rats.get("accuracy", ""),
            "relevancy": scores.get("relevancy"),
            "relevancy_rationale": rats.get("relevancy", ""),
            "completeness": scores.get("completeness"),
            "completeness_rationale": rats.get("completeness", ""),
            "tone": scores.get("tone"),
            "tone_rationale": rats.get("tone", ""),
            "notes": "; ".join(rats.get("notes", [])) if isinstance(rats.get("notes"), list) else str(rats.get("notes", "")),
        }
        
        # Debug logging for output data
        logger.debug(f"Row {i+1}: Output data prepared:")
        logger.debug(f"  ID: {row_data['id']}")
        logger.debug(f"  Verdict: {row_data['verdict']}")
        logger.debug(f"  Overall Score: {row_data['overall']}")
        logger.debug(f"  Individual Scores: accuracy={row_data['accuracy']}, relevancy={row_data['relevancy']}, completeness={row_data['completeness']}, tone={row_data['tone']}")
        logger.debug(f"  Full Bot Response Length: {len(row_data['full_bot_response'])}")
        
        rows.append(row_data)

        if args.sleep > 0:
            logger.debug(f"Sleeping for {args.sleep} seconds...")
            time.sleep(args.sleep)

    logger.info("Writing output files...")
    out_csv = f"{args.out_prefix}.csv"
    out_xlsx = f"{args.out_prefix}.xlsx"
    out_df = pd.DataFrame(rows)
    
    # Debug logging for output data
    logger.debug(f"Output data summary:")
    logger.debug(f"  Total rows processed: {len(rows)}")
    logger.debug(f"  Output columns: {list(out_df.columns)}")
    logger.debug(f"  Verdict distribution: {out_df['verdict'].value_counts().to_dict()}")
    logger.debug(f"  Average overall score: {out_df['overall'].mean():.3f}")
    logger.debug(f"  Score ranges: accuracy={out_df['accuracy'].min():.3f}-{out_df['accuracy'].max():.3f}, relevancy={out_df['relevancy'].min():.3f}-{out_df['relevancy'].max():.3f}")
    
    out_df.to_csv(out_csv, index=False, encoding="utf-8")
    
    # Write Excel with formatting
    with pd.ExcelWriter(out_xlsx, engine='openpyxl') as writer:
        out_df.to_excel(writer, index=False, sheet_name='Evaluation Results')
        
        # Get the workbook and worksheet
        workbook = writer.book
        worksheet = writer.sheets['Evaluation Results']
        
        # Apply formatting with error handling
        try:
            _format_excel_report(workbook, worksheet, out_df)
        except Exception as e:
            logger.error(f"Excel formatting failed: {e}")
            logger.info("Continuing without advanced formatting...")
    
    logger.info(f"Successfully wrote: {out_csv}")
    logger.info(f"Successfully wrote: {out_xlsx} (with formatting)")
    
    # Upload to S3 if requested
    excel_s3_url = None
    excel_download_url = None
    excel_presigned_url = None
    excel_https_url = None
    if args.upload_s3:
        logger.info(f"S3 Upload requested for: {out_xlsx}")
        upload_result = upload_to_s3(out_xlsx)
        if upload_result and isinstance(upload_result, dict):
            excel_presigned_url = upload_result.get("presigned_url")
            excel_https_url = upload_result.get("https_url")
            excel_s3_url = upload_result.get("s3_path")
            
            # Use presigned URL if available, otherwise HTTPS URL
            excel_download_url = excel_presigned_url or excel_https_url
            
            logger.info("FINAL RESULT: Excel file uploaded to S3 successfully")
            logger.info("Download URLs are available in the JSON file (artifact or S3)")
        elif upload_result:
            # Backward compatibility: if it returns a string (old format)
            excel_download_url = upload_result
            logger.info("FINAL RESULT: Excel file uploaded to S3 successfully")
            logger.info("Download URLs are available in the JSON file (artifact or S3)")
        else:
            logger.error("S3 upload failed. Check the error messages above.")
    else:
        logger.info("To upload results to S3, use: --upload-s3")
    
    # Generate JSON summary if requested
    json_path = None
    json_s3_url = None
    json_download_url = None
    if args.generate_json or args.check_threshold:
        json_path = generate_json_summary(
            out_df, 
            args.out_prefix,
            test_type=args.test_type,
            threshold=args.threshold,
            excel_s3_url=excel_s3_url,
            excel_download_url=excel_download_url,
            excel_presigned_url=excel_presigned_url,
            excel_https_url=excel_https_url,
            logger=logger
        )
        
        # Upload JSON to S3 if requested
        if json_path and args.upload_s3:
            logger.info(f"S3 Upload requested for: {json_path}")
            json_upload_result = upload_to_s3(json_path)
            if json_upload_result and isinstance(json_upload_result, dict):
                json_presigned_url = json_upload_result.get("presigned_url")
                json_https_url = json_upload_result.get("https_url")
                json_s3_url = json_upload_result.get("s3_path")
                json_download_url = json_presigned_url or json_https_url
                logger.info("JSON file uploaded to S3 successfully")
                logger.info("Download URLs are available in the JSON file (artifact or S3)")
            elif json_upload_result:
                # Backward compatibility
                json_download_url = json_upload_result
                logger.info("JSON file uploaded to S3 successfully")
                logger.info("Download URLs are available in the JSON file (artifact or S3)")
            else:
                logger.warning("JSON S3 upload failed, but JSON file was generated locally.")
    
    # Check threshold and exit with appropriate code
    exit_code = 0
    if args.check_threshold:
        passed, metrics = check_pass_threshold(out_df, args.threshold, logger)
        
        logger.info("="*60)
        logger.info("THRESHOLD CHECK RESULTS")
        logger.info("="*60)
        logger.info(f"Average Overall Score: {metrics['average_overall_score']:.3f} / 5.0")
        logger.info(f"Threshold Required: {metrics['threshold_score']:.3f} / 5.0 ({metrics['threshold_percentage']:.1f}%)")
        logger.info(f"Pass Rate: {metrics['pass_rate_percentage']:.1f}%")
        logger.info(f"Verdict Distribution: PASS={metrics['verdict_counts']['PASS']}, "
                   f"REVIEW={metrics['verdict_counts']['REVIEW']}, "
                   f"FAIL={metrics['verdict_counts']['FAIL']}, "
                   f"ERROR={metrics['verdict_counts']['ERROR']}")
        
        if passed:
            logger.info("TEST PASSED: Average score meets threshold")
            exit_code = 0
        else:
            logger.error("TEST FAILED: Average score below threshold")
            logger.error(f"   Required: {metrics['threshold_score']:.3f}, Got: {metrics['average_overall_score']:.3f}")
            exit_code = 1
        
        logger.info("="*60)
    
    logger.info("="*60)
    logger.info("LLM JUDGE EVALUATION COMPLETED")
    logger.info("="*60)
    
    return exit_code


if __name__ == "__main__":
    sys.exit(main())

