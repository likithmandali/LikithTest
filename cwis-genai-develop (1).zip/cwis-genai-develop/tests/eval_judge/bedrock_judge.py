import os, json, time, hashlib
import logging
from typing import Dict, Any
import boto3
from botocore.exceptions import ClientError

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
BEDROCK_JUDGE_MODEL_ID = os.getenv("BEDROCK_JUDGE_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0")
CACHE_PATH = os.getenv("JUDGE_CACHE", ".judge_cache.json")

ANTHROPIC_VERSION = "bedrock-2023-05-31"
MAX_TOKENS = 1024
TEMPERATURE = 0

JUDGE_SYSTEM = """
You are an expert evaluator comparing a GOLD reference answer against a CANDIDATE response in response to a specific QUESTION.

**IMPORTANT**: The CANDIDATE may include sections like REASONING, REFERENCES, or other supporting content. 
Focus your evaluation primarily on the main answer content, but you may consider supporting information when it helps assess accuracy or completeness.

The GOLD answer is the authoritative reference - use it as the primary standard for factual accuracy.
Evaluate four dimensions with detailed rationales, then provide an overall assessment.

## EVALUATION DIMENSIONS

**ACCURACY (0-5)**
- 5: All factual claims match gold; no contradictions or errors
- 4: Mostly accurate with 1-2 minor factual variations that don't change meaning
- 3: Generally accurate but contains some inacurate information or unclear statements
- 2: Several factual errors or contradictions that affect reliability
- 1: Major factual errors or contradictions that undermine the response
- 0: Completely inaccurate, harmful, or directly contradicts gold answer

**RELEVANCY (0-5)**
- 5: Directly addresses the specific question asked with focused, on-topic content
- 4: Mostly addresses the question with minimal tangential information
- 3: Generally addresses the question but includes some off-topic details
- 2: Partially addresses the question but misses key aspects or includes irrelevant content
- 1: Poorly addresses the question or misunderstands what was asked
- 0: Completely fails to address the question or answers a different question entirely

**COMPLETENESS (0-5)**
- 5: Covers all essential points from gold answer comprehensively
- 4: Covers most essential points with only minor omissions
- 3: Covers key points but missing some important details or requirements
- 2: Covers basic points but missing several important elements
- 1: Covers few essential points; significant gaps in coverage
- 0: Fails to address essential requirements or provides incomplete response

**TONE (0-5)**
- 5: Professional, clear, appropriate, and well-structured
- 4: Generally professional with minor style or clarity issues
- 3: Acceptable tone but may be unclear, overly casual, or poorly structured
- 2: Somewhat unprofessional, confusing, or inappropriate for context
- 1: Unprofessional, rude, or significantly inappropriate
- 0: Hostile, offensive, or completely inappropriate

## OVERALL SCORING LOGIC

1. Calculate base score: (accuracy + relevancy + completeness + tone) / 4
2. Record the actual calculated overall score
3. Apply quality gates to determine verdict:
   - If ANY dimension ≤ 1: VERDICT = FAIL (regardless of overall score)
   - If ANY dimension = 2: VERDICT = REVIEW (regardless of overall score)
   - If ALL dimensions ≥ 3: Use normal verdict thresholds

## VERDICT THRESHOLDS (when no quality gates triggered)

- **PASS** (≥ 3.0): High quality response meeting standards
- **REVIEW** (2.0-2.9): Acceptable but needs improvement or verification
- **FAIL** (< 2.0): Significant issues requiring major revision

## QUALITY GATE RULES

- **Any dimension ≤ 1**: VERDICT = FAIL (overall score remains actual)
- **Any dimension = 2**: VERDICT = REVIEW (overall score remains actual)
- **All dimensions ≥ 3**: Use normal verdict thresholds based on overall score

## EVALUATION GUIDELINES

- **Primary Authority**: The GOLD answer is the authoritative reference for factual accuracy
- **Question Context**: Use the QUESTION to understand what was being asked and assess relevancy
- **Focus on Main Answer**: Evaluate primarily the core answer content, not the quality of reasoning or references
- **Supporting Content**: Consider REASONING/REFERENCES only when they help assess factual accuracy or completeness
- **Substance Over Style**: Focus on meaning over exact wording unless clarity is significantly impacted
- **Phrasing Flexibility**: Accept different phrasing that conveys the same core meaning as the gold answer
- **Question Alignment**: Ensure the main answer addresses what was actually asked in the question
- **Missing vs. Wrong**: Distinguish between incomplete information and incorrect information
- **Domain Neutrality**: Don't make judgments based on domain knowledge not present in the gold answer
- **Section Awareness**: If the candidate has clear sections (RESPONSE:, REASONING:, etc.), focus evaluation on the main answer section
- **Specific Examples**: Provide concrete examples from the text to support rationales

## OUTPUT FORMAT

Return ONLY valid JSON:
{
"scores": {
"accuracy": 0,
"relevancy": 0,
"completeness": 0,
"tone": 0
},
"overall": 0,
"verdict": "PASS" | "REVIEW" | "FAIL",
"rationales": {
"accuracy": "Specific explanation with examples from text",
"relevancy": "Specific explanation of on-topic vs off-topic elements", 
"completeness": "Specific gaps or coverage assessment",
"tone": "Assessment of professionalism and clarity",
"notes": ["Additional context or edge case considerations"]
}
}
""".strip()

def is_non_retryable_error(error: Exception) -> bool:
    """
    Check if an error is non-retryable (permission/credential/config issues).
    Returns True if error indicates a configuration/permission problem that won't be fixed by retrying.
    """
    error_str = str(error).lower()
    error_type = type(error).__name__
    
    # Non-retryable error indicators
    non_retryable_indicators = [
        "accessdeniedexception",
        "unauthorizedoperation",
        "not authorized",
        "aws marketplace",
        "marketplace:viewsubscriptions",
        "marketplace:subscribe",
        "model access is denied",
        "invalid model",
        "model not found",
        "authentication failed",
        "invalid credentials",
        "unauthorized",
        "401",  # HTTP 401 Unauthorized
        "403",  # HTTP 403 Forbidden
        "invalid model id",
        "model id",
    ]
    
    # Check error message
    for indicator in non_retryable_indicators:
        if indicator in error_str:
            return True
    
    # Check error type
    if error_type in ["AccessDeniedException", "UnauthorizedOperation", "ClientError"]:
        if isinstance(error, ClientError):
            error_code = error.response.get("Error", {}).get("Code", "")
            if error_code in ["AccessDeniedException", "UnauthorizedOperation", "ValidationException"]:
                return True
    
    # Check for HTTP auth errors
    if hasattr(error, "response") and hasattr(error.response, "status_code"):
        if error.response.status_code in [401, 403]:
            return True
    
    return False

def _get_bedrock_client():
    """Get Bedrock client with explicit credentials from environment variables.
    
    This ensures that credentials from AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY
    environment variables are used, rather than relying on boto3's default credential chain
    which might pick up other credential sources.
    """
    logger = logging.getLogger(__name__)
    aws_access_key = os.getenv("AWS_ACCESS_KEY_ID")
    aws_secret_key = os.getenv("AWS_SECRET_ACCESS_KEY")
    
    if aws_access_key and aws_secret_key:
        logger.debug("Using explicit credentials from environment variables")
        return boto3.client(
            "bedrock-runtime",
            region_name=AWS_REGION,
            aws_access_key_id=aws_access_key,
            aws_secret_access_key=aws_secret_key
        )
    else:
        logger.warning("Falling back to default credential chain - AWS_ACCESS_KEY_ID or AWS_SECRET_ACCESS_KEY not set")
        return boto3.client("bedrock-runtime", region_name=AWS_REGION)

def _load_cache(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_cache(path: str, obj: Dict[str, Any]) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

def _cache_key(gold: str, cand: str, model_id: str, question: str = "", rubric_version: str="v3") -> str:
    h = hashlib.sha256()
    for part in (model_id, rubric_version, "G", gold, "C", cand, "Q", question):
        h.update(part.encode("utf-8"))
        h.update(b"|")
    return h.hexdigest()

def _anthropic_messages_payload(system: str, user_text: str) -> dict:
    return {
        "anthropic_version": ANTHROPIC_VERSION,
        "max_tokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
        "system": system,
        "messages": [
            { "role": "user", "content": [ { "type": "text", "text": user_text } ] }
        ]
    }

def _parse_text_response(resp_body: bytes) -> str:
    payload = json.loads(resp_body)
    content = payload.get("content", [])
    if content and isinstance(content, list):
        block = content[0]
        if isinstance(block, dict) and block.get("type") == "text":
            return block.get("text", "")
    return json.dumps(payload, ensure_ascii=False)

def _strip_markdown_code_block(text: str) -> str:
    """Remove markdown code block markers (```json ... ```) from text."""
    if not text:
        return text
    
    text = text.strip()
    
    # Remove leading ```json or ``` (case-insensitive, with optional newline)
    if text.lower().startswith("```json"):
        # Remove "```json" and any following whitespace/newline
        text = text[7:].lstrip()
    elif text.startswith("```"):
        # Remove "```" and any following whitespace/newline
        text = text[3:].lstrip()
    
    # Remove trailing ``` (with optional preceding newline)
    text = text.rstrip()
    if text.endswith("```"):
        text = text[:-3].rstrip()
    
    return text

def judge_pair_bedrock(gold: str, candidate: str, question: str = "",
                      retries: int = 3,
                      backoff_s: float = 1.5,
                      use_cache: bool = True) -> Dict[str, Any]:
    logger = logging.getLogger(__name__)
    logger.debug(f"Starting Bedrock evaluation - Gold length: {len(gold)}, Candidate length: {len(candidate)}")
    
    ck = _cache_key(gold, candidate, BEDROCK_JUDGE_MODEL_ID, question)
    logger.debug(f"Cache key: {ck}")

    cache = _load_cache(CACHE_PATH) if use_cache else {}
    if use_cache and ck in cache:
        logger.info("Found cached result, returning without API call")
        return cache[ck]

    logger.info("No cached result found, calling Bedrock API")

    # Include question if provided
    if question and question.strip():
        user_prompt = f"""QUESTION:

{question}

GOLD:

{gold}

CANDIDATE:
{candidate}
"""
    else:
        user_prompt = f"""GOLD:

{gold}

CANDIDATE:
{candidate}
"""

    last_err = None
    for attempt in range(retries):
        try:
            logger.debug(f"Bedrock API attempt {attempt + 1}/{retries}")
            body = _anthropic_messages_payload(JUDGE_SYSTEM, user_prompt)
            # Get Bedrock client with explicit credentials from environment
            bedrock_client = _get_bedrock_client()
            resp = bedrock_client.invoke_model(
                modelId=BEDROCK_JUDGE_MODEL_ID,
                body=json.dumps(body).encode("utf-8"),
                accept="application/json",
                contentType="application/json",
            )
            resp_body_bytes = resp["body"].read()
            if not resp_body_bytes:
                raise ValueError("Bedrock API returned empty response body")
            
            text = _parse_text_response(resp_body_bytes)
            logger.debug(f"Received response from Bedrock (length: {len(text)})")
            
            # Log first 500 chars of response for debugging if JSON parsing fails
            if not text or not text.strip():
                logger.error(f"Bedrock returned empty text response. Response body (first 500 chars): {resp_body_bytes[:500]}")
                raise ValueError("Bedrock API returned empty text response")
            
            # Strip markdown code block markers if present
            text = _strip_markdown_code_block(text)
            
            try:
                data = json.loads(text)
            except json.JSONDecodeError as json_err:
                logger.error(f"Failed to parse Bedrock response as JSON. Response text (first 1000 chars): {text[:1000]}")
                logger.error(f"JSON decode error: {json_err}")
                raise ValueError(f"Bedrock API returned invalid JSON: {json_err}")
            if not isinstance(data, dict) or "scores" not in data or "overall" not in data or "verdict" not in data:
                logger.error("Judge returned invalid JSON structure")
                raise ValueError("Judge returned invalid JSON structure.")
            
            logger.info(f"Bedrock evaluation successful - Verdict: {data.get('verdict')}, Overall: {data.get('scores', {}).get('overall')}")
            
            if use_cache:
                cache[ck] = data
                _save_cache(CACHE_PATH, cache)
                logger.debug("Result cached successfully")
            return data
        except Exception as e:
            last_err = e
            logger.warning(f"Bedrock API attempt {attempt + 1} failed: {e}")
            if attempt < retries - 1:
                logger.debug(f"Retrying in {backoff_s} seconds...")
                time.sleep(backoff_s)
    
    logger.error(f"Bedrock judge failed after {retries} attempts: {last_err}")
    
    # Check if this is a non-retryable error (permission/config issue)
    if is_non_retryable_error(last_err):
        raise RuntimeError(f"Bedrock judge failed with non-retryable error after retries: {last_err}")
    
    raise RuntimeError(f"Bedrock judge failed after retries: {last_err}")

