#!/usr/bin/env python3
"""
Lightweight GenAI bot health-check.

Reuses the BOT_AUTH_URL / BOT_URL token flow from run_from_excel_bedrock.py
but only sends a small fixed payload and exits non-zero on failure.

Required env vars (same as the existing test runner):
  BOT_AUTH_URL, BOT_URL, BOT_USERNAME, BOT_PASSWORD
  (plus optional BOT_AUTH_METHOD, BOT_TOKEN_KEY, BOT_INSTANCE_ID,
   BOT_MODEL_ARN, BOT_INCLUDE_REFERENCES, BOT_RENDER_MARKDOWN,
   BOT_GUARDRAILS_ID)

Exit codes:
  0 - healthy
  1 - unhealthy (auth or bot call failed)
"""

import os
import sys
import time
import json
import requests
import logging

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _setup_logging() -> logging.Logger:
    fmt = "%(asctime)s | %(levelname)-8s | %(message)s"
    logging.basicConfig(format=fmt, datefmt="%Y-%m-%d %H:%M:%S", level=logging.INFO,
                        stream=sys.stdout)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    return logging.getLogger("healthcheck")

# ---------------------------------------------------------------------------
# Auth (mirrors run_from_excel_bedrock.get_auth_token but without caching)
# ---------------------------------------------------------------------------

def _get_auth_token(logger: logging.Logger) -> str:
    auth_url = os.getenv("BOT_AUTH_URL", "").strip()
    if not auth_url:
        raise RuntimeError("BOT_AUTH_URL is not set.")

    auth_method = os.getenv("BOT_AUTH_METHOD", "username_password").lower()
    if auth_method == "username_password":
        auth_payload = {
            "username": os.getenv("BOT_USERNAME", ""),
            "password": os.getenv("BOT_PASSWORD", ""),
        }
    elif auth_method == "api_key":
        auth_payload = {"api_key": os.getenv("BOT_API_KEY", "")}
    else:
        raise RuntimeError(f"Unsupported auth method: {auth_method}")

    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    logger.info("Authenticating against %s", auth_url)
    resp = requests.post(auth_url, headers=headers, data=auth_payload,
                         timeout=30)
    resp.raise_for_status()
    data = resp.json()

    token_key = os.getenv("BOT_TOKEN_KEY", "access_token")
    if token_key not in data:
        raise RuntimeError(f"Auth response missing key '{token_key}': {list(data.keys())}")

    return str(data[token_key]).strip()

# ---------------------------------------------------------------------------
# Health-check call
# ---------------------------------------------------------------------------

HEALTHCHECK_QUESTION = "Hello"

def _call_bot(token: str, logger: logging.Logger) -> str:
    """Send a minimal question to the bot endpoint and return the response."""
    url = os.getenv("BOT_URL", "").strip()
    if not url:
        raise RuntimeError("BOT_URL is not set.")

    instance_id = os.getenv("BOT_INSTANCE_ID", "1")
    model_arn = (os.getenv("BOT_MODEL_ARN", "").strip()
                 or os.getenv("BOT_MODEL_NAME", "us.anthropic.claude-sonnet-4-20250514-v1:0"))

    payload = {
        "instance_id": instance_id,
        "model": model_arn,
        "input_text": HEALTHCHECK_QUESTION,
        "additional_json_context": {},
        "include_references": os.getenv("BOT_INCLUDE_REFERENCES", "false").lower() == "true",
        "render_markdown": os.getenv("BOT_RENDER_MARKDOWN", "false").lower() == "true",
    }

    guardrails_id = os.getenv("BOT_GUARDRAILS_ID", "").strip()
    if guardrails_id:
        payload["guardrails_id"] = guardrails_id

    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        "Authorization": f"Bearer {token}",
    }

    logger.info("Calling bot endpoint %s", url)

    # Retry once for transient network errors (connection reset, timeout)
    max_attempts = 2
    last_exc: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            resp = requests.post(url, headers=headers, json=payload,
                                 timeout=30)

            if resp.status_code == 401:
                raise RuntimeError("Authentication failed (401) — token may have expired or credentials are wrong.")

            resp.raise_for_status()

            body = (resp.text or "").strip()
            if not body:
                raise RuntimeError("Bot returned an empty response.")

            return body

        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            last_exc = exc
            if attempt < max_attempts:
                logger.warning("Attempt %d/%d failed (%s) — retrying in 3s…",
                               attempt, max_attempts, exc)
                time.sleep(3)
            else:
                raise RuntimeError(
                    f"Bot unreachable after {max_attempts} attempts: {exc}"
                ) from exc

    # Should never be reached, but satisfy type-checkers
    raise RuntimeError(f"Unexpected retry exit: {last_exc}")

# ---------------------------------------------------------------------------
# GitHub Actions job summary helper
# ---------------------------------------------------------------------------

def _write_summary(success: bool, duration_s: float, detail: str = "") -> None:
    """Append a concise Markdown summary to $GITHUB_STEP_SUMMARY if available."""
    summary_path = os.getenv("GITHUB_STEP_SUMMARY")
    if not summary_path:
        return
    status = "Healthy" if success else "Unhealthy"
    icon = "[PASS]" if success else "[FAIL]"
    lines = [
        f"## {icon} GenAI Health-Check: {status}",
        "",
        f"| Metric | Value |",
        f"|--------|-------|",
        f"| Status | **{status}** |",
        f"| Duration | {duration_s:.1f}s |",
        f"| Environment | `{os.getenv('SELECTED_ENV', 'unknown')}` |",
        f"| Bot URL | `{os.getenv('BOT_URL', 'N/A')}` |",
        f"| Timestamp | {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())} |",
    ]
    if detail:
        lines.extend(["", f"**Detail:** {detail}"])
    try:
        with open(summary_path, "a") as fh:
            fh.write("\n".join(lines) + "\n")
    except OSError:
        pass

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    logger = _setup_logging()
    start = time.time()

    try:
        token = _get_auth_token(logger)
        body = _call_bot(token, logger)
        duration = time.time() - start
        logger.info("Health-check PASSED (%.1fs). Response length: %d chars", duration, len(body))
        _write_summary(True, duration, f"Response length: {len(body)} chars")
        return 0
    except Exception as exc:
        duration = time.time() - start
        logger.error("Health-check FAILED (%.1fs): %s", duration, exc)
        _write_summary(False, duration, str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
