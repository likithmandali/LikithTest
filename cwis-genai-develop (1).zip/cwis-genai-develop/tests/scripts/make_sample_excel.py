import os
import pandas as pd

os.makedirs("data", exist_ok=True)

rows = [
    {
        "id": "age-pass-1",
        "question": "What is the minimum age requirement for applicants?",
        "gold_answer": "Applicants must be at least 18 years old.",
        "candidate": "You must be 18 or older to qualify.",
        "expected_verdict": "PASS",  # Optional: for smoke tests with known outcomes
    },
    {
        "id": "age-fail-1",
        "question": "What is the minimum age requirement for applicants?",
        "gold_answer": "Applicants must be at least 18 years old.",
        "candidate": "Appddsalicants must be 21 or older.",
        "expected_verdict": "FAIL",  # Optional: for smoke tests with known outcomes
    },
    {
        "id": "cps-pass-1",
        "question": "How often should children and families be seen?",
        "gold_answer": "Children and families must be seen at least two times per month.",
        "candidate": "Ensure at least two visits per month for children and families.",
        "expected_verdict": "PASS",  # Optional: for smoke tests with known outcomes
    },
    {
        "id": "dynamic-1",
        "question": "Kinship vs TSP",
        "gold_answer": "A Temporary Safety Provider is a person chosen by the parent to provide caretaking responsibilities while they address safety without court involvement. It is used as an intervention in diligent efforts to prevent removal. A Kinship Provider is a person chosen by the parent after their child(ren) has been removed from their custody and must be sanctioned by a judge.",
        # No candidate - will be fetched via REST API
        # No expected_verdict - will be determined by LLM judge
    },
]

df = pd.DataFrame(rows)
df.to_excel("data/smoke.xlsx", index=False)
print("Wrote data/smoke.xlsx")

