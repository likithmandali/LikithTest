aws_region = "us-east-1"

lambda_functions = {
  dhhs-pathnc-p-knowledgebasecreate-prod = {
    function_name  = "dhhs-pathnc-p-knowledgebasecreate-prod"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./lambda-KnowledgeBaseUpdate_payload.zip"
    source_dir     = "../../../app/lambda/knowledge-base-update"                      # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::248189913074:role/dhhs-pathnc-p-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN      = "arn:aws:iam::248189913074:role/dhhs-pathnc-p-genai-sa-role"
      AWS_EMBEDDING_MODEL_NAME                    = "amazon.titan-embed-text-v2:0"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:248189913074:collection/dzkyjkh40lzvgf2y3rvf"
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-pathnc-p-genai-prod-index"
      AWS_PARSING_FOUNDATION_MODEL                = "anthropic.claude-3-5-sonnet-20240620-v1:0"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "pathnc-p-s3-genai-data-bucket-prod"
    }
    application_name = "KnowledgeBaseUpdate"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "prod"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebasecreate-prod"
      stack                  = "dhhs-pathnc-p"
    }
  }
  dhhs-pathnc-p-knowledgebaseupdate-prod = {
    function_name  = "dhhs-pathnc-p-knowledgebaseupdate-prod"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./UpdateExistingKnowledge_payload.zip"
    source_dir     = "../../../app/lambda/update-existing-knowledge/"                 # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::248189913074:role/dhhs-pathnc-p-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-pathnc-p-genai-prod-index"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:248189913074:collection/dzkyjkh40lzvgf2y3rvf"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "pathnc-p-s3-genai-data-bucket-prod"
    }
    application_name = "UpdateExistingKnowledge"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "prod"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-pathnc-p-knowledgebaseupdate-prod"
      stack                  = "dhhs-pathnc-p"
    }
  }
}  