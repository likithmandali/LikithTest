aws_region = "us-east-1"

# DB Subnet Groups (Define these first as they are prerequisites)
db_subnet_groups = {
  pathnc-p-db-genai-subnet-group-prod = {
    description = "This subnet group belongs to pathnc-p-db-genai"
    name        = "pathnc-p-db-genai-subnet-group-prod"
    subnet_ids  = ["subnet-06bd76e32b28f9963", "subnet-0d6b794b3583d07c0"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "prod"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-p-db-genai-subnet-group-prod"
      stack                  = "dhhs-pathnc-p"
    }
  }
}

# RDS Clusters (Define these after subnet groups)
rds_clusters = {
  pathnc-db-genai-cluster-prod = {
    allocated_storage                   = "1"
    availability_zones                  = ["us-east-1b", "us-east-1c"]
    backtrack_window                    = "0"
    backup_retention_period             = "7"
    cluster_identifier                  = "pathnc-db-genai-cluster-prod"
    cluster_members                     = ["pathnc-db-genai-db-prod-instance1"]
    copy_tags_to_snapshot               = false
    database_name                       = "pathncpgenaieprod"
    db_cluster_parameter_group_name     = "default.aurora-postgresql14"
    db_subnet_group_name                = "pathnc-p-db-genai-subnet-group-prod"
    deletion_protection                 = false
    enable_http_endpoint                = false
    enabled_cloudwatch_logs_exports     = ["postgresql"]
    engine                              = "aurora-postgresql"
    engine_mode                         = "provisioned"
    engine_version                      = "14.15"
    iam_database_authentication_enabled = true
    iops                                = "0"
    kms_key_id                          = "arn:aws:kms:us-east-1:248189913074:key/e44f99a1-e02e-4a29-ad42-e9c6be15a8a6"
    master_username                     = "clusterdmin"
    network_type                        = "IPV4"
    port                                = "5432"
    preferred_backup_window             = "04:30-05:00"
    preferred_maintenance_window        = "sun:06:20-sun:06:50"
    storage_encrypted                   = true
    skip_final_snapshot                 = true
    vpc_security_group_ids              = ["sg-06ac16d45f34d5047", "sg-0e2871f11f94d46bb"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "prod"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-cluster-prod"
      stack                  = "dhhs-pathnc-p"
    }
  }
}

# RDS Cluster Instances (Define these after clusters)
rds_cluster_instances = {
  pathnc-db-genai-db-prod-instance1 = {
    identifier         = "pathnc-db-genai-db-prod-instance1"
    cluster_identifier = "pathnc-db-genai-cluster-prod"
    instance_class     = "db.r5.large"
    engine             = "aurora-postgresql"
    engine_version     = "14.15"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "prod"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-db-prod-instance1"
      stack                  = "dhhs-pathnc-p"
    }
  }
}

# Empty DB instances block (if needed for future use)
db_instances = {}