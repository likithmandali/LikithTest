aws_region = "us-east-1"

# Encryption Policy (required first)
encryption_policies = {
  dhhs-pathnc-p-genai-encrypt-pol = {
    name        = "dhhs-pathnc-p-genai-encrypt-pol"
    description = "Encryption policy for DHHS CWIS pathnc-p GenAI collection for prod"
    type        = "encryption"
    policy = {
      rules = [
        {
          resource_type = "collection"
          resource      = ["collection/dhhs-pathnc-p-genai-collection"]
        }
      ]
    }
  }
}

# Network Policy
network_policies = {
  dhhs-pathnc-p-genai-network-pol = {
    name        = "dhhs-pathnc-p-genai-network-pol"
    description = "Network policy for DHHS CWIS pathnc-p GenAI collection with private and public access for prod"
    type        = "network"
    policy = [
      {
        description = "Private access for AWS services and OpenSearch endpoints"
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-pathnc-p-genai-collection"]
          },
        ]
        source_vpcs = []
        source_vpc_endpoints = [
          "bedrock.amazonaws.com",
          "application.opensearchservice.amazonaws.com",
          "directquery.opensearchservice.amazonaws.com"
        ]
        access_type = "private"
      },
      {
        description = "Public access for OpenSearch Dashboards"
        rules = [
          {
            resource_type = "dashboard"
            resource      = ["collection/dhhs-pathnc-p-genai-collection"]
          }
        ]
        source_vpcs          = []
        source_vpc_endpoints = []
        access_type          = "public"
      }
    ]
  }
}

# OpenSearch Collection
opensearch_collections = {
  dhhs-pathnc-p-genai-collection = {
    name        = "dhhs-pathnc-p-genai-collection"
    description = "DHHS CWIS pathnc-p GenAI OpenSearch Serverless collection for prod"
    type        = "VECTORSEARCH"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "prod"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-pathnc-p-genai-collection"
      stack                  = "dhhs-pathnc-p"
    }
  }
}

# Data Access Policy
data_access_policies = {
  dhhs-pathnc-p-genai-data-pol = {
    name        = "dhhs-pathnc-p-genai-data-pol"
    description = "Data access policy for DHHS CWIS pathnc-p GenAI collection for prod"
    type        = "data"
    policy = [
      {
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-pathnc-p-genai-collection"]
            permission = [
              "aoss:CreateCollectionItems",
              "aoss:DeleteCollectionItems",
              "aoss:UpdateCollectionItems",
              "aoss:DescribeCollectionItems"
            ]
          },
          {
            resource_type = "index"
            resource      = ["index/dhhs-pathnc-p-genai-collection/*"]
            permission = [
              "aoss:CreateIndex",
              "aoss:DeleteIndex",
              "aoss:UpdateIndex",
              "aoss:DescribeIndex",
              "aoss:ReadDocument",
              "aoss:WriteDocument"
            ]
          }
        ]
        principal = ["arn:aws:iam::248189913074:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_c-dhhs-ncfast-pathnc-p-devops_e3755ed1ba015a3a"]
      }
    ]
  }
}
