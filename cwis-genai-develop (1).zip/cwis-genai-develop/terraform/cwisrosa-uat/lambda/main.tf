terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">=6.23.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

module "lambda_function" {
  source = "../../modules/lambda"

  lambda_functions = var.lambda_functions
}