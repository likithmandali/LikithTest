aws_region = "us-east-1"

# DB Subnet Groups (Define these first as they are prerequisites)
db_subnet_groups = {
  cwisrosa-d-db-genai-subnet-group-perf = {
    description = "This subnet group belongs to cwisrosa-d-db-genai"
    name        = "cwisrosa-d-db-genai-subnet-group-perf"
    subnet_ids  = ["subnet-0556d667c5777472f", "subnet-0abd16407a990e51c"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "perf"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "cwisrosa-d-db-genai-subnet-group-perf"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
}

# RDS Clusters (Define these after subnet groups)
rds_clusters = {
  pathnc-db-genai-cluster-perf = {
    allocated_storage                   = "1"
    availability_zones                  = ["us-east-1b", "us-east-1c"]
    backtrack_window                    = "0"
    backup_retention_period             = "7"
    cluster_identifier                  = "pathnc-db-genai-cluster-perf"
    cluster_members                     = ["pathnc-db-genai-db-perf-instance1"]
    copy_tags_to_snapshot               = false
    database_name                       = "cwisrosagenaieperf"
    db_cluster_parameter_group_name     = "default.aurora-postgresql14"
    db_subnet_group_name                = "cwisrosa-d-db-genai-subnet-group-perf"
    deletion_protection                 = false
    enable_http_endpoint                = false
    enabled_cloudwatch_logs_exports     = ["postgresql"]
    engine                              = "aurora-postgresql"
    engine_mode                         = "provisioned"
    engine_version                      = "14.15"
    iam_database_authentication_enabled = true
    iops                                = "0"
    kms_key_id                          = "arn:aws:kms:us-east-1:637423651937:key/20e4d036-ef91-4293-bc1c-6172bb94c368"
    master_username                     = "clusterdmin"
    network_type                        = "IPV4"
    port                                = "5432"
    preferred_backup_window             = "04:30-05:00"
    preferred_maintenance_window        = "sun:06:20-sun:06:50"
    storage_encrypted                   = true
    skip_final_snapshot                 = true
    vpc_security_group_ids              = ["sg-03659dbccc1f21d7b", "sg-0f0afa8748a989def"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "perf"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-cluster-perf"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
}

# RDS Cluster Instances (Define these after clusters)
rds_cluster_instances = {
  pathnc-db-genai-db-perf-instance1 = {
    identifier         = "pathnc-db-genai-db-perf-instance1"
    cluster_identifier = "pathnc-db-genai-cluster-perf"
    instance_class     = "db.r5.large"
    engine             = "aurora-postgresql"
    engine_version     = "14.15"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "perf"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-db-perf-instance1"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
}

# Empty DB instances block (if needed for future use)
db_instances = {}