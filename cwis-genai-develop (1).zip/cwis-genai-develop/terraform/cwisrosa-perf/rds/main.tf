provider "aws" {
    region  = var.aws_region
}

module "rds_clusters" {
    source = "../../modules/aws_rds"

    rds_clusters            = var.rds_clusters
    rds_cluster_instances   = var.rds_cluster_instances
    db_instances            = var.db_instances
    db_subnet_groups        = var.db_subnet_groups
}
