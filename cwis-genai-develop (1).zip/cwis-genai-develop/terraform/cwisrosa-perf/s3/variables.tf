variable "aws_region" {
    type = string
    default = "us-east-1"
}

variable "s3_buckets" {
    description = "Map of S3 buckets to create"

    type = map(object({
        bucket_name                             = string
        acl                                     = string
        force_destroy                           = bool
        bucket_key_enabled                      = bool
        encryption_algorithm                    = string
        enable_versioning                       = string
        mfa_delete                              = string
        expiration_days                         = number
        noncurrent_version_days                 = number
        noncurrent_version_storage_class        = string
        noncurrent_version_expiration_days      = number
        transition_days                         = number
        transition_storage_class                = string
        enable_second_transition                = bool
        second_transition_days                  = number
        second_transition_storage_class         = string
        expired_object_delete_marker            = bool
        abort_incomplete_multipart_upload_days  = number
        request_payer                           = string
        object_lock_enabled                     = bool
        tags                                    = map(string)
        policy                                  = string
    })) 
}

variable "common_tags" {
    description = "Common tags applied to all S3 buckets"
    type        = map(string)
    default     = {
        Account = "cwisrosa-d"
    }
}