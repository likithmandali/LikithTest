aws_region = "us-east-1"

lambda_functions = {
  dhhs-cwisrosa-d-knowledgebasecreate-perf = {
    function_name  = "dhhs-cwisrosa-d-knowledgebasecreate-perf"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./lambda-KnowledgeBaseUpdate_payload.zip"
    source_dir     = "../../../app/lambda/knowledge-base-update"                        # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN      = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-sa-role"
      AWS_EMBEDDING_MODEL_NAME                    = "amazon.titan-embed-text-v2:0"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:637423651937:collection/6vamv4pxm42s2gj2qqyh"
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-cwis-genai-perf-index"
      AWS_PARSING_FOUNDATION_MODEL                = "anthropic.claude-3-5-sonnet-20240620-v1:0"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "cwisrosa-d-s3-genai-data-bucket-perf"
    }
    application_name = "KnowledgeBaseUpdate"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "perf"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebasecreate-perf"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
  dhhs-cwisrosa-d-knowledgebaseupdate-perf = {
    function_name  = "dhhs-cwisrosa-d-knowledgebaseupdate-perf"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./UpdateExistingKnowledge_payload.zip"
    source_dir     = "../../../app/lambda/update-existing-knowledge/"                   # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-cwis-genai-perf-index"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:637423651937:collection/6vamv4pxm42s2gj2qqyh"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "cwisrosa-d-s3-genai-data-bucket-perf"
    }
    application_name = "UpdateExistingKnowledge"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "perf"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebaseupdate-perf"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
}  