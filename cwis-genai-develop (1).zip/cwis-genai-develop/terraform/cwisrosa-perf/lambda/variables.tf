variable "aws_region" {
    type = string
    default = "us-east-1"
}

variable "lambda_functions" {
  description = "Map of Lambda function configurations"
  type = map(object({
    function_name         = string
    runtime               = string
    handler               = string
    filename              = string
    source_dir            = string
    iam_lambda_arn        = string
    environment_variables = map(string)
    application_name      = string
    tags                  = map(string)
  }))
}
