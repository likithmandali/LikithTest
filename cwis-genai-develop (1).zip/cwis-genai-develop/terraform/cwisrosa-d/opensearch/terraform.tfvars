aws_region = "us-east-1"

# Encryption Policy (required first)
encryption_policies = {
  auto-dhhs-cwisrosa-genai-coll = {
    name        = "auto-dhhs-cwisrosa-genai-coll"
    description = "Encryption policy for DHHS CWIS ROSA GenAI collection"
    type        = "encryption"
    policy = {
      rules = [
        {
          resource_type = "collection"
          resource      = ["collection/dhhs-cwisrosa-genai-coll"]
        }
      ]
    }
  }
}

# Network Policy
network_policies = {
  auto-dhhs-cwisrosa-genai-coll = {
    name        = "auto-dhhs-cwisrosa-genai-coll"
    description = "Network policy for DHHS CWIS ROSA GenAI collection with private and public access"
    type        = "network"
    policy = [
      {
        description = "Private access for AWS services and OpenSearch endpoints"
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-cwisrosa-genai-coll"]
          },
        ]
        source_vpcs = []
        source_vpc_endpoints = [
          "bedrock.amazonaws.com",
          "application.opensearchservice.amazonaws.com",
          "directquery.opensearchservice.amazonaws.com"
        ]
        access_type = "public"
      },
      {
        description = "Public access for OpenSearch Dashboards"
        rules = [
          {
            resource_type = "dashboard"
            resource      = ["collection/dhhs-cwisrosa-genai-coll"]
          }
        ]
        source_vpcs          = []
        source_vpc_endpoints = []
        access_type          = "public"
      }
    ]
  }
}

# OpenSearch Collection
opensearch_collections = {
  dhhs-cwisrosa-genai-coll = {
    name        = "dhhs-cwisrosa-genai-coll"
    description = "DHHS CWIS ROSA GenAI OpenSearch Serverless collection"
    type        = "VECTORSEARCH"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-genai-coll"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
}

# Data Access Policy
data_access_policies = {
  dhhs-cwisrosa-genai-coll-policy = {
    name        = "dhhs-cwisrosa-genai-coll-policy"
    description = "Data access policy for DHHS CWIS ROSA GenAI collection"
    type        = "data"
    policy = [
      {
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-cwisrosa-genai-coll"]
            permission = [
              "aoss:CreateCollectionItems",
              "aoss:DeleteCollectionItems",
              "aoss:UpdateCollectionItems",
              "aoss:DescribeCollectionItems"
            ]
          },
          {
            resource_type = "index"
            resource      = ["index/dhhs-cwisrosa-genai-coll/*"]
            permission = [
              "aoss:CreateIndex",
              "aoss:DeleteIndex",
              "aoss:UpdateIndex",
              "aoss:DescribeIndex",
              "aoss:ReadDocument",
              "aoss:WriteDocument"
            ]
          }
        ]
        Description = "Data access"
        principal = [ 
                      "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-sa-role",
                      "arn:aws:iam::637423651937:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_dhhs-itd-cwisrosa-devops-role_e9e2af2f3ef4e176"
                    ]
      }
    ]
  }
}
