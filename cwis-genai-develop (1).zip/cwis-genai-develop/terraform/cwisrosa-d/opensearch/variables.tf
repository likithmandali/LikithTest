variable "aws_region" {
  type    = string
  default = "us-east-1"
}

variable "opensearch_collections" {
  description = "Map of OpenSearch Serverless collections to create"
  type = map(object({
    name        = string
    description = string
    type        = string
    tags        = map(string)
  }))
}

variable "network_policies" {
  description = "Map of OpenSearch Serverless network policies"
  type = map(object({
    name        = string
    description = string
    type        = string
    policy = list(object({
      description = string
      rules = list(object({
        resource_type = string
        resource      = list(string)
      }))
      source_vpcs          = list(string)
      source_vpc_endpoints = list(string)
      access_type          = string
    }))
  }))
}

variable "data_access_policies" {
  description = "Map of OpenSearch Serverless data access policies"
  type = map(object({
    name        = string
    description = string
    type        = string
    policy = list(object({
      rules = list(object({
        resource_type = string
        resource      = list(string)
        permission    = list(string)
      }))
      principal = list(string)
    }))
  }))
}

variable "encryption_policies" {
  description = "Map of OpenSearch Serverless encryption policies"
  type = map(object({
    name        = string
    description = string
    type        = string
    policy = object({
      rules = list(object({
        resource_type = string
        resource      = list(string)
      }))
    })
  }))
}

variable "common_tags" {
  description = "Common tags applied to all OpenSearch resources"
  type        = map(string)
  default = {
    Account = "cwisrosa-d"
  }
}
