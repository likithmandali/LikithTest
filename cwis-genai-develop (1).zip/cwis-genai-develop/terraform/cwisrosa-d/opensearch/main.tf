terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">=6.23.0"
    }
  }
}

provider "aws" {
  region = "us-east-1"
}

module "opensearch_serverless" {
  source = "../../modules/aws_opensearch_serverless"

  opensearch_collections = var.opensearch_collections
  network_policies       = var.network_policies
  data_access_policies   = var.data_access_policies
  encryption_policies    = var.encryption_policies
}
