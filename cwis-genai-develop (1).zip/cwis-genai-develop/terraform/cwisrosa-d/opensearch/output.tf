output "opensearch_collections" {
  description = "OpenSearch Serverless collections created"
  value       = module.opensearch_serverless.opensearch_collections
}

output "network_policies" {
  description = "Network policies created"
  value       = module.opensearch_serverless.network_policies
}

output "encryption_policies" {
  description = "Encryption policies created"
  value       = module.opensearch_serverless.encryption_policies
}

output "data_access_policies" {
  description = "Data access policies created"
  value       = module.opensearch_serverless.data_access_policies
}
