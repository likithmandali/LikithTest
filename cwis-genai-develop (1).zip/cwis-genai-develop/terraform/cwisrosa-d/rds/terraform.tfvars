aws_region = "us-east-1"
rds_clusters = {
  pathnc-db-genai-cluster-dev = {
    allocated_storage                   = "1"
    availability_zones                  = ["us-east-1b", "us-east-1c"]
    backtrack_window                    = "0"
    backup_retention_period             = "7"
    cluster_identifier                  = "pathnc-db-genai-cluster-dev"
    cluster_members                     = ["pathnc-db-genai-db-dev"]
    copy_tags_to_snapshot               = false
    database_name                       = "cwisrosagenaiedev"
    db_cluster_parameter_group_name     = "default.aurora-postgresql14"
    db_subnet_group_name                = "cwisrosa-d-db-genai-subnet-group-dev"
    deletion_protection                 = false
    enable_http_endpoint                = false
    enabled_cloudwatch_logs_exports     = ["postgresql"]
    engine                              = "aurora-postgresql"
    engine_mode                         = "provisioned"
    engine_version                      = "14.9"
    iam_database_authentication_enabled = true
    iops                                = "0"
    kms_key_id                          = "arn:aws:kms:us-east-1:637423651937:key/20e4d036-ef91-4293-bc1c-6172bb94c368"
    master_username                     = "clusterdmin"
    network_type                        = "IPV4"
    port                                = "5432"
    preferred_backup_window             = "04:30-05:00"
    preferred_maintenance_window        = "sun:06:20-sun:06:50"
    storage_encrypted                   = true
    skip_final_snapshot                 = true
    vpc_security_group_ids              = ["sg-03659dbccc1f21d7b", "sg-0f0afa8748a989def"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-cluster-dev"
      stack                  = "pathnc-genai-d"
    }
  }
}

rds_cluster_instances = {
  pathnc-db-genai-db-dev-instance1 = {
    identifier         = "pathnc-db-genai-db-dev-instance1"
    cluster_identifier = "pathnc-db-genai-cluster-dev"
    instance_class     = "db.r5.large"
    engine             = "aurora-postgresql"
    engine_version     = "14.9"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-db-dev-instance1"
      stack                  = "pathnc-genai-d"
    }
  }
}

db_instances = {}

db_subnet_groups = {
  cwisrosa-d-postgres-db-genai-subnet-group-dev = {
    description = "This subnet group belongs to cwis-d-oracle-db"
    name        = "cwisrosa-d-postgres-db-genai-subnet-group-dev"
    subnet_ids  = ["subnet-0556d667c5777472f", "subnet-0abd16407a990e51c"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "cwisrosa-d-postgres-db-genai-subnet-group-dev"
      stack                  = "pathnc-genai-d"
    }
  }
  cwisrosa-d-db-genai-subnet-group-dev = {
    description = "This subnet group belongs to cwisrosa-d-db-genai"
    name        = "cwisrosa-d-db-genai-subnet-group-dev"
    subnet_ids  = ["subnet-0556d667c5777472f", "subnet-0abd16407a990e51c"]

    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "cwisrosa-d-db-genai-subnet-group-dev"
      stack                  = "pathnc-genai-d"
    }
  }
  default-vpc-0cadedc2dfac8c3b5 = {
    description = "Created from the RDS Management Console"
    name        = "default-vpc-0cadedc2dfac8c3b5"
    subnet_ids  = ["subnet-02f8dda45fba19edd", "subnet-0556d667c5777472f", "subnet-06f2d3c09edba360a", "subnet-073798aaa89b3a862", "subnet-07ae3068455758f1d", "subnet-09f15e29ae3e0cfbb", "subnet-0abd16407a990e51c", "subnet-0d2e51039ccd5c0fe", "subnet-0e360a0d03674ff0c", "subnet-0febcf20ba315f9f1"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "default-vpc-0cadedc2dfac8c3b5"
      stack                  = "pathnc-genai-d"
    }
  }
}
