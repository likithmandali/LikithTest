terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "5.57.0"
    }
  }
}

provider "aws" {
  region = "us-east-1"
}

module "s3_buckets" {
  source = ".//../../modules/aws_s3_bucket"

  s3_buckets = var.s3_buckets
}