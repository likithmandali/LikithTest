aws_region = "us-east-1"

lambda_functions = {
  dhhs-cwisrosa-d-knowledgebasecreate-dev = {
    function_name  = "dhhs-cwisrosa-d-knowledgebasecreate-dev"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./lambda-KnowledgeBaseUpdate_payload.zip"
    source_dir     = "../../../app/lambda/knowledge-base-update"                        # Updated path to new Lambda code location
    iam_lambda_arn = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN      = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-sa-role"
      AWS_EMBEDDING_MODEL_NAME                    = "amazon.titan-embed-text-v2:0"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:637423651937:collection/lj87olzqp8hfc6sg6t89"
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-genaie-index"
      AWS_PARSING_FOUNDATION_MODEL                = "us.anthropic.claude-sonnet-4-20250514-v1:0"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "cwisrosa-d-s3-genai-data-bucket-dev"
    }
    application_name = "KnowledgeBaseUpdate"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebasecreate-dev"
      stack                  = "dhhs-cwisrosa-d-knowledgebasecreate-dev"
    }
    ephemeral_storage     = { size = 512 }
    logging_config        = { log_format = "Text", log_group = "/aws/lambda/dhhs-cwisrosa-d-knowledgebasecreate-dev" }
    tracing_config        = { mode = "PassThrough" }
  }
  dhhs-cwisrosa-d-knowledgebaseupdate-dev = {
    function_name  = "dhhs-cwisrosa-d-knowledgebaseupdate-dev"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./UpdateExistingKnowledge_payload.zip"
    source_dir     = "../../../app/lambda/update-existing-knowledge"                    # Updated path to new Lambda code location
    iam_lambda_arn = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-genaie-index"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:637423651937:collection/lj87olzqp8hfc6sg6t89"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "cwisrosa-d-s3-genai-data-bucket-dev"
      AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN      = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-sa-role"
      AWS_EMBEDDING_MODEL_NAME                    = "amazon.titan-embed-text-v2:0"
    }
    application_name = "UpdateExistingKnowledge"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "dev"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebaseupdate-dev"
      stack                  = "dhhs-cwisrosa-d-knowledgebaseupdate-dev"
    }
    ephemeral_storage     = { size = 512 }
    logging_config        = { log_format = "Text", log_group = "/aws/lambda/dhhs-cwisrosa-d-knowledgebaseupdate-dev" }
    tracing_config        = { mode = "PassThrough" }
  }
}
