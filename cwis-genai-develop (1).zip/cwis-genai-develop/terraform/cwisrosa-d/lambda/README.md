# Lambda Terraform Configuration

This directory contains the Terraform configuration for deploying Lambda functions for the NC_path Enterprise AI Backend.

## Overview

The Lambda functions are deployed using the Lambda module from the `../../modules/lambda` directory. The Lambda code is located in the `../../../app/services/lambda` directory.

## Lambda Functions

1. **Knowledge Base Update** (`dhhs-cwisrosa-d-knowledgebasecreate-dev`)
   - Creates new AWS Bedrock Knowledge Bases and ingests documents
   - Source code: `../../../app/services/lambda/knowledge-base-update`

2. **Update Existing Knowledge** (`dhhs-cwisrosa-d-knowledgebaseupdate-dev`)
   - Updates existing Knowledge Bases with new documents
   - Source code: `../../../app/services/lambda/update-existing-knowledge`

## Deployment

To deploy the Lambda functions, run the following commands:

```bash
cd terraform/cwisrosa-d/lambda
terraform init
terraform plan
terraform apply
```

## Configuration

The Lambda functions are configured using the `terraform.tfvars` file. This file contains the following configuration:

- Function name
- Runtime
- Handler
- Source code directory
- IAM role ARN
- Environment variables
- Tags

## Environment Variables

### Knowledge Base Update Lambda

```bash
AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN=arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-sa-role
AWS_EMBEDDING_MODEL_NAME=amazon.titan-embed-text-v2:0
AWS_OPENSEARCH_COLLECTION_ARN=arn:aws:aoss:us-east-1:637423651937:collection/0tcpltvpj56pqwl9vm18
AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME=index
AWS_PARSING_FOUNDATION_MODEL=anthropic.claude-3-5-sonnet-20240620-v1:0
AWS_REGIONINFO=us-east-1
AWS_STORAGE_BUCKET_NAME=cwisrosa-d-s3-genai-data-bucket-dev
```

### Update Existing Knowledge Lambda

```bash
AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME=index
AWS_OPENSEARCH_COLLECTION_ARN=arn:aws:aoss:us-east-1:637423651937:collection/0tcpltvpj56pqwl9vm18
AWS_REGIONINFO=us-east-1
AWS_STORAGE_BUCKET_NAME=cwisrosa-d-s3-genai-data-bucket-dev
```
