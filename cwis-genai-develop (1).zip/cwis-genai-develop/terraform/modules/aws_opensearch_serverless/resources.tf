# OpenSearch Serverless Encryption Policy
resource "aws_opensearchserverless_security_policy" "encryption" {
  for_each = var.encryption_policies

  name        = each.value.name
  description = each.value.description
  type        = each.value.type
  policy = jsonencode({
    Rules = [
      for rule in each.value.policy.rules : {
        ResourceType = rule.resource_type
        Resource     = rule.resource
      }
    ]
    AWSOwnedKey = true
  })
}

# OpenSearch Serverless Network Policy
resource "aws_opensearchserverless_security_policy" "network" {
  for_each = var.network_policies

  name        = each.value.name
  description = each.value.description
  type        = each.value.type
  policy = jsonencode([
    for policy_item in each.value.policy :
    merge(
      {
        Rules = [
          for rule in policy_item.rules : {
            ResourceType = rule.resource_type
            Resource     = rule.resource
          }
        ]
        AllowFromPublic = policy_item.access_type == "public" ? true : false
      },
      policy_item.access_type == "private" ? {
        SourceServices = policy_item.source_vpc_endpoints
      } : {}
    )
  ])

  depends_on = [aws_opensearchserverless_security_policy.encryption]
}

# OpenSearch Serverless Collection
resource "aws_opensearchserverless_collection" "this" {
  for_each = var.opensearch_collections

  name        = each.value.name
  description = each.value.description
  type        = each.value.type

  tags = merge(var.common_tags, each.value.tags)

  depends_on = [
    aws_opensearchserverless_security_policy.encryption,
    aws_opensearchserverless_security_policy.network
  ]
}

# OpenSearch Serverless Data Access Policy
resource "aws_opensearchserverless_access_policy" "data" {
  for_each = var.data_access_policies

  name        = each.value.name
  description = each.value.description
  type        = each.value.type
  policy = jsonencode([
    for policy_item in each.value.policy : {
      Rules = [
        for rule in policy_item.rules : {
          ResourceType = rule.resource_type
          Resource     = rule.resource
          Permission   = rule.permission
        }
      ]
      Principal = policy_item.principal
    }
  ])

  depends_on = [aws_opensearchserverless_collection.this]
}
