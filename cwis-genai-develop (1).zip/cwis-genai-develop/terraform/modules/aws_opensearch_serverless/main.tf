# Provider will be inherited from the calling module
