output "opensearch_collections" {
  description = "OpenSearch Serverless collections"
  value = {
    for k, v in aws_opensearchserverless_collection.this : k => {
      id                  = v.id
      name                = v.name
      arn                 = v.arn
      collection_endpoint = v.collection_endpoint
      dashboard_endpoint  = v.dashboard_endpoint
      kms_key_arn         = v.kms_key_arn
    }
  }
}

output "network_policies" {
  description = "OpenSearch Serverless network policies"
  value = {
    for k, v in aws_opensearchserverless_security_policy.network : k => {
      id   = v.id
      name = v.name
    }
  }
}

output "encryption_policies" {
  description = "OpenSearch Serverless encryption policies"
  value = {
    for k, v in aws_opensearchserverless_security_policy.encryption : k => {
      id   = v.id
      name = v.name
    }
  }
}

output "data_access_policies" {
  description = "OpenSearch Serverless data access policies"
  value = {
    for k, v in aws_opensearchserverless_access_policy.data : k => {
      id   = v.id
      name = v.name
    }
  }
}
