# Archive the Lambda code

data "archive_file" "lambda" {
  for_each    = var.lambda_functions
  type        = "zip"
  source_dir  = each.value.source_dir
  output_path = "./${each.value.function_name}_payload.zip"
}

#resource "aws_iam_role" "lambda_exec" {
#  name = "${var.function_name}-exec-role"
#  assume_role_policy = data.aws_iam_policy_document.assume_role.json
#}

#data "aws_iam_policy_document" "assume_role" {
#  statement {
#    actions = ["sts:AssumeRole"]

#    principals {
#      type        = "Service"
#      identifiers = ["lambda.amazonaws.com"]
#    }
#  }
#}

#resource "aws_iam_role_policy_attachment" "lambda_basic" {
#  role       = aws_iam_role.lambda_exec.name
#  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
#}

resource "aws_lambda_function" "this" {
  for_each = var.lambda_functions

  function_name    = each.value.function_name
  role             = each.value.iam_lambda_arn
  handler          = each.value.handler
  runtime          = each.value.runtime
  filename         = data.archive_file.lambda[each.key].output_path
  source_code_hash = data.archive_file.lambda[each.key].output_base64sha256
  memory_size      = try(each.value.memory_size, 128)
  timeout          = try(each.value.timeout, 30)

  environment {
    variables = each.value.environment_variables
  }

  dynamic "ephemeral_storage" {
    for_each = try([each.value.ephemeral_storage], [])
    content {
      size = ephemeral_storage.value.size
    }
  }

  # Optional Logging Config (if provided in var)
  dynamic "logging_config" {
    for_each = try([each.value.logging_config], [])
    content {
      log_format      = logging_config.value.log_format
      log_group = logging_config.value.log_group
    }
  }

  # Optional Tracing Config (if provided in var)
  dynamic "tracing_config" {
    for_each = try([each.value.tracing_config], [])
    content {
      mode = tracing_config.value.mode
    }
  }

  # Optional: VPC config if present
  dynamic "vpc_config" {
    for_each = try(each.value.subnet_ids, null) != null && try(each.value.security_group_ids, null) != null ? [1] : []
    content {
      subnet_ids         = each.value.subnet_ids
      security_group_ids = each.value.security_group_ids
    }
  }

  tags = each.value.tags
}

