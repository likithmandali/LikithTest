# Lambda Terraform Module

This module provisions AWS Lambda functions for the NC_path Enterprise AI Backend.

## Usage

```hcl
module "lambda_functions" {
  source = "../modules/lambda"

  # General settings
  environment         = var.environment
  region              = var.region
  tags                = var.tags

  # Lambda function settings
  function_name       = "knowledge-base-update"
  description         = "Lambda function to create and update knowledge bases"
  handler             = "lambda_function.lambda_handler"
  runtime             = "python3.12"
  memory_size         = 256
  timeout             = 60

  # Source code
  source_code_path    = "../../app/services/lambda/knowledge-base-update"

  # Environment variables
  environment_variables = {
    AWS_REGIONINFO                          = var.region
    AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN  = var.knowledge_base_role_arn
    AWS_EMBEDDING_MODEL_NAME                = "amazon.titan-embed-text-v2:0"
    AWS_OPENSEARCH_COLLECTION_ARN           = var.opensearch_collection_arn
    AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "index"
    AWS_STORAGE_BUCKET_NAME                 = var.storage_bucket_name
    AWS_PARSING_FOUNDATION_MODEL            = "anthropic.claude-3-5-sonnet-20240620-v1:0"
  }

  # IAM role and policies
  iam_role_arn        = var.lambda_role_arn
  attach_policies     = true
  policies            = ["AmazonS3ReadOnlyAccess", "AmazonBedrockFullAccess"]
}
```

## Inputs

| Name                  | Description                                       | Type           | Default                            | Required |
| --------------------- | ------------------------------------------------- | -------------- | ---------------------------------- | :------: |
| function_name         | Name of the Lambda function                       | `string`       | n/a                                |   yes    |
| description           | Description of the Lambda function                | `string`       | `""`                               |    no    |
| handler               | Lambda function handler                           | `string`       | `"lambda_function.lambda_handler"` |   yes    |
| runtime               | Lambda function runtime                           | `string`       | `"python3.12"`                     |   yes    |
| memory_size           | Lambda function memory size                       | `number`       | `256`                              |    no    |
| timeout               | Lambda function timeout                           | `number`       | `60`                               |    no    |
| source_code_path      | Path to the Lambda function source code           | `string`       | n/a                                |   yes    |
| environment_variables | Environment variables for the Lambda function     | `map(string)`  | `{}`                               |    no    |
| iam_role_arn          | IAM role ARN for the Lambda function              | `string`       | n/a                                |   yes    |
| attach_policies       | Whether to attach policies to the Lambda function | `bool`         | `false`                            |    no    |
| policies              | List of policies to attach to the Lambda function | `list(string)` | `[]`                               |    no    |

## Outputs

| Name                | Description                       |
| ------------------- | --------------------------------- |
| function_arn        | ARN of the Lambda function        |
| function_name       | Name of the Lambda function       |
| function_invoke_arn | Invoke ARN of the Lambda function |

## Notes

- The Lambda function source code should be located in the `app/services/lambda` directory
- The Lambda function will be packaged as a ZIP file and uploaded to AWS
- The Lambda function will be configured with the specified environment variables
- The Lambda function will be assigned the specified IAM role and policies
