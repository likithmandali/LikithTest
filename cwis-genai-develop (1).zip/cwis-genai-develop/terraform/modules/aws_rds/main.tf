resource "random_password" "this" {
  for_each = var.rds_clusters
  length   = 16
  special  = false
}

resource "aws_secretsmanager_secret" "this" {
  for_each = var.rds_clusters
  name     = each.value.cluster_identifier
  tags     = each.value.tags
}

resource "aws_secretsmanager_secret_version" "this" {
  for_each  = var.rds_clusters
  secret_id = aws_secretsmanager_secret.this[each.key].id
  secret_string = jsonencode({
    username = coalesce(lookup(var.rds_clusters[each.key], "master_username", null), "clusteradmin")
    password = coalesce(lookup(var.rds_clusters[each.key], "master_password", null), random_password.this[each.key].result)
  })
}

data "aws_secretsmanager_secret" "this" {
  for_each = var.rds_clusters
  name     = aws_secretsmanager_secret.this[each.key].name
}

data "aws_secretsmanager_secret_version" "this" {
  for_each  = var.rds_clusters
  secret_id = data.aws_secretsmanager_secret.this[each.key].id
}

resource "aws_db_subnet_group" "this" {
  for_each    = var.db_subnet_groups
  name        = each.value.name
  subnet_ids  = each.value.subnet_ids
  tags        = each.value.tags
  description = each.value.description
}

resource "aws_rds_cluster" "this" {
  for_each = var.rds_clusters

  #allocated_storage                  = each.value.allocated_storage
  availability_zones                  = each.value.availability_zones
  allow_major_version_upgrade         = true
  backtrack_window                    = each.value.backtrack_window
  backup_retention_period             = each.value.backup_retention_period
  cluster_identifier                  = each.value.cluster_identifier
  cluster_members                     = each.value.cluster_members
  copy_tags_to_snapshot               = each.value.copy_tags_to_snapshot
  database_name                       = each.value.database_name
  db_cluster_parameter_group_name     = each.value.db_cluster_parameter_group_name
  db_subnet_group_name                = each.value.db_subnet_group_name
  deletion_protection                 = each.value.deletion_protection
  enable_http_endpoint                = each.value.enable_http_endpoint
  enabled_cloudwatch_logs_exports     = each.value.enabled_cloudwatch_logs_exports
  engine                              = each.value.engine
  engine_mode                         = each.value.engine_mode
  engine_version                      = each.value.engine_version
  iam_database_authentication_enabled = each.value.iam_database_authentication_enabled
  kms_key_id                          = each.value.kms_key_id
  master_username                     = coalesce(each.value.master_username, "clusteradmin")
  master_password                     = jsondecode(data.aws_secretsmanager_secret_version.this[each.key].secret_string)["password"]
  network_type                        = each.value.network_type
  port                                = each.value.port
  preferred_backup_window             = each.value.preferred_backup_window
  preferred_maintenance_window        = each.value.preferred_maintenance_window
  storage_encrypted                   = each.value.storage_encrypted
  skip_final_snapshot                 = each.value.skip_final_snapshot
  tags                                = each.value.tags
  vpc_security_group_ids              = each.value.vpc_security_group_ids

  lifecycle {
    ignore_changes = [availability_zones]
  }

  depends_on = [
    aws_db_subnet_group.this
    # Add security group resources here if they are created in this module, e.g. aws_security_group.this
  ]
}

resource "aws_rds_cluster_instance" "this" {
  for_each           = var.rds_cluster_instances
  identifier         = each.value.identifier
  cluster_identifier = each.value.cluster_identifier
  instance_class     = each.value.instance_class
  engine             = each.value.engine
  engine_version     = each.value.engine_version
  tags               = each.value.tags

  depends_on = [
    aws_rds_cluster.this,
    aws_db_subnet_group.this
  ]
}

resource "aws_db_instance" "this" {
  for_each = var.db_instances

  allocated_storage                     = each.value.allocated_storage
  auto_minor_version_upgrade            = each.value.auto_minor_version_upgrade
  availability_zone                     = each.value.availability_zone
  backup_retention_period               = each.value.backup_retention_period
  backup_target                         = each.value.backup_target
  backup_window                         = each.value.backup_window
  ca_cert_identifier                    = each.value.ca_cert_identifier
  copy_tags_to_snapshot                 = each.value.copy_tags_to_snapshot
  customer_owned_ip_enabled             = each.value.customer_owned_ip_enabled
  db_name                               = each.value.db_name
  db_subnet_group_name                  = each.value.db_subnet_group_name
  dedicated_log_volume                  = each.value.dedicated_log_volume
  deletion_protection                   = each.value.deletion_protection
  enabled_cloudwatch_logs_exports       = each.value.enabled_cloudwatch_logs_exports
  engine                                = each.value.engine
  engine_version                        = each.value.engine_version
  iam_database_authentication_enabled   = each.value.iam_database_authentication_enabled
  identifier                            = each.value.identifier
  instance_class                        = each.value.instance_class
  kms_key_id                            = each.value.kms_key_id
  license_model                         = each.value.license_model
  maintenance_window                    = each.value.maintenance_window
  max_allocated_storage                 = each.value.max_allocated_storage
  monitoring_interval                   = each.value.monitoring_interval
  multi_az                              = each.value.multi_az
  network_type                          = each.value.network_type
  option_group_name                     = each.value.option_group_name
  parameter_group_name                  = each.value.parameter_group_name
  performance_insights_enabled          = each.value.performance_insights_enabled
  performance_insights_kms_key_id       = each.value.performance_insights_kms_key_id
  performance_insights_retention_period = each.value.performance_insights_retention_period
  port                                  = each.value.port
  publicly_accessible                   = each.value.publicly_accessible
  storage_encrypted                     = each.value.storage_encrypted
  storage_throughput                    = each.value.storage_throughput
  storage_type                          = each.value.storage_type
  vpc_security_group_ids                = each.value.vpc_security_group_ids
  skip_final_snapshot                   = each.value.skip_final_snapshot
  #username                              = local.secrets[each.key]["username"]
  #password                              = local.secrets[each.key]["password"]
  tags = each.value.tags

  depends_on = [
    aws_db_subnet_group.this
    # Add security group resources here if they are created in this module, e.g. aws_security_group.this
  ]
}