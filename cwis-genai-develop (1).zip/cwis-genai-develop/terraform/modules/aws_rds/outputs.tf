output "rds_instance_endpoint" {
  description = "The connection endpoint for the RDS instance"
  value       = values(aws_rds_cluster.this)[*].endpoint
}

output "rds_instance_arn" {
  description = "The ARN of the RDS instance"
  value       = values(aws_rds_cluster.this)[*].arn
}

output "rds_instance_id" {
  description = "The id of the RDS instance"
  value       = values(aws_rds_cluster.this)[*].id
}

output "rds_cluster_secrets" {
  description = "Secrets Manager ARN for RDS clusters"
  value       = { for k, v in aws_secretsmanager_secret.this : k => v.arn }
}