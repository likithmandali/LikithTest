output "bucket_id" {
  description = "The ID of the created s3 bucket"
  value       = values(aws_s3_bucket.this)[*].id
}

output "bucket_name" {
  description = "Name of the created s3 bucket"
  value       = values(aws_s3_bucket.this)[*].bucket
}

output "bucket_arn" {
  description = "ARN for the created s3 bucket"
  value       = values(aws_s3_bucket.this)[*].arn
}