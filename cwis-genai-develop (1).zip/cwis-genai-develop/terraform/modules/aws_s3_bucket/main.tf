terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "5.57.0"
    }
  }
}

provider "aws" {
  region = "us-east-1"
}

resource "aws_s3_bucket" "this" {
  for_each = var.s3_buckets

  bucket        = each.value.bucket_name
  force_destroy = each.value.force_destroy

  object_lock_enabled = each.value.object_lock_enabled

  tags = each.value.tags
  lifecycle {
    ignore_changes = [
      replication_configuration
    ]
  }
}

resource "aws_s3_bucket_versioning" "this" {
  for_each = var.s3_buckets

  bucket = aws_s3_bucket.this[each.key].id

  versioning_configuration {
    status = each.value.enable_versioning
  }
}

resource "aws_s3_bucket_logging" "this" {
  for_each = var.s3_buckets

  bucket = aws_s3_bucket.this[each.key].id

  target_bucket = data.aws_s3_bucket.logging_bucket.id
  target_prefix = "${aws_s3_bucket.this[each.key].id}/"
}

resource "aws_s3_bucket_server_side_encryption_configuration" "this" {
  for_each = var.s3_buckets

  bucket = aws_s3_bucket.this[each.key].id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = each.value.encryption_algorithm
    }

    bucket_key_enabled = each.value.bucket_key_enabled
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "this" {
  for_each = var.s3_buckets

  bucket = aws_s3_bucket.this[each.key].id

  rule {
    id     = "lifecycle_rule"
    status = "Enabled"

    transition {
      days          = each.value.transition_days
      storage_class = each.value.transition_storage_class
    }

    dynamic "transition" {
      for_each = each.value.enable_second_transition ? [1] : []
      content {
        days          = each.value.second_transition_days
        storage_class = each.value.second_transition_storage_class
      }
    }
  }
}

//resource "aws_s3_bucket_policy" "this" {
//    for_each = { for k, v in var.s3_buckets : k => v if v.policy != "" }
//
//    bucket = aws_s3_bucket.this[each.key].id
//
//    policy = each.value.policy
//}


resource "aws_s3_bucket_policy" "s3_bucket" {
  for_each = var.s3_buckets

  bucket = aws_s3_bucket.this[each.key].id
  policy = <<POLICY
{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Sid": "AutoAdd-OnlyAllowSSLAccess",
        "Effect": "Deny",
        "Principal": {
          "AWS": "*"
        },
        "Action": "s3:*",
        "Condition": {
          "Bool": {
            "aws:SecureTransport": "false"
          }
        },
        "Resource": [
          "${aws_s3_bucket.this[each.key].arn}",
          "${aws_s3_bucket.this[each.key].arn}/*"
        ]
      }
    ]
}
POLICY
}

resource "aws_s3_bucket_public_access_block" "s3_bucket" {
  for_each = var.s3_buckets

  bucket = aws_s3_bucket.this[each.key].id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
