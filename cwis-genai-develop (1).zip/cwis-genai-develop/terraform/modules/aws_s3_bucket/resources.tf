data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_s3_bucket" "logging_bucket" {
  bucket = "accessloggingbucket-${data.aws_region.current.name}-${data.aws_caller_identity.current.account_id}"
}