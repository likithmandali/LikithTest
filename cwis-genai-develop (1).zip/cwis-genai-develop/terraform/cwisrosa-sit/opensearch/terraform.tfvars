aws_region = "us-east-1"

# Encryption Policy (required first)
encryption_policies = {
  dhhs-cwis-genai-encrypt-pol-sit = {
    name        = "dhhs-cwis-genai-encrypt-pol-sit"
    description = "Encryption policy for DHHS CWIS ROSA GenAI collection for SIT"
    type        = "encryption"
    policy = {
      rules = [
        {
          resource_type = "collection"
          resource      = ["collection/dhhs-cwis-genai-collection-sit"]
        }
      ]
    }
  }
}

# Network Policy
network_policies = {
  dhhs-cwis-genai-network-pol-sit = {
    name        = "dhhs-cwis-genai-network-pol-sit"
    description = "Network policy for DHHS CWIS ROSA GenAI collection with private and public access for SIT"
    type        = "network"
    policy = [
      {
        description = "Private access for AWS services and OpenSearch endpoints"
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-cwis-genai-collection-sit"]
          },
        ]
        source_vpcs = []
        source_vpc_endpoints = [
          "bedrock.amazonaws.com",
          "application.opensearchservice.amazonaws.com",
          "directquery.opensearchservice.amazonaws.com"
        ]
        access_type = "private"
      },
      {
        description = "Public access for OpenSearch Dashboards"
        rules = [
          {
            resource_type = "dashboard"
            resource      = ["collection/dhhs-cwis-genai-collection-sit"]
          }
        ]
        source_vpcs          = []
        source_vpc_endpoints = []
        access_type          = "public"
      }
    ]
  }
}

# OpenSearch Collection
opensearch_collections = {
  dhhs-cwis-genai-collection-sit = {
    name        = "dhhs-cwis-genai-collection-sit"
    description = "DHHS CWIS ROSA GenAI OpenSearch Serverless collection for SIT"
    type        = "VECTORSEARCH"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "sit"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-genai-collection-sit"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
}

# Data Access Policy
data_access_policies = {
  dhhs-cwis-genai-data-pol-sit = {
    name        = "dhhs-cwis-genai-data-pol-sit"
    description = "Data access policy for DHHS CWIS ROSA GenAI collection for SIT"
    type        = "data"
    policy = [
      {
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-cwis-genai-collection-sit"]
            permission = [
              "aoss:CreateCollectionItems",
              "aoss:DeleteCollectionItems",
              "aoss:UpdateCollectionItems",
              "aoss:DescribeCollectionItems"
            ]
          },
          {
            resource_type = "index"
            resource      = ["index/dhhs-cwis-genai-collection-sit/*"]
            permission = [
              "aoss:CreateIndex",
              "aoss:DeleteIndex",
              "aoss:UpdateIndex",
              "aoss:DescribeIndex",
              "aoss:ReadDocument",
              "aoss:WriteDocument"
            ]
          }
        ]
        principal = ["arn:aws:iam::637423651937:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_dhhs-itd-cwisrosa-devops-role_e9e2af2f3ef4e176"]
      }
    ]
  }
}
