variable "aws_region" {
  type    = string
  default = "us-east-1"
}

variable "rds_clusters" {
  description = "Map of RDS clusters to create"
  type = map(object({
    allocated_storage                   = number
    availability_zones                  = list(string)
    backtrack_window                    = string
    backup_retention_period             = number
    cluster_identifier                  = string
    cluster_members                     = list(string)
    copy_tags_to_snapshot               = bool
    database_name                       = string
    db_cluster_parameter_group_name     = string
    db_subnet_group_name                = string
    deletion_protection                 = bool
    enable_http_endpoint                = bool
    enabled_cloudwatch_logs_exports     = list(string)
    engine                              = string
    engine_mode                         = string
    engine_version                      = string
    iam_database_authentication_enabled = bool
    iops                                = number
    kms_key_id                          = string
    master_username                     = string
    network_type                        = string
    port                                = number
    preferred_backup_window             = string
    preferred_maintenance_window        = string
    storage_encrypted                   = bool
    skip_final_snapshot                 = bool
    tags                                = map(string)
    vpc_security_group_ids              = list(string)
  }))
}

variable "db_instances" {
  description = "Map of db instances to create"
  type = map(object({
    allocated_storage                     = number
    auto_minor_version_upgrade            = bool
    availability_zone                     = string
    backup_retention_period               = number
    backup_target                         = string
    backup_window                         = string
    ca_cert_identifier                    = string
    copy_tags_to_snapshot                 = bool
    customer_owned_ip_enabled             = bool
    db_name                               = string
    db_subnet_group_name                  = string
    dedicated_log_volume                  = bool
    deletion_protection                   = bool
    enabled_cloudwatch_logs_exports       = list(string)
    engine                                = string
    engine_version                        = string
    iam_database_authentication_enabled   = bool
    identifier                            = string
    instance_class                        = string
    iops                                  = number
    kms_key_id                            = string
    license_model                         = string
    maintenance_window                    = string
    max_allocated_storage                 = number
    monitoring_interval                   = string
    multi_az                              = bool
    network_type                          = string
    option_group_name                     = string
    parameter_group_name                  = string
    performance_insights_enabled          = bool
    performance_insights_kms_key_id       = string
    performance_insights_retention_period = number
    port                                  = number
    publicly_accessible                   = bool
    storage_encrypted                     = bool
    storage_throughput                    = number
    storage_type                          = string
    skip_final_snapshot                   = bool
    tags                                  = map(string)
    vpc_security_group_ids                = list(string)
    username                              = string
  }))
}

variable "rds_cluster_instances" {
  description = "Map of rds cluster instances"
  type = map(object({
    identifier         = string
    cluster_identifier = string
    instance_class     = string
    engine             = string
    engine_version     = string
    tags               = map(string)
  }))
  default = {}
}

variable "db_subnet_groups" {
  description = "Map of subnet groups to create"
  type = map(object({
    description = string
    name        = string
    subnet_ids  = list(string)
    tags        = map(string)
  }))
}