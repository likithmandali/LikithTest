aws_region = "us-east-1"

lambda_functions = {
  dhhs-cwisrosa-d-knowledgebasecreate-sit = {
    function_name  = "dhhs-cwisrosa-d-knowledgebasecreate-sit"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./lambda-KnowledgeBaseUpdate_payload.zip"
    source_dir     = "../../../app/lambda/knowledge-base-update"                        # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN      = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-sa-role"
      AWS_EMBEDDING_MODEL_NAME                    = "amazon.titan-embed-text-v2:0"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:637423651937:collection/lr0ah0shw2hn0yyzz73d"
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-cwis-genai-sit-index"
      AWS_PARSING_FOUNDATION_MODEL                = "anthropic.claude-3-5-sonnet-20240620-v1:0"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "pathnc-genaie-data-bucket-sit"
    }
    application_name = "KnowledgeBaseUpdate"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "sit"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebasecreate-sit"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
  dhhs-cwisrosa-d-knowledgebaseupdate-sit = {
    function_name  = "dhhs-cwisrosa-d-knowledgebaseupdate-sit"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./UpdateExistingKnowledge_payload.zip"
    source_dir     = "../../../app/lambda/update-existing-knowledge/"                   # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::637423651937:role/dhhs-cwisrosa-d-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-cwis-genai-sit-index"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:637423651937:collection/lr0ah0shw2hn0yyzz73d"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "pathnc-genaie-data-bucket-sit"
    }
    application_name = "UpdateExistingKnowledge"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "sit"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebaseupdate-sit"
      stack                  = "dhhs-cwisrosa-d"
    }
  }
}  