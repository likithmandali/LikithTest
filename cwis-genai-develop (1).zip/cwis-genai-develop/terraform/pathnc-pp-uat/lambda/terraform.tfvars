aws_region = "us-east-1"

lambda_functions = {
  dhhs-pathnc-pp-knowledgebasecreate-uat = {
    function_name  = "dhhs-pathnc-pp-knowledgebasecreate-uat"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./lambda-KnowledgeBaseUpdate_payload.zip"
    source_dir     = "../../../app/lambda/knowledge-base-update"                       # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::774305615526:role/dhhs-pathnc-pp-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_EMBEDDINGS_KNOWLEDGE_BASE_ROLE_ARN      = "arn:aws:iam::774305615526:role/dhhs-pathnc-pp-genai-sa-role"
      AWS_EMBEDDING_MODEL_NAME                    = "amazon.titan-embed-text-v2:0"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:774305615526:collection/jdem56aiypfzimlov53f"
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-cwis-genai-uat-index-pathnc-pp"
      AWS_PARSING_FOUNDATION_MODEL                = "anthropic.claude-3-5-sonnet-20240620-v1:0"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "pathnc-pp-s3-genai-data-bucket-uat"
    }
    application_name = "KnowledgeBaseUpdate"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "uat"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-d-knowledgebasecreate-uat"
      stack                  = "dhhs-pathnc-pp"
    }
  }
  dhhs-pathnc-pp-knowledgebaseupdate-uat = {
    function_name  = "dhhs-pathnc-pp-knowledgebaseupdate-uat"
    runtime        = "python3.12"
    handler        = "lambda_function.lambda_handler"
    filename       = "./UpdateExistingKnowledge_payload.zip"
    source_dir     = "../../../app/lambda/update-existing-knowledge/"                  # Will be set in main.tf using data source
    iam_lambda_arn = "arn:aws:iam::774305615526:role/dhhs-pathnc-pp-genai-lambda-role" # Will be set in main.tf using module output
    environment_variables = {
      AWS_OPENSEARCH_COLLECTION_VECTOR_INDEX_NAME = "dhhs-cwis-genai-uat-index-pathnc-pp"
      AWS_OPENSEARCH_COLLECTION_ARN               = "arn:aws:aoss:us-east-1:774305615526:collection/jdem56aiypfzimlov53f"
      AWS_REGIONINFO                              = "us-east-1"
      AWS_STORAGE_BUCKET_NAME                     = "pathnc-pp-s3-genai-data-bucket-uat"
    }
    application_name = "UpdateExistingKnowledge"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "uat"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-pathnc-pp-knowledgebaseupdate-uat"
      stack                  = "dhhs-pathnc-pp"
    }
  }
}  