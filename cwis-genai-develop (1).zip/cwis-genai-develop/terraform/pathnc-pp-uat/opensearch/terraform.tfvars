aws_region = "us-east-1"

# Encryption Policy (required first)
encryption_policies = {
  dhhs-cwis-genai-encrypt-pol-uat = {
    name        = "dhhs-cwis-genai-encrypt-pol-uat"
    description = "Encryption policy for DHHS CWIS pathnc-pp GenAI collection for UAT"
    type        = "encryption"
    policy = {
      rules = [
        {
          resource_type = "collection"
          resource      = ["collection/dhhs-cwis-genai-collection-uat"]
        }
      ]
    }
  }
}

# Network Policy
network_policies = {
  dhhs-cwis-genai-network-pol-uat = {
    name        = "dhhs-cwis-genai-network-pol-uat"
    description = "Network policy for DHHS CWIS pathnc-pp GenAI collection with private and public access for UAT"
    type        = "network"
    policy = [
      {
        description = "Private access for AWS services and OpenSearch endpoints"
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-cwis-genai-collection-uat"]
          },
        ]
        source_vpcs = []
        source_vpc_endpoints = [
          "bedrock.amazonaws.com",
          "application.opensearchservice.amazonaws.com",
          "directquery.opensearchservice.amazonaws.com"
        ]
        access_type = "private"
      },
      {
        description = "Public access for OpenSearch Dashboards"
        rules = [
          {
            resource_type = "dashboard"
            resource      = ["collection/dhhs-cwis-genai-collection-uat"]
          }
        ]
        source_vpcs          = []
        source_vpc_endpoints = []
        access_type          = "public"
      }
    ]
  }
}

# OpenSearch Collection
opensearch_collections = {
  dhhs-pathnc-pp-genai-collection-uat = {
    name        = "dhhs-cwis-genai-collection-uat"
    description = "DHHS CWIS pathnc-pp GenAI OpenSearch Serverless collection for UAT"
    type        = "VECTORSEARCH"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "uat"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "dhhs-cwisrosa-genai-collection-uat"
      stack                  = "dhhs-pathnc-pp"
    }
  }
}

# Data Access Policy
data_access_policies = {
  dhhs-cwis-genai-data-pol-uat = {
    name        = "dhhs-cwis-genai-data-pol-uat"
    description = "Data access policy for DHHS CWIS pathnc-pp GenAI collection for UAT"
    type        = "data"
    policy = [
      {
        rules = [
          {
            resource_type = "collection"
            resource      = ["collection/dhhs-cwis-genai-collection-uat"]
            permission = [
              "aoss:CreateCollectionItems",
              "aoss:DeleteCollectionItems",
              "aoss:UpdateCollectionItems",
              "aoss:DescribeCollectionItems"
            ]
          },
          {
            resource_type = "index"
            resource      = ["index/dhhs-cwis-genai-collection-uat/*"]
            permission = [
              "aoss:CreateIndex",
              "aoss:DeleteIndex",
              "aoss:UpdateIndex",
              "aoss:DescribeIndex",
              "aoss:ReadDocument",
              "aoss:WriteDocument"
            ]
          }
        ]
        principal = ["arn:aws:iam::774305615526:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_c-dhhs-ncfast-pathnc-pp-devops_ba7956dd321e7cbe"]
      }
    ]
  }
}
