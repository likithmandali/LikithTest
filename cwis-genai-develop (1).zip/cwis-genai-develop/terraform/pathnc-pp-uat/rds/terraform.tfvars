aws_region = "us-east-1"

# DB Subnet Groups (Define these first as they are prerequisites)
db_subnet_groups = {
  pathnc-pp-db-genai-subnet-group-uat = {
    description = "This subnet group belongs to pathnc-pp-db-genai"
    name        = "pathnc-pp-db-genai-subnet-group-uat"
    subnet_ids  = ["subnet-0b65433b7fe12049a", "subnet-03040079225ac0b64"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "uat"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-pp-db-genai-subnet-group-uat"
      stack                  = "dhhs-pathnc-pp"
    }
  }
}

# RDS Clusters (Define these after subnet groups)
rds_clusters = {
  pathnc-db-genai-cluster-uat = {
    allocated_storage                   = "1"
    availability_zones                  = ["us-east-1b", "us-east-1c"]
    backtrack_window                    = "0"
    backup_retention_period             = "7"
    cluster_identifier                  = "pathnc-db-genai-cluster-uat"
    cluster_members                     = ["pathnc-db-genai-db-uat-instance1"]
    copy_tags_to_snapshot               = false
    database_name                       = "pathncppgenaieuat"
    db_cluster_parameter_group_name     = "default.aurora-postgresql14"
    db_subnet_group_name                = "pathnc-pp-db-genai-subnet-group-uat"
    deletion_protection                 = false
    enable_http_endpoint                = false
    enabled_cloudwatch_logs_exports     = ["postgresql"]
    engine                              = "aurora-postgresql"
    engine_mode                         = "provisioned"
    engine_version                      = "14.15"
    iam_database_authentication_enabled = true
    iops                                = "0"
    kms_key_id                          = "arn:aws:kms:us-east-1:774305615526:key/86203f2c-649e-484b-b7ed-03778c1d919c"
    master_username                     = "clusterdmin"
    network_type                        = "IPV4"
    port                                = "5432"
    preferred_backup_window             = "04:30-05:00"
    preferred_maintenance_window        = "sun:06:20-sun:06:50"
    storage_encrypted                   = true
    skip_final_snapshot                 = true
    vpc_security_group_ids              = ["sg-079355c2cd95ac697", "sg-0829d8f264e0101c7"]
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "uat"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-cluster-uat"
      stack                  = "dhhs-pathnc-pp"
    }
  }
}

# RDS Cluster Instances (Define these after clusters)
rds_cluster_instances = {
  pathnc-db-genai-db-uat-instance1 = {
    identifier         = "pathnc-db-genai-db-uat-instance1"
    cluster_identifier = "pathnc-db-genai-cluster-uat"
    instance_class     = "db.r5.large"
    engine             = "aurora-postgresql"
    engine_version     = "14.15"
    tags = {
      "dhhs:business-owner"  = "rob-morrell"
      "dhhs:compliance"      = "pii-hipaa"
      "dhhs:cost-center"     = "cgg2"
      "dhhs:division"        = "division-of-social-services"
      "dhhs:environment"     = "uat"
      "dhhs:operation-owner" = "xia-feng"
      Agency                 = "DHHS"
      Application            = "CWIS"
      ApplicationOwner       = "feng.xia@dhhs.nc.gov"
      BillCode               = "FCV"
      DataClassification     = "Restricted"
      Division               = "ITD-DIRM"
      SecurityPOC            = "joe.mancuso@dhhs.nc.gov"
      Component              = "comp-genai"
      resource-name          = "pathnc-db-genai-db-uat-instance1"
      stack                  = "dhhs-pathnc-pp"
    }
  }
}

# Empty DB instances block (if needed for future use)
db_instances = {}