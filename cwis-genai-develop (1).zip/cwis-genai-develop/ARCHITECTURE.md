# NC_path Enterprise AI Backend - Architecture Overview

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    NC_path Enterprise AI Platform                │
├─────────────────────────────────────────────────────────────────┤
│  Frontend Layer                                                 │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │   React UI      │    │  Salesforce     │                    │
│  │   (Port 9003)   │    │  Integration    │                    │
│  └─────────────────┘    └─────────────────┘                    │
├─────────────────────────────────────────────────────────────────┤
│  API Gateway Layer                                              │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │   SmartGPT      │    │  Orchestrator   │                    │
│  │   Django API    │    │  FastAPI        │                    │
│  │   (Port 9000)   │    │  (Port 9001)    │                    │
│  └─────────────────┘    └─────────────────┘                    │
├─────────────────────────────────────────────────────────────────┤
│  Processing Layer                                               │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │   Celery        │    │   RAG Engine    │                    │
│  │   Workers       │    │   (Bedrock)     │                    │
│  └─────────────────┘    └─────────────────┘                    │
├─────────────────────────────────────────────────────────────────┤
│  Infrastructure Layer                                           │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │   Redis         │    │   Flower        │                    │
│  │   (Port 6379)   │    │   (Port 9005)   │                    │
│  └─────────────────┘    └─────────────────┘                    │
├─────────────────────────────────────────────────────────────────┤
│  Data Layer                                                     │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │   PostgreSQL    │    │   AWS S3        │                    │
│  │   RDS           │    │   Document      │                    │
│  └─────────────────┘    └─────────────────┘                    │
└─────────────────────────────────────────────────────────────────┘
```

## Core Services

### 1. SmartGPT (Django Backend)

- **Purpose**: Main API backend for user interactions
- **Technology**: Django + Django REST Framework
- **Port**: 9000
- **Responsibilities**:
  - User authentication and authorization
  - Chat history management
  - Policy document management
  - Integration with Salesforce

### 2. Orchestrator (FastAPI Service)

- **Purpose**: Workflow orchestration and AI processing
- **Technology**: FastAPI + Uvicorn
- **Port**: 9001 (4000 internal)
- **Responsibilities**:
  - RAG (Retrieval-Augmented Generation) processing
  - AWS Bedrock integration
  - Document processing workflows
  - AI model orchestration

### 3. UI (React Frontend)

- **Purpose**: User interface for the GenAI platform
- **Technology**: React.js
- **Port**: 9003
- **Responsibilities**:
  - Chat interface
  - Document upload/management
  - User dashboard
  - Real-time updates

### 4. Supporting Services

- **Redis**: Message broker and session storage
- **Flower**: Celery task monitoring
- **Celery**: Asynchronous task processing

## Data Flow

1. **User Query** → React UI → SmartGPT API
2. **Processing** → SmartGPT → Orchestrator → AWS Bedrock
3. **RAG Processing** → Document retrieval from S3 → Knowledge base query
4. **Response** → Orchestrator → SmartGPT → UI
5. **Storage** → Chat history in PostgreSQL

## Deployment Architecture

### Development Environment

- Docker Compose with dev profile
- Local volumes for hot reloading
- Debug configurations enabled

### Production Environment

- Docker Compose with prod profile
- Optimized builds
- Health checks and monitoring
- AWS integration

## Security Considerations

- Environment-based configuration
- Secrets management via .env files
- Network isolation via Docker networks
- CORS configuration for cross-origin requests
