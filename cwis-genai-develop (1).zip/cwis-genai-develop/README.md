# NC_path Enterprise AI Backend

Developed by the GenAIe Team

## Project Overview

NC_path Enterprise AI Backend is a robust, scalable platform designed for the NC_path client by the GenAIe Team. This application leverages the AWS suite of APIs as a backend service within Deloitte, providing advanced document processing, knowledge management, and orchestration services. The platform utilizes AI to automate workflows and enhance enterprise productivity. Built with modern Python frameworks, containerized for cloud-native deployments, and integrated with AWS cloud services, it is tailored for secure, high-performance enterprise use cases within the Deloitte ecosystem.

## Getting Started

### Prerequisites

- Python 3.11 ([Download](https://www.python.org/downloads/release/python-3114/))
- [VS Code](https://code.visualstudio.com/)
- [Docker Desktop](https://www.docker.com/products/docker-desktop)

## Environment Configuration

Before running the application, you must configure the environment files. These files should contain all necessary secrets, API keys, and connection details.

### Development

- **smartgpt:** Create a `.env.docker.dev` file inside the `app` directory. This file should contain the necessary environment variables for the development environment.
- **orchestrator:** Create a `.env.orchestrator.dev` file inside the `app/services/orchestrator` directory with all required environment variables for orchestration services in development.
- **lambda:** Create a `.env` file inside the `app/services/lambda` directory with all required environment variables for AWS Lambda functions.

### Production

- **smartgpt:** Create a `.env.docker.prod` file inside the `app` directory. This file should contain all required secrets and credentials for the production environment.
- **orchestrator:** Create a `.env.orchestrator.prod` file inside the `app/services/orchestrator` directory with production-ready secrets, API keys, and connection details.

All connection credentials, API keys, and secrets required for external services should be specified in these environment files.

## Execution Sequence

This section provides the specific order of commands to set up and run the application.

### Development Environment

The following command sequence is for the development setup:

```bash
# Main application setup
make dev-build
make migrations
make migrate
make createsuperuser
make dev-up

# Lambda functions setup
make setup-lambda-dev
make build-lambda
make up-lambda
```

### Production Environment

The following command sequence is for the production setup:

```bash
make prod-build
make migrations
make migrate
make createsuperuser
make prod-up
```

## Command Reference

This section defines the collection of `make` commands available for managing the application.

### Development Commands

- `make dev-build`: Builds the Docker containers for the development environment.
- `make dev-up`: Starts the development services. Access API docs at <http://0.0.0.0:4000/docs>.
- `make dev-logs`: Tails the logs from the development containers.

### Production Commands

- `make prod-build`: Builds the Docker containers for production.
- `make prod-up`: Deploys the application to production.
- `make prod-logs`: Tails the logs from the production containers.

### Database Commands

- `make migrations`: Creates new database migrations based on model changes.
- `make migrate`: Applies the database migrations.
- `make createsuperuser`: Creates a superuser for the Django admin. You will be prompted to provide a username, email, and password.

---

Built with pride by the GenAIe Team for NC_path

For support, contact [genaiesupport@deloitte.com](mailto:genaiesupport@deloitte.com)
