#!/usr/bin/env python3
"""
NC_path Enterprise AI Backend Data Flow Diagram
This script generates a diagram showing the data flow between components.
"""

from diagrams import Cluster, Diagram, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.database import RDS, ElastiCache
from diagrams.aws.storage import S3
from diagrams.aws.ml import Bedrock
from diagrams.aws.analytics import AmazonOpensearchService
from diagrams.aws.security import IAM
from diagrams.aws.integration import SQS
from diagrams.onprem.compute import Server
from diagrams.onprem.queue import Celery
from diagrams.k8s.compute import Pod
from diagrams.k8s.network import Service
from diagrams.programming.framework import React, Django, FastAPI

# Set graph attributes
graph_attr = {
    "fontsize": "30",
    "bgcolor": "white",
    "pad": "0.75",
    "splines": "curved",
    "nodesep": "1.0",
    "ranksep": "1.2",
    "fontname": "Arial",
    "fontcolor": "#2D3436",
    "fontsize": "24",
}

# Create the diagram
with Diagram("NC_path Enterprise AI Backend Data Flow", show=False, filename="nc_path_data_flow", graph_attr=graph_attr):
    
    # Client User
    user = Server("Client User")
    
    # Frontend
    with Cluster("Frontend"):
        ui = React("UI (React)")
    
    # Backend Services
    with Cluster("Backend Services"):
        web = Django("SmartGPT (Django)")
        orchestrator = FastAPI("Orchestrator (FastAPI)")
        redis = ElastiCache("Redis Cache")
        celery = Celery("Celery Workers")
    
    # AWS Services
    with Cluster("AWS Services"):
        # Database
        db = RDS("PostgreSQL")
        
        # Storage
        s3 = S3("Document Storage")
        
        # Lambda Functions
        kb_create = Lambda("Knowledge Base Create")
        kb_update = Lambda("Knowledge Base Update")
        
        # AI Services
        bedrock = Bedrock("AWS Bedrock")
        opensearch = AmazonOpensearchService("OpenSearch Vector DB")
    
    # Data Flow Connections with Labels
    
    # User Interactions
    user >> Edge(label="1. User Requests") >> ui
    ui >> Edge(label="2. API Calls") >> orchestrator
    ui << Edge(label="12. Response Data") << orchestrator
    
    # Document Processing Flow
    orchestrator >> Edge(label="3. Store Documents") >> s3
    orchestrator >> Edge(label="4. Queue Tasks") >> redis
    redis >> Edge(label="5. Process Tasks") >> celery
    celery >> Edge(label="6. Invoke Lambda") >> kb_create
    
    # Knowledge Base Creation
    kb_create >> Edge(label="7. Read Documents") >> s3
    kb_create >> Edge(label="8. Create Embeddings") >> bedrock
    kb_create >> Edge(label="9. Store Vectors") >> opensearch
    
    # Query Flow
    orchestrator >> Edge(label="10. Query Knowledge Base") >> bedrock
    bedrock >> Edge(label="11. Retrieve Context") >> opensearch
    
    # Database Interactions
    orchestrator >> Edge(label="Store Metadata") >> db
    web >> Edge(label="Read/Write Data") >> db
