#!/usr/bin/env python3
"""
NC_path Enterprise AI Backend Lambda Integration Diagram
This script generates a diagram showing the Lambda functions and their integration.
"""

from diagrams import Cluster, Diagram, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.storage import S3
from diagrams.aws.ml import Bedrock
from diagrams.aws.analytics import AmazonOpensearchService
from diagrams.aws.security import IAM
from diagrams.aws.integration import SQS
from diagrams.onprem.compute import Server
from diagrams.onprem.queue import Celery
from diagrams.k8s.compute import Pod
from diagrams.programming.framework import FastAPI

# Set graph attributes
graph_attr = {
    "fontsize": "30",
    "bgcolor": "white",
    "pad": "0.75",
    "splines": "ortho",
    "nodesep": "1.0",
    "ranksep": "1.2",
    "fontname": "Arial",
    "fontcolor": "#2D3436",
    "fontsize": "24",
}

# Create the diagram
with Diagram("NC_path Lambda Functions Integration", show=False, filename="nc_path_lambda_integration", graph_attr=graph_attr):
    
    # Orchestrator
    with Cluster("OpenShift Cluster"):
        orchestrator = FastAPI("Orchestrator (FastAPI)")
        celery = Celery("Celery Workers")
    
    # AWS Services
    with Cluster("AWS Services"):
        # IAM Roles
        with Cluster("IAM Roles"):
            lambda_role = IAM("Lambda Execution Role")
            sa_role = IAM("Service Account Role")
        
        # Lambda Functions
        with Cluster("Lambda Functions"):
            kb_create = Lambda("Knowledge Base Create")
            kb_update = Lambda("Knowledge Base Update")
        
        # Storage
        s3 = S3("Document Storage")
        
        # AI Services
        with Cluster("AWS Bedrock"):
            bedrock_models = Bedrock("Foundation Models")
            bedrock_kb = Bedrock("Knowledge Bases")
        
        # Vector Database
        opensearch = AmazonOpensearchService("OpenSearch Vector DB")
    
    # Connections
    
    # Orchestrator to Lambda
    orchestrator >> Edge(label="1. Invoke Lambda") >> kb_create
    orchestrator >> Edge(label="6. Invoke Lambda") >> kb_update
    
    # IAM Permissions
    kb_create << Edge(label="2. Assume Role") << lambda_role
    kb_update << Edge(label="7. Assume Role") << lambda_role
    orchestrator << Edge(label="Auth") << sa_role
    
    # Knowledge Base Create Flow
    kb_create >> Edge(label="3. Read Documents") >> s3
    kb_create >> Edge(label="4. Create Embeddings") >> bedrock_models
    kb_create >> Edge(label="5. Create Knowledge Base") >> bedrock_kb
    bedrock_kb >> Edge(label="Store Vectors") >> opensearch
    
    # Knowledge Base Update Flow
    kb_update >> Edge(label="8. Read Documents") >> s3
    kb_update >> Edge(label="9. Update Knowledge Base") >> bedrock_kb
    
    # Celery Integration
    orchestrator >> Edge(label="Queue Tasks") >> celery
    celery >> Edge(label="Process Tasks") >> orchestrator
