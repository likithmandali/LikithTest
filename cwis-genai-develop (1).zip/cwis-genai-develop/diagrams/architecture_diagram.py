#!/usr/bin/env python3
"""
NC_path Enterprise AI Backend Architecture Diagram
This script generates a comprehensive architecture diagram of the system.
"""

from diagrams import Cluster, Diagram, Edge
from diagrams.aws.compute import Lambda
from diagrams.aws.database import RDS, ElastiCache
from diagrams.aws.storage import S3
from diagrams.aws.ml import Bedrock
from diagrams.aws.analytics import AmazonOpensearchService
from diagrams.aws.security import IAM
from diagrams.aws.integration import SQS
from diagrams.onprem.compute import Server
from diagrams.onprem.network import Nginx
from diagrams.onprem.queue import Celery, RabbitMQ
from diagrams.onprem.container import Docker
from diagrams.k8s.compute import Deployment, Pod
from diagrams.k8s.network import Service, Ingress
from diagrams.k8s.storage import PV, PVC
from diagrams.k8s.infra import ETCD
from diagrams.onprem.monitoring import Grafana, Prometheus
from diagrams.programming.framework import React, Django, FastAPI

# Set graph attributes
graph_attr = {
    "fontsize": "30",
    "bgcolor": "white",
    "pad": "0.5",
    "splines": "ortho",
    "nodesep": "0.8",
    "ranksep": "1.0",
    "fontname": "Arial",
    "fontcolor": "#2D3436",
    "fontsize": "24",
}

# Create the diagram
with Diagram("NC_path Enterprise AI Backend Architecture", show=False, filename="nc_path_architecture", graph_attr=graph_attr):
    
    # External User
    user = Server("Client User")
    
    # OpenShift Cluster
    with Cluster("OpenShift Cluster (ROSA)"):
        
        # Ingress/Routes
        ingress = Ingress("OpenShift Routes")
        
        # UI Component
        with Cluster("UI Service"):
            ui_service = Service("UI Service")
            ui_deployment = Deployment("UI Deployment")
            ui_pod = Pod("React UI")
            ui_framework = React("React Framework")
            
            ui_service >> ui_deployment >> ui_pod >> ui_framework
        
        # SmartGPT Component
        with Cluster("SmartGPT Service"):
            web_service = Service("Web Service")
            web_deployment = Deployment("Web Deployment")
            web_pod = Pod("Django App")
            web_framework = Django("Django Framework")
            web_pvc = PVC("Static/Media PVC")
            
            web_service >> web_deployment >> web_pod >> web_framework
            web_pod >> web_pvc
        
        # Orchestrator Component
        with Cluster("Orchestrator Service"):
            orch_service = Service("Orchestrator Service")
            orch_deployment = Deployment("Orchestrator Deployment")
            orch_pod = Pod("FastAPI App")
            orch_framework = FastAPI("FastAPI Framework")
            orch_pvc = PVC("Shared Volume PVC")
            
            orch_service >> orch_deployment >> orch_pod >> orch_framework
            orch_pod >> orch_pvc
        
        # Redis Component
        with Cluster("Redis Service"):
            redis_service = Service("Redis Service")
            redis_deployment = Deployment("Redis Deployment")
            redis_pod = ElastiCache("Redis Pod")
            
            redis_service >> redis_deployment >> redis_pod
        
        # Flower Component
        with Cluster("Flower Service"):
            flower_service = Service("Flower Service")
            flower_deployment = Deployment("Flower Deployment")
            flower_pod = Pod("Flower Dashboard")
            
            flower_service >> flower_deployment >> flower_pod
        
        # Celery Workers
        with Cluster("Celery Workers"):
            celery_worker = Celery("Celery Workers")
            celery_queue = SQS("Task Queue")
            
            celery_worker >> celery_queue
        
        # Service Connections
        ingress >> ui_service
        ingress >> web_service
        ingress >> orch_service
        ingress >> flower_service
        
        ui_pod >> orch_service
        web_pod >> orch_service
        orch_pod >> redis_service
        orch_pod >> celery_worker
        flower_pod >> redis_service
    
    # AWS Services
    with Cluster("AWS Services"):
        
        # IAM Roles
        with Cluster("IAM"):
            sa_role = IAM("Service Account Role")
            lambda_role = IAM("Lambda Role")
        
        # Lambda Functions
        with Cluster("Lambda Functions"):
            kb_create_lambda = Lambda("Knowledge Base Create")
            kb_update_lambda = Lambda("Knowledge Base Update")
        
        # S3 Storage
        s3_bucket = S3("Document Storage")
        
        # RDS Database
        postgres_db = RDS("PostgreSQL Database")
        
        # AWS Bedrock
        with Cluster("AWS Bedrock"):
            bedrock = Bedrock("Foundation Models")
            kb = Bedrock("Knowledge Bases")
        
        # OpenSearch
        opensearch = AmazonOpensearchService("Vector Database")
        
        # Connections
        orch_pod >> sa_role
        sa_role >> kb_create_lambda
        sa_role >> kb_update_lambda
        sa_role >> s3_bucket
        sa_role >> bedrock
        sa_role >> opensearch
        
        kb_create_lambda >> lambda_role
        kb_update_lambda >> lambda_role
        
        lambda_role >> s3_bucket
        lambda_role >> bedrock
        lambda_role >> opensearch
        
        kb_create_lambda >> bedrock
        kb_update_lambda >> bedrock
        kb_create_lambda >> opensearch
        kb_update_lambda >> opensearch
        
        web_pod >> postgres_db
        orch_pod >> postgres_db
        
        bedrock >> kb
    
    # User connections
    user >> ingress
