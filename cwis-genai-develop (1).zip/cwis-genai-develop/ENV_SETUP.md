# Environment Configuration Guide

## Overview

This guide helps you set up environment configurations for the NC_path Enterprise AI Backend across different deployment environments.

## Environment Files Structure

```
config/
├── environments/
│   ├── development/
│   │   ├── .env.smartgpt.dev
│   │   ├── .env.orchestrator.dev
│   │   └── docker-compose.dev.yml
│   ├── production/
│   │   ├── .env.smartgpt.prod
│   │   ├── .env.orchestrator.prod
│   │   └── docker-compose.prod.yml
│   └── staging/
│       ├── .env.smartgpt.staging
│       ├── .env.orchestrator.staging
│       └── docker-compose.staging.yml
```

## Environment Variables Templates

### SmartGPT Service (.env.smartgpt.\*)

```bash
# Database Configuration
DATABASE_URL=postgresql://user:password@db:5432/nc_path
DB_NAME=nc_path
DB_USER=postgres
DB_PASSWORD=your_secure_password
DB_HOST=db
DB_PORT=5432

# Django Configuration
SECRET_KEY=your-super-secret-django-key-here
DEBUG=True # False for production
ALLOWED_HOSTS=localhost,127.0.0.1,0.0.0.0
CORS_ALLOWED_ORIGINS=http://localhost:9003,http://127.0.0.1:9003

# Redis Configuration
REDIS_URL=redis://redis:6379/0
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/0

# AWS Configuration
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_DEFAULT_REGION=us-east-1
AWS_S3_BUCKET_NAME=nc-path-documents
AWS_S3_REGION_NAME=us-east-1

# Salesforce Integration
SALESFORCE_CLIENT_ID=your_salesforce_client_id
SALESFORCE_CLIENT_SECRET=your_salesforce_client_secret
SALESFORCE_USERNAME=your_salesforce_username
SALESFORCE_PASSWORD=your_salesforce_password
SALESFORCE_SECURITY_TOKEN=your_salesforce_token
SALESFORCE_DOMAIN=login # or test for sandbox

# Logging Configuration
LOG_LEVEL=INFO # DEBUG for development
LOG_FORMAT=json

# Security Settings
SECURE_SSL_REDIRECT=False   # True for production
SESSION_COOKIE_SECURE=False # True for production
CSRF_COOKIE_SECURE=False    # True for production
```

### Orchestrator Service (.env.orchestrator.\*)

```bash
# FastAPI Configuration
APP_NAME=NC_path Orchestrator
APP_VERSION=1.0.0
DEBUG=True # False for production
HOST=0.0.0.0
PORT=4000
WORKERS=2 # Increase for production

# AWS Bedrock Configuration
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_DEFAULT_REGION=us-east-1
BEDROCK_MODEL_ID=anthropic.claude-v2
BEDROCK_REGION=us-east-1

# Knowledge Base Configuration
KNOWLEDGE_BASE_ID=your_knowledge_base_id
KNOWLEDGE_BASE_REGION=us-east-1

# Document Processing
MAX_DOCUMENT_SIZE=10485760 # 10MB
SUPPORTED_FORMATS=pdf,docx,txt,md
PROCESSING_TIMEOUT=300 # 5 minutes

# RAG Configuration
CHUNK_SIZE=1000
CHUNK_OVERLAP=200
MAX_CHUNKS_PER_QUERY=10
SIMILARITY_THRESHOLD=0.7

# Redis Configuration (for caching)
REDIS_URL=redis://redis:6379/1
CACHE_TTL=3600 # 1 hour

# Monitoring
ENABLE_METRICS=True
METRICS_PORT=8080
HEALTH_CHECK_INTERVAL=30

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE=/app/logs/orchestrator.log
```

## Environment-Specific Configurations

### Development Environment

- **Debug Mode**: Enabled
- **Hot Reloading**: Enabled
- **Detailed Logging**: Enabled
- **CORS**: Permissive for local development
- **SSL**: Disabled
- **Database**: Local PostgreSQL or SQLite
- **AWS**: Development/sandbox resources

### Staging Environment

- **Debug Mode**: Disabled
- **SSL**: Enabled
- **Database**: Staging PostgreSQL RDS
- **AWS**: Staging resources
- **Monitoring**: Basic monitoring enabled
- **Performance**: Optimized but not production-level

### Production Environment

- **Debug Mode**: Disabled
- **SSL**: Enforced
- **Security Headers**: All enabled
- **Database**: Production PostgreSQL RDS with backups
- **AWS**: Production resources with proper IAM roles
- **Monitoring**: Full monitoring and alerting
- **Performance**: Fully optimized
- **Secrets**: Managed via AWS Secrets Manager or similar

## Security Best Practices

### 1. Secret Management

```bash
# Use AWS Secrets Manager for production
AWS_SECRET_NAME=nc-path/prod/secrets

# Or use environment-specific secret files
source /etc/secrets/nc-path-prod.env
```

### 2. Database Security

```bash
# Use strong passwords
DB_PASSWORD=$(openssl rand -base64 32)

# Enable SSL for database connections
DATABASE_SSL_MODE=require
```

### 3. API Security

```bash
# Use strong JWT secrets
JWT_SECRET_KEY=$(openssl rand -base64 64)

# Enable rate limiting
RATE_LIMIT_ENABLED=True
RATE_LIMIT_REQUESTS_PER_MINUTE=100
```

## Validation Script

Create a validation script to check environment configuration:

```bash
#!/bin/bash
# validate-env.sh

ENV=${1:-dev}
echo "Validating $ENV environment..."

# Check required files exist
if [ ! -f "config/environments/$ENV/.env.smartgpt.$ENV" ]; then
  echo "❌ Missing SmartGPT environment file"
  exit 1
fi

if [ ! -f "config/environments/$ENV/.env.orchestrator.$ENV" ]; then
  echo "❌ Missing Orchestrator environment file"
  exit 1
fi

# Check required variables are set
source config/environments/$ENV/.env.smartgpt.$ENV

required_vars=(
  "DATABASE_URL"
  "SECRET_KEY"
  "AWS_ACCESS_KEY_ID"
  "AWS_SECRET_ACCESS_KEY"
)

for var in "${required_vars[@]}"; do
  if [ -z "${!var}" ]; then
    echo "❌ Missing required variable: $var"
    exit 1
  fi
done

echo "✅ Environment validation passed!"
```

## Quick Setup Commands

```bash
# Copy templates and customize
make setup-dev  # For development
make setup-prod # For production

# Validate configuration
./scripts/validate-env.sh dev

# Test configuration
make ENV=dev check-env
```

## Troubleshooting

### Common Issues:

1. **Database Connection Failed**
   - Check DATABASE_URL format
   - Verify database container is running
   - Check network connectivity

2. **AWS Services Not Accessible**
   - Verify AWS credentials
   - Check IAM permissions
   - Confirm region settings

3. **Redis Connection Issues**
   - Check Redis container status
   - Verify REDIS_URL format
   - Check network configuration

4. **CORS Errors**
   - Update CORS_ALLOWED_ORIGINS
   - Check frontend URL configuration
   - Verify domain settings
